"""Minimal creator surface. Two inputs, one job, visible stages, local delivery."""
import json
import os
from pathlib import Path
import queue
import threading
import subprocess
import sys
import textwrap
import tkinter as tk
from tkinter import filedialog, ttk

from rtl_ui import Label, Button, Treeview, visual, dialogs as messagebox
from app_paths import app_dir
from media_tools import Cancelled
from production import STAGES, new_project, produce, load_json
from smart_editor import save
from audio_edit import waveform, preview_cut
from stage_review import ReviewBridge
from stage_review_ui import StageReviewPanel

BG='#0b1220';CARD='#132138';TEXT='#eef5ff';MUTED='#91a9c4';CYAN='#08BEED';YELLOW='#FFD24C'


class ProductionPanel(tk.Frame):
    def __init__(self,parent):
        super().__init__(parent,bg=BG,padx=22,pady=16)
        self.busy=False;self.cancel=threading.Event();self.events=queue.Queue()
        self.audio='';self.project=None;self.result=None;self.image=None
        self.stage_labels={};self.buttons=[];self.envelope=None;self.wave_cancel=threading.Event()
        self.project_identity=None;self.worker=None
        self.stage_review=None;self.review_bridge=None
        self.columnconfigure(0,weight=1);self.rowconfigure(2,weight=1)
        header=tk.Frame(self,bg=BG);header.grid(row=0,column=0,sticky='ew')
        Label(header,text='من تسجيلك إلى حلقة جاهزة',bg=BG,fg=TEXT,font=('Segoe UI',25,'bold'),anchor='e').pack(fill='x')
        Label(header,text='صوتك + سكربتك  •  مراجعتك بعد كل مرحلة  •  مؤثرات بدون موسيقى  •  الرفع بنفسك',bg=BG,fg=MUTED,font=('Segoe UI',11),anchor='e').pack(fill='x',pady=(4,16))
        stages=tk.Frame(self,bg=BG);stages.grid(row=1,column=0,sticky='ew',pady=(0,15))
        for i,(key,label) in enumerate(STAGES):
            card=tk.Frame(stages,bg=CARD,padx=8,pady=9,highlightbackground='#243851',highlightthickness=1)
            card.grid(row=0,column=5-i,sticky='nsew',padx=3);stages.columnconfigure(5-i,weight=1,uniform='stage')
            number=Label(card,text=f'{i+1:02}',bg=CARD,fg=MUTED,font=('Segoe UI',15,'bold'));number.pack(anchor='e')
            title=Label(card,text=label,bg=CARD,fg=MUTED,font=('Segoe UI',9),wraplength=135,justify='right');title.pack(anchor='e')
            self.stage_labels[key]=(card,number,title)
        self.content=tk.Frame(self,bg=BG);self.content.grid(row=2,column=0,sticky='nsew')
        self.input_view=tk.Frame(self.content,bg=BG);self.input_view.pack(fill='both',expand=True)
        self.input_view.columnconfigure(0,weight=3);self.input_view.columnconfigure(1,weight=2);self.input_view.rowconfigure(0,weight=1)
        script_card=self.card(self.input_view);script_card.grid(row=0,column=0,sticky='nsew',padx=(0,10))
        Label(script_card,text='02   السكربت',bg=CARD,fg=CYAN,font=('Segoe UI',16,'bold')).pack(anchor='e')
        Label(script_card,text='اختياري: السكربت يحسن تدقيق الترجمة؛ يمكن البدء بالصوت فقط',bg=CARD,fg=MUTED,font=('Segoe UI',10)).pack(anchor='e',pady=(2,10))
        self.script=tk.Text(script_card,wrap='word',font=('Segoe UI',12),bg='#0d1728',fg=TEXT,insertbackground=CYAN,relief='flat',padx=12,pady=10,height=7,undo=True)
        self.script.tag_configure('rtl',justify='right');self.script.pack(fill='both',expand=True)
        self.script.bind('<KeyRelease>',lambda event:self.script.tag_add('rtl','1.0','end'))
        script_actions=tk.Frame(script_card,bg=CARD)
        self.script_actions=script_actions
        script_actions.pack(side='bottom',fill='x',pady=(8,0),before=self.script)
        self.pick_script_button=self.button(script_actions,'اختيار ملف السكربت',self.pick_script)
        self.pick_script_button.pack(side='right')
        self.script_preview=tk.Text(script_card,wrap='none',font=('Segoe UI',12),bg='#0d1728',fg=TEXT,relief='flat',padx=12,pady=10,height=7)
        self.script_preview.tag_configure('rtl',justify='right');self.previewing=False
        self.preview_button=self.button(script_actions,'معاينة عربية مقروءة',self.toggle_script)
        self.preview_button.pack(side='left')
        audio_card=self.card(self.input_view);audio_card.grid(row=0,column=1,sticky='nsew')
        audio_heading=Label(audio_card,text='01   تسجيلك الصوتي',bg=CARD,fg=CYAN,font=('Segoe UI',16,'bold'));audio_heading.pack(anchor='e')
        Label(audio_card,text='سجل براحتك، وإذا أخطأت أعد الجملة.\nسنحتفظ بآخر محاولة ونحافظ على ترتيب الكلام.',bg=CARD,fg=MUTED,font=('Segoe UI',10),justify='right',wraplength=340).pack(anchor='e',pady=(4,14))
        self.audio_name=tk.StringVar(value='لم تُضف تسجيلًا بعد')
        self.audio_label=Label(audio_card,textvariable=self.audio_name,bg='#0d1728',fg=TEXT,font=('Segoe UI',11,'bold'),wraplength=340,padx=12,pady=15)
        self.audio_label.pack(fill='x',pady=8)
        self.wave=tk.Canvas(audio_card,height=65,bg=CARD,highlightthickness=0);self.wave.pack(fill='both',expand=True,pady=5)
        self.wave.bind('<Configure>',lambda event:self.draw_wave())
        upload=self.button(audio_card,'ارفع التسجيل الصوتي',self.pick_audio,primary=True)
        self.audio_pick_button=upload
        upload.pack(side='bottom',fill='x',pady=8,before=audio_heading)
        Label(audio_card,text='التسجيل الأصلي يبقى محفوظًا. النشر يدوي.',bg=CARD,fg=MUTED,font=('Segoe UI',10),justify='right',wraplength=340).pack(side='bottom',anchor='e',pady=5,before=audio_heading)
        self.result_view=tk.Frame(self.content,bg=BG)
        self.result_canvas=tk.Canvas(self.result_view,bg=BG,highlightthickness=0)
        result_scroll=ttk.Scrollbar(self.result_view,orient='vertical',command=self.result_canvas.yview)
        self.result_canvas.configure(yscrollcommand=result_scroll.set)
        result_scroll.pack(side='right',fill='y');self.result_canvas.pack(side='left',fill='both',expand=True)
        self.result_body=tk.Frame(self.result_canvas,bg=BG)
        result_window=self.result_canvas.create_window((0,0),window=self.result_body,anchor='nw')
        self.result_body.bind('<Configure>',lambda e:self.result_canvas.configure(scrollregion=self.result_canvas.bbox('all')))
        self.result_canvas.bind('<Configure>',lambda e:self.result_canvas.itemconfigure(result_window,width=e.width))
        self.footer=tk.Frame(self,bg=BG);self.footer.grid(row=3,column=0,sticky='ew',pady=(16,0))
        self.note=tk.StringVar(value='جهّز التسجيل والسكربت، ثم اضغط إنتاج الحلقة.')
        Label(self.footer,textvariable=self.note,bg=BG,fg=MUTED,font=('Segoe UI',10),anchor='e',wraplength=1020).pack(fill='x',pady=(0,8))
        self.progress=ttk.Progressbar(self.footer,maximum=100);self.progress.pack(fill='x')
        bar=tk.Frame(self.footer,bg=BG);bar.pack(fill='x',pady=(10,0))
        self.start_button=self.button(bar,'بدء إنتاج الفيديو',self.start,primary=True);self.start_button.pack(side='right')
        self.cancel_button=self.button(bar,'إيقاف',self.stop);self.cancel_button.pack(side='right',padx=8)
        self.cancel_button.configure(state='disabled')
        self.review_button=self.button(bar,'سجل قص المشروع',self.review_cuts)
        self.review_button.pack(side='right',padx=8);self.review_button.configure(state='disabled')
        self.button(bar,'الأعمال السابقة',self.history).pack(side='left')
        self.drain_id=self.after(80,self.drain);self.bind('<Destroy>',self.shutdown,add='+')

    def card(self,parent):
        return tk.Frame(parent,bg=CARD,padx=18,pady=16,highlightbackground='#243851',highlightthickness=1)

    def button(self,parent,text,command,primary=False):
        button=Button(parent,text=text,command=command,bg=CYAN if primary else '#223b58',fg='#071322' if primary else TEXT,
                         activebackground='#42d6fa' if primary else '#355576',activeforeground='#071322' if primary else TEXT,
                         font=('Segoe UI',11,'bold'),relief='flat',borderwidth=0,padx=18,pady=10,cursor='hand2')
        return button

    def draw_wave(self):
        self.wave.delete('all');width=max(200,self.wave.winfo_width())
        peaks=(self.envelope or {}).get('peaks',[])
        if peaks:
            for i,peak in enumerate(peaks):
                height=max(1,peak*64);x=(i+.5)*width/len(peaks)
                self.wave.create_line(x,35-height/2,x,35+height/2,fill=CYAN,width=2)
            label=f"موجة التسجيل الفعلية • {self.envelope['duration']:.1f} ثانية"
        else:
            self.wave.create_line(0,35,width,35,fill='#304761')
            label='جاري قراءة التسجيل' if self.audio else 'بانتظار التسجيل'
        self.wave.create_text(width/2,77,text=visual(label),fill=MUTED,font=('Segoe UI',9))

    def toggle_script(self):
        if self.previewing:
            self.script_preview.pack_forget();self.script.pack(fill='both',expand=True,after=self.script_actions)
            self.preview_button.configure(text='معاينة عربية مقروءة');self.previewing=False
        else:
            self.script_preview.configure(state='normal');self.script_preview.delete('1.0','end')
            raw=self.script.get('1.0','end').strip()
            lines=[visual(part) for line in raw.split('\n') for part in (textwrap.wrap(line,width=65,break_long_words=False) or [''])]
            self.script_preview.insert('1.0','\n'.join(lines),'rtl');self.script_preview.configure(state='disabled')
            self.script.pack_forget();self.script_preview.pack(fill='both',expand=True,after=self.script_actions)
            self.preview_button.configure(text='تحرير النص الأصلي');self.previewing=True

    def measure_audio(self):
        self.wave_cancel.set();self.wave_cancel=threading.Event();cancel=self.wave_cancel
        audio=self.audio;self.envelope=None;self.draw_wave()
        def worker():
            try:self.events.put({'type':'wave','audio':audio,'result':waveform(audio,cancel=cancel)})
            except Cancelled:pass
            except Exception as exc:self.events.put({'type':'wave_error','audio':audio,'message':str(exc)})
        threading.Thread(target=worker,daemon=True).start()

    def pick_audio(self):
        if self.busy:return
        file=filedialog.askopenfilename(parent=self.winfo_toplevel(),title='تسجيلك الصوتي',filetypes=[('Audio','*.wav *.mp3 *.m4a *.aac *.flac *.ogg *.mp4')])
        if file:self.audio=file;self.audio_name.set(Path(file).name);self.project=None;self.measure_audio()

    def pick_script(self):
        if self.busy:return
        file=filedialog.askopenfilename(parent=self.winfo_toplevel(),title='السكربت',filetypes=[('Text','*.txt')])
        if file:
            try:
                text=Path(file).read_text(encoding='utf-8-sig')
                if len(text)>80_000:raise ValueError('السكربت أطول من الحد.')
                self.script.delete('1.0','end');self.script.insert('1.0',text,'rtl');self.project=None
                if self.previewing:self.toggle_script()
                self.toggle_script()
            except (OSError,UnicodeError,ValueError) as exc:messagebox.showerror('السكربت',str(exc),parent=self)

    def start(self):
        if self.busy:return
        script=self.script.get('1.0','end').strip()
        if not self.audio:messagebox.showinfo('التسجيل الصوتي','أضف التسجيل الصوتي أولًا؛ السكربت اختياري.',parent=self);return
        from captions import local_model_path
        model=local_model_path()
        if not (model/'model.bin').is_file():
            self.setup_model();return
        identity=(str(Path(self.audio).resolve()),script)
        if self.project_identity is not None and identity!=self.project_identity:self.project=None
        self.project_identity=identity
        self.project=self.project or new_project();self.busy=True;self.cancel.clear();self.result=None
        self.review_bridge=ReviewBridge(self.events,self.cancel)
        self.result_view.pack_forget();self.input_view.pack(fill='both',expand=True)
        self.script.configure(state='disabled');self.start_button.configure(state='disabled');self.cancel_button.configure(state='normal');self.progress['value']=0
        self.note.set('بدأ الإنتاج؛ يمكنك إيقافه وإعادة المحاولة دون تغيير التسجيل الأصلي.')
        audio,project=self.audio,self.project
        for widgets in self.stage_labels.values():
            for w in widgets[1:]:w.configure(fg=MUTED)
        def worker():
            try:produce(audio,script,project,model=model,cancel=self.cancel,on_event=self.events.put,on_review=self.review_bridge)
            except Exception as exc:self.events.put({'type':'job_end','error':str(exc)})
        self.worker=threading.Thread(target=worker,daemon=True);self.worker.start()

    def background(self,fn,done):
        if self.busy:return
        self.busy=True;self.cancel.clear();self.start_button.configure(state='disabled');self.cancel_button.configure(state='normal')
        def worker():
            try:self.events.put({'type':'task_done','result':fn(),'done':done})
            except Exception as exc:self.events.put({'type':'job_end','error':str(exc)})
        self.worker=threading.Thread(target=worker,daemon=True);self.worker.start()

    def idle(self):
        self.clear_stage_review()
        if self.result is None:self.input_view.pack(fill='both',expand=True)
        self.busy=False;self.script.configure(state='normal');self.start_button.configure(state='normal');self.cancel_button.configure(state='disabled')

    def clear_stage_review(self):
        audio_preview=getattr(self,'audio_preview',None)
        if audio_preview is not None and audio_preview.winfo_exists():audio_preview.destroy()
        if self.stage_review is not None:self.stage_review.destroy();self.stage_review=None

    def stop(self):
        if self.stage_review is not None:self.stage_review.stop()
        else:self.cancel.set()

    def show_stage_review(self,event):
        self.clear_stage_review();self.input_view.pack_forget();self.result_view.pack_forget()
        token=event['token']
        self.stage_review=StageReviewPanel(self.content,event['request'],
                        lambda response:self.review_bridge.submit(token,response),self.open,self.cancel)
        self.stage_review.pack(fill='both',expand=True)
        self.note.set('بانتظار مراجعتك؛ لا تبدأ المرحلة التالية حتى تعتمد الحالية.')
        key=event['request']['key']
        for widget in self.stage_labels[key][1:]:widget.configure(fg=YELLOW)

    def setup_model(self):
        if self.busy:return
        from importlib.util import find_spec
        if find_spec('faster_whisper') is None:
            messagebox.showinfo('تجهيز الصوت','شغّل SETUP_ARABIC_MODEL.bat مرة لتثبيت التفريغ المحلي، ثم افتح البرنامج.',parent=self);return
        from model_setup_ui import choose_model
        name=choose_model(self)
        if name is None:return
        from faster_whisper.utils import download_model
        self.note.set('جاري تنزيل نموذج الصوت؛ التسجيل لا يُرسل لأي خدمة.')
        # download_model is a library transfer; cancellation is checked before accepting its result.
        def setup():
            path=download_model(name,output_dir=str(app_dir()/'models'/name))
            if self.cancel.is_set():raise Cancelled('أوقفت التجهيز؛ الملفات المحملة محفوظة للمحاولة التالية.')
            return path
        self.background(setup,lambda result:self.note.set('نموذج الصوت جاهز. اضغط إنتاج الحلقة.'))

    def drain(self):
        # Keep exactly one poll scheduled, including explicit refreshes in tests
        # and recovery screens. Otherwise old callbacks outlive a closed window.
        if self.drain_id:
            self.after_cancel(self.drain_id);self.drain_id=None
        while not self.events.empty():
            event=self.events.get();kind=event['type']
            if kind=='stage':
                self.clear_stage_review();self.input_view.pack(fill='both',expand=True)
                key=event['key'];index=next(i for i,s in enumerate(STAGES) if s[0]==key)
                for i,(k,label) in enumerate(STAGES):
                    card,number,title=self.stage_labels[k]
                    color=CYAN if i==index else '#6fe3aa' if i<index else MUTED
                    number.configure(fg=color,text='✓' if i<index else f'{i+1:02}');title.configure(fg=color)
                self.note.set(event['detail']);self.progress['value']=event['progress']
            elif kind=='log':self.note.set(event['message'])
            elif kind=='render_progress':
                self.note.set(event['sequence']+' — '+str(event['progress'])+'%');self.progress['value']=event['overall']
            elif kind=='review':self.show_stage_review(event)
            elif kind=='complete':
                self.idle()
                self.progress['value']=100;self.result=event['result'];self.show_result()
                for card,number,title in self.stage_labels.values():number.configure(text='✓',fg='#6fe3aa');title.configure(fg='#6fe3aa')
            elif kind=='needs_media':
                self.idle();self.result=event['result'];self.note.set(event['message'])
                if self.result.get('pro_project'):
                    self.button(self.input_view,'فتح المسودة وإكمال اللقطات في Pro Editor',self.open_pro_editor).pack(anchor='e',pady=8)
            elif kind in ('failed','job_end'):
                self.idle()
                self.note.set(event.get('message') or event.get('error','تعذر الإنتاج'))
                if self.project and (self.project/'audio_edits.json').is_file():self.review_button.configure(state='normal')
            elif kind=='task_done':
                self.idle();event['done'](event['result'])
            elif kind=='wave' and event['audio']==self.audio:
                self.envelope=event['result'];self.draw_wave()
            elif kind=='wave_error' and event['audio']==self.audio:
                self.note.set('تعذرت قراءة التسجيل: '+event['message'])
        self.drain_id=self.after(80,self.drain)

    def show_result(self):
        self.input_view.pack_forget()
        for child in self.result_body.winfo_children():child.destroy()
        self.result_view.pack(fill='both',expand=True)
        body=self.result_body
        body.columnconfigure(0,weight=1);body.columnconfigure(1,weight=1)
        self.result_canvas.yview_moveto(0)
        r=self.result
        Label(body,text='ملفات حلقتك في مكان واحد',bg=BG,fg=TEXT,font=('Segoe UI',21,'bold')).grid(row=0,column=0,columnspan=2,sticky='e',pady=(0,12))
        thumb=self.card(body);thumb.grid(row=1,column=0,sticky='nsew',padx=(0,12))
        try:
            from PIL import Image,ImageTk
            path=r.get('thumbnail') or r.get('preview_image')
            image=Image.open(path);image.thumbnail((480,270));self.image=ImageTk.PhotoImage(image)
            Label(thumb,image=self.image,bg=CARD).pack(fill='both',expand=True)
        except (OSError,KeyError,TypeError,AttributeError):pass
        Label(thumb,text='معاينة الحلقة — الثامنيل تصممه بنفسك',bg=CARD,fg=MUTED).pack(fill='x',pady=8)
        files=self.card(body);files.grid(row=1,column=1,sticky='nsew')
        seconds=r.get('removed_seconds',0)
        Label(files,text=f'أزلنا {seconds:.1f} ثانية  •  {r.get("edits_removed",0)} قصّات\nالمؤثرات: {r.get("effect_count",0)}  •  الميمز: {r.get("reaction_count",0)}  •  الشورتات: {sum(f["kind"]=="short" for f in r["files"])}',bg=CARD,fg=CYAN,font=('Segoe UI',12,'bold'),justify='right').pack(anchor='e',pady=(0,12))
        self.button(files,'شاهد المقطع الطويل',lambda:self.open(r['files'][0]['path']),True).pack(fill='x',pady=4)
        self.button(files,'افتح مجلد الملفات والشورتات',lambda:self.open(r['delivery'])).pack(fill='x',pady=4)
        self.button(files,'افتح المشروع في Pro Editor',self.open_pro_editor).pack(fill='x',pady=4)
        short_row=tk.Frame(files,bg=CARD);short_row.pack(fill='x',pady=4)
        for i,file in enumerate((f for f in r['files'] if f['kind']=='short'),1):
            self.button(short_row,f'شورت {i}',lambda path=file['path']:self.open(path)).pack(side='right',fill='x',expand=True,padx=2)
        self.button(files,'راجع القص أو استرجع محاولة',self.review_cuts).pack(fill='x',pady=4)
        self.button(files,'إعادة مراجعة المراحل',self.start).pack(fill='x',pady=4)
        self.button(files,'حلقة جديدة',self.reset).pack(fill='x',pady=4)
        for child in files.winfo_children():
            if isinstance(child,Button):child.configure(pady=6,font=('Segoe UI',10,'bold'))
        details=tk.Frame(body,bg=BG);details.grid(row=2,column=0,columnspan=2,sticky='ew',pady=(10,0))
        warnings=r.get('warnings',[])
        text='الملفات جاهزة للرفع بنفسك بعد مراجعة المراحل. الثامنيل خارج هذا المسار.'
        if r.get('cards_used'):text+='\nبعض المواضيع تستخدم بطاقات؛ لا توجد لها لقطات مناسبة واضحة الرخصة.'
        Label(details,text=text,bg=BG,fg=YELLOW,font=('Segoe UI',10),justify='right',anchor='e',wraplength=990).pack(fill='x')
        if warnings:self.button(details,f'تفاصيل الجودة والمصادر ({len(warnings)})',self.show_warnings).pack(anchor='e',pady=4)
        self.note.set('الملفات محفوظة للمشاهدة والتنزيل؛ لا يحدث أي نشر تلقائي.')
        self.start_button.configure(text='إعادة الإنتاج')
        self.review_button.configure(state='normal')

    def open_pro_editor(self):
        if not self.result or self.busy:return
        from pro_editor_ui import open_editor
        path=self.result.get('pro_project') or str(Path(self.result['delivery']).parent/'timeline.json')
        try:open_editor(self,path,exports=self.result.get('files',[]))
        except (ValueError,OSError,KeyError) as exc:messagebox.showerror('Pro Editor',str(exc),parent=self)

    def show_warnings(self):
        messagebox.showinfo('تقرير الإنتاج','\n\n'.join(self.result.get('warnings',[])) or 'لا تحذيرات.',parent=self)

    def open(self,path):
        path=Path(path)
        if not path.exists():messagebox.showerror('ملف مفقود','الملف غير موجود. أعد الإنتاج أو اربط التسجيل الأصلي.',parent=self);return
        audio_stage=self.stage_review is not None and self.stage_review.request['key']=='audio'
        if path.suffix.lower()in ('.wav','.mp3','.m4a','.aac','.flac','.ogg')or(audio_stage and path.suffix.lower()in('.mp4','.mov','.mkv')):
            from audio_preview import open_preview
            return open_preview(self,path)
        audio_preview=getattr(self,'audio_preview',None)
        if audio_preview is not None and audio_preview.winfo_exists():audio_preview.stop()
        try:
            if os.name=='nt':os.startfile(str(path.resolve()))
            else:subprocess.Popen(['open' if sys.platform=='darwin' else 'xdg-open',str(path.resolve())])
        except OSError as exc:messagebox.showerror('فتح الملف',str(exc),parent=self)

    def review_cuts(self):
        if not self.project or self.busy:return
        data=load_json(self.project/'audio_edits.json',{})
        popup=tk.Toplevel(self);popup.title('اختيار آخر محاولة واسترجاع القص');popup.geometry('900x610');popup.configure(bg=BG)
        Label(popup,text='اختر القصّة، ثم استرجعها أو احذفها. يُعاد الإنتاج في مجلد جديد؛ الأصل محفوظ.',bg=BG,fg=TEXT,wraplength=850,pady=15).pack(fill='x')
        tree=Treeview(popup,columns=('time','kind','action','text'),show='headings',selectmode='browse')
        for key,label,width in [('time','التوقيت الأصلي',110),('kind','السبب',110),('action','القرار',80),('text','الكلام',560)]:tree.heading(key,text=label);tree.column(key,width=width,anchor='e')
        tree.pack(fill='both',expand=True,padx=14)
        cut_wave=tk.Canvas(popup,height=100,bg=CARD,highlightthickness=0);cut_wave.pack(fill='x',padx=14,pady=5)
        def draw_cuts(event=None):
            cut_wave.delete('all');width=max(200,cut_wave.winfo_width());limit=data.get('source_duration',1)
            peaks=(self.envelope or {}).get('peaks',[])
            for i,peak in enumerate(peaks):
                x=(i+.5)*width/len(peaks);cut_wave.create_line(x,45-peak*35,x,45+peak*35,fill=CYAN)
            for edit in data.get('edits',[]):
                if overrides.get(edit['id'],edit['action'])=='remove':cut_wave.create_rectangle(edit['start']/limit*width,10,edit['end']/limit*width,80,outline=YELLOW,width=2)
            if tree.selection():
                edit=next(e for e in data['edits'] if e['id']==tree.selection()[0])
                cut_wave.create_rectangle(edit['start']/limit*width,5,edit['end']/limit*width,85,outline='#f46c81',width=3)
            cut_wave.create_text(width/2,95,text=visual('التسجيل الأصلي • الأصفر: القص المقترح • الوردي: المحدد'),fill=MUTED)
        cut_wave.bind('<Configure>',draw_cuts);tree.bind('<<TreeviewSelect>>',draw_cuts)
        for edit in data.get('edits',[]):tree.insert('','end',iid=edit['id'],values=(f'{edit["start"]:.2f} – {edit["end"]:.2f}',{'silence':'سكوت','repeat':'إعادة — آخر محاولة','restart':'تصحيح','uncertain':'اختلاف غير محسوم'}.get(edit['kind'],edit['kind']),'حذف' if edit['action']=='remove' else 'احتفاظ',edit['text']))
        overrides=load_json(self.project/'cut_overrides.json',{})
        def change(action):
            if not tree.selection() or self.busy:return
            key=tree.selection()[0];overrides[key]=action
            values=list(tree.item(key,'values'));values[2]='حذف' if action=='remove' else 'احتفاظ';tree.item(key,values=values)
            draw_cuts()
        row=tk.Frame(popup,bg=BG);row.pack(fill='x',padx=14,pady=12)
        self.button(row,'استرجع المحدد',lambda:change('keep')).pack(side='right',padx=4)
        self.button(row,'احذف المحدد',lambda:change('remove')).pack(side='right',padx=4)
        def listen():
            if not tree.selection() or self.busy:return
            edit=next(e for e in data['edits'] if e['id']==tree.selection()[0])
            folder=self.project/'previews';folder.mkdir(exist_ok=True)
            self.background(lambda:preview_cut(self.audio,edit,folder/'selected_cut.wav',self.cancel),self.open)
        self.button(row,'اسمع المحدد مع سياقه',listen).pack(side='right',padx=4)
        def rebuild():
            if self.busy:return
            save(overrides,self.project/'cut_overrides.json');popup.destroy();self.start()
        self.button(row,'احفظ وأعد الإنتاج',rebuild,True).pack(side='left')

    def edit_thumbnail(self):
        if not self.result or self.busy:return
        from tkinter import simpledialog
        title=simpledialog.askstring(visual('عنوان الثامنيل'),visual('اكتب عنوانًا قصيرًا (ست كلمات بحد أقصى):'),parent=self)
        if not title:return
        # Same approved assets; editing the thumbnail never publishes or changes narration.
        result=dict(self.result)
        def create():
            from thumbnail import make_thumbnail
            work=Path(result['delivery']).parent
            assets=load_json(work/'manifest.json')['assets']
            asset=next(a for a in assets if a['role']=='clip')
            return make_thumbnail(asset,title,result['thumbnail'])
        self.background(create,lambda path:self.show_result())

    def reset(self):
        if self.busy:return
        self.project=None;self.project_identity=None;self.result=None;self.audio='';self.envelope=None;self.wave_cancel.set();self.audio_name.set('لم تُضف تسجيلًا بعد')
        self.script.delete('1.0','end');self.result_view.pack_forget();self.input_view.pack(fill='both',expand=True)
        if self.previewing:self.toggle_script()
        self.progress['value']=0;self.draw_wave();self.note.set('تسجيل جديد وسكربت جديد، ثم إنتاج الحلقة.')
        self.start_button.configure(text='بدء إنتاج الفيديو')
        self.review_button.configure(state='disabled')

    def history(self):
        if self.busy:return
        parent=app_dir()/'output/productions'
        files=sorted(parent.glob('*/production.json'),reverse=True)[:30]
        popup=tk.Toplevel(self);popup.title('الأعمال السابقة');popup.geometry('800x470')
        tree=Treeview(popup,columns=('date','state'),show='headings');tree.heading('date',text='المشروع');tree.heading('state',text='الحالة');tree.pack(fill='both',expand=True,padx=12,pady=12)
        for i,path in enumerate(files):
            data=load_json(path,{});tree.insert('','end',iid=str(i),values=(path.parent.name,{'ready_for_review':'ملفات جاهزة للرفع اليدوي','draft_ready_for_review':'مسودة للمراجعة — غير جاهزة للنشر','needs_media':'يحتاج لقطات — المسودة محفوظة','waiting_for_review':'بانتظار مراجعتك — أعد فتحه','failed':'تعذر الإنتاج','cancelled':'أوقفت المعالجة','running':'قيد المعالجة أو متوقف'}.get(data.get('status'),'محفوظ')))
        def select():
            if not tree.selection() or self.busy:return
            path=files[int(tree.selection()[0])];data=load_json(path);self.project=path.parent;self.audio=data['input']['audio'];self.audio_name.set(Path(self.audio).name)
            self.script.delete('1.0','end');self.script.insert('1.0',(path.parent/'script.txt').read_text(encoding='utf-8'),'rtl');popup.destroy()
            self.project_identity=(str(Path(self.audio).resolve()),self.script.get('1.0','end').strip());self.measure_audio()
            self.review_button.configure(state='normal' if (self.project/'audio_edits.json').is_file() else 'disabled')
            if data.get('status')=='ready_for_review':self.result=data;self.show_result()
            else:self.input_view.pack(fill='both',expand=True);self.result_view.pack_forget()
        self.button(popup,'افتح المشروع',select,True).pack(pady=10)

    def shutdown(self,event):
        if event.widget is self:
            self.cancel.set()
            self.wave_cancel.set()
            if self.drain_id:self.after_cancel(self.drain_id);self.drain_id=None
