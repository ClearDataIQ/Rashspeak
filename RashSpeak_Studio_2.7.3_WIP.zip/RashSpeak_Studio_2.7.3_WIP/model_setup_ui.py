"""Explicit local-ASR download choices; opening/cancelling never downloads."""
import tkinter as tk
from rtl_ui import Label,Button

BG='#0b1220';CARD='#132138';TEXT='#eef5ff';MUTED='#91a9c4';CYAN='#08beed'


class ModelChoice(tk.Toplevel):
    def __init__(self,parent):
        super().__init__(parent)
        self.result=None
        self.title('تجهيز التفريغ المحلي');self.configure(bg=BG)
        self.geometry('680x520');self.minsize(620,420)
        self.transient(parent.winfo_toplevel())
        Label(self,text='اختر نموذج التفريغ الصوتي',bg=BG,fg=CYAN,font=('Segoe UI',18,'bold')).pack(anchor='e',padx=20,pady=(18,10))
        self.explanation='لا يوجد نموذج تفريغ جاهز داخل هذه النسخة.\nالتنزيل مرة واحدة؛ تسجيلك يبقى على جهازك.'
        Label(self,text=self.explanation,bg=BG,fg=TEXT,font=('Segoe UI',12),wraplength=620,justify='right').pack(fill='x',padx=20,pady=8)
        self.cancel_button=Button(self,text='رجوع بدون تنزيل',command=lambda:self.choose(None),bg='#223b58',fg=TEXT,relief='flat',padx=18,pady=8)
        self.cancel_button.pack(side='bottom',anchor='e',padx=20,pady=10)
        card=tk.Frame(self,bg=CARD,padx=16,pady=12);card.pack(fill='x',padx=20,pady=7)
        Label(card,text='small — الموصى به للبدء',bg=CARD,fg=TEXT,font=('Segoe UI',13,'bold')).pack(anchor='e')
        Label(card,text='حجم تقريبي 500 MB. أخف وأسرع في التفريغ.',bg=CARD,fg=MUTED,font=('Segoe UI',11)).pack(anchor='e',pady=4)
        self.small_button=Button(card,text='تنزيل small',command=lambda:self.choose('small'),bg=CYAN,fg=BG,relief='flat',padx=18,pady=8)
        self.small_button.pack(anchor='e')
        card=tk.Frame(self,bg=CARD,padx=16,pady=12);card.pack(fill='x',padx=20,pady=7)
        Label(card,text='medium — أكبر وقد يحسّن الدقة',bg=CARD,fg=TEXT,font=('Segoe UI',13,'bold')).pack(anchor='e')
        Label(card,text='حجم تقريبي 1.5 GB. يحتاج وقتًا وموارد أكثر.',bg=CARD,fg=MUTED,font=('Segoe UI',11)).pack(anchor='e',pady=4)
        self.medium_button=Button(card,text='تنزيل medium',command=lambda:self.choose('medium'),bg='#223b58',fg=TEXT,relief='flat',padx=18,pady=8)
        self.medium_button.pack(anchor='e')
        self.protocol('WM_DELETE_WINDOW',lambda:self.choose(None))
        self.bind('<Escape>',lambda event:self.choose(None))

    def choose(self,name):
        if name not in (None,'small','medium'):raise ValueError('نموذج صوت غير مدعوم.')
        self.result=name;self.destroy()


def choose_model(parent):
    previous=parent.grab_current()
    window=ModelChoice(parent)
    try:
        window.grab_set();window.small_button.focus_set()
        parent.wait_window(window)
        return window.result
    finally:
        if previous is not None and previous.winfo_exists():previous.grab_set()
