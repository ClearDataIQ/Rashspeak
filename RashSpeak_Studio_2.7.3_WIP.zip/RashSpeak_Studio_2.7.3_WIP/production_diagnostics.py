"""Explain missing footage separately from API outages, rights and bad selections."""
from source_usage import accepted
from collections import Counter,defaultdict
import csv
import re
from pathlib import Path

from production_quality import assess
from smart_editor import save

ACTION={
 'ai_response':'ردّ خدمة الفهم غير متوافق مع الجمل المطلوبة. أعد فهم المحتوى واللقطات فقط؛ احتفظ بالتفريغ والصوت، ولا تغيّر المفتاح لمجرد هذا الرفض.',
 'missing_source':'توسيع مصادر اللعبة أو إضافة لقطاتك المحلية؛ لا تستخدم لعبة أخرى لسد النقص.',
 'no_visual_match':'المصادر موجودة لكن المشاهد لا تطابق الفكرة؛ راجع مصدرًا آخر أو جزءًا لاحقًا.',
 'invalid_selection':'مراجعة حدود اللقطات أو تقسيم الجملة مرئيًا إلى لقطات قصيرة؛ التسجيل لا يتغير.',
 'quota':'متابعة الاختيارات غير المكتملة بعد توفر حصة Gemini؛ النتائج الصحيحة محفوظة.',
 'ai_unavailable':'التحقق من اتصال Gemini وإعداده؛ لا تُعد التفريغ أو حذف الأصول المنجزة.',
 'rights_review':'افتح مصادر اللقطات وحدد المصدر ووافق على استخدامه على مسؤوليتك؛ ثم أعد تركيب اللقطات.',
 'source_unavailable':'فحص الوصول الفعلي للمضيف؛ رفض الوكيل قبل المصادقة لا يثبت أن المفتاح خطأ.',
 'download_failed':'مراجعة خطأ تنزيل المقتطف وإعادة الناقص؛ الأجزاء السليمة باقية في الأرشيف.',
 'search_budget':'متابعة البحث للجمل المتبقية أو إضافة مصدر محلي مطابق؛ لا يعني نفاد الميزانية عدم وجود الفيديو.',
 'ai_selection':'تفعيل Gemini لاختيار النتائج الموجودة بعد فحص المشاهد؛ لا تعتمد توقيتًا من العنوان وحده.',
 'context':'تحديد سياق الجملة العام قبل اختيار اللقطات.',
 'pending':'متابعة معالجة هذا الطلب المحفوظ.',
 'gemini_missing':'افتح إعدادات الخدمات، أضف مفتاح Gemini واحفظه، ثم أعد محاولة هذه المرحلة.',
 'gemini_disabled':'فعّل Gemini في الإنتاج واحفظ الإعداد، ثم أعد المحاولة من هذه المرحلة.',
 'youtube_missing':'أضف مفتاح YouTube Data API واحفظه للبحث في القنوات الرسمية؛ المصادر البديلة مستقلة عنه.',
 'model_unavailable':'اختر نموذج تحليل متاحًا في إعدادات Gemini واختبره، ثم أعد المحاولة من هذه المرحلة.',
 'ai_request':'شغّل «اختبار تحليل فعلي» في إعدادات Gemini؛ راجع نوع رفض الطلب والحقول المذكورة، ثم أعد تحليل السياق من هذه المرحلة.',
 'ai_account':'راجع أهلية الحساب والمفتاح والمنطقة للخدمة؛ تغيير السكربت أو حذف التفريغ لا يحل رفض الحساب.',
 'source_identity':'راجع رقم اللعبة واسمها في مصدر Steam؛ لا تعتمد لعبة أخرى. عدم توفر بيانات المتجر مختلف عن رفض الشبكة.',
 'source_listing':'قد لا تتوفر بيانات هذه اللعبة في المتجر/المنطقة؛ جرّب مصدرًا رسميًا آخر أو أضف لقطات محلية.',
}
LABELS={'ai_response':'ردّ تحليل المحتوى غير صالح','missing_source':'لا نتائج مصادر','no_visual_match':'لا مشهد متحقق مطابق','invalid_selection':'اختيار أو توقيت غير صالح',
 'quota':'حصة Gemini غير متاحة','ai_unavailable':'تعذر Gemini','rights_review':'المصدر ينتظر اختيار طريقة الاستخدام',
 'source_unavailable':'تعذر البحث أو الاتصال بالمصدر','download_failed':'تعذر تنزيل المقتطف','search_budget':'حد البحث الحالي',
 'ai_selection':'ينتظر اختيار Gemini','context':'لم تتحدد اللعبة في هذا النطاق','pending':'طلب لم يكتمل',
 'gemini_missing':'مفتاح Gemini غير متاح','gemini_disabled':'Gemini معطل','youtube_missing':'مفتاح YouTube غير متاح',
 'model_unavailable':'نموذج Gemini غير متاح','ai_request':'رفض Gemini صيغة الطلب',
 'ai_account':'رفض حساب Gemini أو المفتاح','source_identity':'هوية مصدر Steam غير مطابقة','source_listing':'بيانات لعبة Steam غير متاحة'}


def safe_message(value):
    text=str(value)
    text=re.sub(r'AQ\.[A-Za-z0-9_.-]{20,}|AIza[0-9A-Za-z_-]{25,}|sk-or-[A-Za-z0-9_-]{20,}','[مخفي]',text)
    text=re.sub(r'(?i)((?:key|api_key|token|x-goog-api-key|access_token)\s*[=:]\s*)[^\s&,;]+',r'\1[مخفي]',text)
    return text[:1000]


def error_cause(reason):
    if '[response_validation]'in reason or 'نطاق شورت غير معروف'in reason:return 'ai_response'
    reason=reason.replace('OpenRouter','Gemini')  # Shared recovery categories, explicit provider remains in displayed reason.
    if any(t in reason for t in ('حد الاستخدام','حصة','429','quota')):return 'quota'
    if 'Gemini'in reason and any(t in reason for t in ('404','النموذج غير موجود','model not found')):return 'model_unavailable'
    if 'Gemini'in reason and any(t in reason for t in ('[credential]','[account]')):return 'ai_account'
    if 'Gemini'in reason and any(t in reason for t in ('HTTP 400','HTTP 422')):return 'ai_request'
    if 'Gemini'in reason:return 'ai_unavailable'
    return None


def cause(row):
    status=row.get('status','planned');reason=row.get('reason','')
    if status in ('cached','downloaded'):return None
    if status=='needs_source_review':
        candidates=row.get('candidates',[])
        if candidates and all(accepted(c)for c in candidates):return 'no_visual_match'
        return 'rights_review'
    if status=='needs_context':return 'context'
    if status=='source_unavailable':return source_cause(reason)
    if status in ('download_failed','partial_media'):return 'download_failed'
    if status=='search_budget_reached':return 'search_budget'
    if status in ('needs_ai_selection','pending_ai_selection'):return 'ai_selection'
    if status=='no_verified_scene':
        errors=[error_cause(c.get('scene_error',''))for c in row.get('candidates',[])if c.get('scene_error')]
        return next((c for c in errors if c),None)or'no_visual_match'
    if status=='selection_invalid' or any(t in reason for t in ('المقتطف أقصر','توقيت المقتطف','نطاق المشهد')):
        return 'invalid_selection'
    if status=='ai_unavailable':
        return error_cause(reason)or'ai_unavailable'
    if status=='no_match':return 'no_visual_match' if row.get('candidates') else 'missing_source'
    return 'pending'


def summarize(plan,services=None,ai_status=None):
    services=services or{};ai_status=ai_status or{};issues={}
    def add(code,reason='',count=1):
        issue=issues.setdefault(code,{'code':code,'label':LABELS[code],'count':0,'reasons':[],'next_action':ACTION[code]})
        issue['count']+=count;reason=safe_message(reason)
        if reason and reason not in issue['reasons']:issue['reasons'].append(reason)
    gemini=services.get('gemini',{})
    if gemini.get('enabled')is False:add('gemini_disabled')
    elif gemini.get('key_available')is False:add('gemini_missing')
    if services.get('youtube',{}).get('key_available')is False:add('youtube_missing')
    if ai_status.get('reason')and ai_status.get('status')!='analysed':
        add(error_cause(ai_status['reason'])or'ai_unavailable',ai_status['reason'])
    for row in (plan or{}).get('sentences',[]):
        if row.get('role','clip')!='clip':continue
        code=cause(row)
        if code:add(code,row.get('reason',''))
        for candidate in row.get('candidates',[]):
            if candidate.get('scene_error'):
                message=candidate['scene_error'];add(error_cause(message)or'source_unavailable',message)
    for attempt in (plan or{}).get('source_attempts',[]):
        if attempt.get('status')=='unavailable':add(source_cause(attempt.get('reason','')),attempt.get('provider','')+': '+attempt.get('reason',''))
    return list(issues.values())


def source_cause(reason):
    if '[identity_mismatch]'in reason:return 'source_identity'
    if '[listing_unavailable]'in reason or '[listing_invalid]'in reason:return 'source_listing'
    return 'source_unavailable'


def recovery_text(report):
    lines=['تشخيص تركيب اللقطات',f"تغطية الفيديو المطابق: {report.get('quality',{}).get('matching_video_ratio',0):.1%}"]
    for issue in report.get('issues',[]):
        lines+=['',issue['label'],*issue.get('reasons',[])[:3],'الحل: '+issue['next_action']]
    return '\n'.join(lines)


def write_report(timeline,plan,folder,services=None,ai_status=None):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True);groups=defaultdict(Counter);unresolved=[]
    for row in (plan or {}).get('sentences',[]):
        category=cause(row)
        if category is None or row.get('role','clip')!='clip':continue
        game=row.get('game') or 'سياق عام';groups[game][category]+=1
        unresolved.append({k:safe_message(row.get(k,''))if k=='reason'else row.get(k,'')for k in ('id','game','event','start','end','query','status','reason')}
                         | {'cause':category,'next_action':ACTION[category]})
    report={'quality':assess(timeline),'games':dict(groups),'unresolved_count':len(unresolved),
            'causes':dict(Counter(cause(r)for r in (plan or {}).get('sentences',[]) if cause(r))),
            'source_attempts':[{k:safe_message(v)if k=='reason'else v for k,v in a.items()}for a in (plan or{}).get('source_attempts',[])],
            'services':services or{},'context_status':{k:safe_message(v)if k=='reason'else v for k,v in (ai_status or{}).items()},
            'issues':summarize(plan,services,ai_status),'actions':ACTION,
            'note':'Counts describe sentence requests; coverage uses actual timeline duration. Original narration is untouched.'}
    save(report,folder/'media_diagnostics.json')
    csv_path=folder/'missing_media.csv'
    with csv_path.open('w',encoding='utf-8-sig',newline='')as dest:
        fields=['id','game','event','start','end','query','status','cause','reason','next_action']
        writer=csv.DictWriter(dest,fieldnames=fields);writer.writeheader();writer.writerows(unresolved)
    lines=['# أسباب توقف الفيديو الطويل','',f'تغطية الفيديو المطابق: {report["quality"]["matching_video_ratio"]:.1%}',
           '', '| اللعبة | الطلبات غير المكتملة |','| --- | --- |']
    for game,counts in groups.items():lines.append('| '+game+' | '+'؛ '.join(f'{k}: {v}'for k,v in counts.items())+' |')
    lines+=['','## إجراءات المتابعة','']+[f'- {key}: {value}'for key,value in ACTION.items() if key in report['causes']]
    lines+=['','## التشخيص المباشر','',recovery_text(report)]
    lines+=['','التفاصيل في media_diagnostics.json، وطلبات المصادر في missing_media.csv. لا تعني سلامة التصدير اكتمال اللقطات.']
    (folder/'media_diagnostics.md').write_text('\n'.join(lines),encoding='utf-8')
    return report
