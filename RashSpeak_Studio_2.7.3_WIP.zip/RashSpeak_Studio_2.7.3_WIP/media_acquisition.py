"""Bounded, explicitly permitted excerpts. No cookies, login or access-control workarounds."""
import math
import ipaddress
from pathlib import Path
import re
from urllib.parse import urlparse

import requests

from media_tools import Cancelled, duration, run
from official_sources import SourceUnavailable

MAX_BYTES = 250_000_000


def permission(candidate):
    from source_policy import ai_generated
    if ai_generated(candidate):raise SourceUnavailable('سياسة المالك تمنع صور وفيديوهات الذكاء الاصطناعي.')
    grant = candidate.get('permission', {})
    from source_usage import owner_permission
    if candidate.get('rights_status')=='owner_accepted'and owner_permission(candidate):return grant
    link = urlparse(grant.get('evidence_url', ''))
    if (candidate.get('rights_status') != 'approved' or grant.get('usage_approved') is not True
            or grant.get('download_allowed') is not True or not grant.get('license', '').strip()
            or grant['license'].lower() in ('unknown', 'غير معروف')
            or link.scheme != 'https' or not link.hostname or link.username or link.password):
        raise SourceUnavailable('الأصل ينتظر توثيق السماح بالاستخدام والتنزيل؛ قصر المقتطف وحده لا يكفي.')
    return grant


def download_excerpt(candidate, start, end, folder, cancel=None):
    grant = permission(candidate)
    folder = Path(folder).resolve(); folder.mkdir(parents=True, exist_ok=True)
    if type(candidate.get('duration'))not in (int,float) or not math.isfinite(candidate['duration']):
        raise SourceUnavailable('مدة المصدر لم تُفحص؛ يلزم تحليل الفيديو الفعلي أولًا.')
    if (not all(type(v) in (int, float) and math.isfinite(v) for v in (start, end))
            or not 0 <= start < end or end - start > 30 or end > candidate.get('duration', 1)):
        raise ValueError('مقتطف متصل حتى 30 ثانية داخل المصدر فقط.')
    if cancel and cancel.is_set():
        raise Cancelled('أُلغي تنزيل المقتطف.')
    if candidate['provider'] in ('commons_video','steam'):
        from internet_video import excerpt
        return excerpt(candidate,start,end,folder,cancel)
    if candidate['provider'] == 'youtube':
        if not candidate.get('official_channel_checked') or not re.fullmatch(r'[A-Za-z0-9_-]{11}', candidate.get('video_id', '')):
            raise SourceUnavailable('لا تنزيل من قناة غير متحقق من هويتها.')
        if candidate.get('url')!='https://www.youtube.com/watch?v='+candidate['video_id']:
            raise SourceUnavailable('رابط المصدر لا يطابق فيديو YouTube المعتمد.')
        try:
            import yt_dlp
            from yt_dlp.utils import download_range_func
        except ImportError:
            raise SourceUnavailable('منزّل المقتطفات الاختياري غير مثبت؛ ثبّت requirements-media.txt.') from None
        class SilentLogger:
            def debug(self, msg): pass
            def info(self, msg): pass
            def warning(self, msg): pass
            def error(self, msg): pass
        def progress(data):
            if cancel and cancel.is_set():
                raise Cancelled('أُلغي تنزيل المقتطف.')
            if data.get('downloaded_bytes', 0) > MAX_BYTES:
                raise SourceUnavailable('المقتطف تجاوز حد التنزيل.')
        options = {'format': 'bestvideo[height<=1080]/best[height<=1080]',
                   'outtmpl': str(folder / 'source.%(ext)s'), 'noplaylist': True,
                   'download_ranges': download_range_func(None, [(start, end)]),
                   'force_keyframes_at_cuts': True,
                   # Limit the excerpt output, not the size of the full source video.
                   'external_downloader_args':{'ffmpeg_o':['-fs',str(MAX_BYTES)]},
                   'retries': 0, 'fragment_retries': 0, 'socket_timeout': 20,
                   'geo_bypass': False, 'cachedir':False,'quiet': True, 'no_warnings': True,
                   'logger': SilentLogger(), 'progress_hooks': [progress]}
        try:
            with yt_dlp.YoutubeDL(options) as downloader:
                metadata = downloader.extract_info(candidate['url'], download=False)
                if (metadata.get('id') != candidate['video_id']
                        or metadata.get('channel_id') != candidate['channel_id']
                        or metadata.get('is_live') or metadata.get('live_status') == 'is_live'):
                    raise SourceUnavailable('تغيرت هوية المصدر أو أنه بث مباشر؛ لم يُنزّل.')
                downloader.process_ie_result(metadata, download=True)
        except (Cancelled, SourceUnavailable):
            raise
        except Exception:
            raise SourceUnavailable('تعذر تنزيل المقتطف؛ قد تكون الشبكة أو قيود المصدر مانعة. لم يُستخدم تسجيل دخول أو تجاوز للقيود.') from None
        files = [p for p in folder.glob('source.*') if p.suffix.lower() in ('.mp4', '.mkv', '.webm', '.mov')]
        if len(files) != 1:
            raise SourceUnavailable('لم ينتج المنزّل مقتطف فيديو واحدًا صالحًا.')
        source = files[0]
        if source.stat().st_size > MAX_BYTES:
            raise SourceUnavailable('المقتطف تجاوز حد التنزيل.')
        measured = duration(source)
        if abs(measured - (end - start)) > .5:
            raise SourceUnavailable('مدة المقتطف لا تطابق النطاق المطلوب؛ لم يُدرج على الخط الزمني.')
        dest = folder / 'excerpt.mp4'
        run(['ffmpeg', '-v', 'error', '-y', '-i', str(source), '-t', str(end - start),
             '-an', '-vf', 'scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2,setsar=1',
             '-c:v', 'libx264', '-preset', 'fast', '-crf', '20', '-movflags', '+faststart', str(dest)], cancel=cancel)
        return dest
    if candidate['provider'] in ('google_images','commons_images'):
        url = urlparse(candidate['url'])
        allowed = grant.get('download_hosts', [])
        if (url.scheme != 'https' or url.hostname not in allowed or url.username or url.password
                or url.port not in (None, 443)):
            raise SourceUnavailable('مضيف الصورة غير معتمد في تصريح المصدر.')
        hostname=url.hostname.lower()
        if '.' not in hostname or hostname.endswith(('.local','.internal','.localhost')):
            raise SourceUnavailable('مضيف محلي غير مسموح لمصدر الصور.')
        try:
            if not ipaddress.ip_address(hostname).is_global:raise SourceUnavailable('عنوان صورة خاص أو محلي غير مسموح.')
        except ValueError:pass
        try:
            with requests.get(candidate['url'], stream=True, timeout=(8, 25), allow_redirects=False) as response:
                if response.status_code != 200:
                    raise SourceUnavailable('مصدر الصورة رفض التنزيل؛ لم يُتبع أي تحويل.')
                data = bytearray()
                for chunk in response.iter_content(65536):
                    if cancel and cancel.is_set(): raise Cancelled('أُلغي تنزيل الصورة.')
                    data.extend(chunk)
                    if len(data) > 20_000_000: raise SourceUnavailable('الصورة تتجاوز 20 MB.')
            from PIL import Image
            import io
            with Image.open(io.BytesIO(data)) as image:
                if image.width * image.height > 40_000_000: raise SourceUnavailable('أبعاد الصورة أكبر من الحد.')
                target = folder / 'image.png'; image.convert('RGBA').save(target)
            return target
        except requests.RequestException:
            raise SourceUnavailable('تعذر تنزيل الصورة من مصدرها.') from None
    raise SourceUnavailable('نوع مصدر غير مدعوم للتنزيل.')
