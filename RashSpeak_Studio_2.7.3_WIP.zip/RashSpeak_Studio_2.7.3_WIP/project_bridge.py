"""One editable canonical project; never silently overwrite newer Pro edits."""
import hashlib
import json
from pathlib import Path

from pro_project import load_project,write_project,edit_digest
from smart_editor import save

class ProjectConflict(ValueError):pass

def sync_project(auto_document,inputs,path):
    path=Path(path);baseline=path.with_suffix('.auto-baseline.json')
    signature=hashlib.sha256(json.dumps(inputs,sort_keys=True,ensure_ascii=False,allow_nan=False).encode()).hexdigest()
    if path.exists():
        current=load_project(path)
        try:previous=json.loads(baseline.read_text(encoding='utf-8'))
        except (OSError,ValueError):previous={}
        if previous.get('input_digest')==signature:return current
        if previous.get('edit_digest')!=edit_digest(current):
            raise ProjectConflict('يوجد تعديل محفوظ في Pro Editor ومدخلات Auto تغيّرت. مشروع Pro محفوظ ولم يُستبدل؛ أكمل التعديل والتصدير منه أو أنشئ إنتاجًا جديدًا. لا يُعاد بناء مونتاجك فوق تعديلاتك.')
    write_project(auto_document,path)
    save({'input_digest':signature,'edit_digest':edit_digest(load_project(path))},baseline)
    return auto_document
