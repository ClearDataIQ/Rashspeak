"""Secure Gemini settings and reviewed editing proposals, entirely on the Tk thread."""
from copy import deepcopy
from pathlib import Path
import tkinter as tk
from tkinter import ttk

from rtl_ui import Label,Button,Treeview,visual,dialogs as messagebox
from gemini_client import settings,save_settings,api_key,save_key,use_session_key,GeminiClient,GeminiError
from smart_editor import fingerprint
import ai_editing
import pro_render

BG='#0b1220';CARD='#132138';TEXT='#eef5ff';CYAN='#08BEED';MUTED='#91a9c4'


def button(parent,text,fn):return Button(parent,text=text,command=fn,bg='#223b58',fg=TEXT,relief='flat',padx=10,pady=7)


def open_settings(parent):
    from api_settings_ui import open_settings as open_api_settings
    return open_api_settings(parent,provider='gemini')


class AssistantPanel(tk.Frame):
    def __init__(self,parent,editor):
        super().__init__(parent,bg=BG,padx=14,pady=12);self.editor=editor;self.proposal=None;self.expected_preview=None
        Label(self,text='AI Editing Assistant • Gemini',bg=BG,fg=CYAN,font=('Segoe UI',18,'bold')).pack(fill='x')
        Label(self,text='اكتب أمرًا بالعربية. الاقتراح لا يُطبّق حتى تعرض معاينته وتعتمده.\nالنص والتوقيت وبيانات محدودة للوسائط تُرسل؛ المصادر الأصلية لا تتغير.',bg=BG,fg=MUTED,wraplength=790,justify='right').pack(fill='x',pady=8)
        self.command=tk.Text(self,height=3,bg=CARD,fg=TEXT,insertbackground=TEXT,wrap='word');self.command.pack(fill='x')
        self.command.insert('1.0','حسّن الصوت فقط دون تعديل الفيديو')
        row=tk.Frame(self,bg=BG);row.pack(fill='x',pady=8)
        button(row,'طلب اقتراح Gemini',self.request).pack(side='right',padx=3)
        button(row,'إعداد Gemini',lambda:open_settings(self)).pack(side='right',padx=3)
        self.summary=tk.StringVar(value='');Label(self,textvariable=self.summary,bg=BG,fg=TEXT,wraplength=790,justify='right').pack(fill='x',pady=6)
        self.tree=Treeview(self,columns=('op','target','change','reason'),show='headings',height=8)
        for k,label,width in [('op','التعديل',125),('target','العنصر',100),('change','القيمة',200),('reason','السبب',320)]:self.tree.heading(k,text=label);self.tree.column(k,width=width)
        self.tree.pack(fill='both',expand=True)
        footer=tk.Frame(self,bg=BG);footer.pack(fill='x',pady=8)
        self.preview_button=button(footer,'إنتاج معاينة الاقتراح',self.preview);self.preview_button.pack(side='right',padx=3)
        self.watch_button=button(footer,'شاهد المعاينة',self.watch);self.watch_button.pack(side='right',padx=3)
        self.approve_button=button(footer,'اعتماد كتعديل واحد',self.approve);self.approve_button.pack(side='right',padx=3)
        button(footer,'رفض / مسح الاقتراح',self.clear).pack(side='right',padx=3);self.clear()

    def clear(self):
        self.proposal=None;self.expected_preview=None;self.tree.delete(*self.tree.get_children());self.summary.set('المشروع الحالي لم يتغير.')
        for b in (self.preview_button,self.watch_button,self.approve_button):b.configure(state='disabled')

    def request(self):
        if self.editor.busy:return
        command=self.command.get('1.0','end-1c');p=deepcopy(self.editor.session.project);selected=list(self.editor.selected);at=self.editor.playhead
        self.clear();self.summary.set('Gemini يحوّل الأمر إلى اقتراح مضبوط…')
        def work():
            from timeline_ops import verified_silences
            silences=verified_silences(p,self.editor.cancel) if 'سكوت' in command or 'silence' in command.lower() else []
            return ai_editing.propose(p,command,selected,at,silences=silences,cancel=self.editor.cancel)
        self.editor.task(work,self.received,'طلب اقتراح Gemini')

    def received(self,proposal):
        if not self.winfo_exists():return
        self.proposal=proposal;self.summary.set(proposal['summary'])
        for i,a in enumerate(proposal['actions']):self.tree.insert('','end',iid=str(i),values=(a['op'],a['target'],a['property']+' = '+a['value'] if a['property'] else f'{a["start"]} → {a["end"]}',a['reason']))
        self.preview_button.configure(state='normal' if proposal['actions'] else 'disabled')

    def preview(self):
        if not self.proposal or self.editor.busy:return
        if self.proposal['base_digest']!=ai_editing.edit_digest(self.editor.session.project):
            self.summary.set('تغير المشروع؛ اطلب اقتراحًا جديدًا.');return
        proposal=self.proposal;self.approve_button.configure(state='disabled')
        def done(path):
            if not self.winfo_exists() or self.proposal is not proposal:return
            proposal['preview']=path;proposal['preview_fingerprint']=fingerprint(path);self.expected_preview=proposal['preview_fingerprint']
            proposal['preview_model_digest']=ai_editing.edit_digest(proposal['project'])
            self.watch_button.configure(state='normal');self.summary.set('المعاينة جاهزة. شاهدها قبل اعتماد التعديلات.')
        self.editor.task(lambda:pro_render.proxy(proposal['project'],self.editor.session.path.parent/'ai_preview',
            sequence_id=proposal['project']['active_sequence'],cancel=self.editor.cancel),done,'رندر اقتراح Gemini دون تغيير المشروع')

    def watch(self):
        if not self.proposal or not self.proposal.get('preview'):return
        self.editor.open_file(self.proposal['preview']);self.approve_button.configure(state='normal')

    def approve(self):
        if not self.proposal or self.editor.busy:return
        try:
            ai_editing.commit(self.editor.session,self.proposal);self.editor.refresh();self.summary.set('اعتمدت التعديلات. Undo يرجعها كلها كعملية واحدة.')
            self.approve_button.configure(state='disabled');self.preview_button.configure(state='disabled')
        except (ValueError,GeminiError,OSError) as exc:self.summary.set(str(exc))


def open_assistant(editor):
    w=tk.Toplevel(editor);w.title('AI Editing Assistant • Gemini');w.geometry('880x650');w.configure(bg=BG)
    AssistantPanel(w,editor).pack(fill='both',expand=True);return w
