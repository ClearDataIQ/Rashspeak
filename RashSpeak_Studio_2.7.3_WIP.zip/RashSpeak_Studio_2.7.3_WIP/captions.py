"""Logical Unicode Arabic captions: libass handles bidi and shaping once."""
import json
import math
from pathlib import Path
import re
import textwrap
import unicodedata

from caption_layout import layout, text_measure


def validate(segments, duration):
    result = []
    previous = 0.0
    for item in segments:
        start, end = float(item['start']), float(item['end'])
        if not all(math.isfinite(x) for x in (start, end)) or end > duration + .02:
            raise ValueError('توقيت الترجمة خارج مدة الصوت أو غير صالح.')
        end = min(end, duration)
        if 0 <= duration - end <= .001:
            end = duration
        if abs(start - previous) <= .001:
            start = previous
        text = str(item.get('text', '')).strip()
        if not all(math.isfinite(x) for x in (start, end)) or not 0 <= start < end <= duration:
            raise ValueError('توقيت الترجمة خارج مدة الصوت أو غير صالح.')
        if start < previous - .001:
            raise ValueError('جمل الترجمة متداخلة؛ صحح التوقيت قبل المتابعة.')
        if not text:
            raise ValueError('جملة ترجمة فارغة.')
        if item.get('mode', 'auto') not in ('auto', 'factual', 'sensitive', 'crucial', 'cta', 'humor', 'frustration', 'surprise'):
            raise ValueError('نوع الجملة غير معروف.')
        importance = float(item.get('importance', 0))
        if not math.isfinite(importance) or not 0 <= importance <= 10:
            raise ValueError('أهمية الجملة بين 0 و10.')
        result.append({**item, 'start': start, 'end': min(end, duration), 'text': text})
        previous = end
    return result


def stamp(seconds, ass=False):
    units = round(seconds * (100 if ass else 1000))
    h, units = divmod(units, 360000 if ass else 3600000)
    m, units = divmod(units, 6000 if ass else 60000)
    s, fraction = divmod(units, 100 if ass else 1000)
    return f'{h}:{m:02}:{s:02}.{fraction:02}' if ass else f'{h:02}:{m:02}:{s:02},{fraction:03}'


def read_srt(path):
    text = Path(path).read_text(encoding='utf-8-sig').replace('\r', '')
    result = []
    def seconds(t):
        h, m, s = t.replace(',', '.').split(':')
        return int(h) * 3600 + int(m) * 60 + float(s)
    for block in re.split(r'\n\s*\n', text.strip()):
        lines = block.splitlines()
        timing = next((i for i, line in enumerate(lines) if '-->' in line), None)
        if timing is None:
            raise ValueError('صيغة SRT غير صالحة.')
        start, end = lines[timing].split('-->')
        result.append({'start': seconds(start.strip()), 'end': seconds(end.strip()),
                       'text': ' '.join(lines[timing + 1:])})
    return result


def load(path):
    path = Path(path)
    return read_srt(path) if path.suffix.lower() == '.srt' else json.loads(path.read_text(encoding='utf-8-sig'))


def wrapped(text, width=38):
    # Reject invisible overrides and ASS syntax; retain Arabic in logical order.
    text = ''.join(c for c in text if unicodedata.category(c) != 'Cf')
    text = text.replace('\\', '／').replace('{', '〔').replace('}', '〕')
    lines = textwrap.wrap(' '.join(text.split()), width=width, break_long_words=True, break_on_hyphens=False)
    return lines or ['']


def pages(segments, width=38):
    return layout(segments, width)


def write_srt(segments, path):
    text = ''.join(f'{i}\n{stamp(s["start"])} --> {stamp(s["end"])}\n{s["text"]}\n\n' for i, s in enumerate(pages(segments), 1))
    Path(path).write_text(text, encoding='utf-8-sig')


def write_ass(segments, path, size=(1920, 1080), font='Arial', style='gaming', region=(.10, .78, .80, .15),font_size=None,outline=None,highlight=False,font_file=None,time_range=None):
    w, h = size
    x, y, rw, rh = region
    if any(c in font for c in ',\r\n{}\\'):
        raise ValueError('اسم الخط غير صالح.')
    font_size = font_size if font_size is not None else max(18, round(min(h * .058, rh * h / 2.2)))
    outline = outline if outline is not None else round(2*min(w,h)/1080,2)
    bold = -1 if style == 'gaming' else 0
    # Position captions inside the chosen rectangle. Explicit wraps guarantee <=2 lines.
    header = f'''[Script Info]
ScriptType: v4.00+
PlayResX: {w}
PlayResY: {h}
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,{font},{font_size},&H00FFFFFF,&H000000FF,&H00000000,&H90000000,{bold},0,0,0,100,100,0,0,1,{outline},0.5,2,{round(x*w)},{round((1-x-rw)*w)},{round((1-y-rh)*h)},-1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
'''
    measure = text_measure(font, font_size, bool(bold), font_file)
    formatted = layout(segments, max(1, rw * w - 2 * outline - 8), measure)
    if time_range is not None:
        # Paginate before slicing so a preview in the middle shows the export's page.
        start, end = time_range
        formatted = [{**p, 'start': max(start,p['start'])-start, 'end': min(end,p['end'])-start,
                      'words':[{**word,'start':word['start']-start,'end':word['end']-start}for word in p['words']]}
                     for p in formatted if p['end']>start and p['start']<end]
    events = []
    for item in formatted:
        position = f'\\an2\\pos({round((x+rw/2)*w)},{round((y+rh)*h)})'
        if item['scale'] < 1:
            position += f'\\fs{font_size * item["scale"]:.2f}'
        content = item['text'].replace('\n', r'\N')
        events.append(f'Dialogue: 0,{stamp(item["start"],True)},{stamp(item["end"],True)},Default,,0,0,0,,{{{position}}}{content}\n')
        if highlight:
            # Use the identical page and wraps at real word intervals, including long cues.
            offset = 0
            for word in item['words']:
                begin = item['text'].find(word['text'], offset)
                finish = begin + len(word['text']);offset = finish
                start, end = max(item['start'],word['start']), min(item['end'],word['end'])
                if begin < 0 or end <= start or stamp(start,True) == stamp(end,True):
                    continue
                text = (item['text'][:begin] + r'{\c&H00D2FF&}' + item['text'][begin:finish]
                        + r'{\c&HFFFFFF&}' + item['text'][finish:]).replace('\n',r'\N')
                events.append(f'Dialogue: 1,{stamp(start,True)},{stamp(end,True)},Default,,0,0,0,,{{{position}}}{text}\n')
    Path(path).write_text(header + ''.join(events), encoding='utf-8-sig')


def local_model_path():
    from app_paths import app_dir
    for name in ('large-v3-turbo','medium','small'):
        path=app_dir()/'models'/name
        if (path/'model.bin').is_file():return path
    return app_dir()/'models/small'


def transcribe(audio, model_path, logger=print, cancel=None, device='auto', dialect='saudi', vocabulary=None, return_words=False):
    from resource_policy import configure_cuda_libraries,cuda_available,gpu_slot
    if device not in ('auto','cpu','cuda'):raise ValueError('جهاز التفريغ غير صالح.')
    configure_cuda_libraries()
    selected=('cuda'if cuda_available()else'cpu')if device=='auto'else device
    if selected=='cuda':
        try:
            with gpu_slot(cancel,logger):return _transcribe(audio,model_path,logger,cancel,selected,dialect,vocabulary,return_words)
        except RuntimeError as exc:
            if device!='auto'or not any(s in str(exc).lower()for s in ('cuda','cublas','cudnn','out of memory')):raise
            logger('تعذر تنفيذ CUDA؛ أُعيد التفريغ كاملًا على CPU دون مزج نتائج جزئية.')
    else:logger('التفريغ على CPU محليًا.'if device=='cpu'else'CUDA غير جاهز؛ يستخدم التفريغ CPU محليًا.')
    return _transcribe(audio,model_path,logger,cancel,'cpu',dialect,vocabulary,return_words)


def _transcribe(audio, model_path, logger=print, cancel=None, device='cpu', dialect='saudi', vocabulary=None, return_words=False):
    if not Path(model_path).is_dir():
        raise ValueError('اختر مجلد نموذج Whisper المحلي. تنزيل النموذج يتم منفصلًا وبموافقتك.')
    try:
        from faster_whisper import WhisperModel
    except ImportError as exc:
        raise RuntimeError('ثبّت التعرف الصوتي باستخدام INSTALL_ARABIC_SUBTITLES.bat أو استورد SRT.') from exc
    from media_tools import Cancelled, duration
    limit = duration(audio, 'audio')
    from resource_policy import cpu_threads
    logger('تفريغ CUDA محلي بكلمات متزامنة.'if device=='cuda'else'تفريغ CPU بكلمات متزامنة.')
    model = WhisperModel(str(model_path), device=device, compute_type='int8' if device == 'cpu' else 'float16', cpu_threads=cpu_threads(), num_workers=1, local_files_only=True)
    prompt = 'تعليق ألعاب باللهجة السعودية: يا جماعة، ذحين، الحين، ترى، تبغى، خلونا، مرة، وش رايكم.' if dialect == 'saudi' else 'تعليق أخبار ألعاب باللغة العربية.'
    prompt += ' أسماء الألعاب: ' + '، '.join(str(x) for x in (vocabulary or ['فورتنايت','ماينكرافت','إكس بوكس','بلايستيشن','GTA','The Witcher','Elden Ring']) if str(x).strip())[:400]
    stream, _ = model.transcribe(str(audio), language='ar', beam_size=8, vad_filter=True, word_timestamps=True,
                                initial_prompt=prompt, condition_on_previous_text=False,
                                temperature=0.,hallucination_silence_threshold=1.,
                                repetition_penalty=1.05)
    result, timed_words = [], []
    previous_word=0.0
    for segment in stream:
        if cancel and cancel.is_set():
            raise Cancelled('أُلغي التفريغ.')
        words = list(segment.words or [])
        for word in words:
            start=max(0,word.start,previous_word);end=min(limit,word.end)
            if end > start and word.word.strip():
                timed_words.append({'start':start,'end':end,'text':word.word.strip(),
                                    'probability':float(getattr(word,'probability',0))})
                previous_word=end
        if not words:
            if segment.text.strip() and segment.end > segment.start:
                result.append({'start': max(0, segment.start), 'end': min(limit, segment.end), 'text': segment.text.strip()})
            continue
        group = []
        for word in words:
            group.append(word)
            if len(''.join(x.word for x in group)) >= 64 or word.end - group[0].start >= 5 or word.word.strip().endswith(('؟', '!', '.', '،')):
                result.append({'start': max(0, group[0].start), 'end': min(limit, group[-1].end), 'text': ''.join(x.word for x in group).strip()})
                group = []
        if group:
            result.append({'start': max(0, group[0].start), 'end': min(limit, group[-1].end), 'text': ''.join(x.word for x in group).strip()})
        logger(f'تفريغ {segment.end:.1f} / {limit:.1f} ثانية')
    # ASR rounding can yield adjacent zero-length/overlapping words; keep real word times.
    cleaned = []
    previous = 0
    for s in result:
        s['start'] = max(s['start'], previous)
        if s['end'] > s['start'] and s['text']:
            cleaned.append(s)
            previous = s['end']
    if not cleaned:
        raise ValueError('لم يُكتشف كلام. استورد ترجمة مراجعة أو تابع بمسار اللقطات فقط.')
    cleaned=validate(cleaned, limit)
    return {'segments':cleaned,'words':timed_words} if return_words else cleaned
