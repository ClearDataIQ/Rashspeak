"""Two-input local production: edit narration -> media -> reactions -> files.

All outputs are review copies, never network publication or fabricated approvals.
"""
from datetime import datetime
import hashlib
import json
from pathlib import Path
import re

from PIL import Image, ImageDraw
import audio_edit
import captions
from app_paths import app_dir
from channel_style import load_profile, long_description
from licensed_media import gather, topics, credits_text
from media_tools import Cancelled, duration
from smart_editor import save, plan, import_asset, fingerprint, contains, validate_timeline, SENSITIVE
from thumbnail import make_thumbnail
from timeline_render import render

STAGES=[('audio','تعديل الصوت'),('media','تركيب اللقطات'),('effects','إضافة المؤثرات'),
        ('reactions','الميمز عند الحاجة'),('montage','المونتاج والشورتات'),('delivery','تجهيز الملفات للرفع')]


def load_json(path,default=None):
    return json.loads(Path(path).read_text(encoding='utf-8')) if Path(path).is_file() else default


def new_project(root=None):
    parent=Path(root or app_dir()/'output/productions');parent.mkdir(parents=True,exist_ok=True)
    folder=parent/datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
    suffix=1
    while folder.exists():folder=parent/(datetime.now().strftime('%Y-%m-%d_%H-%M-%S')+f'_{suffix}');suffix+=1
    folder.mkdir();return folder.resolve()


def topic_card(topic,folder,index,cancel=None):
    """Explicitly labelled editorial graphic when licensed gameplay is unavailable."""
    file=Path(folder)/f'topic_card_{index}.jpg';base=Path(folder)/f'card_base_{index}.png'
    file.parent.mkdir(parents=True,exist_ok=True)
    image=Image.new('RGB',(1280,720));draw=ImageDraw.Draw(image)
    draw.rectangle((0,0,1280,720),fill='#111827')
    image.save(base)
    asset=import_asset(base,license='Original generated graphic',source='Generated locally by RashSpeak',approved=True)
    # Missing-media drafts show a topic label, never duplicate spoken captions.
    title=' '.join(topic.split()[:6]) or 'لقطات غير متاحة'
    make_thumbnail(asset,title,file,genre='news',cancel=cancel)
    asset=import_asset(file,game=topic,tags=[topic],license='Original generated graphic',source='Generated locally by RashSpeak',approved=True)
    asset.update(editorial_card=True,missing_media=True,display_text=title)
    return asset


def contextual_cues(segments,available_topics,folder):
    """Carry a story topic between mentions; do not change the spoken captions."""
    # Recognition pages can split a real game name. Use contiguous transcript
    # context, never assign an arbitrary script/game label to the introduction.
    available_topics=list(dict.fromkeys([*available_topics,*topics(' '.join(s['text']for s in segments))]))
    current='';rows=[]
    for index,segment in enumerate(segments):
        hits=[t for t in available_topics if contains(segment['text'],t)]
        if not hits and index+1<len(segments)and segments[index+1]['start']-segment['end']<.8:
            following=segments[index+1]['text']
            hits=[t for t in available_topics if not contains(following,t)and contains(segment['text']+' '+following,t)]
        semantic=segment.get('semantic')or{}
        if semantic.get('game')and semantic.get('confidence',0)>=.75:
            current=semantic['game']
        if hits:current=hits[-1]
        segment['story_topic']=current
        if current:rows.append({'start':segment['start'],'end':segment['end'],'tag':current})
    import csv
    file=Path(folder)/'story_cues.csv'
    with file.open('w',encoding='utf-8-sig',newline='') as dest:
        writer=csv.DictWriter(dest,fieldnames=['start','end','tag']);writer.writeheader();writer.writerows(rows)
    return file


def complete_shorts(segments,limit,count=3,minimum=25,maximum=60,target=50):
    from short_policy import select
    return select(segments,limit,count,minimum,maximum,target)


def produce(audio,script,project=None,online=True,model=None,cancel=None,on_event=None,
            asr_override=None,assets_override=None,sizes=None,on_review=None,quality_mode='final'):
    """Shared engine. The main UI supplies mandatory owner review checkpoints."""
    from reviewed_production import run_production
    return run_production(audio,script,project,online,model,cancel,on_event,
                          asr_override,assets_override,sizes,on_review,quality_mode)
