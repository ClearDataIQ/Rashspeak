"""Provider boundaries and a persistent, explicit-resume quota circuit."""
import hashlib
import json
from pathlib import Path
import threading
import time

from app_paths import app_dir
from smart_editor import save

ENDPOINTS={'google':'https://generativelanguage.googleapis.com/v1beta',
           'openrouter':'https://openrouter.ai/api/v1'}
_lock=threading.RLock()
_memory_paused=set()


def endpoint(provider, url=''):
    if provider not in ENDPOINTS:
        raise ValueError('اختر مزودًا مدعومًا: Google مباشرة أو OpenRouter.')
    if url and url.rstrip('/')!=ENDPOINTS[provider]:
        raise ValueError('عنوان الاتصال لا يطابق المزوّد؛ لم يُرسل أي مفتاح.')
    return ENDPOINTS[provider]


def circuit_path():
    return app_dir()/'output/settings/ai_quota_circuit.json'


def scope(provider,key):
    # Only a one-way scope identifier is persisted, never the credential itself.
    return hashlib.sha256((provider+'\0'+key).encode()).hexdigest()


def _read():
    try:
        value=json.loads(circuit_path().read_text(encoding='utf-8'))
        return value if isinstance(value,dict)else{}
    except (OSError,ValueError):return{}


def paused(provider,key):
    with _lock:return scope(provider,key)in _memory_paused or _read().get(scope(provider,key),{}).get('paused',False) is True


def pause(provider,key):
    with _lock:
        _memory_paused.add(scope(provider,key))
        state=_read();state[scope(provider,key)]={'paused':True,'reason':'quota','at':time.time()}
        try:save(state,circuit_path())
        except OSError:pass  # Remain stopped in memory even if storage is locked.


def resume(provider,key):
    """Only an explicit user action may clear the quota stop; no service switch."""
    with _lock:
        state=_read();state.pop(scope(provider,key),None);save(state,circuit_path());_memory_paused.discard(scope(provider,key))


QUOTA_MESSAGE='توقفت طلبات الذكاء بعد نفاد الحصة (HTTP 429). النتائج الصحيحة محفوظة. بعد تجدد الحصة اضغط «استئناف الطلبات» في إعدادات المزوّد؛ لن ننتقل إلى خدمة مدفوعة.'

def model_identity(client):
    identity=getattr(client,'cache_identity',None)
    if isinstance(identity,(list,tuple)):return identity
    model=getattr(client,'model','')
    return model if isinstance(model,str)else''
