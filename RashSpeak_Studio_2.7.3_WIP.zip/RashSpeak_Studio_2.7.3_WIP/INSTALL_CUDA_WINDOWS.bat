@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo Run INSTALL_WINDOWS.bat first.
 pause
 exit /b 1
)
".venv\Scripts\python.exe" -m pip install --only-binary=:all: -r requirements-cuda-windows.txt
if errorlevel 1 (
 echo CUDA runtime setup failed. CPU mode is still available.
 pause
 exit /b 1
)
echo Optional NVIDIA libraries installed inside this app only. Restart RashSpeak.
pause
