"""Conservative narration processing: fixed gain, no echo or adaptive gain tail."""
import math
from pathlib import Path
import re
from media_tools import run

DEFAULTS={'highpass':50,'denoise':False,'noise_floor':-50,'loudness':-16,'normalize':True}


def fixed_gain(source,folder,target=-16,cancel=None):
    folder=Path(folder)
    filters=('ebur128=metadata=1,ametadata=print:key=lavfi.r128.I:file=loudness.txt,'
             'astats=metadata=1:reset=0,ametadata=print:key=lavfi.astats.Overall.Peak_level:file=peak.txt')
    run(['ffmpeg','-v','error','-y','-i',source,'-af',filters,'-f','null','-'],cwd=folder,cancel=cancel)
    def last(name,key):
        matches=re.findall(re.escape(key)+r'=([^\s]+)',(folder/name).read_text(encoding='utf-8'))
        if not matches:raise RuntimeError('تعذر قياس مستوى الصوت؛ لم يُستبدل الملف المنظف.')
        return float(matches[-1])
    loudness=last('loudness.txt','lavfi.r128.I');peak=last('peak.txt','lavfi.astats.Overall.Peak_level')
    gain=max(-30.,min(12.,target-loudness,-2.-peak))if math.isfinite(peak)and peak>-60 and math.isfinite(loudness)else 0.
    return gain,{'input_lufs':loudness if math.isfinite(loudness)else None,
                 'input_peak_db':peak if math.isfinite(peak)else None,'fixed_gain_db':gain}
