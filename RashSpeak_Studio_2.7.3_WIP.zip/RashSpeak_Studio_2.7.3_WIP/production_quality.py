"""Auto Studio acceptance checks. A decoded placeholder is not a finished montage."""
from collections import defaultdict
from licensed_media import game_key, same_game, visual_suitable
from smart_editor import licensed, normalize
from media_tools import source_resolution_ok
from pathlib import Path
import json


class MissingFootage(ValueError):
    def __init__(self, report):
        self.report = report
        super().__init__('تغطية اللقطات غير كافية؛ حُفظت المسودة ولم يُنتج فيديو نهائي من البطاقات. '
                         + '؛ '.join(report['blockers']))


def _union_length(ranges):
    end = 0.; total = 0.
    for lo, hi in sorted(ranges):
        if hi > max(lo, end):
            total += hi - max(lo, end)
        end = max(end, hi)
    return total


def context_matches(asset,semantic,game):
    from visual_beats import entity_keys
    if game and not same_game(asset.get('game'),game):return False
    if semantic.get('search_intent')=='specific_event' and normalize(asset.get('event',''))!=normalize(semantic.get('event','')):return False
    required=entity_keys(e for e in semantic.get('entities',[])if not same_game(e,game))
    return required<=entity_keys(asset.get('entities',[]))


def assess(timeline):
    from visual_beats import split_segments
    segments=split_segments(timeline['segments'])
    limit = timeline['duration']; assets = {a['id']: a for a in timeline['assets']}
    videos = []; cards = []; topics = defaultdict(lambda: {'required': [], 'covered': []})
    duplicate = []; longest_card = 0.; card_start = None; previous_end = 0.;low_resolution=[];images=[];unverified=[];source_ranges=[]
    for shot in sorted(timeline['shots'], key=lambda s: s['start']):
        start, end = shot['start'], shot['end']; asset = assets.get(shot.get('asset_id'), {})
        card = bool(asset.get('editorial_card') or asset.get('missing_media') or not asset)
        display_text=asset.get('display_text','')
        if card and not display_text and asset.get('path'):
            metadata=Path(asset['path']).with_suffix('.json')
            if metadata.is_file():
                try:display_text=json.loads(metadata.read_text(encoding='utf-8-sig')).get('headline','')
                except (OSError,ValueError,AttributeError):pass
        if card:
            cards.append((start, end))
            if card_start is None or start > previous_end + .001:
                card_start = start
            longest_card = max(longest_card, end - card_start)
        else:
            card_start = None
        previous_end = end
        usable = (not card and asset.get('kind') in ('video', 'animation') and licensed(asset)
                  and visual_suitable(asset, 'gameplay'))
        floor=timeline.get('source_quality',{}).get('min_source_height',0)
        visual=not card and asset.get('kind')in ('video','animation','image') and licensed(asset)
        if visual and not source_resolution_ok(asset,floor):
            low_resolution.append({'start':start,'end':end,'asset_id':asset['id'],
                                   'kind':asset['kind'],'width':asset.get('width',0),'height':asset.get('height',0)})
        verified=not timeline.get('require_scene_evidence') or asset.get('scene_verified')is True
        if visual and not verified:
            unverified.append({'start':start,'end':end,'asset_id':asset['id']});usable=False
        if usable:
            offset = shot.get('source_offset', 0)
            usable = offset >= 0 and offset + end - start <= asset.get('duration', 0) + .02
        for segment in segments:
            lo, hi = max(start, segment['start']), min(end, segment['end'])
            if hi <= lo:
                continue
            semantic = segment.get('semantic', {})
            game = semantic.get('game') or segment.get('story_topic', '')
            if game:
                topics[game_key(game)]['required'].append((lo, hi))
            matches = usable and context_matches(asset,semantic,game)
            if verified and not card and asset.get('kind')=='image' and licensed(asset)and context_matches(asset,semantic,game):images.append((lo,hi))
            if matches:
                videos.append((lo, hi))
                from visual_diversity import source_id
                source_ranges.append({'start':lo,'end':hi,'game':game_key(game),'source_id':source_id(asset)})
                if game:
                    topics[game_key(game)]['covered'].append((lo, hi))
            label=normalize(display_text)
            # A game name can contain four or more words. A topic label is not
            # a second transcript just because that name is also spoken.
            topic_labels={normalize(value) for value in (
                asset.get('game',''),shot.get('topic',''),game) if value}
            if card and label not in topic_labels and len(label.split())>=4 and label in normalize(segment.get('source_sentence_text',segment['text'])):
                duplicate.append({'start': lo, 'end': hi})
    coverage = _union_length(videos) / max(.001, limit)
    card_ratio = _union_length(cards) / max(.001, limit)
    missing = [{'game': game, 'required_seconds': round(_union_length(data['required']), 2),
                'covered_seconds': round(_union_length(data['covered']), 2)}
               for game, data in topics.items()
               if _union_length(data['required']) >= 8 and _union_length(data['covered']) < .6 * _union_length(data['required'])]
    blockers = []
    if coverage < .8:
        blockers.append(f'لقطات متحركة مطابقة تغطي {coverage:.1%}؛ المطلوب 80% على الأقل')
    if card_ratio > .1 or longest_card > 4:
        blockers.append(f'البطاقات تغطي {card_ratio:.1%}؛ أطول امتداد {longest_card:.1f} ثانية')
    if missing:
        blockers.append('مواضيع تحتاج لقطات: ' + ', '.join(t['game'] for t in missing))
    if duplicate:
        blockers.append('يوجد نص منطوق مكرر في الخلفية والترجمة')
    if low_resolution and timeline.get('source_quality',{}).get('enforced'):
        blockers.append('توجد لقطات أقل من الحد الأدنى لدقة المصدر؛ اختر أصلًا أعلى جودة قبل التصدير النهائي')
    if unverified:blockers.append('توجد لقطات لم تثبت مطابقة مشاهدها؛ تطابق اسم اللعبة وحده لا يكفي لاعتماد المونتاج')
    from visual_diversity import source_stats
    variety=[];rules=timeline.get('source_variety',{})
    scopes=[('topic:'+game, min(a for a,b in data['required']),max(b for a,b in data['required']),
             [r for r in source_ranges if r['game']==game])for game,data in topics.items()if data['required']]
    scopes += [('short:'+str(i),s['start'],s['end'],source_ranges)for i,s in enumerate(timeline.get('shorts',[]))if s.get('approved')]
    for label,a,b,ranges in scopes:
        if b-a<rules.get('min_seconds',25):continue
        stats=source_stats(ranges,a,b);stats.update(scope=label,start=a,end=b,target_sources=rules.get('target_sources',3))
        stats['needs_more_sources']=stats['source_count']<rules.get('minimum_sources',2)or stats['dominant_source_ratio']>.85
        variety.append(stats)
        if rules.get('enforced')and stats['covered_seconds']>=.8*(b-a)and stats['needs_more_sources']:
            blockers.append(f'تنويع المصادر غير كافٍ في {label}: يلزم مصدران مطابقان على الأقل دون هيمنة فيديو واحد؛ الهدف ثلاثة مصادر')
    return {'ready': not blockers, 'matching_video_ratio': round(coverage, 5),
            'placeholder_ratio': round(card_ratio, 5), 'longest_placeholder_seconds': round(longest_card, 3),
            'missing_topics': missing, 'duplicate_text_ranges': duplicate, 'blockers': blockers,
            'matching_image_ratio':round(_union_length(images)/max(.001,limit),5),'low_resolution_ranges':low_resolution,
            'unverified_scene_ranges':unverified,
            'source_variety':variety,'matching_source_ranges':source_ranges,
            'effect_count': sum(bool(e.get('approved')) for e in timeline.get('sound_effects', [])),
            'meme_count': sum(bool(e.get('approved')) for e in timeline.get('memes', [])),
            'thresholds': {'matching_video_ratio': .8, 'max_placeholder_ratio': .1, 'max_placeholder_seconds': 4}}
