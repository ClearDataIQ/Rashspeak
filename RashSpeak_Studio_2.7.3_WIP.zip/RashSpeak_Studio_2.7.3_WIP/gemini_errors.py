"""Bounded Google error parsing; never return server-echoed prompts or secrets."""
import json
import re
from requests import RequestException

LIMIT=64*1024


def describe(response,cancel=None):
    chunks=[];size=0
    try:
        for block in response.iter_content(4096):
            if cancel:cancel()
            size+=len(block)
            if size>LIMIT:return {'kind':'unknown','fields':[]}
            chunks.append(block)
        data=json.loads(b''.join(chunks))
        error=data.get('error',{})
        if not isinstance(error,dict):raise ValueError()
    except (ValueError,TypeError,AttributeError,RequestException):return {'kind':'unknown','fields':[]}
    # Only fixed classifications and recognized request-field paths leave this function.
    # Google may echo a user prompt, URL or credential in message/description/metadata.
    message=str(error.get('message','')).lower()+' '+str(error.get('status','')).lower();fields=[];reasons=[]
    details=error.get('details',[])
    for detail in details if isinstance(details,list)else[]:
        if not isinstance(detail,dict):continue
        reasons.append(str(detail.get('reason','')).lower())
        violations=detail.get('fieldViolations',[])
        for violation in violations if isinstance(violations,list)else[]:
            if isinstance(violation,dict):
                field=violation.get('field','')
                if isinstance(field,str)and re.fullmatch(r'(?:generation_config|generationConfig|system_instruction|systemInstruction|contents)(?:\.[A-Za-z_]+|\[\d+\])*',field):
                    fields.append(field[:180])
                message+=' '+str(violation.get('description','')).lower()
    hints=message+' '+' '.join(fields).lower()+' '+' '.join(reasons)
    mentions=lambda *tokens:any(token in hints for token in tokens)
    kind='unknown'
    if mentions('api_key_invalid','api key not valid','api key expired','api_key_service_blocked','api_key_http_referrer_blocked',
                'api_key_ip_address_blocked','api_key_expired','api_key_not_found','api key was reported as leaked','api key has been blocked'):
        kind='credential'
    elif mentions('billing','not available in your country','location is not supported','region is not supported','failed_precondition'):
        kind='account'
    elif mentions('input token count','exceeds the maximum number of tokens','context length','input is too long'):
        kind='context_limit'
    elif mentions('response_mime_type','responsemimetype')and mentions('not supported','unsupported'):
        kind='json_unsupported'
    elif mentions('video','file_uri','fileuri','inline_data','inlinedata','mime_type','mimetype') and mentions('fetch','access','not found','invalid','unsupported','not supported','failed'):
        kind='media_input'
    elif mentions('schema')and mentions('too complex','too many states','too many nesting','too deeply nested','complexity'):
        kind='schema_complexity'
    elif mentions('responseschema','response_schema')and mentions('not supported','unsupported','unknown name','unrecognized'):
        kind='schema_unsupported'
    elif mentions('thinkingconfig','thinking_config','thinkinglevel','thinking_level')and mentions('not supported','unsupported','unknown name','invalid','unrecognized'):
        kind='thinking_unsupported'
    for wire,camel in [('response_schema','responseSchema'),('thinking_config','thinkingConfig'),('max_output_tokens','maxOutputTokens'),('temperature','temperature')]:
        if wire in hints or camel.lower()in hints:
            fields.append('generationConfig.'+camel)
    return {'kind':kind,'fields':list(dict.fromkeys(fields))[:5]}


MESSAGES={
 'credential':'رفضت Google مفتاح API أو قيوده؛ راجع صلاحية المفتاح للخدمة، ولا تغيّر التفريغ.',
 'account':'رفضت Google إعداد الحساب أو المنطقة أو الفوترة؛ راجع أهلية الحساب للخدمة.',
 'context_limit':'حجم النص يتجاوز حد سياق النموذج؛ قسّم التحليل إلى نطاق أصغر.',
 'json_unsupported':'النموذج لا يدعم وضع استجابة JSON المطلوب؛ اختر نموذج تحليل يدعمه، ثم اختبر التحليل الفعلي.',
 'media_input':'تعذر قبول أو قراءة فيديو/صورة المصدر؛ راجع الملف أو رابط المصدر، دون اعتماد مشهد من العنوان.',
 'schema_complexity':'رفض النموذج تعقيد بنية الاستجابة.',
 'schema_unsupported':'النموذج لا يقبل responseSchema بهذه الصيغة.',
 'thinking_unsupported':'النموذج رفض إعداد التفكير thinkingConfig.',
 'unknown':'رفضت Google صيغة الطلب. السبب الدقيق غير معروف؛ شغّل اختبار التحليل الفعلي بالنموذج المختار، فنجاح قائمة النماذج وحده لا يكفي.',
}
