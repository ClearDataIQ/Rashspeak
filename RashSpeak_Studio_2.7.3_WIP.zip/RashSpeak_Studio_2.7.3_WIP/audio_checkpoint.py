"""Reuse exact processed narration when only context/API/media is retried."""
import hashlib
import json
from pathlib import Path

import audio_edit
from media_tools import Cancelled
from smart_editor import fingerprint,save

REVISION='natural-stereo-tail-flush-2.7'

def render_cached(audio,analysis,project,processing,cancel=None):
    if cancel and cancel.is_set():raise Cancelled('أُلغي استرجاع الصوت.')
    binding={'revision':REVISION,'source':str(Path(audio).resolve()),'input':fingerprint(audio),
             'keeps':analysis['keeps'],'processing':processing}
    binding=json.loads(json.dumps(binding,ensure_ascii=False,allow_nan=False))
    key=hashlib.sha256(json.dumps(binding,sort_keys=True,ensure_ascii=False,allow_nan=False).encode()).hexdigest()
    path=Path(project)/'audio_cache'/(key+'.wav');meta=path.with_suffix('.json')
    try:
        record=json.loads(meta.read_text(encoding='utf-8'))
        if record['binding']==binding and record['sha256']==hashlib.sha256(path.read_bytes()).hexdigest():return str(path),True
    except (OSError,ValueError,KeyError,TypeError):pass
    clean=audio_edit.render_audio(audio,analysis,path,cancel,processing)
    save({'binding':binding,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()},meta)
    return clean,False
