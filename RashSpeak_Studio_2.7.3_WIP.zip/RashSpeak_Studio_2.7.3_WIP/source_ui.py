"""One-time source setup and the shared downloadable-media archive."""
import tkinter as tk
from tkinter import ttk
from pathlib import Path

from rtl_ui import Label, Button, visual
from official_sources import credential, configure_credential, settings, config_path
from smart_editor import save


def open_path(path):
    import os,subprocess,sys
    path=Path(path).resolve()
    if not path.exists():return
    if os.name=='nt':os.startfile(str(path))
    else:subprocess.Popen(['open' if sys.platform=='darwin' else 'xdg-open',str(path)])


def open_settings(parent,candidate=None):
    window=tk.Toplevel(parent);window.title('مصادر اللقطات والأرشيف');window.geometry('760x720')
    body=ttk.Frame(window,padding=16);body.pack(fill='both',expand=True)
    Label(body,text='القنوات الرسمية • خطة لكل جملة • أرشيف مشترك',font=('Segoe UI',15,'bold')).pack(anchor='e')
    Label(body,text='YouTube للقناة الرسمية، وSteam وCommons مصادر بديلة دون مفتاح بحث إضافي. يُحفظ اختيارك لاستخدام المصدر على مسؤوليتك. تُفحص مشاهد الفيديو نفسه وتُحفظ التنزيلات لإعادة استخدامها. يظهر نقص التغطية بدل ملئه بلقطات عشوائية.',wraplength=700,justify='right').pack(fill='x',pady=8)
    book=ttk.Notebook(body);book.pack(fill='both',expand=True)
    api=ttk.Frame(book,padding=12);book.add(api,text=visual('الاتصال'))
    from api_settings_ui import ApiPanel
    ApiPanel(api,'youtube').pack(fill='both',expand=True)
    note=tk.StringVar(value='لا تحفظ المفاتيح داخل المشروع أو ملف الأرشيف.')
    rights=ttk.Frame(book,padding=12);book.add(rights,text=visual('تصاريح المصادر'))
    Label(rights,text='اختر المصدر أو القناة ووافق على استخدامها. لا يلزم إدخال اسم رخصة أو رابط تصريح أو مضيف تنزيل؛ تُضبط بيانات التنزيل من المصدر نفسه.',wraplength=690,justify='right').pack(fill='x',pady=5)
    fields={}
    scopes=[candidate['id']]if candidate else[]
    if candidate and candidate.get('official_channel_checked')and candidate.get('channel_handle'):scopes.append(candidate['channel_handle'])
    if candidate and candidate.get('official_listing_checked')and candidate.get('permission_scope'):scopes.append(candidate['permission_scope'])
    fields['source']=tk.StringVar(value=(candidate or{}).get('id',''))
    Label(rights,text='المصدر أو القناة التي تختار استخدامها').pack(anchor='e')
    if scopes:ttk.Combobox(rights,textvariable=fields['source'],values=scopes,state='readonly').pack(fill='x',pady=4)
    else:ttk.Entry(rights,textvariable=fields['source']).pack(fill='x',pady=4)
    if len(scopes)>1:Label(rights,text='اختر الفيديو وحده، أو القناة/قائمة اللعبة لحفظ اختيارك لمصادرها التالية.',wraplength=680,justify='right').pack(fill='x',pady=5)
    from urllib.parse import urlparse
    direct_host=urlparse((candidate or{}).get('url','')).hostname if (candidate or{}).get('provider')!='youtube'else None
    fields['download_hosts']=tk.StringVar(value=direct_host or'')
    Label(rights,text='مضيفو تنزيل الوسائط — اختياري، يُحدد تلقائيًا إن تركته فارغًا').pack(anchor='e')
    ttk.Entry(rights,textvariable=fields['download_hosts'],justify='left').pack(fill='x',pady=4)
    Label(rights,text='المضيف هو الجزء بعد https:// وقبل أول / في رابط ملف الفيديو، مثل video.fastly.steamstatic.com. ليس اسم قناة YouTube. لا يلزم إدخاله يدويًا؛ تفحص الأداة رابط التنزيل الفعلي.',wraplength=680,justify='right').pack(fill='x',pady=5)
    approved=tk.BooleanVar(value=False)
    ttk.Checkbutton(rights,text=visual('أوافق على استخدام المصدر وتنزيله على مسؤوليتي'),variable=approved).pack(anchor='e',pady=8)
    def save_grant():
        from source_usage import owner_grant
        try:
            key=fields['source'].get().strip()
            if not key or not approved.get():raise ValueError()
            grant=owner_grant(key,fields['download_hosts'].get().split(','))
            cfg=settings();cfg.setdefault('permissions',{})[key]=grant;save(cfg,config_path())
            note.set('حُفظ اختيار المصدر على مسؤوليتك. ارجع واضغط إعادة الفهم واللقطات.')
        except (ValueError,OSError):note.set('حدد المصدر وفعّل الموافقة. المضيف اختياري؛ إن كتبته فأدخل اسم الموقع فقط دون رابط كامل.')
    grant_button=Button(rights,text='حفظ اختيار المصدر',command=save_grant);grant_button.pack(anchor='e',pady=8)
    window.rights_fields=fields;window.rights_approved=approved;window.grant_button=grant_button;window.rights_note=note
    window.source_notebook=book;window.rights_tab=rights
    channels=ttk.Frame(book,padding=12);book.add(channels,text=visual('القنوات المعتمدة'))
    Label(channels,text='يمكن إضافة قناة لأي لعبة أو ناشر. اعتمد الحساب الذي يشير إليه الموقع الرسمي؛ التحقق عبر API يطابق معرّف الحساب المختار ولا يحوّل حسابًا عشوائيًا إلى ناشر رسمي.',wraplength=690,justify='right').pack(fill='x',pady=8)
    game=tk.StringVar();handle=tk.StringVar()
    Label(channels,text='اللعبة أو الناشر').pack(anchor='e');ttk.Entry(channels,textvariable=game).pack(fill='x',pady=5)
    Label(channels,text='اسم القناة مثل @Battlefield').pack(anchor='e');ttk.Entry(channels,textvariable=handle).pack(fill='x',pady=5)
    def save_channel():
        import re
        from licensed_media import game_key
        value=handle.get().strip()
        if not game.get().strip() or not re.fullmatch(r'@[A-Za-z0-9_.-]{2,80}',value):
            note.set('أدخل اسم اللعبة واسم حساب القناة بصيغة @handle.');return
        cfg=settings();cfg.setdefault('channels',{})[game_key(game.get())]=[value];save(cfg,config_path())
        note.set('حُفظت القناة المعتمدة للعبة. تصريح الاستخدام والتنزيل مستقل عن اختيار القناة.')
    Button(channels,text='اعتماد القناة لهذه اللعبة',command=save_channel).pack(anchor='e',pady=8)
    archive=ttk.Frame(book,padding=12);book.add(archive,text=visual('أرشيف التحميلات'))
    Label(archive,text='كل أصل نُزّل يُحفظ مرة واحدة مع SHA256 والمصدر والقناة واللعبة والحدث والعناصر ونطاقه الأصلي. تفحص المشاريع الجديدة هذا الأرشيف قبل البحث والتنزيل. لا يُعاد استخدام أصل لخبر مختلف لمجرد تطابق اسم اللعبة.',wraplength=690,justify='right').pack(fill='x',pady=10)
    def show_archive():
        from media_archive import MediaArchive
        catalog=MediaArchive();open_path(catalog.root/'catalog.json')
    def show_folder():
        from media_archive import MediaArchive
        open_path(MediaArchive().root)
    Button(archive,text='فتح فهرس كل التحميلات',command=show_archive).pack(anchor='e',pady=8)
    Button(archive,text='فتح مجلد الملفات المحفوظة',command=show_folder).pack(anchor='e',pady=8)
    Label(body,textvariable=note,wraplength=700,justify='right').pack(fill='x',pady=8)
    if candidate:book.select(rights)
    return window
