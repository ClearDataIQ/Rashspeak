"""Bounded cache cleanup only for app-owned proxy names, never source media."""
import json
from pathlib import Path
import re


def prune(folder,max_bytes=512*1024*1024,protected=()):
    folder=Path(folder);safe={str(Path(p).resolve()) for p in protected};items=[];total=0;removed=[]
    if not folder.exists():return removed
    for file in folder.iterdir():
        if not file.is_file() or not (re.fullmatch(r'[0-9a-f]{64}\.mp4',file.name) or re.fullmatch(r'frame_[0-9a-f]{16}\.png',file.name)):continue
        parts=[file]
        if file.suffix=='.mp4':parts += [file.with_suffix('.json'),file.with_suffix('.preview.wav')]
        parts=[p for p in parts if p.is_file()];size=sum(p.stat().st_size for p in parts);total+=size
        timestamp=file.stat().st_mtime
        if file.suffix=='.mp4' and file.with_suffix('.json').exists():
            try:timestamp=json.loads(file.with_suffix('.json').read_text(encoding='utf-8')).get('last_access',timestamp)
            except (ValueError,OSError):pass
        items.append((timestamp,size,parts))
    for _,size,parts in sorted(items,key=lambda x:x[0]):
        if total<=max_bytes:break
        if any(str(p.resolve()) in safe for p in parts):continue
        success=True
        for p in parts:
            try:p.unlink(missing_ok=True);removed.append(str(p))
            except OSError:success=False
        if success:total-=size
    return removed
