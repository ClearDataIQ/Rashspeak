"""Download source-licensed Commons video once, then analyse/render local files."""
import hashlib
import math
from pathlib import Path
import requests

from media_tools import Cancelled,duration, run
from official_sources import SourceUnavailable
from smart_editor import save


def source_file(candidate, folder, cancel=None):
    from licensed_media import download
    from media_acquisition import permission
    permission(candidate)
    if candidate.get('provider')=='steam':
        from steam_sources import download_source
        try:return download_source(candidate,folder,cancel)
        except Cancelled:raise
        except SourceUnavailable:raise
        except (OSError,RuntimeError,ValueError,requests.RequestException):
            raise SourceUnavailable('لم يكتمل فحص فيديو Steam الفعلي أو ملف التنزيل.') from None
    item=candidate.get('commons_metadata',{})
    if (candidate.get('provider')!='commons_video' or not item.get('mime','').startswith('video/')
            or any(candidate.get(k)!=item.get(k) for k in ('url','source','license','author'))
            or candidate['permission']['evidence_url']!=item.get('license_url') and not candidate.get('permission_from_settings')):
        raise SourceUnavailable('بيانات تنزيل الفيديو لا تطابق مصدر الرخصة.')
    if item.get('rights_review_required') and candidate.get('permission_from_settings'):
        from source_usage import evidence,OWNER
        if candidate['permission'].get('usage_basis')==OWNER:
            item={**item,**evidence(candidate['permission']),'rights_review_approved':False}
        else:item={**item,'rights_review_approved':True,'approval_evidence':candidate['permission']['evidence_url']}
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    try:
        source=download(item,folder,cancel)
        from media_tools import probe
        info=probe(source);video=next(s for s in info['streams']if s.get('codec_type')=='video')
        candidate.update(width=video['width'],height=video['height'])
        seconds=duration(source)
        if abs(seconds-candidate['duration'])>.5:
            raise ValueError('duration changed')
    except (OSError,RuntimeError,ValueError,StopIteration,requests.RequestException) as exc:
        if isinstance(exc,Cancelled):raise
        raise SourceUnavailable('لم يكتمل تنزيل فيديو الإنترنت أو لا تطابق مدته بيانات المصدر.') from None
    return source


def analysis_proxy(candidate, folder, cancel=None,start=0.):
    """Actual silent source frames, at original timestamps, never generated visuals."""
    source=source_file(candidate,Path(folder)/'sources',cancel)
    from media_library import digest
    sha=digest(source,cancel)
    if type(start)not in (int,float) or not math.isfinite(start) or not 0<=start<candidate['duration']:
        raise ValueError('نافذة التحليل خارج المصدر.')
    seconds=min(180.,candidate['duration']-start)
    identity=sha+'|'+str(seconds)+'|v2'+('' if start==0 else '|start='+str(start))
    key=hashlib.sha256(identity.encode()).hexdigest()
    proxy=Path(folder)/(key+'.mp4')
    if not proxy.is_file():
        pending=proxy.with_suffix('.pending.mp4')
        try:
            run(['ffmpeg','-v','error','-y','-ss',str(start),'-i',source,'-t',str(seconds),'-an',
                 '-vf','scale=640:360:force_original_aspect_ratio=decrease,pad=640:360:(ow-iw)/2:(oh-ih)/2,fps=8,setsar=1',
                 '-threads','2','-c:v','libx264','-preset','fast','-crf','30',
                 '-maxrate','300k','-bufsize','600k','-movflags','+faststart',pending],cancel=cancel)
            if pending.stat().st_size>10_000_000 or abs(duration(pending)-seconds)>.3:
                raise SourceUnavailable('نسخة تحليل الفيديو تتجاوز الحد أو لا تطابق توقيت المصدر.')
            pending.replace(proxy)
        finally:
            pending.unlink(missing_ok=True)
    save({'source_id':candidate['id'],'source':candidate['source'],'license':candidate['license'],
          'author':candidate['author'],'original':str(source),'proxy':str(proxy),
          'source_sha256':sha,
          'analysed_start':start,'analysed_end':start+seconds,'input':'actual_downloaded_source_video'},
         proxy.with_suffix('.json'))
    return proxy,seconds


def excerpt(candidate,start,end,folder,cancel=None):
    from app_paths import app_dir
    import requests
    try:
        source=source_file(candidate,app_dir()/'output'/'media_archive'/'internet_sources'/'sources',cancel)
    except requests.RequestException:
        raise SourceUnavailable('تعذر تنزيل فيديو الإنترنت من مصدره.') from None
    target=Path(folder)/'excerpt.mp4'
    count=math.ceil((end-start)*30-1e-8)
    run(['ffmpeg','-v','error','-y','-ss',str(start),'-i',source,'-an',
         '-vf',f"trim=duration={end-start},setpts=PTS-STARTPTS,fps=30,scale=w='min(1920,iw)':h='min(1080,ih)':force_original_aspect_ratio=decrease:force_divisible_by=2,setsar=1,tpad=stop_mode=clone:stop_duration=0.1",
         '-frames:v',str(count),
         '-threads','2','-c:v','libx264','-preset','fast','-crf','20','-movflags','+faststart',target],cancel=cancel)
    if abs(duration(target)-count/30)>.02:
        raise SourceUnavailable('مدة مقتطف الإنترنت لا تطابق النطاق المطلوب.')
    return target
