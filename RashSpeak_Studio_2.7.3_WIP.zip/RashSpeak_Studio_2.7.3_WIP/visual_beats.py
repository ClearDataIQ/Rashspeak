"""Visual-only word anchors; narration and caption text are never edited here."""
from copy import deepcopy

from caption_layout import timed_words
from smart_editor import normalize

ALIASES = {
    'swords': ('sword','swords','sword combat','sword fighting','سيف','السيف','سيوف','السيوف'),
    'magic': ('magic','spells','spell','spellcasting','magic casting','سحر','السحر','تعويذات','التعويذات'),
    'shields': ('shield','shields','درع','الدرع','دروع','الدروع'),
    'gunfire': ('gunfire','shooting','إطلاق النار','اطلاق النار'),
    'driving': ('driving','قيادة','القيادة'),
    'stealth': ('stealth','تسلل','التسلل'),
}
LOOKUP={normalize(v):key for key,values in ALIASES.items()for v in (key,*values)}


def entity_key(text):
    value=normalize(text)
    if value in LOOKUP:return LOOKUP[value]
    if value.startswith(('و','ف'))and value[1:]in LOOKUP:return LOOKUP[value[1:]]
    return value


def entity_keys(values):
    return {entity_key(v)for v in values}


def _matches(spoken,entity):
    if entity_key(spoken)==entity_key(entity):return True
    a,b=normalize(spoken),normalize(entity)
    return len(b)>=4 and a.startswith(('و','ف'))and a[1:]==b


def split_segments(segments):
    """Split only the visual plan at verified spoken nouns/actions, in source order."""
    result=[]
    for parent_index,segment in enumerate(segments):
        semantic=segment.get('semantic')or{}
        if semantic.get('visual','gameplay')not in ('gameplay','title'):
            result.append(deepcopy(segment));continue
        words=timed_words(segment)
        if not words:
            result.append(deepcopy(segment));continue
        game=semantic.get('game')or segment.get('story_topic','')
        explicit=[e for e in semantic.get('entities',[])if normalize(e)!=normalize(game)]
        anchors=[]
        for i,word in enumerate(words):
            matches=[]
            for entity in explicit:
                for n in range(1,min(6,len(words)-i)+1):
                    phrase=' '.join(w['text']for w in words[i:i+n])
                    if _matches(phrase,entity):matches.append((entity,n));break
            if not matches:
                for n in range(1,min(3,len(words)-i)+1):
                    phrase=' '.join(w['text']for w in words[i:i+n])
                    key=entity_key(phrase)
                    if key in ALIASES:matches=[(key,n)];break
            if matches:
                entity,n=matches[0]
                if not anchors or entity_key(anchors[-1]['entity'])!=entity_key(entity):
                    anchors.append({'index':i,'entity':entity,'width':n})
        if not anchors:
            result.append(deepcopy(segment));continue
        # Entities absent from the timing evidence remain requirements on every beat.
        anchored=entity_keys(a['entity']for a in anchors)
        remaining=[e for e in explicit if entity_key(e)not in anchored]
        for index,anchor in enumerate(anchors):
            a=0 if index==0 else anchor['index']
            b=anchors[index+1]['index']if index+1<len(anchors)else len(words)
            start=segment['start']if index==0 else words[a]['start']
            end=segment['end']if b==len(words)else words[b]['start']
            if end<=start:continue
            row=deepcopy(segment)
            row.update(start=start,end=end,text=' '.join(w['text']for w in words[a:b]),
                       words=deepcopy(words[a:b]),visual_parent_index=parent_index,
                       visual_beat_index=index,visual_entity=anchor['entity'],
                       source_sentence_text=segment['text'])
            context=deepcopy(semantic)
            context.update(game=game,entities=[*remaining,anchor['entity']],
                           idea=' '.join(x for x in (semantic.get('idea',''),anchor['entity'])if x))
            if index:context.update(meme=False,effect='none')
            context['queries']=[' '.join(x for x in (game,semantic.get('event',''),anchor['entity'])if x)]
            row['semantic']=context;result.append(row)
    return result
