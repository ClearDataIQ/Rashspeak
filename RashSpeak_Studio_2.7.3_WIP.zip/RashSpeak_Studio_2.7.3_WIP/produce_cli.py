"""The same two-input engine for Windows/Linux automation; no publication."""
import argparse
from pathlib import Path
import sys
from production import produce


def main():
    parser=argparse.ArgumentParser(description='RashSpeak: narration + script -> local deliverables')
    parser.add_argument('--audio',required=True)
    parser.add_argument('--script',help='Optional UTF-8 script for caption proofreading')
    parser.add_argument('--project',help='New or unchanged saved production directory')
    parser.add_argument('--model',help='Local faster-whisper model directory')
    parser.add_argument('--offline',action='store_true',help='Use explicit topic cards instead of online media')
    parser.add_argument('--auto',action='store_true',help='Explicitly bypass owner reviews for a batch/test run')
    args=parser.parse_args()
    if hasattr(sys.stdout,'reconfigure'):sys.stdout.reconfigure(encoding='utf-8')
    def event(item):
        if item['type']=='stage':print(item['detail'],flush=True)
        elif item['type']=='log':print(item['message'],flush=True)
    if not args.auto and not sys.stdin.isatty():
        parser.error('Use an interactive terminal for stage reviews, or --auto explicitly for a batch/test run.')
    def review(request):
        import json
        print('\nReview:',request['label'])
        for item in request['previews']:print(item['label'],item['path'])
        if request['error']:print('Needs correction:',request['error'])
        path=Path(request['work'])/'reviews'/f"{request['key']}_pending.json"
        print('Edit the data section in:',path)
        while True:
            answer=input('[a] approve current preview / [e] apply JSON edits and regenerate / [q] stop: ').strip().lower()
            if answer=='a' and not request['error']:return {'action':'approve'}
            if answer=='e':return {'action':'revise','data':json.loads(path.read_text(encoding='utf-8'))['data']}
            if answer=='q':return {'action':'cancel'}
    try:
        result=produce(args.audio,Path(args.script).read_text(encoding='utf-8-sig')if args.script else'',args.project,
                       online=not args.offline,model=args.model,on_event=event,on_review=None if args.auto else review)
    except Exception as exc:print(str(exc),file=sys.stderr);return 1
    print('Delivery:',result['delivery'])
    for warning in result['warnings']:print(warning)
    return 0


if __name__=='__main__':raise SystemExit(main())
