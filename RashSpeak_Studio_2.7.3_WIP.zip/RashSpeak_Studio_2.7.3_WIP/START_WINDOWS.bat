@echo off
chcp 65001 >nul
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0bootstrap.ps1" -Launch
if errorlevel 1 (
 echo.
 echo Application could not start. See the error above or retry INSTALL_WINDOWS.bat.
 pause
 exit /b 1
)
exit /b 0
