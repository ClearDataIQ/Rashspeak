"""Width-aware caption pages; word times are accepted only when text agrees."""
from functools import lru_cache
import math
import os
from pathlib import Path
import shutil
import subprocess
import unicodedata


def clean(text):
    # Keep logical Unicode for libass; strip directional/ASS injection only.
    value = ''.join(c for c in str(text) if unicodedata.category(c) != 'Cf')
    return ' '.join(value.replace('\\', '／').replace('{', '〔').replace('}', '〕').split())


@lru_cache(maxsize=64)
def font_path(family, bold=False, explicit=None):
    if explicit and Path(explicit).is_file():
        return str(Path(explicit).resolve())
    if Path(family).is_file():
        return family
    # fontconfig selects the same Arabic-capable fallback used by libass on Linux.
    if shutil.which('fc-match'):
        try:
            value = subprocess.run(['fc-match', '-f', '%{file}',
                                    f'{family}:weight={"bold" if bold else "regular"}:charset=0627'],
                                   capture_output=True, text=True, timeout=5, check=True).stdout.strip()
            if Path(value).is_file():
                return value
        except (OSError, subprocess.SubprocessError):
            pass
    # Pillow also searches the Windows font folder by filename.
    candidates = [family, family + '.ttf']
    if family.lower() == 'arial':
        candidates.insert(0, 'arialbd.ttf' if bold else 'arial.ttf')
    if os.name == 'nt':
        candidates += [str(Path(os.getenv('WINDIR', 'C:/Windows')) / 'Fonts' / f)
                       for f in candidates[:]]
        # Linux project fonts (e.g. DejaVu Sans) often aren't installed on
        # Windows. Measure an actual Arabic-capable system fallback rather
        # than assigning every Arabic letter an unshaped estimated width.
        # This is also libass's Windows fallback for the default Arial style.
        fonts = Path(os.getenv('WINDIR', 'C:/Windows')) / 'Fonts'
        candidates += [str(fonts / ('arialbd.ttf' if bold else 'arial.ttf')),
                       str(fonts / ('segoeuib.ttf' if bold else 'segoeui.ttf')),
                       str(fonts / 'tahoma.ttf')]
    from PIL import ImageFont
    for value in candidates:
        try:
            ImageFont.truetype(value, 24)
            return value
        except OSError:
            pass
    return None


def text_measure(family, size, bold=False, explicit=None):
    """Shape only for measuring; captions themselves always remain logical RTL."""
    from PIL import ImageFont, features
    path = font_path(family, bold, explicit)
    if path is None:
        # Missing fonts must not stop editing. Export still uses libass fallback.
        return lambda text: sum(.35 if c.isspace() else .7 for c in text) * size
    font = ImageFont.truetype(path, max(1, round(size)))
    raqm = features.check_feature('raqm')

    @lru_cache(maxsize=4096)
    def measure(text):
        if not raqm:
            # Windows Pillow builds may lack libraqm. This is metrics only.
            import arabic_reshaper
            from bidi.algorithm import get_display
            text = get_display(arabic_reshaper.reshape(text))
        return float(font.getlength(text)) * size / max(1, round(size))
    return measure


def timed_words(segment):
    words = segment.get('words') or []
    if (not isinstance(words,list) or not words or
            any(not isinstance(w,dict) or not isinstance(w.get('text'),str) or not clean(w['text']) for w in words)):
        return []
    if clean(' '.join(w['text'] for w in words)) != clean(segment['text']):
        return []
    previous = float(segment['start'])
    result = []
    for word in words:
        try:
            start, end = float(word['start']), float(word['end'])
        except (KeyError, TypeError, ValueError):
            return []
        if (not all(math.isfinite(x) for x in (start, end)) or
                start < previous - .001 or not start < end <= segment['end'] + .001):
            return []
        start, end = max(start, previous), min(end, segment['end'])
        if end <= start:
            return []
        result.append({'text': clean(word['text']), 'start': start, 'end': end})
        previous = end
    return result


def layout(segments, max_width=38, measure=len):
    """At most two balanced lines; never split a word or infer word highlights."""
    result = []
    for segment in segments:
        words = timed_words(segment)
        atoms = [w['text'] for w in words] if words else clean(segment['text']).split()
        if not atoms:
            continue
        # Keep short Latin game names together in mixed Arabic/English captions.
        # Longer names use the largest complete chunks that fit the line.
        locked = set()
        def latin(token):
            names = [unicodedata.name(c, '') for c in token]
            return (any('LATIN' in n for n in names) or token.strip('.,!?؟،').isdigit()) and not any('ARABIC' in n for n in names)
        def fits(text):
            width = measure(text)
            # A small page font adjustment is clearer than isolating the game's number.
            return width <= max_width or (width <= max_width * 1.08 and all(latin(t)for t in text.split()))
        run = 0
        while run < len(atoms):
            if not latin(atoms[run]):
                run += 1
                continue
            finish = run + 1
            while finish < len(atoms) and latin(atoms[finish]):
                finish += 1
            while run < finish:
                stop = run + 1
                while stop < finish and fits(' '.join(atoms[run:stop + 1])):
                    stop += 1
                locked.update(range(run + 1, stop))
                run = stop
        groups = []
        begin = 0
        while begin < len(atoms):
            stop = begin
            for _ in range(2):
                if stop >= len(atoms):
                    break
                choices = (i for i in range(stop + 1, len(atoms) + 1) if i not in locked)
                end = next(choices)
                for candidate in choices:
                    if not fits(' '.join(atoms[stop:candidate])):
                        break
                    end = candidate
                stop = end
            text = ' '.join(atoms[begin:stop])
            if fits(text) or stop == begin + 1:
                lines = [text]
            else:
                options = []
                for split in range(begin + 1, stop):
                    if split in locked:
                        continue
                    left, right = ' '.join(atoms[begin:split]), ' '.join(atoms[split:stop])
                    a, b = measure(left), measure(right)
                    if fits(left) and fits(right):
                        options.append((abs(a - b), split, left, right))
                if options:
                    _, _, left, right = min(options)
                    lines = [left, right]
                else:
                    # A single unusually long token is kept intact and fitted by ASS.
                    stop = begin + 1
                    lines = [atoms[begin]]
            groups.append((begin, stop, lines))
            begin = stop
        total = sum(len(' '.join(atoms[a:b])) for a, b, _ in groups)
        at = segment['start']
        for i, (a, b, lines) in enumerate(groups):
            if i == len(groups) - 1:
                end = segment['end']
            elif words:
                end = words[b]['start']
            else:
                end = at + (segment['end'] - segment['start']) * len(' '.join(atoms[a:b])) / total
            result.append({'start': at, 'end': end, 'text': '\n'.join(lines),
                           'words': words[a:b] if words else [],
                           'timing_source': 'word_times' if words else 'segment_estimate',
                           'scale': min(1., max_width / max(1, *(measure(line) for line in lines)))})
            at = end
    return result
