"""Reversible source-time edits: pauses, repeated takes, explicit restarts.

An ASR mismatch alone is never evidence that the creator made a mistake.
"""
import difflib
import hashlib
import math
from pathlib import Path
import re
import tempfile
import unicodedata
import wave

import captions
from media_tools import run, duration, Cancelled


def tokens(text):
    text=unicodedata.normalize('NFKC',str(text)).lower()
    text=re.sub('[\u064b-\u065f\u0670\u0640]','',text).translate(str.maketrans('أإآىة','ااايه'))
    return re.findall(r'[\w]+',text)


def word_units(words, limit):
    result=[];previous=0
    for word_index,word in enumerate(words):
        start,end=float(word['start']),float(word['end'])
        if not all(math.isfinite(x) for x in (start,end)) or not 0<=start<end<=limit+.02:
            raise ValueError('توقيت كلمة خارج التسجيل.')
        if start < previous-.001:raise ValueError('الكلمات متداخلة؛ راجع التفريغ.')
        pieces=tokens(word['text'])
        for i,piece in enumerate(pieces):
            result.append({'start':start+(end-start)*i/len(pieces),'end':start+(end-start)*(i+1)/len(pieces),
                           'text':piece,'original':word['text'],'probability':word.get('probability',0),
                           'word_index':word_index,'word_start':start,'word_end':end})
        previous=max(previous,end)
    return result


def decision(start,end,kind,text='',confidence=1,action='remove'):
    value={'start':round(start,6),'end':round(end,6),'kind':kind,'text':text,
           'confidence':confidence,'action':action}
    value['id']=hashlib.sha256(f'{start:.4f}|{end:.4f}|{kind}'.encode()).hexdigest()[:16]
    return value


def alignment(written, spoken):
    """Monotonic script positions, with equal matches preferring the latest take."""
    result={}
    matcher=difflib.SequenceMatcher(None,written[::-1],spoken[::-1],autojunk=False)
    for block in matcher.get_matching_blocks():
        for offset in range(block.size):
            result[len(spoken)-1-block.b-offset]=len(written)-1-block.a-offset
    return result


def last_takes(script, units, written):
    """Replace nearby restarts of one script passage; never cut intervening stories.

    Alignment alone prefers the longest take, which is wrong for a final partial
    take. Detect restarted prefixes first, then align the remaining words.
    """
    spoken=[w['text'] for w in units];mapping=alignment(written,spoken)
    script_positions={}
    for p,word in enumerate(written):script_positions.setdefault(word,[]).append(p)
    sentence_ends=[];at=0
    for sentence in re.split(r'(?<=[.!؟])\s+|\n+',script.strip()):
        at+=len(tokens(sentence));sentence_ends.append(at)
    removed=set();edits=[];warnings=[]
    markers={'لا','اقصد','نعيد','اعيد','غلط','خلني','من','جديد'}
    for j in range(1,len(units)):
        if units[j]['word_index']==units[j-1]['word_index']:continue
        for i in range(j-1,max(-1,j-61),-1):
            if i in removed or spoken[i]!=spoken[j] or units[j]['start']-units[i]['start']>25:continue
            # Two separate intended occurrences in the script are not retakes.
            if i in mapping and j in mapping and mapping[i]!=mapping[j]:continue
            common=0
            while i+common<j and j+common<len(units) and spoken[i+common]==spoken[j+common]:common+=1
            immediate=j==i+1
            positions=[p for p in script_positions.get(spoken[j],[]) if written[p:p+common]==spoken[j:j+common]]
            p=mapping.get(j,mapping.get(i))
            if p is None:
                if len(positions)!=1:continue
                p=positions[0]
            if p not in positions:continue
            stop=next((e for e in sentence_ends if e>p),len(written))
            target=written[p:stop]
            explicit=any(x in spoken[i:j] for x in ('اقصد','نعيد','اعيد','غلط')) or 'لا لا' in ' '.join(spoken[i:j])
            whole_final=spoken[j:j+len(target)]==target and len(target)>=3
            partial_final=j==len(units)-1 and spoken[i:i+len(target)]==target and units[j]['start']-units[j-1]['end']>=.4
            sentence_start=p==0 or p in sentence_ends
            if common<2 and not immediate and not (sentence_start and len(positions)==1 and (whole_final or partial_final or explicit)):continue
            # A restart cannot swallow a different sentence, even if it shares words.
            if any(not p<=mapping[k]<stop for k in range(i,j) if k in mapping):continue
            earlier=[x for x in spoken[i:j] if x not in markers]
            matched=sum(b.size for b in difflib.SequenceMatcher(None,target,earlier,autojunk=False).get_matching_blocks())
            if matched/max(1,len(earlier))<(.35 if whole_final or explicit else .65):continue
            a=units[i]['word_start']
            if i and units[i-1]['word_end']>a:continue
            a=max(units[i-1]['word_end'] if i else 0,a-.04)
            b=max(units[j-1]['word_end'],units[j]['word_start']-.04)
            if b>units[j]['word_start']+.001:continue
            edits.append(decision(a,b,'repeat',' '.join(spoken[i:j]),.97))
            removed.update(range(i,j))
            # Never substitute the earlier suffix to make an incomplete last take whole.
            later=spoken[j:j+len(target)]
            if len(target)>common and later!=target and spoken[i:i+len(target)]==target:
                warnings.append('آخر محاولة غير مكتملة أو مختلفة عن السكربت؛ احتُفظ بها ولم تُستكمل من محاولة سابقة.')
            break
    return removed,edits,warnings


def analyse(script, words, silences, limit, overrides=None, pause=.22):
    """Choose the last matching take. Uncertain deviations remain audible."""
    if not script.strip():raise ValueError('السكربت مطلوب لمقارنة التسجيل.')
    if not math.isfinite(limit) or limit<=0:raise ValueError('مدة تسجيل غير صالحة.')
    units=word_units(words,limit);spoken=[w['text'] for w in units];written=tokens(script)
    removed,edits,warnings=last_takes(script,units,written)
    remaining=[k for k in range(len(units)) if k not in removed]
    mapping=alignment(written,[spoken[k] for k in remaining])
    matches={remaining[k] for k in mapping};script_hits=set(mapping.values())
    coverage=len(script_hits)/max(1,len(written))
    for start,end in silences:
        start,end=max(0,float(start)),min(limit,float(end))
        if end-start<.65:continue
        a,b=(start,end-pause) if start<.03 else (start+pause/2,end) if end>=limit-.03 else (start+pause/2,end-pause/2)
        # Protect detected words, including quiet speech inside silence detector spans.
        if b>a and not any(w['start']<b and w['end']>a for w in units):
            edits.append(decision(a,b,'silence','سكوت طويل'))
        elif b>a:warnings.append('سكوت يتقاطع مع كلمة؛ تُرك لحماية الكلام.')
    unmatched=[];i=0
    while i<len(units):
        if i in matches or i in removed:i+=1;continue
        j=i+1
        while j<len(units) and j not in matches and j not in removed:j+=1
        unmatched.append((i,j));i=j
    for i,j in unmatched:
        chunk=spoken[i:j];text=' '.join(chunk)
        if not chunk:continue
        start,end=units[i]['word_start'],units[j-1]['word_end']
        repeat=next((k for k in range(j,min(len(units)-len(chunk)+1,j+60))
                     if len(chunk)>=2 and spoken[k:k+len(chunk)]==chunk
                     and units[k]['start']-end<=25
                     and all(n in matches for n in range(k,k+len(chunk)))),None)
        marker=any(phrase in text for phrase in ('لا لا','اقصد','نعيد','اعيد','من جديد','خلني اعيد','غلط'))
        left=sum(k in matches for k in range(max(0,i-3),i))
        right=sum(k in matches for k in range(j,min(len(units),j+3)))
        single_repeat=len(chunk)==1 and j<len(units) and spoken[j]==chunk[0] and j in matches
        if single_repeat and coverage>=.65:
            edits.append(decision(start,max(end,units[j]['start']-.05),'repeat',text,.97))
        elif repeat is not None and coverage>=.65:
            # Only the unmatched chunk is removed, never speech between occurrences.
            edits.append(decision(start,end,'repeat',text,.97))
        elif marker and coverage>=.72 and right>=3 and (left>=2 or i==0) and end-start<=12:
            edits.append(decision(start,end,'restart',text,.90))
        else:
            edits.append(decision(start,end,'uncertain',text,.35,'keep'))
    if coverage<.65:warnings.append('مطابقة السكربت ضعيفة؛ تُحفظ الاختلافات ولا تُحذف أخطاء تخمينية.')
    if not units:warnings.append('لا توجد توقيتات كلمات؛ تنظيف السكوت فقط دون حذف إعادة أو خطأ.')
    overrides=overrides or {}
    for edit in edits:
        low_confidence=any(w.get('probability',1)<.5 and w['start']<edit['end'] and w['end']>edit['start'] for w in words)
        if edit['kind']!='silence' and low_confidence:
            edit.update(action='keep',confidence=.4,review_needed=True,reason='التفريغ ضعيف داخل هذا النطاق؛ اسمعه قبل الحذف.')
        if edit['id'] in overrides:
            if overrides[edit['id']] not in ('keep','remove'):raise ValueError('قرار تعديل غير صالح.')
            edit['action']=overrides[edit['id']];edit['manual']=True
    for edit in edits:
        if edit['action']=='remove' and any(
            w['start']<edit['start']<w['end']-.001 or w['start']+.001<edit['end']<w['end']
            for w in words):
            raise ValueError('القص يقطع كلمة؛ استرجع القرار أو صحح توقيت التفريغ.')
    keeps=keep_ranges(edits,limit)
    return {'version':'2.2','source_duration':limit,'coverage':round(coverage,3),'edits':edits,'keeps':keeps,
            'clean_duration':round(sum(b-a for a,b in keeps),6),'warnings':warnings}


def keep_ranges(edits,limit):
    cuts=[]
    for edit in sorted((e for e in edits if e['action']=='remove'),key=lambda e:e['start']):
        a,b=float(edit['start']),float(edit['end'])
        if not 0<=a<b<=limit:raise ValueError('نطاق قص غير صالح.')
        if cuts and a<=cuts[-1][1]:cuts[-1][1]=max(cuts[-1][1],b)
        else:cuts.append([a,b])
    result=[];at=0
    for a,b in cuts:
        if a>at:result.append([at,a])
        at=b
    if limit>at:result.append([at,limit])
    if sum(b-a for a,b in result)<.5:raise ValueError('القص سيزيل التسجيل كله؛ أعد مراجعة القرارات.')
    return result


def source_time(at,keeps):
    elapsed=0
    for a,b in keeps:
        if a<=at<=b:return elapsed+at-a
        elapsed+=b-a
    return None


def remap_words(words,keeps):
    result=[]
    for word in words:
        for a,b in keeps:
            start,end=float(word['start']),float(word['end'])
            if start>=a-.001 and end<=b+.001:
                result.append({**word,'start':source_time(max(a,start),keeps),'end':source_time(min(b,end),keeps)})
                break
            if start<b-.001 and end>a+.001:
                raise ValueError('القص يقطع كلمة؛ لا يمكن إعادة توقيت كلمة ناقصة.')
    return result


def segments_from_words(words):
    result=[];group=[]
    def flush():
        if group:
            result.append({'start':group[0]['start'],'end':group[-1]['end'],'text':' '.join(w['text'] for w in group),'mode':'auto',
                           'sentence_end':group[-1]['text'].rstrip().endswith(('.', '؟','!'))})
            group.clear()
    for word in words:
        if group and word['start']-group[-1]['end']>.55:
            flush();result[-1]['sentence_end']=True
        group.append(word)
        if len(group)>=11 or word['end']-group[0]['start']>=4.5 or word['text'].endswith(('.', '؟','!')):flush()
    flush()
    return result


def detect_silences(audio,limit,cancel=None,threshold=-38):
    # media_tools.run returns stdout; silencedetect logs are deliberately captured here.
    with tempfile.TemporaryDirectory(prefix='rash_silence_') as folder:
        metadata=Path(folder)/'silence.txt'
        run(['ffmpeg','-v','error','-y','-i',audio,'-af',
             'silencedetect=noise='+str(threshold)+'dB:d=0.65,ametadata=mode=print:file=silence.txt',
             '-f','null','-'],cwd=folder,cancel=cancel,timeout=max(600,limit*2))
        data=metadata.read_text(encoding='utf-8') if metadata.exists() else ''
    starts=[float(x) for x in re.findall(r'lavfi.silence_start=([\d.]+)',data)]
    ends=[float(x) for x in re.findall(r'lavfi.silence_end=([\d.]+)',data)]
    if len(starts)>len(ends):ends.append(limit)
    return list(zip(starts,ends))


def waveform(audio,bins=160,cancel=None):
    """Measured peak envelope, bounded memory even for a two-hour input."""
    import array
    with tempfile.TemporaryDirectory(prefix='rash_wave_') as folder:
        file=Path(folder)/'wave.wav'
        run(['ffmpeg','-v','error','-y','-i',audio,'-vn','-ac','1','-ar','8000','-c:a','pcm_s16le',file],cancel=cancel)
        with wave.open(str(file),'rb') as source:
            frames=source.getnframes();count=min(bins,frames);peaks=[]
            for i in range(count):
                if cancel and cancel.is_set():raise Cancelled('أُلغي تحليل الموجة.')
                size=(i+1)*frames//count-i*frames//count
                values=array.array('h',source.readframes(size))
                peaks.append(max((abs(v) for v in values),default=0)/32768)
            return {'duration':frames/source.getframerate(),'peaks':peaks}


def preview_cut(audio,edit,output,cancel=None,context=1.5):
    """Source context to audition a decision before changing it."""
    start=max(0,edit['start']-context)
    end=min(duration(audio,'audio'),edit['end']+context)
    run(['ffmpeg','-v','error','-y','-ss',str(start),'-i',audio,'-t',str(end-start),
         '-vn','-ar','48000','-c:a','pcm_s16le',output],cancel=cancel)
    return str(output)


def render_audio(audio,analysis,output,cancel=None,processing=None):
    """Sample-accurate splices, tiny ramps at edits, original retained untouched."""
    output=Path(output).resolve();output.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='rash_audio_') as folder:
        tmp=Path(folder);pcm=tmp/'source.wav'
        from media_tools import probe
        info=probe(audio);channels=next(s.get('channels',1)for s in info['streams']if s.get('codec_type')=='audio')
        if channels not in (1,2):raise ValueError('تسجيل التعليق يدعم Mono أو Stereo؛ اختر المسار الصوتي المناسب بدل مزج قنوات متعددة تلقائيًا.')
        run(['ffmpeg','-v','error','-y','-i',audio,'-map','0:a:0','-vn','-ar','48000','-ac',channels,'-c:a','pcm_s16le',pcm],cancel=cancel)
        import array
        stitched=tmp/'stitched.wav'
        with wave.open(str(pcm),'rb') as source,wave.open(str(stitched),'wb') as dest:
            dest.setparams(source.getparams());rate=source.getframerate()
            for a,b in analysis['keeps']:
                if cancel and cancel.is_set():raise Cancelled('أُلغي تنظيف الصوت.')
                source.setpos(min(source.getnframes()-1,round(a*rate)))
                values=array.array('h',source.readframes(round((b-a)*rate)))
                ramp=min(144,len(values)//channels//2)
                for i in range(ramp):
                    for channel in range(channels):
                        first=i*channels+channel;last=len(values)-(i+1)*channels+channel
                        values[first]=round(values[first]*i/max(1,ramp))
                        values[last]=round(values[last]*i/max(1,ramp))
                dest.writeframes(values.tobytes())
        staged=tmp/'processed.wav'
        from voice_processing import DEFAULTS,fixed_gain
        settings={**DEFAULTS,**(processing or {})}
        if (not 0<=float(settings['highpass'])<=100 or not -80<=float(settings['noise_floor'])<=-20
                or not -20<=float(settings['loudness'])<=-14 or type(settings['normalize'])is not bool or type(settings['denoise'])is not bool):
            raise ValueError('إعدادات معالجة الصوت خارج النطاق المناسب للصوت البشري.')
        filters=[]
        if settings['highpass']:filters.append('highpass=f='+str(settings['highpass']))
        if settings['denoise']:
            from media_tools import filter_option_supported
            smoothing=':gs=12'if filter_option_supported('afftdn','gs')else''
            # Older afftdn drops its final FFT window unless the input is
            # flushed. Pad before filtering and trim to the exact real PCM
            # sample count afterward; never replace a clipped final word with
            # silence after the fact.
            with wave.open(str(stitched),'rb')as source:real_samples=source.getnframes()
            filters.append('apad=pad_len=4800')
            filters.append('afftdn=nr=4:nf='+str(settings['noise_floor'])+':tn=1'+smoothing)
            filters.append('atrim=end_sample='+str(real_samples))
        filtered=stitched
        if filters:
            filtered=tmp/'filtered.wav'
            run(['ffmpeg','-v','error','-y','-i',stitched,'-af',','.join(filters),'-c:a','pcm_s16le',filtered],cancel=cancel)
        gain,metrics=fixed_gain(filtered,tmp,settings['loudness'],cancel)if settings['normalize']else(0.,{})
        run(['ffmpeg','-v','error','-y','-i',filtered,'-af','volume='+str(gain)+'dB',
             '-ar','48000','-ac',channels,'-c:a','pcm_s16le',staged],cancel=cancel)
        analysis['audio_processing']={'mode':'natural_fixed_gain','channels':channels,'denoise':settings['denoise'],**metrics}
        actual=duration(staged,'audio')
        if abs(actual-analysis['clean_duration'])>.06:raise RuntimeError('مدة الصوت المنظف لا تطابق خطة القص.')
        pending=output.with_suffix('.pending.wav');pending.write_bytes(staged.read_bytes());pending.replace(output)
    return str(output)
