"""Content-checked synthetic image/video probes, separate from listing and text."""
import tempfile
from pathlib import Path
from PIL import Image,ImageDraw

from api_connections import ConnectionError,validate_key,current_key
from gemini_client import GeminiClient,GeminiError
from media_tools import run


def check_media(kind,value='',model=None,cancel=None,ai_provider=None,base_url=None):
    if kind not in ('image','video'):raise ConnectionError('نوع فحص غير صالح.')
    key=validate_key(value)or current_key(ai_provider or'gemini')
    if not key:raise ConnectionError('أدخل مفتاح المزوّد أولًا.')
    try:
        kwargs={'provider':ai_provider,'base_url':base_url}if ai_provider else{}
        client=GeminiClient(key=key,model=model,cancel=cancel,**kwargs)
        with tempfile.TemporaryDirectory(prefix='rash-ai-probe-')as folder:
            folder=Path(folder)
            if kind=='image':
                path=folder/'probe.png';im=Image.new('RGB',(320,180),'white');ImageDraw.Draw(im).rectangle((80,40,240,140),fill='red');im.save(path)
                expected={'object_color':'red'};supplied={'image_path':path}
                system='Inspect the provided test image. Return the color of the large central rectangle as object_color, in lowercase English. JSON only.'
            else:
                path=folder/'probe.mp4'
                run(['ffmpeg','-v','error','-y','-f','lavfi','-i','color=c=red:s=320x180:r=10:d=1',
                     '-f','lavfi','-i','color=c=blue:s=320x180:r=10:d=1','-filter_complex','[0:v][1:v]concat=n=2:v=1:a=0[v]',
                     '-map','[v]','-an','-c:v','libx264','-threads','1',path],cancel=cancel)
                expected={'first_color':'red','last_color':'blue'};supplied={'video_path':path}
                system='Inspect the full provided test video. Return its first_color and last_color as lowercase English color names. JSON only.'
            schema={'type':'OBJECT','properties':{k:{'type':'STRING'}for k in expected},'required':list(expected)}
            result=client.generate(system,{'purpose':'declared synthetic capability test'},schema,**supplied)
            if result!=expected:raise ConnectionError('وصل رد JSON، لكنه لم يطابق محتوى وسيط الاختبار؛ لم يُعتمد دعم '+kind+'.')
        return {'kind':kind,'provider':client.provider,'model':client.model,'content_verified':True,
                'message':'نجح فحص '+('الصورة'if kind=='image'else'الفيديو')+' التجريبي ومحتواه وJSON. لا يثبت جودة تحليل مشاهد قناتك.'}
    except GeminiError as exc:raise ConnectionError(str(exc))from None
    except (OSError,RuntimeError,ValueError)as exc:
        if isinstance(exc,ConnectionError):raise
        raise ConnectionError('تعذر تجهيز أو تحليل ملف الاختبار؛ تحقق من أدوات الوسائط وإعدادات المزوّد.')from None
