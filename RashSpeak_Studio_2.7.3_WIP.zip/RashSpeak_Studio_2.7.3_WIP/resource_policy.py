"""Conservative local CUDA loading and one GPU task across app processes."""
from contextlib import contextmanager
import os
from pathlib import Path
import sys
import threading
import time
from functools import lru_cache

_dll_handles=[]
_dll_configured=False
_thread_slot=threading.Lock()

def configure_cuda_libraries():
    global _dll_configured
    if _dll_configured:return
    _dll_configured=True
    if os.name!='nt':return
    root=Path(sys.prefix)/'Lib/site-packages/nvidia'
    folders=[p for p in root.glob('*/bin')if p.is_dir()]
    for folder in folders:_dll_handles.append(os.add_dll_directory(str(folder)))
    # CT2 uses LoadLibrary too; this PATH change applies only to this process.
    if folders:os.environ['PATH']=os.pathsep.join(map(str,folders))+os.pathsep+os.environ.get('PATH','')

def cuda_available():
    configure_cuda_libraries()
    try:
        import ctranslate2
        if ctranslate2.get_cuda_device_count()<1:return False
        if os.name=='nt':
            import ctypes
            ctypes.WinDLL('cublas64_12.dll');ctypes.WinDLL('cudnn64_9.dll')
        return True
    except (ImportError,OSError,RuntimeError):return False

def cpu_threads():return max(1,min(8,(os.cpu_count()or 2)//2))

@lru_cache(maxsize=1)
def nvenc_available():
    from media_tools import run
    try:
        with gpu_slot():
            run(['ffmpeg','-v','error','-f','lavfi','-i','color=black:s=320x180:r=10:d=0.2',
                 '-an','-c:v','h264_nvenc','-preset','p4','-f','null','-'],timeout=20)
        return True
    except (OSError,RuntimeError,TimeoutError):return False

def preferred_encoder():return 'nvenc'if nvenc_available()else'cpu'

def gpu_lock_path():
    return Path(os.getenv('LOCALAPPDATA')or Path.home()/'.cache')/'RashSpeakStudio/gpu.lock'

@contextmanager
def gpu_slot(cancel=None,logger=None):
    def check():
        if cancel and cancel.is_set():
            from media_tools import Cancelled
            raise Cancelled('أُلغي انتظار بطاقة الرسومات.')
    check();announced=False
    while not _thread_slot.acquire(timeout=.1):
        check()
        if logger and not announced:logger('بانتظار مهمة البطاقة السابقة لتجنب تزامن استهلاك الذاكرة.');announced=True
    stream=None;locked=False
    try:
        path=gpu_lock_path();path.parent.mkdir(parents=True,exist_ok=True)
        stream=open(path,'a+b')
        if path.stat().st_size==0:stream.write(b'0');stream.flush()
        while True:
            check();stream.seek(0)
            try:
                if os.name=='nt':
                    import msvcrt
                    msvcrt.locking(stream.fileno(),msvcrt.LK_NBLCK,1)
                else:
                    import fcntl
                    fcntl.flock(stream,fcntl.LOCK_EX|fcntl.LOCK_NB)
                locked=True;break
            except (BlockingIOError,OSError):
                if logger and not announced:logger('بانتظار مهمة البطاقة السابقة.');announced=True
                time.sleep(.1)
        yield
    finally:
        if stream:
            if locked:
                stream.seek(0)
                if os.name=='nt':
                    import msvcrt
                    msvcrt.locking(stream.fileno(),msvcrt.LK_UNLCK,1)
                else:
                    import fcntl
                    fcntl.flock(stream,fcntl.LOCK_UN)
            stream.close()
        _thread_slot.release()
