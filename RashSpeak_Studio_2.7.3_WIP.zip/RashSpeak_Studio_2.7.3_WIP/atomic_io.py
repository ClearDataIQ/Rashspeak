"""Atomic project saves, including transient Windows sharing/rename failures."""
import os
from pathlib import Path
import tempfile
import time


RETRY_DELAYS = (.05, .1, .2, .4, .8, .8, .8)


class AtomicSaveError(OSError):
    """The previous file is intact and a complete new draft is retained."""

    def __init__(self, target, recovery_path, cause):
        self.target = Path(target)
        self.recovery_path = Path(recovery_path)
        self.original_error = cause
        super().__init__(
            f'تعذر استبدال ملف المشروع: {target}. '
            'بقي الملف السابق محفوظًا، وحُفظت النسخة الجديدة هنا: '
            f'{recovery_path}. أغلق أي برنامج يستخدم الملف ثم أعد المحاولة. '
            f'(رمز النظام: {getattr(cause, "winerror", None) or cause.errno})')


def atomic_write_text(path, text):
    """Close/fsync a unique sibling before replacement; never truncate target.

    Windows can report access denied (5), sharing violation (32), or lock
    violation (33) while an indexer/sync client briefly holds the destination.
    Retry only those errors, for a bounded total of 3.15 seconds. Persistent
    failures retain the complete draft, without changing permissions or deleting
    the previous destination. Concurrent saves never share a staging filename.
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix='.' + path.name + '.', suffix='.tmp', dir=path.parent)
    staged = Path(name)
    complete = False
    try:
        with os.fdopen(fd, 'w', encoding='utf-8', newline='\n') as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        complete = True
        for attempt in range(len(RETRY_DELAYS) + 1):
            try:
                os.replace(staged, path)
                return
            except OSError as exc:
                if getattr(exc, 'winerror', None) not in (5, 32, 33) or attempt == len(RETRY_DELAYS):
                    raise AtomicSaveError(path, staged, exc) from exc
                time.sleep(RETRY_DELAYS[attempt])
    finally:
        # A partially written draft is unusable; a complete failed save is kept.
        if not complete:
            staged.unlink(missing_ok=True)
