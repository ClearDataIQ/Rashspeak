"""Shape display labels only. Narration, scripts and exported captions stay logical.

Tk labels do not perform Unicode bidi consistently across platforms. Keep the
source StringVar separate from its visual presentation, including mixed Arabic,
Latin game names and numerals. Text inputs are never reshaped before analysis.
"""
import re
import sys
import tkinter as tk
from tkinter import ttk, font
from tkinter import messagebox as native_messagebox
import arabic_reshaper
from bidi.algorithm import get_display


def visual(text):
    text=str(text)
    if re.search('[\ufb50-\ufdff\ufe70-\ufeff]',text):return text
    if not re.search('[\u0600-\u06ff]',text):return text
    # Service names/HTTP codes must not select LTR for an Arabic paragraph.
    # Translate isolates only in this display copy; raw text/keys stay intact.
    text=text.translate(str.maketrans({'\u2066':'\u202a','\u2067':'\u202b','\u2068':'\u202b','\u2069':'\u202c'}))
    lines=[]
    for line in text.split('\n'):
        arabic=bool(re.search('[\u0600-\u06ff]',line))
        # A number followed by a Latin unit is one LTR token ("500 MB"),
        # otherwise bidi treats the leading number as a separate weak run.
        line=re.sub(r'(?<![A-Za-z0-9])([0-9]+(?:[.,][0-9]+)?\s*(?:[KMGT]?i?B|[kMG]?Hz|fps|ms|CPU|GPU))(?![A-Za-z0-9])',
                    lambda match:'\u202a'+match.group(1)+'\u202c',line)
        shown=get_display(arabic_reshaper.reshape(line),base_dir='R'if arabic else'L')
        # Tk needs visual order, but its Windows text backend can bidi selected
        # Arabic runs again. LRO protects the prepared glyph order per line.
        if sys.platform=='win32'and arabic:shown='\u202d'+shown+'\u202c'
        lines.append(shown)
    return '\n'.join(lines)


class DisplayMixin:
    def __init__(self,parent,**kwargs):
        self.logical_variable=kwargs.pop('textvariable',None)
        self.variable_trace=None
        self.logical_text=kwargs.pop('text','')
        self.wrap=int(kwargs.get('wraplength',0))
        if self.logical_variable is not None:
            self.display_variable=tk.StringVar(master=parent)
            kwargs['textvariable']=self.display_variable
        super().__init__(parent,**kwargs)
        if self.logical_variable is not None:
            self.variable_trace=self.logical_variable.trace_add('write',lambda *args:self.update_display())
        self.update_display()
        self.bind('<Destroy>',self.remove_trace,add='+')

    def update_display(self):
        text=self.logical_variable.get() if self.logical_variable is not None else self.logical_text
        if self.wrap:
            f=font.Font(master=self,font=self.cget('font'));lines=[]
            for paragraph in text.split('\n'):
                line=''
                for word in paragraph.split():
                    candidate=(line+' '+word).strip()
                    if line and f.measure(visual(candidate))>self.wrap:
                        lines.append(line);line=word
                    else:line=candidate
                lines.append(line)
            text='\n'.join(lines)
        shown=visual(text)
        if self.logical_variable is not None:self.display_variable.set(shown)
        else:super().configure(text=shown)

    def configure(self,cnf=None,**kwargs):
        if cnf is not None:
            if isinstance(cnf,dict):kwargs={**cnf,**kwargs}
            else:return super().configure(cnf,**kwargs)
        changed=False
        if 'text' in kwargs:self.logical_text=kwargs.pop('text');changed=True
        if 'wraplength' in kwargs:self.wrap=int(kwargs['wraplength']);changed=True
        result=super().configure(**kwargs)
        if changed:self.update_display()
        return result

    config=configure

    def remove_trace(self,event):
        if event.widget is self and self.variable_trace:
            self.logical_variable.trace_remove('write',self.variable_trace);self.variable_trace=None


class Label(DisplayMixin,tk.Label):pass
class Button(DisplayMixin,tk.Button):pass


class Dialogs:
    def __getattr__(self,name):
        def show(title,message,**kwargs):
            # Windows message boxes already shape Arabic and apply bidi. Sending
            # Tk's visual glyph order makes Windows reorder it a second time.
            if sys.platform=='win32':
                if 'detail' in kwargs:kwargs['detail']=native_text(kwargs['detail'])
                return getattr(native_messagebox,name)(str(title),native_text(message),**kwargs)
            return getattr(native_messagebox,name)(visual(title),visual(message),**kwargs)
        return show


dialogs=Dialogs()


def native_text(text):
    """Keep logical Unicode; set each Arabic paragraph's native bidi direction."""
    return '\n'.join('\u202b'+line+'\u202c' if re.search('[\u0600-\u06ff]',line) else line
                     for line in str(text).split('\n'))


class Treeview(ttk.Treeview):
    def heading(self,column,option=None,**kwargs):
        if 'text' in kwargs:kwargs['text']=visual(kwargs['text'])
        return super().heading(column,option,**kwargs)

    def insert(self,parent,index,iid=None,**kwargs):
        if 'text' in kwargs:kwargs['text']=visual(kwargs['text'])
        if 'values' in kwargs:kwargs['values']=[visual(v) for v in kwargs['values']]
        return super().insert(parent,index,iid,**kwargs)

    def item(self,item,option=None,**kwargs):
        if 'text' in kwargs:kwargs['text']=visual(kwargs['text'])
        if 'values' in kwargs:kwargs['values']=[visual(v) for v in kwargs['values']]
        return super().item(item,option,**kwargs)
