"""Retry context planning independently of ASR/audio, including newly saved keys."""
from copy import deepcopy

import gemini_client
import gemini_context


def resolve_context(script,segments,project,cancel=None,on_progress=None):
    cfg=gemini_client.settings()
    status={'provider':'local_rules','model':cfg['model'],'enabled':cfg['enabled'],
            'credential_available':bool(gemini_client.api_key()),'api_provider':cfg.get('provider','google')}
    if not cfg['enabled']:
        status.update(status='gemini_disabled',reason='Gemini معطل في إعدادات الإنتاج؛ فعّله واحفظ الإعداد ثم أعد محاولة تركيب اللقطات.')
        return deepcopy(segments),None,status
    try:
        try:
            analysis=gemini_context.cached_analysis(script,segments,cache=project/'gemini_cache',cancel=cancel)
            if on_progress:on_progress('استعادة تحليل Gemini محفوظ ومطابق؛ لم يُرسل تسجيل أو طلب جديد.')
        except gemini_client.GeminiError:
            if not status['credential_available']:
                raise gemini_client.GeminiUnavailable('مفتاح Gemini غير متاح ولا يوجد تحليل محفوظ مطابق. أضفه من إعدادات الخدمات واحفظه ثم أعد المحاولة من هذه المرحلة.')
            if on_progress:on_progress('Gemini يحلل النص والتوقيت؛ التسجيل الصوتي يبقى محليًا.')
            analysis=gemini_context.analyse(script,segments,cache=project/'gemini_cache',cancel=cancel,on_progress=on_progress)
        status.update(provider='gemini',status='analysed',model=analysis['model'],cached=analysis['cached'],reason='')
        status['warnings']=analysis.get('short_warnings',[])
        if on_progress and status['warnings']:on_progress('حُفظ فهم الجمل؛ رُفضت اقتراحات شورت غير صالحة دون إيقاف تركيب اللقطات.')
        return gemini_context.enrich(segments,analysis),analysis,status
    except gemini_client.GeminiError as exc:
        status.update(status='context_invalid'if getattr(exc,'kind','')=='response_validation'else'gemini_unavailable',reason=str(exc))
        if on_progress:on_progress('توقف تحليل Gemini: '+str(exc))
        return deepcopy(segments),None,status
