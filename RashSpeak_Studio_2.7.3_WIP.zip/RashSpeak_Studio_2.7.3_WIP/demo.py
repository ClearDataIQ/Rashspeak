"""Generated media only; no network, platform calls, or user recordings."""
import argparse
import sys
from pathlib import Path
from PIL import Image, ImageDraw

import captions
from media_tools import run
from smart_editor import approve, import_asset, plan, save, validate_timeline
from timeline_render import caption_preview, render


def make_demo(folder, voice=None, transcript=None, test_fixtures=False):
    folder = Path(folder).resolve()
    media = folder / 'synthetic'
    media.mkdir(parents=True, exist_ok=True)
    audio = media / ('narration.wav' if voice else 'test_tone.wav')
    # This is deliberately a test tone, never labelled a real Arabic voice recording.
    if voice:
        run(['ffmpeg', '-v', 'error', '-y', '-i', voice, '-ar', '48000', '-c:a', 'pcm_s16le', audio])
    else:
        run(['ffmpeg', '-v', 'error', '-y', '-f', 'lavfi', '-i', 'sine=frequency=220:sample_rate=48000:duration=14', '-af', 'volume=0.1', audio])
    assets = []
    for game, color in [('fortnite', '0x325d8c'), ('minecraft', '0x2c7350'), ('xbox', '0x614278')]:
        file = media / f'{game}.mp4'
        run(['ffmpeg', '-v', 'error', '-y', '-f', 'lavfi', '-i', f'color=c={color}:s=640x360:r=30:d=8',
             '-vf', 'drawgrid=w=80:h=60:t=2:c=white@0.18,drawbox=x=260:y=100:w=120:h=170:c=white@0.3:t=fill',
             '-an', '-c:v', 'libx264', '-preset', 'ultrafast', '-pix_fmt', 'yuv420p', file])
        assets.append(import_asset(file, game=game, tags=[game], license='CC0 synthetic', source='Generated locally by demo.py', approved=True, previews=folder / 'previews'))
    if test_fixtures:
        png = media / 'reaction.png'
        image = Image.new('RGBA', (200, 200), (0, 0, 0, 0))
        draw = ImageDraw.Draw(image)
        draw.ellipse((10, 10, 190, 190), fill='#ffcf4c')
        draw.ellipse((45, 60, 65, 80), fill='black')
        draw.ellipse((135, 60, 155, 80), fill='black')
        draw.arc((50, 90, 150, 155), 0, 180, fill='black', width=10)
        image.save(png)
        gif = media / 'reaction.gif'
        second = image.rotate(12)
        image.save(gif, save_all=True, append_images=[second], duration=[250, 250], loop=0, disposal=2)
        for file in (png, gif):
            assets.append(import_asset(file, role='meme', mood='humor', license='CC0 synthetic', source='Generated locally by demo.py (test fixture, not a production reaction)', approved=True, previews=folder / 'previews'))
    segments = [{'start': 0, 'end': 3, 'text': 'أهلًا بكم في أخبار فورتنايت', 'mode': 'factual'},
                {'start': 3, 'end': 6, 'text': 'هههه فورتنايت! هذه اللحظة ضحكتني', 'mode': 'humor'},
                {'start': 6, 'end': 10, 'text': 'ماينكرافت: تسريح موظفين، خبر يحتاج احترامًا', 'mode': 'sensitive'},
                {'start': 10, 'end': 14, 'text': 'إكس بوكس Xbox 2026: موعد إصدار جديد', 'mode': 'factual', 'importance': 9}]
    if transcript:
        segments = captions.load(transcript)
    timeline = plan(audio, {'assets': assets}, segments, memes_enabled=test_fixtures)
    if test_fixtures:
        timeline['memes'][0]['asset_id'] = assets[-1]['id']  # Exercise animated GIF, not only PNG.
        timeline['memes'][0]['approved'] = True
    if test_fixtures and not timeline['shorts']:
        # A manually authored legacy Short verifies old-project rendering, not new suggestions.
        timeline['shorts']=[{'start':10.,'end':14.,'approved':True,'score':1,
                            'reason':'Explicit synthetic legacy-project render fixture'}]
    for short in timeline['shorts']:short['approved']=True
    validate_timeline(timeline)
    save({'version': '2.1', 'assets': assets}, folder / 'manifest.json')
    save(segments, folder / 'transcript.json')
    save({'audio': str(audio), 'out': str(folder), 'model': '', 'cues': '', 'script': ''}, folder / 'project.json')
    save(timeline, folder / 'timeline.json')
    captions.write_srt(segments, folder / 'input_ar.srt')
    caption_preview(timeline, folder / 'caption_preview.png', at=10)
    return timeline


def main():
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', default='output/demo')
    parser.add_argument('--render', action='store_true')
    parser.add_argument('--small', action='store_true')
    parser.add_argument('--voice', help='Optional local generated test narration; requires --transcript')
    parser.add_argument('--transcript', help='Reviewed JSON with known phrase timings')
    parser.add_argument('--test-fixtures', action='store_true', help='Generated emoji fixtures for automated media tests only')
    args = parser.parse_args()
    if bool(args.voice) != bool(args.transcript):
        parser.error('--voice and --transcript must be supplied together')
    timeline = make_demo(args.out, args.voice, args.transcript, args.test_fixtures)
    if args.render:
        sizes = {'size': (640, 360), 'portrait_size': (360, 640)} if args.small else {}
        render(timeline, args.out, **sizes)
        # Demo-only: generated assets and synthetic tone; final approval does not publish anything.
        approve(timeline, accept_warnings=True)
        render(timeline, args.out, final=True, **sizes)


if __name__ == '__main__':
    main()
