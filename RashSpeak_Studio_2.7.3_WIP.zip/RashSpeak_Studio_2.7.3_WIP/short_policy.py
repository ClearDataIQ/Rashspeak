"""Owner's default: meaningful contiguous Shorts, 25–60 seconds, no padding."""
import math

MIN_SECONDS = 25
MAX_SECONDS = 60
TARGET_SECONDS = 50
TRAILING_WORDS=set('لكن ولكن بس عشان لان لأن بسبب اذا إذا لو لما عندما عندما حتى اللي الذي التي حيث مثل زي سواء او أو و ثم الى إلى على عن من في مع ان أن إن كان كانت يكون تكون راح سوف because but if when although and or to with'.split())
WEAK_STARTS=set('وهذا وهذي وهذه وهو وهي وبكذا وبالتالي لذلك وكذلك وايضا which therefore'.split())
HOOKS=('تخيل','تدري','تعرف','ليش','ليه','كيف','هل','المشكلة','الصدمة','المفاجأة',
       'الغريب','أقوى','أفضل','أسوأ','مستحيل','مو معقول','ما توقعت','مجاني','تحديث جديد')


def duration_allowed(seconds):
    return math.isfinite(seconds) and MIN_SECONDS <= seconds <= MAX_SECONDS


def ending_complete(segment):
    from smart_editor import normalize
    text=segment['text'].strip();words=normalize(text).split()
    if not words or text.endswith(('…','...',',','،',':','؛','-')):return False
    dangling={normalize(w)for w in TRAILING_WORDS}
    if words[-1]in dangling:return False
    return (segment.get('semantic')or{}).get('ending_complete')is not False


def boundary(segments,index):
    s=segments[index]
    if not ending_complete(s):return False
    semantic=s.get('semantic')or{}
    if semantic.get('ending_complete')is True:return True
    gap=segments[index+1]['start']-s['end']if index+1<len(segments)else 0
    return bool(s.get('sentence_end',s['text'].rstrip().endswith(('.', '؟','!','?'))))or gap>.55


def hook_strength(segment):
    from smart_editor import contains,normalize
    text=' '.join(segment['text'].split()[:16])
    first=normalize(text).split()
    if not first or first[0]in WEAK_STARTS:return -1.
    proposed=(segment.get('semantic')or{}).get('hook_score',0)
    if type(proposed)not in (int,float)or not math.isfinite(proposed):proposed=0
    return min(10.,max(float(proposed),sum(contains(text,t)for t in HOOKS)*2+float(segment.get('importance',0))*.2))


def review_range(segments,start,end,limit,tolerance=.005):
    """Reject a new automatic/manual range that cuts a word or an unfinished thought."""
    if not duration_allowed(end-start)or not 0<=start<end<=limit+tolerance:
        raise ValueError('الشورت بين25و60ثانية من التسجيل المتصل.')
    indices=[i for i,s in enumerate(segments)if s['start']<end-tolerance and s['end']>start+tolerance]
    if not indices:raise ValueError('يلزم نص موقّت للتحقق من بداية الشورت ونهايته.')
    a,b=indices[0],indices[-1];first,last=segments[a],segments[b]
    if abs(start-first['start'])>tolerance or abs(end-last['end'])>tolerance:
        raise ValueError('اختر بداية ونهاية عند جمل كاملة؛ لا تقطع الشورت داخل الكلام.')
    if a and segments[a-1]['end']>=start-.55 and not boundary(segments,a-1):
        raise ValueError('بداية الشورت تكملة لجملة سابقة؛ اختر بداية فكرة مستقلة.')
    if hook_strength(first)<0 or not boundary(segments,b):
        raise ValueError('بداية الشورت تحتاج سياقًا سابقًا أو نهايته تنتظر تكملة؛ اختر هوكًا مفهومًا وخاتمة مكتملة.')
    return {'hook':first['text'],'ending':last['text'],'hook_score':hook_strength(first)}


def select(segments, limit, count=3, minimum=MIN_SECONDS, maximum=MAX_SECONDS, target=TARGET_SECONDS):
    from smart_editor import contains, SENSITIVE
    if not segments:
        return []
    if not 0 < minimum <= target <= maximum or count < 1:
        raise ValueError('حدود مدة الشورت غير صالحة.')
    sentences=[];group=[]
    for i,s in enumerate(segments):
        if group and s.get('story_topic','') != group[0].get('story_topic',''):
            group=[]  # Never carry an unfinished sentence into another game.
        importance=float(s.get('importance',0))
        if not math.isfinite(importance):raise ValueError('أهمية جملة غير صالحة.')
        group.append(s)
        if boundary(segments,i):
            sentences.append({'start':group[0]['start'],'end':s['end'],'segments':group,
                              'topic':group[0].get('story_topic','')})
            group=[]
    candidates=[]
    for i,sentence in enumerate(sentences):
        items=[]
        for last in sentences[i:]:
            if last['topic']!=sentence['topic'] or last['end']-sentence['start']>maximum:break
            items+=last['segments']
            if any(s.get('mode')in ('sensitive','cta') or any(contains(s['text'],term)for term in
                (*SENSITIVE,'اشترك','السلام عليكم','مرحبا'))for s in items):break
            seconds=last['end']-sentence['start']
            if seconds<minimum or last['end']>limit:continue
            try:edges=review_range(segments,sentence['start'],last['end'],limit)
            except ValueError:continue
            score=sum(float(s.get('importance',0))+sum(contains(s['text'],term)for term in
                      ('جديد','مجاني','تحديث','ليش','مفاجاه','اصدار'))for s in items)
            candidates.append({'start':sentence['start'],'end':last['end'],'score':score,
                **edges,'ending_review':'local_sentence_boundary','hook_review':'local_heuristic',
                'reason':'بداية مفهومة ونهاية جملة مكتملة من كلام متصل؛ راجع قوة الهوك واكتمال الفكرة','approved':False})
    selected=[]
    for candidate in sorted(candidates,key=lambda s:(-s['hook_score'],-s['score'],abs(s['end']-s['start']-target),s['start'])):
        if any(candidate['start']<s['end'] and candidate['end']>s['start']for s in selected):continue
        selected.append(candidate)
        if len(selected)>=count:break
    return selected
