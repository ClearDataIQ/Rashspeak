"""One owned audio audition at a time; switching A/B stops the previous file."""
import os
from pathlib import Path
import subprocess
import sys
import tkinter as tk

from media_tools import tool
from rtl_ui import Label,Button


class Audition:
    def __init__(self,spawn=None,executable=None):
        self.spawn=spawn or subprocess.Popen;self.executable=executable;self.process=None

    def stop(self):
        process=self.process;self.process=None
        if process is not None and process.poll()is None:
            process.terminate()
            try:process.wait(timeout=.5)
            except subprocess.TimeoutExpired:process.kill();process.wait(timeout=.5)

    def start(self,path):
        self.stop();path=Path(path).resolve()
        if not path.is_file():raise ValueError('ملف الصوت غير موجود.')
        executable=self.executable or tool('ffplay')
        self.process=self.spawn([executable,'-nodisp','-autoexit','-loglevel','error','-vn',str(path)],
            stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt'else 0)


class AudioPreview(tk.Toplevel):
    def __init__(self,parent,path):
        super().__init__(parent);self.title('مراجعة الصوت');self.geometry('680x250');self.configure(bg='#132138')
        self.controller=Audition();self.path=None;self.timer=None
        self.status=tk.StringVar()
        Label(self,textvariable=self.status,bg='#132138',fg='#eef5ff',wraplength=630,justify='right').pack(fill='x',padx=16,pady=16)
        row=tk.Frame(self,bg='#132138');row.pack(fill='x',padx=16,pady=8)
        def button(text,fn):
            b=Button(row,text=text,command=fn,bg='#223b58',fg='#eef5ff',padx=12,pady=8,relief='flat');b.pack(side='right',padx=4)
        button('تشغيل',self.play);button('إيقاف',self.stop);button('فتح خارجي بعد الإيقاف',self.external)
        Label(self,text='يُوقف الصوت السابق قبل التبديل بين الأصل والمنظف. أغلق أي مشغل خارجي كان يعمل مسبقًا عند المقارنة.',
            bg='#132138',fg='#91a9c4',wraplength=630,justify='right').pack(fill='x',padx=16,pady=8)
        self.bind('<Destroy>',self.destroyed)
        self.load(path)

    def load(self,path):
        self.path=Path(path).resolve();self.play();self.lift()

    def play(self):
        try:
            self.stop();self.controller.start(self.path);self.status.set('تشغيل: '+self.path.name)
            self.timer=self.after(200,self.poll)
        except (ValueError,OSError,RuntimeError):
            self.status.set('المشغل الداخلي للصوت غير متاح. ضع FFplay مع FFmpeg في tools، أو افتح الملف خارجيًا مع تشغيل ملف واحد فقط.')

    def stop(self):
        if self.timer:self.after_cancel(self.timer);self.timer=None
        self.controller.stop();self.status.set('توقف التشغيل.')

    def poll(self):
        self.timer=None;process=self.controller.process
        if process is None:return
        code=process.poll()
        if code is None:self.timer=self.after(200,self.poll)
        else:self.status.set('اكتمل التشغيل.'if code==0else'تعذر إخراج الصوت؛ جرّب فتح الملف خارجيًا وحده.')

    def destroyed(self,event):
        if event.widget is self:
            if self.timer:self.after_cancel(self.timer);self.timer=None
            self.controller.stop()

    def external(self):
        self.stop()
        if os.name=='nt':os.startfile(str(self.path))
        else:subprocess.Popen(['open'if sys.platform=='darwin'else'xdg-open',str(self.path)])


def open_preview(parent,path):
    window=getattr(parent,'audio_preview',None)
    if window is not None and window.winfo_exists():window.load(path)
    else:window=AudioPreview(parent,path);parent.audio_preview=window
    return window
