"""Regressions from the owner's actual Windows installation and source errors."""
from array import array
from copy import deepcopy
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
import wave
import math
from unittest.mock import Mock, patch

from media_tools import limiter_filter, tool
from official_sources import SourceUnavailable
from steam_sources import SteamOfficial


class LimiterCompatibilityTests(unittest.TestCase):
    def filtered(self, samples, channels):
        response = subprocess.run([
            tool('ffmpeg'), '-v', 'error', '-f', 'f32le', '-ar', '48000',
            '-ac', str(channels), '-i', 'pipe:0', '-af', limiter_filter(),
            '-f', 'f32le', 'pipe:1'], input=samples.tobytes(),
            capture_output=True, check=True, timeout=20)
        result = array('f'); result.frombytes(response.stdout)
        return result

    def test_real_limiter_preserves_sample_count_and_both_edge_words(self):
        # A declared synthetic impulse fixture, not a human-listening claim.
        samples = array('f', [0.0] * 4800)
        for at in (0, 1200, 4799): samples[at] = .3
        result = self.filtered(samples, 1)
        self.assertEqual(len(result), len(samples))
        for at in (0, 1200, 4799): self.assertAlmostEqual(result[at], .3, places=5)
        self.assertTrue(all(abs(v) < .00001 for i, v in enumerate(result) if i not in (0, 1200, 4799)))

    def test_stereo_channels_keep_their_distinct_sample_positions(self):
        samples = array('f', [0.0] * 9600)
        samples[600 * 2] = .2
        samples[1600 * 2 + 1] = .4
        result = self.filtered(samples, 2)
        self.assertEqual(len(result), len(samples))
        self.assertAlmostEqual(result[1200], .2, places=5)
        self.assertAlmostEqual(result[3201], .4, places=5)
        self.assertAlmostEqual(result[1201], 0., places=5)
        self.assertAlmostEqual(result[3200], 0., places=5)

    def test_denoise_flushes_the_real_final_phoneme_instead_of_silence_padding(self):
        from audio_edit import render_audio
        samples=array('h',[0]*96000)
        for index in range(95040,96000):samples[index]=round(6000*math.sin(index*2*math.pi*600/48000))
        with tempfile.TemporaryDirectory()as folder:
            source=Path(folder)/'tail.wav';output=Path(folder)/'clean.wav'
            with wave.open(str(source),'wb')as target:
                target.setnchannels(1);target.setsampwidth(2);target.setframerate(48000);target.writeframes(samples.tobytes())
            render_audio(source,{'keeps':[[0.,2.]],'clean_duration':2.},output,
                processing={'highpass':0,'denoise':True,'normalize':False})
            with wave.open(str(output),'rb')as target:
                actual=array('h');actual.frombytes(target.readframes(target.getnframes()))
            self.assertEqual(len(actual),len(samples))
            self.assertGreater(max(abs(value)for value in actual[95040:95800]),1000)


class FontFallbackTests(unittest.TestCase):
    @unittest.skipUnless(os.name == 'nt', 'Windows system font fallback')
    def test_missing_project_font_measures_a_real_arabic_font_on_windows(self):
        from caption_layout import font_path, text_measure
        fallback = font_path('RashSpeak Missing Font Fixture', True)
        self.assertIsNotNone(fallback)
        self.assertTrue(Path(fallback).is_file())
        measure = text_measure('RashSpeak Missing Font Fixture', 104, True)
        self.assertLess(measure('القصة والحوارات'), 790)
        self.assertNotEqual(measure('مممم'), measure('اااا'))


class SteamListingRepairTests(unittest.TestCase):
    def search(self, title, appid=292030):
        listing = {'292030': {'success': True, 'data': {
            'steam_appid': appid, 'type': 'game', 'name': title,
            'publishers': ['Declared test publisher'], 'movies': [{
                'id': 42, 'name': 'Declared trailer fixture', 'mp4': {
                    'max': 'https://video.fastly.steamstatic.com/store_trailers/42/movie_max.mp4'}}]}}}
        with patch('steam_sources._get_json', return_value=listing):
            return SteamOfficial(config={}).search({'game': 'The Witcher 3', 'role': 'clip'})

    def test_observed_official_display_title_keeps_same_appid_without_granting_rights(self):
        result = self.search('The Witcher 3: Wild Hunt — Remastered')
        self.assertEqual(result[0]['steam_app_id'], 292030)
        self.assertEqual(result[0]['rights_status'], 'pending')
        self.assertIsNone(result[0]['duration'])

    def test_different_edition_or_wrong_appid_still_fails_closed(self):
        for title, appid in [('The Witcher 3: Wild Hunt — Other Edition', 292030),
                             ('The Witcher 3: Wild Hunt — Remastered', 99)]:
            with self.assertRaises(SourceUnavailable): self.search(title, appid)

    def test_approved_steam_candidate_is_probed_before_an_unknown_duration_is_used(self):
        from media_archive import MediaArchive
        from media_director import build_plan
        from test_media_director import source, request
        candidate = {**source(), 'provider': 'steam', 'duration': None}
        provider = Mock(); provider.search.return_value = [candidate]
        row = request(); segment = {'start': 0., 'end': 3., 'text': 'تجربة اللعبة.',
            'story_topic': row['game'], 'semantic': {'game': row['game'], 'entities': [],
                'event': '', 'visual': 'gameplay', 'confidence': .9, 'queries': ['gameplay']}}
        def analysed(item, *args, **kwargs):
            self.assertIsNone(item['duration'])
            item['duration'] = 30.
            return [{'start': 1., 'end': 10., 'game': row['game'], 'event': '', 'entities': []}]
        with tempfile.TemporaryDirectory() as folder, patch('media_director.analyse_video', side_effect=analysed) as analysis, \
                patch('media_director.choose', return_value=None):
            result = build_plan([segment], MediaArchive(folder), {'youtube': provider}, Mock(), max_scene_analyses=3)
            self.assertEqual(analysis.call_count, 1)
            self.assertNotEqual(result['sentences'][0]['status'], 'source_unavailable')


class ContextSchemaRepairTests(unittest.TestCase):
    def fixture(self):
        from test_gemini import ContextTests
        text, _, response = ContextTests().data()
        segments = [{'start': i * 4., 'end': i * 4. + 4., 'text': text} for i in range(12)]
        rows = [{**deepcopy(response['segments'][0]), 'id': f's{i:04}'} for i in range(12)]
        return text, segments, {'segments': rows, 'shorts': []}

    def test_twelve_row_request_avoids_the_reproduced_array_bounds_rejection(self):
        import gemini_context
        text, segments, result = self.fixture()
        def generate(system, data, schema):
            self.assertNotIn('minItems', schema['properties']['segments'])
            self.assertNotIn('maxItems', schema['properties']['segments'])
            self.assertEqual(len(schema['properties']['segments']['items']['properties']['id']['enum']), 12)
            self.assertEqual(len(data['sentences']), 12)
            return result
        client = Mock(model='declared-protocol-fixture', last_usage={})
        client.generate.side_effect = generate
        self.assertEqual(len(gemini_context.analyse(text, segments, client=client)['segments']), 12)

    def test_missing_duplicate_extra_rows_still_fail_after_simplifying_server_schema(self):
        from gemini_context import validate_context
        from gemini_client import GeminiError
        text, segments, response = self.fixture()
        for rows in (response['segments'][:-1], response['segments'] + [response['segments'][0]],
                     [{**response['segments'][0], 'id': 'invented'}, *response['segments'][1:]]):
            with self.assertRaises(GeminiError):
                validate_context({'segments': rows, 'shorts': []}, text, segments)


class ProjectPathRepairTests(unittest.TestCase):
    def test_foreign_absolute_source_paths_survive_save_reopen_without_pointing_at_another_drive(self):
        from pro_project import Session, new_project, new_clip, load_project
        foreign = '/workspace/original.mp4' if os.name == 'nt' else 'C:/Originals/voice.mp4'
        session = Session(new_project())
        track = session.add_track('video')
        asset = {'id': 'foreign', 'kind': 'video', 'duration': 2., 'path': foreign,
                 'has_audio': False, 'fingerprint': {}, 'license': 'owned',
                 'source': 'Declared path-only fixture', 'usage_approved': True}
        session.add(track, new_clip(asset['id'], duration=30), asset)
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'project.rash.json'; session.save(path)
            self.assertEqual(load_project(path)['media'][0]['path'], foreign)
