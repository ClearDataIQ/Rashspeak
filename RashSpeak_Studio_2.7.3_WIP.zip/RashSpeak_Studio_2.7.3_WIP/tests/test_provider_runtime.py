from copy import deepcopy
import json
import os
from pathlib import Path
import tempfile
import threading
import time
import tkinter as tk
import unittest
from unittest.mock import patch,Mock

import ai_runtime
import api_connections as api
import gemini_client as g
import resource_policy as resources
from gemini_context import analyse,cached_analysis
from test_gemini import Response,HTTP
import test_gemini as fixtures


class QueueHTTP:
    def __init__(self,*responses):self.responses=list(responses);self.calls=[]
    def request(self,*args,**kwargs):
        self.calls.append((args,kwargs));return self.responses.pop(0)


def catalog(modalities=('text','image'),price='0'):
    return {'data':[{'id':'test/vision:free','architecture':{'input_modalities':list(modalities),'output_modalities':['text']},
        'pricing':{'prompt':'0','completion':'0','image':price},'supported_parameters':['response_format']}]}


class ProviderTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        self.circuit=patch('ai_runtime.circuit_path',return_value=self.root/'circuit.json');self.circuit.start();self.addCleanup(self.circuit.stop)

    def test_quota_is_one_request_and_stays_paused_across_new_clients_until_explicit_resume(self):
        http=HTTP(Response({'error':{'message':'DECLARED_PRIVATE_ECHO'}},429))
        one=g.GeminiClient(key='DECLARED_PRIVATE_KEY',model='gemini-fixture',http=http)
        for client in (one,g.GeminiClient(key='DECLARED_PRIVATE_KEY',model='gemini-other',http=http)):
            with self.assertRaises(g.GeminiUnavailable)as caught:client.generate('system',{}, {'type':'OBJECT'})
            self.assertIn('429',str(caught.exception));self.assertNotIn('DECLARED_PRIVATE',str(caught.exception))
        self.assertEqual(len(http.calls),1)
        text=(self.root/'circuit.json').read_text();self.assertNotIn('DECLARED_PRIVATE_KEY',text)
        ai_runtime.resume('google','DECLARED_PRIVATE_KEY');self.assertFalse(ai_runtime.paused('google','DECLARED_PRIVATE_KEY'))

    def test_provider_and_endpoint_mismatch_never_sends_key(self):
        http=HTTP(Response({}))
        for kwargs in ({'provider':'google','key':'sk-or-declared-fixture'},
                       {'provider':'openrouter','key':'AIzaDECLARED_FIXTURE','model':'test/vision:free'},
                       {'provider':'google','key':'fixture','base_url':'https://evil.example/v1'}):
            with self.subTest(kwargs=kwargs),self.assertRaises((g.GeminiError,ValueError)):g.GeminiClient(http=http,**kwargs)
        self.assertFalse(http.calls)

    def test_credential_and_account_failures_are_distinct_without_raw_echo(self):
        for status,kind in ((401,'credential'),(403,'account')):
            http=HTTP(Response({'error':{'message':'DECLARED_PRIVATE_ECHO'}},status))
            client=g.GeminiClient(key='DECLARED_KEY',http=http)
            with self.assertRaises(g.GeminiUnavailable)as caught:client.models()
            self.assertEqual(caught.exception.kind,kind);self.assertNotIn('DECLARED_PRIVATE',str(caught.exception));self.assertEqual(len(http.calls),1)

    def test_quota_stops_in_memory_even_when_circuit_file_cannot_be_saved(self):
        with patch('ai_runtime.save',side_effect=PermissionError('declared locked settings fixture')):
            ai_runtime.pause('google','LOCKED_STORE_FIXTURE')
        self.assertTrue(ai_runtime.paused('google','LOCKED_STORE_FIXTURE'))
        ai_runtime.resume('google','LOCKED_STORE_FIXTURE')

    def test_provider_credentials_do_not_fall_back_to_google_or_youtube(self):
        with patch.dict(os.environ,{'GOOGLE_API_KEY':'GOOGLE_FIXTURE'},clear=True),patch.object(g,'_provider_session_keys',{}),patch('keyring.get_password',return_value=None):
            self.assertEqual(g.api_key('google'),'GOOGLE_FIXTURE');self.assertEqual(g.api_key('openrouter'),'')

    def test_openrouter_only_current_zero_price_catalog_and_bearer_route(self):
        http=QueueHTTP(Response(catalog()),Response({'choices':[{'finish_reason':'stop','message':{'content':'{"ok":true}'}}]}))
        client=g.GeminiClient(provider='openrouter',model='test/vision:free',key='gateway_fixture',http=http)
        self.assertEqual(client.generate('system',{}, {'type':'OBJECT'}),{'ok':True})
        args,kwargs=http.calls[-1]
        self.assertEqual(args[1],'https://openrouter.ai/api/v1/chat/completions')
        self.assertEqual(kwargs['headers']['Authorization'],'Bearer gateway_fixture');self.assertNotIn('x-goog-api-key',kwargs['headers'])
        self.assertFalse(kwargs['json']['provider']['allow_fallbacks']);self.assertEqual(kwargs['json']['provider']['max_price']['prompt'],0)

    def test_zero_tokens_but_charged_image_is_rejected_before_generation(self):
        http=QueueHTTP(Response(catalog(price='.01')))
        client=g.GeminiClient(provider='openrouter',model='test/vision:free',key='fixture',http=http)
        with self.assertRaises(g.GeminiUnavailable):client.generate('s',{}, {'type':'OBJECT'})
        self.assertEqual(len(http.calls),1)

    def test_video_unsupported_is_explicit_without_sending_fake_frames_or_post(self):
        http=QueueHTTP(Response(catalog()))
        client=g.GeminiClient(provider='openrouter',model='test/vision:free',key='fixture',http=http)
        with self.assertRaises(g.GeminiError)as caught:client.generate('s',{}, {'type':'OBJECT'},video_path=self.root/'nonexistent.mp4')
        self.assertIn('الفيديو',str(caught.exception));self.assertEqual(len(http.calls),1)

    def test_incomplete_gateway_json_is_not_success(self):
        http=QueueHTTP(Response(catalog()),Response({'choices':[{'finish_reason':'length','message':{'content':'{}'}}]}))
        client=g.GeminiClient(provider='openrouter',model='test/vision:free',key='fixture',http=http)
        with self.assertRaises(g.GeminiError):client.generate('s',{}, {'type':'OBJECT'})

    def test_saved_grounded_decision_does_not_expire_while_quota_is_unavailable(self):
        script,segments,response=fixtures.ContextTests().data()
        client=Mock(model='gemini-fixture',last_usage={},cache_identity=None);client.generate.return_value=response
        analyse(script,segments,self.root,client)
        path=next(self.root.glob('*.json'));raw=json.loads(path.read_text(encoding='utf-8'));raw['created']=time.time()-86400*10
        path.write_text(json.dumps(raw),encoding='utf-8')
        self.assertTrue(cached_analysis(script,segments,self.root,model='gemini-fixture')['cached'])

    def test_provider_change_cannot_reuse_another_providers_semantic_decisions(self):
        script,segments,response=fixtures.ContextTests().data()
        first=Mock(model='test/vision:free',last_usage={},cache_identity=['openrouter','endpoint-one','test/vision:free']);first.generate.return_value=response
        second=Mock(model=first.model,last_usage={},cache_identity=['openrouter','endpoint-two',first.model]);second.generate.return_value=response
        analyse(script,segments,self.root,first);analyse(script,segments,self.root,second)
        self.assertEqual(first.generate.call_count,1);self.assertEqual(second.generate.call_count,1)

    def test_media_probe_checks_answer_content_not_just_json(self):
        from ai_capabilities import check_media
        with patch('ai_capabilities.GeminiClient')as client:
            client.return_value.generate.return_value={'object_color':'blue'}
            with self.assertRaises(api.ConnectionError):check_media('image','DECLARED_KEY','gemini-fixture')
            client.return_value.generate.return_value={'object_color':'red'}
            self.assertTrue(check_media('image','DECLARED_KEY','gemini-fixture')['content_verified'])


class ResourceTests(unittest.TestCase):
    def test_gpu_work_is_serial_and_wait_is_cancellable(self):
        with tempfile.TemporaryDirectory()as directory,patch('resource_policy.gpu_lock_path',return_value=Path(directory)/'gpu.lock'):
            cancel=threading.Event();errors=[];entered=threading.Event()
            def second():
                try:
                    with resources.gpu_slot(cancel):entered.set()
                except Exception as exc:errors.append(exc)
            with resources.gpu_slot():
                worker=threading.Thread(target=second);worker.start();time.sleep(.15);self.assertFalse(entered.is_set());cancel.set();worker.join(2)
            self.assertFalse(worker.is_alive());self.assertEqual(type(errors[0]).__name__,'Cancelled')
            with resources.gpu_slot():pass

    def test_cuda_runtime_failure_discards_partial_asr_and_uses_cpu(self):
        import captions
        with patch('resource_policy.cuda_available',return_value=True),patch('captions._transcribe',side_effect=[RuntimeError('CUDA out of memory'),{'segments':['cpu only']}])as call:
            self.assertEqual(captions.transcribe('fixture','fixture',logger=lambda m:None),{'segments':['cpu only']})
            self.assertEqual([c.args[4]for c in call.call_args_list],['cuda','cpu'])


class ProviderUITests(unittest.TestCase):
    def test_switch_removes_typed_key_and_google_selection_is_explicit_before_save(self):
        from api_settings_ui import open_settings
        root=tk.Tk();root.withdraw()
        try:
            window=open_settings(root,'gemini');panel=window.api_panels['gemini'];panel.key.set('DECLARED_KEY')
            panel.ai_provider.set('openrouter');panel.provider_changed();self.assertEqual(panel.key.get(),'')
            self.assertEqual(panel.base_url.get(),'https://openrouter.ai/api/v1')
            panel.ai_provider.set('google');panel.provider_changed();panel.model.set('gemini-fixture');panel.key.set('DECLARED_KEY')
            with patch('api_connections.check_generation',return_value={'message':'fixture'})as check:
                panel.test(generation=True)
                end=time.monotonic()+3
                while panel.busy and time.monotonic()<end:root.update();time.sleep(.01)
                self.assertEqual(check.call_args.kwargs['ai_provider'],'google')
                self.assertEqual(check.call_args.kwargs['base_url'],ai_runtime.ENDPOINTS['google'])
        finally:root.destroy()


if __name__=='__main__':unittest.main()
