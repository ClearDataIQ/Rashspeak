"""Cache recovery never substitutes fixtures for missing live provider responses."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from gemini_context import analyse,cached_analysis
from gemini_client import GeminiUnavailable


class CachedContextTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.segments=[{'start':float(i*3),'end':float(i*3+3),'text':f'هذه فقرة الاختبار {i}'}for i in range(13)]
        self.script=' '.join(s['text']for s in self.segments)
        class Fixture:
            model='gemini-flash-latest';last_usage={}
            def generate(self,system,data,schema):
                return {'segments':[{'id':s['id'],'evidence':s['text'],'game':'','event':'','idea':'اختبار',
                         'tone':'neutral','importance':5,'confidence':.8,'visual':'title','meme':False,
                         'effect':'none','reason':'Fixture only, not real analysis','queries':[]}for s in data['sentences']],
                        'shorts':[]}
        self.client=Fixture()
    def tearDown(self):self.tmp.cleanup()

    def test_complete_multibatch_cache_restores_without_client_key_or_network(self):
        original=analyse(self.script,self.segments,self.root,self.client)
        with patch('gemini_context.GeminiClient',side_effect=AssertionError('No live client allowed')):
            restored=cached_analysis(self.script,self.segments,self.root,model=self.client.model)
        self.assertTrue(restored['cached']);self.assertEqual(restored['segments'],original['segments'])
        self.assertEqual([r['id']for r in restored['segments']],[f's{i:04}'for i in range(13)])

    def test_missing_expired_changed_timing_model_and_evidence_never_restore(self):
        with self.assertRaises(GeminiUnavailable):cached_analysis(self.script,self.segments,self.root,model=self.client.model)
        analyse(self.script,self.segments,self.root,self.client)
        changed=deepcopy(self.segments);changed[0]['start']=.5
        for segments,model in ((changed,self.client.model),(self.segments,'gemini-another-model')):
            with self.assertRaises(GeminiUnavailable):cached_analysis(self.script,segments,self.root,model=model)
        path=next(self.root.glob('*.json'));raw=json.loads(path.read_text())
        for bad in ({**raw,'created':0}, {**raw,'response':{'segments':[],'shorts':[]}}):
            path.write_text(json.dumps(bad))
            with self.assertRaises(GeminiUnavailable):cached_analysis(self.script,self.segments,self.root,model=self.client.model)
        path.unlink()
        with self.assertRaises(GeminiUnavailable):cached_analysis(self.script,self.segments,self.root,model=self.client.model)
