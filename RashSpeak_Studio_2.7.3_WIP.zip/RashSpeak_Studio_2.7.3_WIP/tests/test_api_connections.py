import threading
import time
import tkinter as tk
import unittest
from unittest.mock import patch,Mock

import requests
import api_connections as api
import gemini_client
import official_sources
from api_settings_ui import open_settings


class ConnectionTests(unittest.TestCase):
    def test_provider_keys_are_separate_and_never_written_to_project_settings(self):
        with patch.object(official_sources,'_SESSION_KEYS',{}),patch.object(gemini_client,'_session_key',''),\
             patch('keyring.set_password')as stored,patch('smart_editor.save')as project_write:
            api.configure('youtube','TEST_YOUTUBE_KEY')
            api.configure('gemini','TEST_GEMINI_KEY')
            self.assertEqual(api.current_key('youtube'),'TEST_YOUTUBE_KEY')
            self.assertEqual(api.current_key('gemini'),'TEST_GEMINI_KEY')
            stored.assert_not_called();project_write.assert_not_called()
            self.assertFalse(api.configure('youtube',''))
            self.assertEqual(api.current_key('youtube'),'TEST_YOUTUBE_KEY')

    def test_remember_uses_each_providers_system_keyring(self):
        with patch('keyring.set_password')as stored,patch.object(official_sources,'_SESSION_KEYS',{}),patch.object(gemini_client,'_session_key',''):
            api.configure('youtube','TEST_YOUTUBE_KEY',True)
            api.configure('gemini','TEST_GEMINI_KEY',True)
            self.assertEqual(stored.call_args_list[0].args,('RashSpeakMediaSources','youtube','TEST_YOUTUBE_KEY'))
            self.assertEqual(stored.call_args_list[1].args,(gemini_client.SERVICE,'api_key','TEST_GEMINI_KEY'))

    def test_failed_system_store_does_not_silently_replace_active_key(self):
        with patch.object(official_sources,'_SESSION_KEYS',{'youtube':'old'}),\
             patch('keyring.set_password',side_effect=RuntimeError('TEST_PRIVATE_SECRET')):
            with self.assertRaises(api.ConnectionError)as error:api.configure('youtube','TEST_NEW_KEY',True)
            self.assertNotIn('TEST_PRIVATE_SECRET',str(error.exception))
            self.assertEqual(api.current_key('youtube'),'old')

    def test_connection_checks_typed_key_without_saving_it(self):
        with patch('api_connections.current_key',return_value='old'),patch('official_sources.YouTubeOfficial')as client,\
             patch('api_connections.configure')as store:
            result=api.check('youtube','NEW_TEST_KEY')
            self.assertEqual(client.call_args.kwargs['key'],'NEW_TEST_KEY')
            self.assertEqual(client.return_value.request.call_args.args,('channels',))
            self.assertIn('ليس اختبار تنزيل',result['message']);store.assert_not_called()

    def test_empty_key_uses_existing_binding_and_missing_key_is_reported(self):
        with patch('api_connections.current_key',return_value=''),patch('official_sources.YouTubeOfficial')as client:
            with self.assertRaises(api.ConnectionError):api.check('youtube')
            client.assert_not_called()
        with patch('api_connections.current_key',return_value='EXISTING_KEY'),patch('official_sources.YouTubeOfficial')as client:
            api.check('youtube');self.assertEqual(client.call_args.kwargs['key'],'EXISTING_KEY')

    def test_bad_typed_key_never_falls_back_to_an_existing_key(self):
        with patch('api_connections.current_key',return_value='old'),patch('official_sources.YouTubeOfficial')as client:
            with self.assertRaises(api.ConnectionError):api.check('youtube','bad key\n')
            client.assert_not_called()

    def test_proxy_rejection_is_distinct_from_key_rejection_and_never_echoes_key(self):
        with patch('official_sources.requests.get',side_effect=requests.exceptions.ProxyError('TEST_PRIVATE_SECRET')):
            with self.assertRaises(api.ConnectionError)as error:api.check('youtube','TEST_PRIVATE_SECRET')
            self.assertIn('قبل المصادقة',str(error.exception));self.assertNotIn('TEST_PRIVATE_SECRET',str(error.exception))
        with patch('gemini_client.requests.Session')as session:
            session.return_value.request.side_effect=requests.exceptions.ProxyError('TEST_PRIVATE_SECRET')
            with self.assertRaises(api.ConnectionError)as error:api.check('gemini','TEST_PRIVATE_SECRET')
            self.assertIn('قبل المصادقة',str(error.exception));self.assertNotIn('TEST_PRIVATE_SECRET',str(error.exception))

    def test_unexpected_request_error_is_sanitized(self):
        with patch('official_sources.YouTubeOfficial',side_effect=RuntimeError('TEST_PRIVATE_SECRET')):
            with self.assertRaises(api.ConnectionError)as error:api.check('youtube','TEST_PRIVATE_SECRET')
            self.assertNotIn('TEST_PRIVATE_SECRET',str(error.exception))

    def test_gemini_models_check_does_not_claim_generation_success(self):
        with patch('gemini_client.GeminiClient')as client:
            client.return_value.models.return_value=['gemini-3.1-flash-lite','gemini-image-preview']
            result=api.check('gemini','TEST_GEMINI_KEY','gemini-3.1-flash-lite')
            self.assertEqual(result['models'],['gemini-3.1-flash-lite'])
            self.assertIn('لا يختبر',result['message'])


class ApiUITests(unittest.TestCase):
    def setUp(self):
        self.root=tk.Tk();self.root.withdraw()
        with patch('api_connections.current_key',return_value='EXISTING_TEST_KEY'):
            self.window=open_settings(self.root)
        self.root.update();self.panels=self.window.api_panels

    def tearDown(self):
        self.root.destroy()

    def pump(self,panel):
        end=time.monotonic()+5
        while panel.busy and time.monotonic()<end:self.root.update();time.sleep(.01)
        self.root.update();self.assertFalse(panel.busy)

    def test_two_independent_masked_inputs_are_empty_and_persistence_is_opt_in(self):
        self.assertEqual(len(self.window.api_notebook.tabs()),2)
        for panel in self.panels.values():
            self.assertTrue(panel.entry.cget('show'));self.assertEqual(panel.key.get(),'');self.assertFalse(panel.remember.get())
        self.panels['youtube'].key.set('TEST_YOUTUBE_KEY')
        self.assertEqual(self.panels['gemini'].key.get(),'')

    def test_save_clears_and_remasks_only_the_selected_service(self):
        panel=self.panels['youtube'];panel.key.set('TEST_YOUTUBE_KEY');panel.reveal.set(True)
        with patch('api_connections.configure',return_value=True)as configure:
            panel.save();configure.assert_called_once_with('youtube','TEST_YOUTUBE_KEY',False)
        self.assertEqual(panel.key.get(),'');self.assertFalse(panel.reveal.get());self.assertTrue(panel.entry.cget('show'))

    def test_real_button_dispatches_off_thread_and_delivers_result_on_tk_thread(self):
        panel=self.panels['youtube'];panel.key.set('TEST_YOUTUBE_KEY');threads=[];main=threading.get_ident()
        def check(provider,value,model,cancel):
            threads.append(threading.get_ident());return {'message':'connected fixture','provider':provider}
        with patch('api_connections.check',side_effect=check)as check:
            panel.test_button.invoke();self.pump(panel)
        self.assertNotEqual(threads[0],main);self.assertEqual(panel.status.get(),'connected fixture')
        self.assertEqual(check.call_args.args[:2],('youtube','TEST_YOUTUBE_KEY'))
        self.assertEqual(panel.key.get(),'TEST_YOUTUBE_KEY')  # Testing doesn't save credentials.

    def test_invalid_new_input_does_not_test_the_old_saved_key(self):
        panel=self.panels['youtube'];panel.key.set('bad key')
        with patch('api_connections.check')as check:panel.test();check.assert_not_called()
        self.assertFalse(panel.busy)

    def test_worker_errors_and_closing_window_do_not_touch_destroyed_tk_widgets(self):
        panel=self.panels['youtube'];panel.key.set('TEST_YOUTUBE_KEY')
        with patch('api_connections.check',side_effect=RuntimeError('TEST_PRIVATE_SECRET')):
            panel.test();self.pump(panel)
        self.assertNotIn('TEST_PRIVATE_SECRET',panel.status.get())
        release=threading.Event();started=threading.Event();worker=[]
        def slow(*args):
            started.set();release.wait(2);return {'message':'unused'}
        with patch('api_connections.check',side_effect=slow):
            panel.test();self.assertTrue(started.wait(1));worker.append(panel.worker)
            self.window.destroy();release.set();worker[0].join(2);self.root.update()
        self.assertTrue(panel.cancel.is_set());self.assertFalse(worker[0].is_alive())

    def test_legacy_gemini_entry_opens_same_settings_with_gemini_selected(self):
        from gemini_ui import open_settings as legacy_settings
        self.window.destroy();self.window=legacy_settings(self.root);self.root.update()
        self.assertEqual(self.window.api_notebook.select(),str(self.window.api_panels['gemini']))
