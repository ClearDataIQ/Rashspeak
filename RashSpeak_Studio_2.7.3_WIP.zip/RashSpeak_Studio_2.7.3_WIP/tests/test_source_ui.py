from pathlib import Path
import tempfile
import threading
import tkinter as tk
from tkinter import ttk
import unittest
from unittest.mock import patch

from source_ui import open_settings


class SourceUITests(unittest.TestCase):
    def test_source_settings_has_real_tabs_one_masked_key_and_free_images_without_cx(self):
        root=tk.Tk();root.withdraw()
        try:
            with patch('source_ui.credential',return_value=''):
                window=open_settings(root);root.update()
            def walk(widget):
                for child in widget.winfo_children():
                    yield child
                    yield from walk(child)
            widgets=list(walk(window))
            books=[w for w in widgets if isinstance(w,ttk.Notebook)]
            self.assertEqual(len(books[0].tabs()),4)
            entries=[w for w in widgets if isinstance(w,(tk.Entry,ttk.Entry)) and w.cget('show')]
            self.assertEqual(len(entries),1)
            self.assertTrue(all(not w.get()for w in entries))
            window.destroy()
        finally:root.destroy()

    def test_insufficient_media_prevents_owner_approval_but_opens_editable_draft(self):
        from stage_review_ui import StageReviewPanel
        root=tk.Tk();root.withdraw();sent=[]
        try:
            request={'key':'media','label':'تركيب اللقطات','data':{'assets':[],'shots':[],'segments':[],
                     'quality':{'ready':False,'blockers':['لقطات ناقصة']},'draft_pro_project':'draft.json'},
                     'previews':[],'error':None,'last_good':{}}
            panel=StageReviewPanel(root,request,sent.append,lambda path:None,threading.Event());root.update()
            self.assertEqual(str(panel.approve_button['state']),'disabled')
            panel.approve();self.assertFalse(sent)
            panel.destroy()
        finally:root.destroy()
