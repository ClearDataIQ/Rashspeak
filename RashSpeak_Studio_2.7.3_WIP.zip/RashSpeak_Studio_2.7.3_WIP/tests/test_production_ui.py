import tempfile
from pathlib import Path
import threading
import time
import tkinter as tk
import gc
from tkinter import messagebox
import unittest
from unittest.mock import patch

from gui import create_app
from production_ui import ProductionPanel


class ProductionGuiTests(unittest.TestCase):
    def setUp(self):
        try:self.root=create_app()
        except tk.TclError as exc:self.skipTest(str(exc))
        self.root.withdraw();self.panel=self.root.production

    def tearDown(self):
        if hasattr(self,'root'):self.root.destroy()
        self.panel=None;self.root=None;gc.collect()

    def pump(self,until,timeout=5):
        end=time.monotonic()+timeout
        while not until() and time.monotonic()<end:
            self.root.update();time.sleep(.01)
        self.root.update();self.assertTrue(until())

    def test_main_window_is_two_input_production(self):
        self.assertIsInstance(self.panel,ProductionPanel)
        self.assertEqual(self.panel.script.get('1.0','end').strip(),'')
        self.assertEqual(len(self.panel.stage_labels),6)
        self.assertIn('2.7',self.root.title())
        self.assertEqual(self.panel.cancel_button['state'],'disabled')

    def test_input_actions_fit_small_window_and_arabic_preview_still_toggles(self):
        self.root.deiconify();self.root.geometry('1040x660');self.root.update()
        for widget in (self.panel.start_button,self.panel.audio_pick_button,self.panel.pick_script_button,self.panel.preview_button):
            self.assertGreaterEqual(widget.winfo_height(),widget.winfo_reqheight())
            self.assertLessEqual(widget.winfo_rooty()+widget.winfo_height(),self.root.winfo_rooty()+self.root.winfo_height())
        self.panel.script.insert('1.0','تجربة Elden Ring بالعربية.')
        self.panel.toggle_script();self.root.update();self.assertTrue(self.panel.previewing)
        self.panel.toggle_script();self.assertEqual(self.panel.script.get('1.0','end').strip(),'تجربة Elden Ring بالعربية.')

    def test_visible_api_button_opens_separate_youtube_and_gemini_inputs(self):
        self.root.api_button.invoke();self.root.update()
        window=next(w for w in self.root.winfo_children()if hasattr(w,'api_panels'))
        self.assertEqual(set(window.api_panels),{'youtube','gemini'})
        self.assertTrue(all(p.entry.cget('show')for p in window.api_panels.values()))

    def test_background_failure_delivered_to_tk_main_thread(self):
        self.panel.background(lambda:(_ for _ in ()).throw(ValueError('فشل الاختبار')),lambda x:self.fail())
        self.pump(lambda:not self.panel.busy)
        self.assertEqual(self.panel.note.get(),'فشل الاختبار')
        self.assertEqual(self.panel.cancel_button['state'],'disabled')

    def test_background_callback_main_thread_and_ui_responsive(self):
        main=threading.get_ident();threads=[];release=threading.Event();received=[]
        def work():threads.append(threading.get_ident());release.wait(2);return 42
        self.panel.background(work,lambda r:received.append((r,threading.get_ident())))
        self.root.update();self.assertTrue(self.panel.busy);release.set()
        self.pump(lambda:bool(received))
        self.assertNotEqual(threads[0],main);self.assertEqual(received,[(42,main)])

    def test_stale_waveform_result_is_ignored(self):
        self.panel.audio='new.wav'
        self.panel.events.put({'type':'wave','audio':'old.wav','result':{'duration':7,'peaks':[1]}})
        self.panel.drain()
        self.assertIsNone(self.panel.envelope)

    def test_history_and_new_episode_do_not_interrupt_job(self):
        self.panel.busy=True;self.panel.audio='input.wav'
        with patch('production_ui.tk.Toplevel') as window:self.panel.history();window.assert_not_called()
        self.panel.reset();self.assertEqual(self.panel.audio,'input.wav')

    def test_complete_and_failed_events_restore_controls(self):
        self.panel.busy=True
        with patch.object(self.panel,'show_result') as show:
            self.panel.events.put({'type':'complete','result':{'delivery':'example'}})
            self.panel.drain();show.assert_called_once()
        self.assertFalse(self.panel.busy)
        self.assertEqual(self.panel.progress['value'],100)
        self.panel.events.put({'type':'failed','message':'فشل الرندر'})
        self.panel.drain();self.assertEqual(self.panel.note.get(),'فشل الرندر')

    def test_cuts_remain_accessible_after_failed_rebuild(self):
        with tempfile.TemporaryDirectory() as folder:
            self.panel.project=Path(folder);(self.panel.project/'audio_edits.json').write_text('{"edits":[]}')
            self.panel.events.put({'type':'failed','message':'القص يقطع كلمة'})
            self.panel.drain()
            self.assertEqual(self.panel.review_button['state'],'normal')
            self.assertFalse(self.panel.busy)

    def test_delivery_controls_are_not_clipped_at_minimum_window_height(self):
        from PIL import Image
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'thumbnail.jpg';Image.new('RGB',(1280,720)).save(path)
            self.panel.result={'thumbnail':str(path),'files':[{'kind':'long','path':'long.mp4'},
                              *[{'kind':'short','path':f'short_{i}.mp4'} for i in range(3)]],'delivery':folder}
            self.root.deiconify();self.root.geometry('1120x800');self.root.update()
            self.panel.show_result();self.root.update()
            from rtl_ui import Button
            for card in self.panel.result_body.winfo_children():
                for widget in card.winfo_children():
                    if isinstance(widget,Button):self.assertGreaterEqual(widget.winfo_height(),widget.winfo_reqheight())
            self.assertTrue(self.panel.result_canvas.cget('scrollregion'))

    def test_thumbnail_edit_is_off_tk_thread(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);(root/'manifest.json').write_text('{"assets":[{"role":"clip"}]}')
            self.panel.result={'delivery':str(root/'delivery'),'thumbnail':str(root/'thumbnail.jpg')}
            threads=[]
            with patch('tkinter.simpledialog.askstring',return_value='عنوان'),patch('thumbnail.make_thumbnail',side_effect=lambda *a:threads.append(threading.get_ident()) or 'thumbnail.jpg'),patch.object(self.panel,'show_result'):
                self.panel.edit_thumbnail();self.pump(lambda:not self.panel.busy)
            self.assertNotEqual(threads[0],threading.get_ident())

    def test_start_uses_original_arabic_script_from_readable_preview(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);model=root/'models/small';model.mkdir(parents=True);(model/'model.bin').touch()
            self.panel.audio=str(root/'voice.wav');text='فورتنايت فيها تحديث مجاني.'
            self.panel.script.insert('1.0',text);self.panel.toggle_script()
            received=[]
            def engine(audio,script,project,**kwargs):
                received.append((audio,script,threading.get_ident()))
                kwargs['on_event']({'type':'complete','result':{'delivery':'test'}})
            with patch('production_ui.app_dir',return_value=root),patch('captions.local_model_path',return_value=model),patch('production_ui.new_project',return_value=root/'project'),patch('production_ui.produce',side_effect=engine),patch.object(self.panel,'show_result'):
                self.panel.start();self.pump(lambda:not self.panel.busy)
            self.assertEqual(received[0][:2],(self.panel.audio,text))
            self.assertNotEqual(received[0][2],threading.get_ident())
