from pathlib import Path
import tempfile
import unittest

from production_diagnostics import cause,write_report
from tests import test_media_director as director_tests


class DiagnosticsTests(unittest.TestCase):
    def test_bad_choice_is_not_misreported_as_an_api_outage(self):
        self.assertEqual(cause({'status':'ai_unavailable','reason':'المقتطف أقصر من الجملة'}),'invalid_selection')
        self.assertEqual(cause({'status':'ai_unavailable','reason':'Gemini تجاوز حد الاستخدام'}),'quota')
        self.assertEqual(cause({'status':'no_match','candidates':[]}),'missing_source')
        self.assertEqual(cause({'status':'no_match','candidates':[{'id':'a'}]}),'no_visual_match')
        self.assertEqual(cause({'status':'search_budget_reached'}),'search_budget')
        self.assertEqual(cause({'status':'partial_media'}),'download_failed')
        self.assertEqual(cause({'status':'needs_ai_selection'}),'ai_selection')

    def test_actionable_files_are_written_without_copying_private_sentence_text(self):
        row={'id':'s0000','game':'Elden Ring','status':'no_match','text':'PRIVATE NARRATION','start':0.,'end':4.,'query':'gameplay'}
        with tempfile.TemporaryDirectory() as folder:
            report=write_report(director_tests.QualityTests().timeline(True),{'sentences':[row]},folder)
            self.assertEqual(report['games']['Elden Ring']['missing_source'],1)
            for name in ('media_diagnostics.md','media_diagnostics.json','missing_media.csv'):
                content=(Path(folder)/name).read_text(encoding='utf-8-sig')
                self.assertNotIn('PRIVATE NARRATION',content)
