"""Exercise the actual PowerShell launcher with a declared non-media fixture."""
import hashlib
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest


@unittest.skipUnless(os.name=='nt'and shutil.which('powershell.exe'),'Windows PowerShell launcher')
class WindowsLauncherTests(unittest.TestCase):
    def test_arabic_space_path_launches_without_get_file_hash_cmdlet(self):
        source=Path(__file__).resolve().parent.parent
        with tempfile.TemporaryDirectory(prefix='rash-launch-')as temporary:
            root=Path(temporary)/'أداة اختبار مع مسافات';root.mkdir()
            shutil.copy2(source/'bootstrap.ps1',root/'bootstrap.ps1')
            subprocess.run([sys.executable,'-m','venv','--without-pip',str(root/'.venv')],check=True,capture_output=True,timeout=40)
            digest=hashlib.sha256(b'').hexdigest().upper()
            for filename,marker in (('requirements.txt','rash-ready.txt'),('requirements-asr.txt','rash-asr-ready.txt')):
                (root/filename).write_bytes(b'')
                (root/'.venv'/marker).write_text(digest,encoding='ascii')
            (root/'gui.py').write_text("from pathlib import Path\nPath('fixture-launched.txt').write_text('declared test fixture',encoding='utf-8')\n",encoding='utf-8')
            # Reproduce the absent/broken optional cmdlet without altering the host.
            command="function Get-FileHash { throw 'Get-FileHash unavailable in test' }; & '"+str(root/'bootstrap.ps1').replace("'","''")+"' -Launch"
            result=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-Command',command],capture_output=True,text=True,timeout=60)
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertEqual((root/'fixture-launched.txt').read_text(encoding='utf-8'),'declared test fixture')
            self.assertEqual((root/'.venv/rash-asr-ready.txt').read_text(encoding='ascii'),digest)


if __name__=='__main__':unittest.main()
