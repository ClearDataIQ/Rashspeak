"""Declared test sources/media only; no live API or owner preference changes."""
from copy import deepcopy
import gc
import hashlib
import json
from pathlib import Path
import tempfile
import tkinter as tk
import unittest
from unittest.mock import Mock,patch
from PIL import Image

from source_usage import owner_grant,accepted,evidence
from official_sources import apply_permission,SourceUnavailable
from media_acquisition import permission,download_excerpt
from smart_editor import licensed,import_asset


def source():
    return {'id':'youtube:abcdefghijk','provider':'youtube','video_id':'abcdefghijk','channel_id':'UC_FIXTURE',
            'official_channel_checked':True,'channel_handle':'@FixturePublisher','rights_status':'pending',
            'url':'https://www.youtube.com/watch?v=abcdefghijk','source':'https://www.youtube.com/watch?v=abcdefghijk',
            'title':'Declared fixture','duration':8.,'game':'Elden Ring','license':'unknown'}


class OwnerPermissionTests(unittest.TestCase):
    def test_explicit_owner_decision_needs_neither_license_nor_policy_url(self):
        c=source();grant=owner_grant(c['id']);c=apply_permission(c,{'permissions':{c['id']:grant}})
        self.assertEqual(c['rights_status'],'owner_accepted');self.assertTrue(accepted(c))
        self.assertEqual(permission(c)['license'],'unknown');self.assertEqual(permission(c)['evidence_url'],'')
        self.assertEqual(permission(c)['download_hosts'],[])  # Watch-page host is not a media CDN.
        self.assertFalse(evidence(permission(c))['publisher_permission_verified'])

    def test_unknown_source_without_owner_decision_stays_pending(self):
        c=source()
        with self.assertRaises(SourceUnavailable):permission(c)
        self.assertFalse(accepted(c))

    def test_channel_scope_reuses_decision_but_never_applies_to_other_channel(self):
        c=source();cfg={'permissions':{'@FixturePublisher':owner_grant('@FixturePublisher')}}
        self.assertTrue(accepted(apply_permission(deepcopy(c),cfg)))
        for mutate in ('channel','unverified'):
            other=deepcopy(c)
            if mutate=='channel':other['channel_handle']='@OtherPublisher'
            else:other['official_channel_checked']=False
            self.assertFalse(accepted(apply_permission(other,cfg)))

    def test_copied_or_unconfirmed_owner_record_does_not_authorize_another_source(self):
        c=source();c['rights_status']='owner_accepted';c['permission']=owner_grant('youtube:other')
        with self.assertRaises(SourceUnavailable):permission(c)
        c['permission']=owner_grant(c['id']);c['permission']['owner_decision']['accepted']=False
        self.assertFalse(accepted(c))
        with self.assertRaises(SourceUnavailable):permission(c)

    def test_legacy_documented_permission_remains_supported(self):
        c=source();g={'usage_approved':True,'download_allowed':True,'license':'Declared fixture policy','evidence_url':'https://publisher.example/policy'}
        c=apply_permission(c,{'permissions':{c['id']:g}})
        self.assertEqual(c['rights_status'],'approved');self.assertEqual(permission(c)['license'],g['license'])

    def test_auto_host_uses_exact_candidate_and_optional_manual_host_is_respected(self):
        c=source();c.update(id='steam:1174180:42',provider='steam',url='https://video.fastly.steamstatic.com/store_trailers/42/movie.mp4',
                            official_listing_checked=True,permission_scope='steam-app:1174180')
        cfg={'permissions':{'steam-app:1174180':owner_grant('steam-app:1174180')}}
        applied=apply_permission(deepcopy(c),cfg)
        self.assertEqual(applied['permission']['download_hosts'],['video.fastly.steamstatic.com'])
        self.assertEqual(cfg['permissions']['steam-app:1174180']['download_hosts'],[])
        cfg['permissions']['steam-app:1174180']=owner_grant('steam-app:1174180',['custom.example'])
        self.assertEqual(apply_permission(c,cfg)['permission']['download_hosts'],['custom.example'])
        with self.assertRaises(ValueError):owner_grant('steam-app:1174180',['https://custom.example/file.mp4'])

    def test_owner_choice_does_not_enable_AI_sources_or_private_image_download(self):
        c=source();c['ai_generated']=True
        c=apply_permission(c,{'permissions':{c['id']:owner_grant(c['id'])}})
        self.assertFalse(accepted(c))
        c=source();c.update(id='image:fixture',provider='google_images',url='https://127.0.0.1/image.png')
        c=apply_permission(c,{'permissions':{c['id']:owner_grant(c['id'])}})
        with tempfile.TemporaryDirectory()as folder,patch('media_acquisition.requests.get')as network:
            with self.assertRaises(SourceUnavailable):download_excerpt(c,0.,1.,folder)
            network.assert_not_called()

    def test_owner_choice_still_requires_actual_verified_scene(self):
        from visual_choices import validate_sequence
        from gemini_client import GeminiError
        from tests.test_visual_choices import candidate,decision
        from tests.test_media_director import request
        c=candidate();c=apply_permission(c,{'permissions':{c['id']:owner_grant(c['id'])}})
        row={**request(),'end':4.,'entities':['Ranni','Liurnia']}
        self.assertEqual(validate_sequence(row,[c],decision())['status'],'ready_to_download')
        c['reviewed_scenes']=[]
        with self.assertRaises(GeminiError):validate_sequence(row,[c],decision())

    def test_owner_steam_download_works_without_manual_fields_and_reuses_bytes(self):
        from tests.test_steam_sources import search
        from internet_video import source_file
        from media_tools import run
        with tempfile.TemporaryDirectory()as folder:
            root=Path(folder);fixture=root/'fixture.mp4'
            run(['ffmpeg','-v','error','-y','-f','lavfi','-i','color=blue:s=320x240:r=30:d=1','-c:v','libx264','-threads','1',fixture])
            payload=fixture.read_bytes();response=Mock();response.status_code=200;response.headers={'Content-Length':str(len(payload))}
            response.iter_content.side_effect=lambda _:iter([payload]);response.__enter__=Mock(return_value=response);response.__exit__=Mock(return_value=False)
            c=search({'permissions':{'steam-app:1174180':owner_grant('steam-app:1174180')}})[0][0]
            with patch('steam_sources.requests.get',return_value=response)as network:
                one=source_file(c,root/'cache');two=source_file(c,root/'cache')
            self.assertEqual(one,two);self.assertEqual(network.call_count,1)
            record=json.loads(one.with_suffix('.rights.json').read_text())
            self.assertEqual(record['license'],'unknown');self.assertFalse(record['publisher_permission_verified'])
            self.assertEqual(record['sha256'],hashlib.sha256(payload).hexdigest())

    def test_archive_reopen_render_and_delivery_preserve_unknown_license_and_owner_decision(self):
        from media_archive import MediaArchive
        from pro_project import new_project,Session,new_clip,load_project
        from pro_render import render,package
        c=source();c=apply_permission(c,{'permissions':{c['id']:owner_grant(c['id'])}})
        context={'game':'Elden Ring','event':'','entities':[],'idea':'Declared fixture'}
        def download(candidate,start,end,folder,cancel):
            p=folder/'image.png';Image.new('RGB',(320,180),'blue').save(p);return p
        def imported(p):return import_asset(p,game='Elden Ring',license='unknown',source=c['url'],approved=True)
        with tempfile.TemporaryDirectory()as folder:
            root=Path(folder);archive=MediaArchive(root/'archive')
            a,reused=archive.acquire(c,0.,1.,download,imported,context)
            self.assertFalse(reused);self.assertTrue(licensed(a));self.assertEqual(a['license'],'unknown')
            a2,reused=MediaArchive(root/'archive').acquire(c,0.,1.,Mock(side_effect=AssertionError('No second download')),imported,context)
            self.assertTrue(reused);self.assertEqual(a2['owner_decision'],a['owner_decision'])
            session=Session(new_project(size=(320,180)));track=session.add_track('image')
            session.add(track,new_clip(a['id'],duration=30),a)
            output=root/'actual.mp4';render(session.project,output)
            result=package(session.project,root/'delivery',[{'path':str(output),'kind':'long'}])
            delivery=Path(result['folder']);p=load_project(delivery/'Project/project.rash.json')
            self.assertEqual(p['media'][0]['owner_decision'],a['owner_decision'])
            credits=json.loads((delivery/'Media/credits.json').read_text())
            self.assertEqual(credits[0]['license'],'unknown');self.assertFalse(credits[0]['publisher_permission_verified'])
            self.assertIn('تصريح الناشر غير موثق',(delivery/'Media/MEDIA_CREDITS.txt').read_text(encoding='utf-8'))


class MinimalSourceFormTests(unittest.TestCase):
    def test_form_removes_two_required_fields_and_keeps_optional_auto_host(self):
        from source_ui import open_settings
        root=tk.Tk();root.withdraw()
        try:
            with tempfile.TemporaryDirectory()as folder,patch('api_connections.current_key',return_value=''),\
                 patch('source_ui.settings',return_value={'permissions':{}}),patch('source_ui.config_path',return_value=Path(folder)/'settings.json'):
                window=open_settings(root,source());root.update()
                self.assertEqual(set(window.rights_fields),{'source','download_hosts'})
                self.assertEqual(window.rights_fields['download_hosts'].get(),'')
                self.assertFalse((Path(folder)/'settings.json').exists())
                window.grant_button.invoke();self.assertFalse((Path(folder)/'settings.json').exists())
                window.rights_approved.set(True);window.grant_button.invoke()
                saved=json.loads((Path(folder)/'settings.json').read_text())
                self.assertEqual(saved['permissions'][source()['id']]['license'],'unknown')
                self.assertEqual(saved['permissions'][source()['id']]['evidence_url'],'')
                self.assertFalse(window.rights_approved.get()is False)
        finally:root.destroy();gc.collect()


if __name__=='__main__':unittest.main()
