from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from PIL import Image

from audio_checkpoint import render_cached
from project_bridge import sync_project,ProjectConflict
from pro_project import Session,new_project,import_media,new_clip,load_project,edit_digest

class CheckpointTests(unittest.TestCase):
    def test_audio_reuses_exact_bytes_and_invalidates_processing_keeps_or_tampering(self):
        with tempfile.TemporaryDirectory()as directory:
            root=Path(directory);source=root/'أصلي.wav';source.write_bytes(b'declared audio fixture')
            def render(audio,analysis,path,*args):path.parent.mkdir(exist_ok=True);path.write_bytes(b'processed fixture');return str(path)
            with patch('audio_edit.render_audio',side_effect=render)as call:
                one,reused=render_cached(source,{'keeps':[(0,1)]},root,{'denoise':False})
                self.assertFalse(reused)
                two,reused=render_cached(source,{'keeps':[(0,1)]},root,{'denoise':False})
                self.assertTrue(reused);self.assertEqual(one,two);self.assertEqual(call.call_count,1)
                Path(one).write_bytes(b'changed')
                self.assertFalse(render_cached(source,{'keeps':[(0,1)]},root,{'denoise':False})[1])
                self.assertFalse(render_cached(source,{'keeps':[(0,1)]},root,{'denoise':True})[1])
                self.assertFalse(render_cached(source,{'keeps':[(0,.5)]},root,{'denoise':False})[1])
                self.assertEqual(source.read_bytes(),b'declared audio fixture')

    def test_same_auto_inputs_reopen_pro_trim_and_undo_without_rebuilding(self):
        with tempfile.TemporaryDirectory()as directory:
            root=Path(directory);image=root/'صورة.png';Image.new('RGB',(320,180),'red').save(image)
            session=Session(new_project(size=(320,180)));track=session.add_track('image');asset=import_media(image)
            clip=session.add(track,new_clip(asset['id'],duration=90),asset);auto=deepcopy(session.project);path=root/'current.rash.json'
            sync_project(auto,{'input':'same'},path)
            editor=Session(load_project(path));editor.properties(clip,transform={'x':.1,'y':.1,'scale':.8,'opacity':1.});edited=edit_digest(editor.project);editor.save(path)
            reopened=sync_project(auto,{'input':'same'},path)
            self.assertEqual(edit_digest(reopened),edited)
            before=path.read_bytes()
            with self.assertRaises(ProjectConflict):sync_project(auto,{'input':'changed'},path)
            self.assertEqual(path.read_bytes(),before)
            editor.undo();editor.save(path)
            self.assertEqual(edit_digest(sync_project(auto,{'input':'changed'},path)),edit_digest(auto))

if __name__=='__main__':unittest.main()
