import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock,patch

from media_tools import run
from official_sources import SourceUnavailable
from steam_sources import SteamOfficial,valid_video_url


URL='https://video.fastly.steamstatic.com/store_trailers/42/movie_max.mp4'
GRANT={'usage_approved':True,'download_allowed':True,'license':'Explicit synthetic test permission',
       'evidence_url':'https://publisher.example/permission','download_hosts':['video.fastly.steamstatic.com']}


class Response:
    status_code=200
    def __init__(self,data):self.data=data;self.content=json.dumps(data).encode()
    def json(self):return self.data
    def close(self):pass


def listing():
    return {'1174180':{'success':True,'data':{'steam_appid':1174180,'name':'Red Dead Redemption 2','type':'game',
        'publishers':['Synthetic fixture publisher'],'movies':[{'id':42,'name':'Synthetic trailer','mp4':{'max':URL}}]}}}


def search(config=None,data=None):
    http=Mock();http.get.return_value=Response(data or listing())
    provider=SteamOfficial(config=config or {},http=http)
    return provider.search({'game':'Red Dead Redemption 2','role':'clip'}),http


class SteamTests(unittest.TestCase):
    def test_public_search_uses_no_key_and_does_not_invent_duration_or_rights(self):
        with patch('official_sources.credential',side_effect=AssertionError('no key required')):
            items,http=search()
        self.assertEqual(len(items),1);self.assertEqual(items[0]['rights_status'],'pending')
        self.assertIsNone(items[0]['duration']);self.assertEqual(http.get.call_args.kwargs['params'],{'appids':1174180,'l':'english'})

    def test_app_scope_grant_is_specific_and_other_game_or_host_is_not_approved(self):
        items,_=search({'permissions':{'steam-app:1174180':GRANT}})
        self.assertEqual(items[0]['rights_status'],'approved')
        pending,_=search({'permissions':{'steam-app:292030':GRANT}})
        self.assertEqual(pending[0]['rights_status'],'pending')
        for url in ['http://video.fastly.steamstatic.com/store_trailers/42/a.mp4',
                    'https://video.fastly.steamstatic.com.evil.example/store_trailers/a.mp4',
                    'https://127.0.0.1/store_trailers/a.mp4','https://video.fastly.steamstatic.com/private/a.mp4']:
            self.assertFalse(valid_video_url(url))

    def test_changed_listing_or_stream_only_movie_never_becomes_a_download(self):
        data=listing();data['1174180']['data']['name']='Different game'
        with self.assertRaises(SourceUnavailable):search(data=data)
        data=listing();data['1174180']['data']['movies']=[{'id':42,'hls_h264':'https://example.test/private.m3u8'}]
        self.assertEqual(search(data=data)[0],[])

    def test_unapproved_source_never_probed_downloaded_or_sent_for_analysis(self):
        from internet_video import source_file
        items,_=search()
        with tempfile.TemporaryDirectory() as folder,patch('steam_sources.requests.get')as network,self.assertRaises(SourceUnavailable):
            source_file(items[0],folder)
        network.assert_not_called()

    def test_granted_file_is_downloaded_once_probed_and_cached_with_real_hash(self):
        from internet_video import source_file
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);fixture=root/'fixture.mp4'
            run(['ffmpeg','-v','error','-y','-f','lavfi','-i','color=blue:s=320x240:r=30:d=2','-c:v','libx264','-threads','1',fixture])
            data=fixture.read_bytes();response=Mock();response.status_code=200
            response.headers={'Content-Length':str(len(data))};response.iter_content.side_effect=lambda _:iter([data])
            response.__enter__=Mock(return_value=response);response.__exit__=Mock(return_value=False)
            item=search({'permissions':{'steam-app:1174180':GRANT}})[0][0]
            with patch('steam_sources.requests.get',return_value=response)as network:
                one=source_file(item,root/'cache');two=source_file(item,root/'cache')
            self.assertEqual(network.call_count,1);self.assertEqual(one,two)
            self.assertAlmostEqual(item['duration'],2.,delta=.05)
            rights=json.loads(one.with_suffix('.rights.json').read_text())
            self.assertEqual(rights['sha256'],hashlib.sha256(data).hexdigest())


if __name__=='__main__':unittest.main()
