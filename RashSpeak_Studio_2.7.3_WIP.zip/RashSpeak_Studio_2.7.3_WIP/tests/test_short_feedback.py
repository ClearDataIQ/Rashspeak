"""Quality regressions use declared fixtures; actual owner audio is tested separately."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock,patch

import captions
from image_fallback import extend_plan,insert_window
from transcript_quality import reconcile
from licensed_media import candidate,download_variant
from production_quality import assess,context_matches
from tests import test_licensed_media as media_fixture
from tests import test_media_director as director_fixture
from tests import test_production as voice_fixture


class FeedbackTests(unittest.TestCase):
    def test_custom_caption_stroke_scales_with_preview_and_export_pixels(self):
        from media_tools import run
        from pro_project import Session,new_project,new_clip,sequence
        from pro_render import render
        from PIL import Image
        with tempfile.TemporaryDirectory()as folder:
            root=Path(folder);session=Session(new_project(size=(640,360)))
            track=session.add_track('text');session.add(track,new_clip(start=0,duration=30,text='مرحبا بالعالم'))
            t=next(t for t in sequence(session.project)['tracks']if t['id']==track)
            t['caption']={'font':'Arial','style':'gaming','region':[.1,.6,.8,.3],'font_size':50,'outline':2.}
            counts=[]
            for w,h in ((640,360),(1280,720)):
                video=root/f'{w}.mp4';frame=root/f'{w}.png'
                render(session.project,video,size=(w,h),crf=12)
                run(['ffmpeg','-v','error','-y','-ss','0.3','-i',video,'-frames:v','1',frame])
                with Image.open(frame)as image:counts.append(sum(max(pixel[:3])<12 for pixel in image.convert('RGB').getdata()))
            self.assertGreater(counts[0],100)
            self.assertGreater(counts[1]/counts[0],3.)
            self.assertLess(counts[1]/counts[0],5.5)

    def test_same_game_metadata_alone_never_passes_real_production_scene_gate(self):
        t=director_fixture.QualityTests().timeline();t['require_scene_evidence']=True
        self.assertTrue(assess(t)['unverified_scene_ranges']);self.assertFalse(assess(t)['ready'])
        t['assets'][0]['scene_verified']=True
        self.assertTrue(assess(t)['ready'])

    def test_verified_scene_flag_survives_archive_restart_after_materialization(self):
        from media_archive import MediaArchive
        from media_director import materialize
        from smart_editor import import_asset
        from PIL import Image
        with tempfile.TemporaryDirectory()as folder:
            archive=MediaArchive(folder);row={**director_fixture.request(),'kind':'image','status':'ready_to_download',
                'selection':{'candidate':director_fixture.source(),'source_in':0.,'source_out':1.,'scene_verified':True,'reason':'Explicit fixture evidence'}}
            def download(c,a,b,p,cancel):
                file=p/'fixture.png';Image.new('RGB',(64,64)).save(file);return file
            def imported(p,c):return import_asset(p,game='Elden Ring',license='Synthetic fixture',source='Synthetic fixture',approved=True)
            materialize({'sentences':[row]},archive,download,imported)
            cached=MediaArchive(folder).find({**row,'require_scene_evidence':True})
            self.assertEqual(len(cached),1);self.assertTrue(cached[0]['scene_verified'])

    def test_real_hd_original_wins_over_480p_derivative_with_inflated_estimate(self):
        page=media_fixture.page();info=page['imageinfo'][0]
        info.update(size=118804149,width=1920,height=1080,duration=355.661,
            derivatives=[{'src':'https://upload.wikimedia.org/480.webm','type':'video/webm',
                          'transcodekey':'480p.vp9.webm','width':854,'height':480,'bandwidth':1076168}])
        item=candidate(page,'Fortnite')
        self.assertEqual(item['url'],info['url']);self.assertEqual((item['width'],item['height']),(1920,1080))
        self.assertEqual(item['size'],118804149)
        info['size']=800_000_000
        self.assertEqual(download_variant(info)['height'],480)

    def test_script_corrects_anchored_spelling_but_never_inserts_missing_words_or_changes_numbers(self):
        words=voice_fixture.words('اليوم عندنا لعبه عالم مفتوح جميلة');words[2].update(text='لعبةه',probability=.45)
        before=deepcopy(words)
        fixed,report=reconcile(words,'اليوم عندنا لعبة عالم مفتوح جميلة')
        self.assertEqual(fixed[2]['text'],'لعبة');self.assertEqual(fixed[2]['original_text'],'لعبةه')
        self.assertEqual(words,before);self.assertEqual(len(fixed),len(words))
        self.assertEqual([(w['start'],w['end'])for w in fixed],[(w['start'],w['end'])for w in words])
        fixed,report=reconcile(voice_fixture.words('اليوم عندنا 20 لعبة ممتازة جدا'),'اليوم عندنا 30 لعبة ممتازة جدا')
        self.assertEqual(fixed[2]['text'],'20');self.assertTrue(report['proposals'])
        fixed,report=reconcile(before,'اليوم عندنا لعبة جديدة جدا عالم مفتوح جميلة')
        self.assertEqual(len(fixed),len(before));self.assertEqual(report['words_added'],0)

    def test_without_script_keeps_dialect_and_exposes_uncertain_words(self):
        words=voice_fixture.words('وش رايكم ذحين نلعب');words[2]['probability']=.3
        fixed,report=reconcile(words)
        self.assertEqual(fixed,words);self.assertEqual(report['needs_listening'][0]['index'],2)
        self.assertEqual(report['reference'],'none')

    def test_caption_defaults_larger_and_thinner_at_both_aspects_custom_style_preserved(self):
        with tempfile.TemporaryDirectory()as folder:
            for size,region in [((1920,1080),(.1,.78,.8,.15)),((1080,1920),(.1,.7,.74,.12))]:
                path=Path(folder)/'captions.ass'
                captions.write_ass([{'start':0.,'end':2.,'text':'وش رايكم يا جماعة'}],path,size=size,region=region)
                style=next(l for l in path.read_text(encoding='utf-8-sig').splitlines()if l.startswith('Style:')).split(',')
                old=round(min(size[1]*.048,region[3]*size[1]/2.8))
                self.assertGreater(float(style[2]),old);self.assertLess(float(style[16]),3)
            captions.write_ass([],path,font_size=44,outline=1.25)
            self.assertIn('Arial,44,',path.read_text(encoding='utf-8-sig'))

    def test_wrong_entity_and_low_resolution_cannot_pass_the_auto_gate(self):
        self.assertFalse(context_matches({'game':'Elden Ring','entities':['Ranni']}, {'entities':['Radahn']}, 'Elden Ring'))
        t=director_fixture.QualityTests().timeline()
        before=assess(t)
        self.assertTrue(before['ready'])
        t['source_quality']={'min_source_height':720,'enforced':True}
        for a in t['assets']:a['height']=480
        result=assess(t)
        self.assertFalse(result['ready']);self.assertTrue(result['low_resolution_ranges'])
        self.assertGreater(len(result['blockers']),len(before['blockers']))

    def test_picture_is_brief_on_named_word_and_gameplay_returns_in_real_timeline(self):
        from media_director import apply_plan
        row={**director_fixture.request(entities=['Ranni']),'start':0.,'end':8.,'text':'A Ranni character',
             'kind':'gameplay','role':'clip','status':'no_verified_scene','idea':'character','query':'Ranni','reason':'Test fixture'}
        segments=[{'start':0.,'end':8.,'text':row['text'],'words':[{'start':4.,'end':4.5,'text':'Ranni'}]}]
        self.assertEqual(insert_window(row,segments),(3.85,6.65))
        image={'id':'picture','kind':'image','game':'Elden Ring'}
        planned={**row,'kind':'image','status':'cached','asset':image,'asset_id':'picture'}
        provider=Mock();archive=Mock()
        with patch('media_director.build_plan',return_value={'sentences':[planned]})as planner:
            result=extend_plan({'sentences':[row]},segments,archive,{'images':provider},None)
        fallback=result['sentences'][-1];self.assertTrue(fallback['fallback_image']);self.assertEqual(fallback['id'],row['id']+':image')
        # Apply the actual planned window, not the original eight-second sentence.
        call=planner.call_args.args[0][0];fallback.update(start=call['start'],end=call['end'])
        t={'assets':[{'id':'gameplay','kind':'video'}],'shots':[{'start':0.,'end':8.,'asset_id':'gameplay','source_offset':0.}]}
        apply_plan(t,result)
        self.assertEqual([s['asset_id']for s in t['shots']],['gameplay','picture','gameplay'])
        self.assertAlmostEqual(t['shots'][-1]['start'],6.65)

    def test_audio_only_reaches_real_audio_review_without_owner_script(self):
        from production import produce
        from media_tools import Cancelled
        words=voice_fixture.words('وش رايكم نلعب فورتنايت');asr={'words':words,'segments':[{'start':0.,'end':2.,'text':'وش رايكم نلعب فورتنايت'}]}
        with tempfile.TemporaryDirectory()as folder:
            root=Path(folder);audio=root/'voice.wav';voice_fixture.signal(audio,words,2.)
            def review(request):
                self.assertEqual(request['key'],'audio');self.assertEqual(request['data']['transcript_review']['reference'],'none')
                return {'action':'cancel'}
            with self.assertRaises(Cancelled):produce(audio,'',root/'project',online=False,asr_override=asr,on_review=review)
            state=json.loads((root/'project/production.json').read_text())
            self.assertEqual(state['script_origin'],'asr_derived_reference')
            self.assertTrue((root/'project/asr_reference.txt').is_file())

    def test_retranscription_preserves_old_cache_and_requires_fresh_audio_review(self):
        from production import produce
        from media_tools import Cancelled
        words=voice_fixture.words('وش رايكم نلعب فورتنايت');asr={'words':words,'segments':[{'start':0.,'end':2.,'text':'وش رايكم نلعب فورتنايت'}]}
        fresh=deepcopy(asr);fresh['words'][1]['text']='رأيكم';fresh['segments'][0]['text']='وش رأيكم نلعب فورتنايت'
        calls=[]
        with tempfile.TemporaryDirectory()as folder:
            root=Path(folder);audio=root/'voice.wav';voice_fixture.signal(audio,words,2.)
            def review(request):
                calls.append(request)
                if len(calls)==1:
                    data=deepcopy(request['data']);data['retranscribe']=True
                    return {'action':'revise','data':data}
                self.assertEqual(request['data']['words'][1]['text'],'رأيكم')
                return {'action':'cancel'}
            with patch('captions.transcribe',return_value=fresh)as decoder,self.assertRaises(Cancelled):
                produce(audio,'',root/'project',online=False,asr_override=asr,on_review=review)
            decoder.assert_called_once();self.assertEqual(len(calls),2)
            backups=list((root/'project/asr_revisions').glob('*.json'));self.assertEqual(len(backups),1)
            self.assertEqual(json.loads(backups[0].read_text())['result']['words'][1]['text'],'رايكم')
