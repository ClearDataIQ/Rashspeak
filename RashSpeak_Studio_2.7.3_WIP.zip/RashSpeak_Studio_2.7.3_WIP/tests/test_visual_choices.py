"""Batched visual edits use declared fixtures; no synthetic gameplay claims."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock,patch

from gemini_client import GeminiError
from media_director import apply_plan,build_plan,materialize
from visual_choices import choose_batch,validate_sequence,spread_within_reviewed_scene
from tests.test_media_director import request,source


def candidate():
    value=source();value['reviewed_scenes']=[{'start':0.,'end':2.,'game':'Elden Ring','event':'','entities':['Ranni']},
        {'start':3.,'end':5.,'game':'Elden Ring','event':'','entities':['Liurnia']}]
    return value


def decision(key='s0000'):
    return {'id':key,'shots':[{'candidate_id':source()['id'],'source_in':a,'source_out':b,
                             'scene_verified':True,'reason':'Synthetic scene evidence'} for a,b in [(0.,2.),(3.,5.)]]}


class BatchChoiceTests(unittest.TestCase):
    def test_pending_rights_preserves_batch_queue_without_ai_or_download(self):
        from media_archive import MediaArchive
        segments=[{'start':0.,'end':4.,'text':'إلدن رينج عالم مفتوح','story_topic':'Elden Ring'}]
        c=candidate();c['rights_status']='pending';c.pop('reviewed_scenes')
        provider=Mock();provider.search.return_value=[c]
        client=Mock();client.model='gemini-test'
        with tempfile.TemporaryDirectory()as folder:
            result=build_plan(segments,MediaArchive(folder),{'youtube':provider},client,batch_size=8)
        self.assertEqual(result['sentences'][0]['status'],'needs_source_review')
        client.generate.assert_not_called();self.assertEqual(result['selection_batch_count'],0)

    def test_offline_missing_provider_does_not_spend_search_budget(self):
        from media_archive import MediaArchive
        segments=[{'start':i*4.,'end':i*4.+4.,'text':str(i),'story_topic':'Elden Ring'}for i in range(3)]
        with tempfile.TemporaryDirectory()as folder:
            result=build_plan(segments,MediaArchive(folder),{},max_searches=1,batch_size=8)
        self.assertEqual(result['search_count'],0)
        self.assertEqual([r['status']for r in result['sentences']],['source_unavailable']*3)

    def test_variation_stays_inside_same_reviewed_scene(self):
        c=candidate();c['reviewed_scenes']=[{'start':0.,'end':12.,'game':'Elden Ring','event':'','entities':[]}]
        choice={'candidate':c,'source_in':2.,'source_out':4.,'reason':'Reviewed scene','scene_verified':True}
        result=spread_within_reviewed_scene([choice],{c['id']:[(2.,4.)]})
        self.assertEqual((result[0]['source_in'],result[0]['source_out']),(0.,2.))
        self.assertEqual(choice['source_in'],2.)

    def test_local_window_timestamps_are_mapped_back_to_source_and_cache_is_validated(self):
        from media_director import analyse_video
        c=candidate();c['provider']='commons_video';c['duration']=400.
        local={'start':2.,'end':4.,'game':'Elden Ring','event':'','entities':[],
               'description':'Synthetic window','confidence':.95}
        client=Mock();client.model='gemini-test';client.generate.return_value={'scenes':[local]}
        with tempfile.TemporaryDirectory() as folder,patch('internet_video.analysis_proxy',return_value=(Path(folder)/'window180.mp4',10.)):
            one=analyse_video(c,request(),client,folder,window_start=180.)
            two=analyse_video(c,request(),client,folder,window_start=180.)
        self.assertEqual((one[0]['start'],one[0]['end']),(182.,184.));self.assertEqual(one,two)
        self.assertEqual(client.generate.call_count,1)
    def test_two_short_scenes_can_cover_one_sentence_without_changing_words(self):
        row={**request(),'end':4.,'entities':['Ranni','Liurnia']};before=deepcopy(row)
        result=validate_sequence(row,[candidate()],decision())
        self.assertEqual(result['status'],'ready_to_download');self.assertEqual(len(result['selections']),2)
        self.assertEqual(row,before)
        bad=decision();bad['shots'][1]['source_in']=2.;bad['shots'][1]['source_out']=4.
        with self.assertRaises(GeminiError):validate_sequence(row,[candidate()],bad)
        with self.assertRaises(GeminiError):validate_sequence({**row,'event':'new update'},[candidate()],decision())
        with self.assertRaises(GeminiError):validate_sequence({**row,'entities':['unseen character']},[candidate()],decision())

    def test_shared_candidate_payload_and_individual_cache_survive_retry(self):
        rows=[{**request(),'id':f's{i:04d}','end':4.,'candidates':[candidate()]} for i in range(2)]
        client=Mock();client.model='gemini-test'
        client.generate.return_value={'selections':[decision(r['id'])for r in rows]}
        with tempfile.TemporaryDirectory() as folder:
            first=choose_batch(rows,client,folder);again=choose_batch(rows,client,folder)
        self.assertEqual(client.generate.call_count,1);self.assertEqual(first,again)
        payload=client.generate.call_args.args[1]
        self.assertEqual(len(payload['candidates']),1)
        self.assertNotIn('candidates',payload['sentences'][0])

    def test_invalid_row_does_not_discard_other_valid_decision_or_poison_cache(self):
        rows=[{**request(),'id':f's{i:04d}','end':4.,'candidates':[candidate()]}for i in range(2)]
        bad=decision(rows[1]['id']);bad['shots'][0]['candidate_id']='invented'
        client=Mock();client.model='gemini-test';client.generate.side_effect=[{'selections':[decision(rows[0]['id']),bad]},
            {'selections':[decision(rows[1]['id'])]}]
        with tempfile.TemporaryDirectory() as folder:
            first=choose_batch(rows,client,folder)
            self.assertEqual([r['status']for r in first],['ready_to_download','selection_invalid'])
            second=choose_batch(rows,client,folder)
        self.assertTrue(all(r['status']=='ready_to_download' for r in second))
        self.assertEqual(len(client.generate.call_args.args[1]['sentences']),1)

    def test_unknown_and_duplicate_ids_rejected_before_any_application(self):
        row={**request(),'end':4.,'candidates':[candidate()]};client=Mock();client.model='gemini-test'
        for values in [[decision('invented')],[decision(),decision()]]:
            client.generate.return_value={'selections':values}
            with self.assertRaises(GeminiError):choose_batch([row],client)

    def test_eight_sentences_share_one_choice_call_and_retain_individual_times(self):
        from media_archive import MediaArchive
        segments=[{'start':i*4.,'end':i*4.+4.,'text':'صوت محفوظ','story_topic':'Elden Ring'}for i in range(8)]
        provider=Mock();provider.search.return_value=[candidate()]
        client=Mock();client.model='gemini-test';client.generate.return_value={'selections':[decision(f's{i:04d}')for i in range(8)]}
        with tempfile.TemporaryDirectory() as folder,patch('media_director.analyse_video',return_value=candidate()['reviewed_scenes']):
            plan=build_plan(segments,MediaArchive(folder),{'youtube':provider},client,batch_size=8)
        self.assertEqual(client.generate.call_count,1);self.assertEqual(plan['ready_count'],8)
        self.assertEqual(plan['sentences'][-1]['start'],28.)

    def test_two_real_visual_parts_reach_renderer_and_sources_are_not_modified(self):
        from PIL import Image
        from media_archive import MediaArchive
        from media_tools import run,duration
        from smart_editor import import_asset,plan as legacy_plan
        from pro_project import from_legacy
        from pro_render import render
        from tests.test_production import words,signal
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);original=root/'synthetic.mp4'
            run(['ffmpeg','-v','error','-y','-f','lavfi','-i','color=red:s=320x180:r=30:d=3',
                 '-f','lavfi','-i','color=blue:s=320x180:r=30:d=3','-filter_complex','[0:v][1:v]concat=n=2:v=1:a=0[v]',
                 '-map','[v]','-c:v','libx264','-threads','1',original])
            original_bytes=original.read_bytes();context={**request(),'end':4.,'status':'ready_to_download','reason':'Synthetic visual sequence','selections':validate_sequence({**request(),'end':4.},[candidate()],decision())['selections']}
            context['selection']=context['selections'][0]
            def download(c,a,b,p,cancel):
                out=p/'clip.mp4';run(['ffmpeg','-v','error','-y','-ss',str(a),'-i',original,'-t',str(b-a),'-c:v','libx264','-threads','1',out]);return out
            def imported(p,c):return import_asset(p,game='Elden Ring',license='Synthetic fixture',source='Synthetic fixture',approved=True)
            archive=MediaArchive(root/'archive')
            plan=materialize({'sentences':[context]},archive,download,imported)
            self.assertEqual(len(plan['sentences'][0]['visual_parts']),2)
            again=materialize({'sentences':[context]},archive,Mock(side_effect=AssertionError('must reuse')),imported)
            self.assertTrue(all(p['status']=='cached'for p in again['sentences'][0]['visual_parts']))
            audio=root/'voice.wav';text='إلدن رينج عالم مفتوح';signal(audio,words(text),4)
            timeline=legacy_plan(audio,{'assets':[]},[{'start':0.,'end':4.,'text':text,'story_topic':'Elden Ring'}])
            apply_plan(timeline,plan)
            doc=from_legacy(timeline)
            for seq in doc['sequences']:seq.update(width=320,height=180)
            output=root/'actual.mp4';render(doc,output)
            self.assertAlmostEqual(duration(output),4.,delta=.08)
            colors=[]
            for time in (.5,2.5):
                frame=root/(str(time)+'.png');run(['ffmpeg','-v','error','-y','-ss',str(time),'-i',output,'-frames:v','1',frame])
                with Image.open(frame)as image:colors.append(image.getpixel((10,10)))
            self.assertGreater(colors[0][0],colors[0][2]+100);self.assertGreater(colors[1][2],colors[1][0]+100)
            self.assertEqual(original.read_bytes(),original_bytes)
