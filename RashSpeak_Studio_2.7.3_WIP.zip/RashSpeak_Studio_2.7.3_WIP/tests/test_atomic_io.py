import concurrent.futures
import ctypes
import json
import os
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch

import atomic_io
from smart_editor import save


def windows_error(code):
    error = PermissionError('declared Windows lock fixture')
    error.winerror = code
    return error


class AtomicSaveTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / 'sentence_media_plan.json'
        self.path.write_text('{"previous": true}', encoding='utf-8')

    def test_transient_windows_errors_retry_and_commit_complete_arabic_json(self):
        replace = os.replace
        for code in (5, 32, 33):
            with self.subTest(code=code), patch('atomic_io.os.replace', side_effect=[windows_error(code), windows_error(code), None]) as call, patch('atomic_io.time.sleep') as sleep:
                # Perform the eventual rename for real, after two declared locks.
                def replace_after_lock(source, target):
                    if call.call_count <= 2:
                        raise windows_error(code)
                    replace(source, target)
                call.side_effect = replace_after_lock
                save({'text': 'خطة اللقطات', 'rows': list(range(100))}, self.path)
                self.assertEqual(call.call_count, 3)
                self.assertEqual(sleep.call_count, 2)
                self.assertEqual(json.loads(self.path.read_text(encoding='utf-8'))['text'], 'خطة اللقطات')
                self.assertEqual(list(self.path.parent.glob('*.tmp')), [])

    def test_persistent_lock_retains_old_target_and_complete_recovery_draft(self):
        previous = self.path.read_bytes()
        with patch('atomic_io.os.replace', side_effect=windows_error(5)) as call, patch('atomic_io.time.sleep') as sleep:
            with self.assertRaises(atomic_io.AtomicSaveError) as caught:
                save({'new': 'تقدم محفوظ'}, self.path)
        self.assertEqual(call.call_count, len(atomic_io.RETRY_DELAYS) + 1)
        self.assertEqual(sleep.call_count, len(atomic_io.RETRY_DELAYS))
        self.assertEqual(self.path.read_bytes(), previous)
        draft = caught.exception.recovery_path
        self.assertEqual(json.loads(draft.read_text(encoding='utf-8')), {'new': 'تقدم محفوظ'})
        self.assertIn(str(draft), str(caught.exception))

    def test_disk_error_is_not_retried_or_hidden(self):
        with patch('atomic_io.os.replace', side_effect=OSError(28, 'disk full')), patch('atomic_io.time.sleep') as sleep:
            with self.assertRaises(atomic_io.AtomicSaveError) as caught:
                save({'new': True}, self.path)
        sleep.assert_not_called()
        self.assertEqual(caught.exception.original_error.errno, 28)
        self.assertTrue(json.loads(self.path.read_text())['previous'])

    def test_invalid_payload_leaves_no_partial_file(self):
        with self.assertRaises(TypeError):
            save({'bad': object()}, self.path)
        self.assertEqual(len(list(self.path.parent.iterdir())), 1)

    def test_flush_failure_cleans_incomplete_draft_and_preserves_target(self):
        previous = self.path.read_bytes()
        with patch('atomic_io.os.fsync', side_effect=OSError(28, 'disk full')):
            with self.assertRaises(OSError):
                save({'new': True}, self.path)
        self.assertEqual(self.path.read_bytes(), previous)
        self.assertEqual(list(self.path.parent.glob('*.tmp')), [])

    def test_concurrent_writers_have_distinct_drafts_and_never_partial_json(self):
        real_replace = os.replace
        staged = []
        seen = set()
        mutex = threading.Lock()
        barrier = threading.Barrier(6)
        def synchronized_replace(source, target):
            with mutex:
                first = str(source) not in seen
                if first:
                    seen.add(str(source))
                    staged.append(str(source))
            if first:
                barrier.wait(timeout=10)
            real_replace(source, target)
        with patch('atomic_io.os.replace', side_effect=synchronized_replace):
            with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
                list(pool.map(lambda n: save({'writer': n, 'rows': [n] * 2000}, self.path), range(6)))
        result = json.loads(self.path.read_text())
        self.assertEqual(result['rows'], [result['writer']] * 2000)
        self.assertEqual(len(set(staged)), 6)
        self.assertEqual(list(self.path.parent.glob('*.tmp')), [])

    @unittest.skipUnless(os.name == 'nt', 'requires actual Windows file sharing')
    def test_actual_windows_handle_denies_replace_then_save_recovers(self):
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel.CreateFileW.argtypes = [ctypes.c_wchar_p, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_void_p, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_void_p]
        kernel.CreateFileW.restype = ctypes.c_void_p
        kernel.CloseHandle.argtypes = [ctypes.c_void_p]
        # Read/write sharing allowed, deletion/rename sharing explicitly denied.
        handle = kernel.CreateFileW(str(self.path), 0x80000000, 3, None, 3, 0, None)
        self.assertNotEqual(handle, ctypes.c_void_p(-1).value)
        locked_attempt = threading.Event()
        original_replace = os.replace
        codes = []
        def observed_replace(source, target):
            try:
                original_replace(source, target)
            except OSError as exc:
                codes.append(exc.winerror)
                locked_attempt.set()
                raise
        try:
            with patch('atomic_io.os.replace', side_effect=observed_replace):
                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                    future = pool.submit(save, {'resumed': True}, self.path)
                    try:
                        self.assertTrue(locked_attempt.wait(5))
                        self.assertTrue(json.loads(self.path.read_text())['previous'])
                    finally:
                        kernel.CloseHandle(handle)
                        handle = None
                    future.result(timeout=8)
        finally:
            if handle is not None:
                kernel.CloseHandle(handle)
        self.assertIn(codes[0], (5, 32, 33))
        self.assertTrue(json.loads(self.path.read_text())['resumed'])


if __name__ == '__main__':
    unittest.main()
