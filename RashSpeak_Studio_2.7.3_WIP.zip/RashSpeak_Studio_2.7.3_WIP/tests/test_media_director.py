from copy import deepcopy
import json
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import Mock, patch

from PIL import Image
import requests

from gemini_client import GeminiError
from licensed_media import candidate, same_game
from media_archive import MediaArchive
from media_director import sentence_requests, choose, build_plan, materialize, apply_plan, analyse_video
from official_sources import YouTubeOfficial, GoogleImages, SourceUnavailable
from media_acquisition import download_excerpt
from production_quality import assess, MissingFootage
from smart_editor import import_asset, fingerprint


def request(event='',entities=None):
    return {'id':'s0000','game':'Elden Ring','event':event,'entities':entities or [],
            'query':'Elden Ring exploration','kind':'gameplay','start':0.,'end':3.,'text':'إلدن رينج عالم واسع','idea':'استكشاف'}


def source():
    return {'id':'youtube:abcdefghijk','provider':'youtube','video_id':'abcdefghijk',
            'url':'https://www.youtube.com/watch?v=abcdefghijk','game':'Elden Ring',
            'channel_id':'UC_Official','official_channel_checked':True,'duration':100.,
            'rights_status':'approved','permission':{'usage_approved':True,'download_allowed':True,
            'license':'Publisher permission','evidence_url':'https://publisher.example/policy'}}


def imported(path):
    return import_asset(path,game='Elden Ring',license='Original test image',source='Synthetic test fixture',approved=True)


class ArchiveTests(unittest.TestCase):
    def test_restart_reuses_bytes_without_downloading_again_and_has_readable_index(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);archive=MediaArchive(root/'archive');count=[]
            def download(candidate,start,end,target,cancel):
                count.append(1);p=target/'frame.png';Image.new('RGB',(320,180),'red').save(p);return p
            context=request();context['kind']='image'
            first,reused=archive.acquire(source(),2,5,download,imported,context)
            second,reused=MediaArchive(root/'archive').acquire(source(),2,5,download,imported,context)
            self.assertEqual(len(count),1);self.assertTrue(reused);self.assertEqual(first['sha256'],second['sha256'])
            catalog=json.loads((archive.root/'catalog.json').read_text())
            self.assertEqual(catalog['download_count'],1);self.assertTrue(Path(catalog['assets'][0]['path']).is_file())
            self.assertEqual(MediaArchive(root/'archive').find(context)[0]['sha256'],first['sha256'])

    def test_specific_event_and_arbitrary_entities_cannot_reuse_wrong_context(self):
        with tempfile.TemporaryDirectory() as folder:
            archive=MediaArchive(folder)
            def download(c,s,e,p,cancel):
                target=p/'image.png';Image.new('RGB',(20,20)).save(target);return target
            context=request('update 1',['Ranni','Liurnia']);context['kind']='image'
            archive.acquire(source(),1,4,download,imported,context)
            self.assertEqual(archive.find({**context,'event':'update 2'}),[])
            self.assertEqual(archive.find({**context,'entities':['different boss']}),[])
            self.assertEqual(len(archive.find({**context,'event':''})),1)

    def test_changed_cached_file_is_not_reused(self):
        with tempfile.TemporaryDirectory() as folder:
            archive=MediaArchive(folder)
            def download(c,s,e,p,cancel):
                target=p/'image.png';Image.new('RGB',(20,20)).save(target);return target
            context=request();context['kind']='image'
            asset,_=archive.acquire(source(),1,4,download,imported,context)
            Path(asset['path']).write_bytes(b'changed')
            self.assertEqual(archive.find(context),[])

    def test_concurrent_projects_only_download_one_range(self):
        with tempfile.TemporaryDirectory() as folder:
            count=[];errors=[]
            def download(c,s,e,p,cancel):
                count.append(1);target=p/'image.png';Image.new('RGB',(20,20)).save(target);return target
            def work():
                try:MediaArchive(folder).acquire(source(),1,4,download,imported,request())
                except Exception as exc:errors.append(exc)
            threads=[threading.Thread(target=work)for _ in range(3)]
            for t in threads:t.start()
            for t in threads:t.join()
            self.assertFalse(errors);self.assertEqual(len(count),1)


class PlanningTests(unittest.TestCase):
    def test_general_entities_and_specific_news_are_preserved_without_changing_words(self):
        segments=[{'start':0,'end':4,'text':'كلام بصوتي','semantic':{
            'game':'Elden Ring','visual':'gameplay','event':'New boss update','search_intent':'specific_event',
            'entities':['character','vehicle','studio','performance'],'queries':['exact new boss trailer']}}]
        before=deepcopy(segments);rows=sentence_requests(segments)
        self.assertEqual(rows[0]['entities'],segments[0]['semantic']['entities']);self.assertEqual(segments,before)
        segments[0]['semantic']['search_intent']='general'
        self.assertEqual(sentence_requests(segments)[0]['event'],'')

    def test_a_text_title_is_not_a_full_screen_narration_duplicate(self):
        rows=sentence_requests([{'start':0,'end':4,'text':'النص لا يتحول إلى خلفية','story_topic':'Elden Ring','semantic':{'visual':'title'}}])
        self.assertEqual(rows[0]['kind'],'gameplay')

    def test_hallucinated_id_invalid_timing_and_metadata_only_scene_claim_rejected(self):
        value={'candidate_id':'youtube:abcdefghijk','source_in':2,'source_out':5,'scene_verified':True,'reason':'شرح'}
        client=Mock();client.generate.return_value=value
        self.assertFalse(choose(request(),[source()],client)['scene_verified'])
        bad={**value,'candidate_id':'invented'};client.generate.return_value=bad
        with self.assertRaises(GeminiError):choose(request(),[source()],client)
        client.generate.return_value={**value,'source_out':101}
        with self.assertRaises(GeminiError):choose(request(),[source()],client)

    def test_real_video_is_supplied_to_gemini_and_ranges_are_validated(self):
        client=Mock();client.model='gemini-test'
        scene={'start':2,'end':8,'game':'Elden Ring','event':'','entities':[],
               'description':'actual gameplay','confidence':.9}
        client.generate.return_value={'scenes':[scene]}
        with tempfile.TemporaryDirectory() as folder:
            scenes=analyse_video(source(),request(),client,folder)
            self.assertEqual(client.generate.call_args.kwargs['video_url'],source()['url'])
            self.assertEqual(analyse_video(source(),request(),client,folder),scenes)
            self.assertEqual(client.generate.call_count,1)
        client.generate.return_value={'scenes':[{**scene,'end':101}]}
        with self.assertRaises(GeminiError):analyse_video(source(),request(),client)

    def test_offline_failure_is_explicit_and_repeated_queries_only_search_once(self):
        provider=Mock();provider.search.side_effect=SourceUnavailable('API not configured')
        segments=[{'start':i*4,'end':i*4+4,'text':'حديث عن اللعبة','story_topic':'Elden Ring'}for i in range(2)]
        with tempfile.TemporaryDirectory() as folder:
            plan=build_plan(segments,MediaArchive(folder),{'youtube':provider})
        self.assertEqual(provider.search.call_count,1)
        self.assertTrue(all(r['status']=='source_unavailable'for r in plan['sentences']))
        self.assertEqual(plan['ready_count'],0)

    def test_pending_rights_never_download(self):
        bad=source();bad['rights_status']='pending'
        plan={'sentences':[{'status':'ready_to_download','selection':{'candidate':bad,'source_in':1,'source_out':4,'scene_verified':True}}]}
        with self.assertRaises(ValueError):materialize(plan,Mock(),Mock(),Mock())
        downloader=Mock()
        with patch('media_acquisition.requests.get',downloader),self.assertRaises(SourceUnavailable):
            download_excerpt(bad,1,4,Path('/tmp'))
        downloader.assert_not_called()

    def test_free_image_is_inspected_then_reused_without_a_second_download(self):
        s=source();s.update(id='commons:picture',provider='commons_images',duration=1.,
            url='https://upload.wikimedia.org/example.png',role='clip',event='',entities=[])
        s['permission']['download_hosts']=['upload.wikimedia.org']
        provider=Mock();provider.search.return_value=[s]
        client=Mock();client.generate.side_effect=[{'matches':True,'confidence':.95,'description':'لقطة اللعبة المطلوبة'},
            {'candidate_id':s['id'],'source_in':0.,'source_out':1.,'reason':'صورة مطابقة','scene_verified':True}]
        segments=[{'start':0.,'end':3.,'text':'إلدن رينج','semantic':{'game':'Elden Ring','visual':'image'}},
                  {'start':3.,'end':6.,'text':'نفس اللعبة','semantic':{'game':'Elden Ring','visual':'image'}}]
        with tempfile.TemporaryDirectory() as folder:
            archive=MediaArchive(folder)
            def download(c,start,end,target,cancel):
                p=target/'image.png';Image.new('RGB',(320,180),'green').save(p);return p
            with patch('media_acquisition.download_excerpt',side_effect=download) as network:
                p=build_plan(segments,archive,{'images':provider},client)
                result=materialize(p,archive,network,lambda path,candidate:imported(path))
                self.assertEqual(network.call_count,1)
            self.assertEqual(provider.search.call_count,1)
            self.assertEqual(result['ready_count'],2)
            self.assertIn('image_path',client.generate.call_args_list[0].kwargs)
            self.assertEqual(json.loads((archive.root/'catalog.json').read_text())['download_count'],1)

    def test_reaction_is_a_separate_optional_overlay_request(self):
        segments=[{'start':0.,'end':4.,'text':'تعليق ساخر','semantic':{'game':'Elden Ring','visual':'gameplay',
                  'tone':'humor','meme':True,'effect':'pop'}}]
        rows=sentence_requests(segments)
        self.assertEqual([r['role']for r in rows],['clip','meme'])
        self.assertEqual(rows[1]['kind'],'reaction');self.assertLessEqual(rows[1]['end']-rows[1]['start'],1.4)

    def test_sentence_edit_changes_real_shots_and_undersized_sources_leave_no_holes(self):
        card={'id':'card','kind':'image','editorial_card':True}
        video={'id':'video','kind':'video','duration':3}
        timeline={'assets':[card],'segments':[{'text':'نص ثابت'}],
                  'shots':[{'start':0,'end':8,'asset_id':'card','source_offset':0}]}
        plan={'sentences':[{'id':'s0001','start':2,'end':6,'status':'cached','asset_id':'video','asset':video,'reason':'تطابق','game':'Elden Ring'}]}
        apply_plan(timeline,plan)
        self.assertEqual(sum(s['end']-s['start']for s in timeline['shots']),8)
        self.assertEqual(timeline['segments'],[{'text':'نص ثابت'}])
        self.assertFalse(any(s['asset_id']=='video'for s in timeline['shots']))
        video['duration']=4;apply_plan(timeline,plan)
        self.assertTrue(any(s['asset_id']=='video'for s in timeline['shots']))


class QualityTests(unittest.TestCase):
    def timeline(self,card=False):
        asset={'id':'a','kind':'image' if card else 'video','game':'Elden Ring','duration':20,
               'usage_approved':True,'license':'own','source':'synthetic fixture','editorial_card':card}
        return {'duration':12,'assets':[asset],'segments':[{'start':0,'end':12,'text':'إلدن رينج عالم واسع','story_topic':'Elden Ring'}],
                'shots':[{'start':0,'end':12,'asset_id':'a','source_offset':0}]}

    def test_placeholder_cannot_pass_and_matching_continuous_video_can(self):
        self.assertFalse(assess(self.timeline(True))['ready'])
        self.assertTrue(assess(self.timeline())['ready'])

    def test_previous_game_or_wrong_news_never_counts_as_coverage(self):
        t=self.timeline();t['assets'][0]['game']='Fortnite'
        self.assertEqual(assess(t)['matching_video_ratio'],0)
        t=self.timeline();t['segments'][0]['semantic']={'game':'Elden Ring','search_intent':'specific_event','event':'update 2'}
        t['assets'][0]['event']='update 1'
        self.assertFalse(assess(t)['ready'])

    def test_doubled_narration_in_background_is_reported(self):
        t=self.timeline(True);t['assets'][0]['display_text']=t['segments'][0]['text']
        self.assertTrue(assess(t)['duplicate_text_ranges'])

    def test_spoken_multiword_game_name_is_a_topic_label_not_duplicate_narration(self):
        t=self.timeline(True)
        for name in ('Red Dead Redemption 2',"Assassin's Creed Mirage"):
            t['assets'][0].update(game=name,display_text=name)
            t['segments'][0].update(text=f'{name} عالمها واسع وفيه أشياء كثيرة',story_topic=name)
            self.assertEqual(assess(t)['duplicate_text_ranges'],[])
            t['assets'][0]['display_text']=t['segments'][0]['text']
            self.assertTrue(assess(t)['duplicate_text_ranges'])

    def test_canonical_game_names_do_not_discard_matching_witcher_footage(self):
        self.assertTrue(same_game('The Witcher 3','The Witcher 3: Wild Hunt'))
        self.assertFalse(same_game('',''))


class APIResponse:
    def __init__(self,data,status=200):self.data=data;self.status_code=status;self.content=json.dumps(data).encode()
    def json(self):return self.data
    def close(self):pass


class OwnerMediaPolicyTests(unittest.TestCase):
    def test_ai_generation_models_are_rejected(self):
        from gemini_client import GeminiClient
        for name in ['gemini-3-pro-image-preview','gemini-flash-image','gemini-tts-preview']:
            with self.assertRaises(ValueError):GeminiClient(key='TEST',model=name)

    def test_ai_generated_media_cannot_be_licensed_or_downloaded(self):
        from smart_editor import licensed
        self.assertFalse(licensed({'usage_approved':True,'license':'own','source':'source','ai_generated':True}))
        item=source();item['description']='AI-generated video using a generation model'
        with patch('media_acquisition.requests.get')as network,self.assertRaises(SourceUnavailable):
            download_excerpt(item,1,4,Path('/tmp'))
        network.assert_not_called()

    def test_commons_ai_category_is_rejected_even_with_an_allowed_license(self):
        from tests.test_licensed_media import page
        p=page();p['imageinfo'][0]['extmetadata']['Categories']={'value':'AI-generated images'}
        self.assertIsNone(candidate(p,'Fortnite'))

    def test_free_images_needs_neither_google_api_key_nor_cx(self):
        from official_sources import FreeImages
        with patch('licensed_media.search',return_value=[])as search:
            result=FreeImages().search(request(entities=['character','studio']))
        self.assertEqual(result,[]);self.assertTrue(search.call_args.kwargs['images'])
        self.assertEqual(search.call_args.kwargs['hint'],'character studio')

    def test_non_game_subject_can_use_general_image_entities(self):
        rows=sentence_requests([{'start':0.,'end':4.,'text':'خبر عن الشركة','semantic':{'visual':'image',
                                'game':'','entities':['Electronic Arts']}}])
        self.assertEqual(rows[0]['game'],'Electronic Arts')


class SourceTests(unittest.TestCase):
    def test_authorized_long_source_requests_only_the_bounded_excerpt(self):
        from media_tools import run,duration
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);fixture=root/'fixture.mp4'
            run(['ffmpeg','-v','error','-y','-f','lavfi','-i','testsrc2=s=320x180:r=30:d=3',
                 '-c:v','libx264','-pix_fmt','yuv420p',str(fixture)])
            output=root/'download';output.mkdir();captured={}
            class Downloader:
                def __init__(self,options):captured.update(options)
                def __enter__(self):return self
                def __exit__(self,*args):pass
                def extract_info(self,url,download):
                    self_request=source()
                    return {'id':self_request['video_id'],'channel_id':self_request['channel_id'],'duration':5000}
                def process_ie_result(self,metadata,download):
                    import shutil
                    shutil.copyfile(fixture,output/'source.mp4')
            candidate=source();candidate['duration']=5000
            with patch('yt_dlp.YoutubeDL',Downloader):result=download_excerpt(candidate,1.,4.,output)
            self.assertNotIn('max_filesize',captured)
            ranges=list(captured['download_ranges']({'duration':5000},None))
            self.assertEqual(ranges[0]['start_time'],1.);self.assertEqual(ranges[0]['end_time'],4.)
            self.assertIn('-fs',captured['external_downloader_args']['ffmpeg_o'])
            self.assertAlmostEqual(duration(result),3.,delta=.1)

    def test_official_channel_filter_rejects_another_channel(self):
        http=Mock();http.get.side_effect=[APIResponse({'items':[{'id':'official','snippet':{}}]}),
            APIResponse({'items':[{'id':{'videoId':'abcdefghijk'}}]}),
            APIResponse({'items':[{'id':'abcdefghijk','snippet':{'channelId':'gamer','title':'Elden Ring'},
                                    'contentDetails':{'duration':'PT1M'},'status':{'privacyStatus':'public'}}]})]
        self.assertEqual(YouTubeOfficial(key='TEST',config={},http=http).search(request()),[])

    def test_unavailable_credentials_and_request_errors_do_not_leak_secret(self):
        with self.assertRaises(SourceUnavailable):YouTubeOfficial(key='',config={}).search(request())
        http=Mock();http.get.side_effect=requests.ConnectionError('url?key=PRIVATE_TEST')
        with self.assertRaises(SourceUnavailable) as exc:YouTubeOfficial(key='PRIVATE_TEST',config={},http=http).search(request())
        self.assertNotIn('PRIVATE_TEST',str(exc.exception))

    def test_google_results_are_discovery_not_automatic_license_approval(self):
        http=Mock();http.get.return_value=APIResponse({'items':[{'link':'https://publisher.example/a.png','title':'Boss',
                                                            'image':{'contextLink':'https://publisher.example/news'}}]})
        with patch('official_sources.settings',return_value={'permissions':{}}):
            result=GoogleImages(key='TEST',engine='engine',http=http).search(request())
        self.assertEqual(result[0]['rights_status'],'pending');self.assertEqual(result[0]['license'],'unknown')

    def test_large_original_uses_api_advertised_derivative(self):
        from tests.test_licensed_media import page
        p=page();info=p['imageinfo'][0];info.update(size=1_800_000_000,duration=120)
        info['derivatives']=[{'src':'https://upload.wikimedia.org/transcoded/test.webm','type':'video/webm',
                              'transcodekey':'1080p.vp9.webm','width':1920,'height':1080,'bandwidth':2_000_000}]
        item=candidate(p,'Fortnite');self.assertIsNotNone(item)
        self.assertIsNone(item['size']);self.assertEqual(item['original_size'],1_800_000_000)


class ProductionIntegrationTests(unittest.TestCase):
    def test_final_pipeline_preserves_editable_draft_but_refuses_card_only_export(self):
        from tests.test_production import words,signal
        from production import produce
        from pro_project import load_project
        text='إلدن رينج عالم مفتوح.';units=words(text)
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);audio=root/'voice.wav';limit=units[-1]['end']+.3
            signal(audio,units,limit);original=audio.read_bytes()
            image=root/'card.png';Image.new('RGB',(320,180)).save(image)
            asset=imported(image);asset['editorial_card']=True
            detailed={'words':units,'segments':[{'start':units[0]['start'],'end':units[-1]['end'],'text':text}]}
            with patch('pro_render.render') as renderer:
                with self.assertRaises(MissingFootage):
                    produce(audio,text,root/'project',online=False,asr_override=detailed,assets_override=[asset])
                renderer.assert_not_called()
            state=json.loads((root/'project/production.json').read_text())
            self.assertEqual(state['status'],'needs_media');self.assertFalse(state['quality']['ready'])
            self.assertEqual(state['stages']['media'],'needs_media')
            self.assertTrue(load_project(state['pro_project'])['sequences'])
            self.assertEqual(audio.read_bytes(),original);self.assertNotIn('delivery',state)

    def test_cached_video_reaches_shared_real_renderer_and_next_project_downloads_nothing(self):
        from media_tools import run,duration
        from pro_project import from_legacy
        from pro_render import render
        from tests.test_production import words,signal
        from smart_editor import plan as legacy_plan
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);original=root/'source.mp4'
            run(['ffmpeg','-v','error','-y','-f','lavfi','-i','testsrc2=s=320x180:r=30:d=6',
                 '-c:v','libx264','-pix_fmt','yuv420p',str(original)])
            count=[]
            def download(c,start,end,target,cancel):
                count.append(1);dest=target/'clip.mp4'
                run(['ffmpeg','-v','error','-y','-ss',str(start),'-i',str(original),'-t',str(end-start),
                     '-c:v','libx264',str(dest)])
                return dest
            row=request();row.update(status='ready_to_download',selection={'candidate':source(),
                'source_in':1.,'source_out':4.,'scene_verified':True},reason='Synthetic integration evidence')
            archive=MediaArchive(root/'archive')
            director_plan=materialize({'sentences':[row]},archive,download,lambda p,c:imported(p))
            second=materialize({'sentences':[row]},MediaArchive(root/'archive'),download,lambda p,c:imported(p))
            self.assertEqual(len(count),1);self.assertEqual(second['sentences'][0]['status'],'cached')
            audio=root/'voice.wav';units=words('إلدن رينج عالم مفتوح');signal(audio,units,3)
            still=root/'draft.png';Image.new('RGB',(320,180)).save(still)
            card=imported(still);card['editorial_card']=True
            timeline=legacy_plan(audio,{'assets':[card]},[{'start':0,'end':3,'text':'إلدن رينج عالم مفتوح','story_topic':'Elden Ring'}])
            apply_plan(timeline,director_plan)
            self.assertTrue(assess(timeline)['ready'])
            doc=from_legacy(timeline)
            for seq in doc['sequences']:seq.update(width=320,height=180)
            output=root/'actual.mp4';render(doc,output)
            self.assertAlmostEqual(duration(output),3,delta=.08)
            run(['ffmpeg','-v','error','-i',str(output),'-f','null','-'])
