"""Regressions for real Arabic layout, verified word paging and render parity."""
from copy import deepcopy
from pathlib import Path
import tempfile
import unittest

import captions
from caption_layout import layout, text_measure
from timeline_render import slice_segments, caption_options, caption_preview


def cue():
    text='القصة والحوارات ممتازة جدا وفيها اختيارات كثيرة تغير نهاية اللعبة'
    words=[]
    for index, word in enumerate(text.split()):
        # Uneven speech: character-proportional page times are wrong here.
        start=index*.4 if index<5 else 5+(index-5)*.2
        words.append({'text':word,'start':start,'end':start+.15})
    return {'text':text,'start':0.,'end':7.,'words':words}


class CaptionLayoutTests(unittest.TestCase):
    def test_arabic_phrase_fits_one_line_using_actual_shaped_font_width(self):
        measure=text_measure('DejaVu Sans',104)
        self.assertLess(measure('القصة والحوارات'),790)
        pages=layout([{'start':0.,'end':2.,'text':'القصة والحوارات'}],790,measure)
        self.assertEqual(pages[0]['text'],'القصة والحوارات')

    def test_word_paging_does_not_show_later_words_at_estimated_character_times(self):
        segment=cue();before=deepcopy(segment)
        pages=layout([segment],20)
        self.assertGreater(len(pages),1)
        for page in pages[1:]:
            self.assertEqual(page['start'],page['words'][0]['start'])
        self.assertEqual(pages[-1]['end'],segment['end'])
        self.assertEqual(' '.join(p['text'].replace('\n',' ')for p in pages),segment['text'])
        self.assertEqual(segment,before)

    def test_words_and_numbers_are_not_broken_to_fit_a_narrow_line(self):
        text='اللعبة Battlefield 2042 تدعم CrossPlatformOnline'
        pages=layout([{'start':0.,'end':4.,'text':text}],8)
        self.assertEqual(' '.join(p['text'].replace('\n',' ')for p in pages),text)
        self.assertTrue(all(len(p['text'].splitlines())<=2 for p in pages))
        self.assertTrue(any(p['scale']<1 for p in pages))

    def test_english_game_name_stays_together_with_correct_logical_word_order(self):
        text='ليش تلعب The Witcher 3'
        measure=text_measure('DejaVu Sans',104,True)
        pages=layout([{'start':0.,'end':2.,'text':text}],790,measure)
        self.assertEqual(len(pages),1)
        self.assertEqual(pages[0]['text'],'ليش تلعب\nThe Witcher 3')

    def test_long_english_title_wraps_as_complete_readable_chunks(self):
        text='ليش تلعب The Witcher 3 Wild Hunt'
        measure=text_measure('DejaVu Sans',104,True)
        pages=layout([{'start':0.,'end':2.,'text':text}],790,measure)
        self.assertEqual(' '.join(p['text'].replace('\n',' ')for p in pages),text)
        self.assertTrue(any('The Witcher 3'in p['text']for p in pages))
        self.assertTrue(any('Wild Hunt'in p['text']for p in pages))

    def test_unverified_or_invalid_word_times_never_create_highlights(self):
        segment=cue();segment['words'][0]['text']='نص مختلف'
        self.assertTrue(all(p['timing_source']=='segment_estimate'for p in layout([segment],15)))
        with tempfile.TemporaryDirectory()as folder:
            path=Path(folder)/'ar.ass'
            captions.write_ass([segment],path,highlight=True)
            self.assertNotIn('Dialogue: 1,',path.read_text(encoding='utf-8-sig'))
        segment=cue();segment['words'][0]['start']=float('nan')
        self.assertFalse(any(p['words']for p in layout([segment])))

    def test_malformed_optional_word_metadata_falls_back_to_cue_timing(self):
        for words in ('incorrect',{'text':'نص'},[None],[{'text':None}],[{'text':'نص','start':None,'end':1.}]):
            pages=layout([{'start':0.,'end':2.,'text':'نص','words':words}])
            self.assertEqual(pages[0]['text'],'نص')
            self.assertEqual(pages[0]['words'],[])

    def test_highlight_uses_same_wrapped_page_for_long_cues_and_actual_word_times(self):
        with tempfile.TemporaryDirectory()as folder:
            path=Path(folder)/'ar.ass';segment=cue()
            captions.write_ass([segment],path,size=(1080,1920),region=(.1,.7,.74,.12),highlight=True)
            lines=path.read_text(encoding='utf-8-sig').splitlines()
            pages=[l for l in lines if l.startswith('Dialogue: 0,')]
            highlights=[l for l in lines if l.startswith('Dialogue: 1,')]
            self.assertGreater(len(pages),1)
            self.assertEqual(len(highlights),len(segment['words']))
            for word,line in zip(segment['words'],highlights):
                self.assertIn(','+captions.stamp(word['start'],True)+',',line)
                self.assertIn(r'{\c&H00D2FF&}'+word['text']+r'{\c&HFFFFFF&}',line)

    def test_preview_in_middle_of_page_keeps_export_text_and_highlight(self):
        with tempfile.TemporaryDirectory()as folder:
            root=Path(folder);segment=cue();at=5.1
            for name,bounds in (('full',None),('slice',(at,at+.5))):
                captions.write_ass([segment],root/(name+'.ass'),size=(1080,1920),
                                   region=(.1,.7,.74,.12),highlight=True,time_range=bounds)
            full=(root/'full.ass').read_text(encoding='utf-8-sig').splitlines()
            sliced=(root/'slice.ass').read_text(encoding='utf-8-sig').splitlines()
            base=[l.split(',',9)[-1]for l in full if l.startswith('Dialogue: 0,')]
            for line in sliced:
                if line.startswith('Dialogue: 0,'):
                    self.assertIn(line.split(',',9)[-1],base)
            self.assertTrue(any(l.startswith('Dialogue: 1,')for l in sliced))

    def test_short_srt_uses_spoken_words_and_rebases_their_times(self):
        sliced=slice_segments([cue()],5.,5.4)
        self.assertEqual(sliced[0]['text'],'اختيارات كثيرة')
        self.assertAlmostEqual(sliced[0]['words'][0]['start'],0.)
        self.assertAlmostEqual(sliced[0]['words'][1]['start'],.2)
        self.assertLessEqual(sliced[0]['words'][-1]['end'],.4)

    def test_pro_cursor_window_keeps_full_caption_timing_across_a_video_cut(self):
        from pro_project import Session,new_project,new_clip,sequence,import_media
        from pro_render import frame_window
        from PIL import Image
        with tempfile.TemporaryDirectory()as folder:
            path=Path(folder)/'image.png';Image.new('RGB',(320,180),'red').save(path)
            session=Session(new_project(size=(320,180)));video=session.add_track('image')
            asset=import_media(path)
            session.add(video,new_clip(asset['id'],start=90,duration=30),asset)
            text=session.add_track('text')
            session.add(text,new_clip(text='كلمة أولى كلمة ثانية',duration=180,
                word_timing=[{'text':w,'start':i*40,'end':i*40+20}for i,w in enumerate('كلمة أولى كلمة ثانية'.split())]))
            window,local=frame_window(session.project,105)
            self.assertEqual(local,105)
            caption=next(t for t in sequence(window)['tracks']if t['id']==text)['clips'][0]
            self.assertEqual(caption['start'],0)
            self.assertEqual(caption['duration'],180)
            self.assertEqual(caption['word_timing'][-1]['start'],120)

    def test_opening_old_project_does_not_reuse_obsolete_rendered_preview(self):
        import hashlib,json
        from media_tools import run
        from smart_editor import fingerprint
        from pro_project import Session,new_project,new_clip
        from pro_render import proxy
        from PIL import Image
        with tempfile.TemporaryDirectory()as folder:
            root=Path(folder);session=Session(new_project(size=(640,360)))
            track=session.add_track('text');session.add(track,new_clip(text='ترجمة جديدة',duration=30))
            old_key=hashlib.sha256(json.dumps({'project':session.project,'seq':None,'size':(640,360)},
                                            sort_keys=True,ensure_ascii=False).encode()).hexdigest()
            old=root/(old_key+'.mp4')
            run(['ffmpeg','-v','error','-y','-f','lavfi','-i','color=red:s=640x360:d=1:r=30',
                 '-c:v','libx264','-threads','1',old])
            old.with_suffix('.json').write_text(json.dumps({'fingerprint':fingerprint(old)}))
            path=proxy(session.project,root)
            self.assertNotEqual(Path(path),old);self.assertTrue(old.is_file())
            run(['ffmpeg','-v','error','-y','-i',path,'-frames:v','1',root/'new.png'])
            with Image.open(root/'new.png')as im:
                red,_,blue=im.convert('RGB').getpixel((0,0))
                self.assertGreater(blue,red)

    def test_caption_preview_renders_same_pixels_as_full_ass_at_that_time(self):
        from PIL import Image,ImageChops
        from media_tools import run
        with tempfile.TemporaryDirectory()as folder:
            root=Path(folder);segment=cue();size=(540,960);at=5.1
            caption={'font':'DejaVu Sans','style':'gaming','region':[.1,.78,.8,.15],
                     'portrait_region':[.1,.7,.74,.12],'font_size':96,'outline':1.5,'highlight':True}
            captions.write_ass([segment],root/'full.ass',size,font=caption['font'],**caption_options(caption,size))
            run(['ffmpeg','-v','error','-y','-f','lavfi','-i',f'color=c=0x101b30:s={size[0]}x{size[1]}:r=30',
                 '-vf',f'setpts=PTS+{at}/TB,ass=full.ass:shaping=complex','-frames:v','1',root/'full.png'],cwd=root)
            caption_preview({'duration':7.,'segments':[segment],'caption':caption},root/'preview.png',at,size)
            with Image.open(root/'full.png')as full,Image.open(root/'preview.png')as preview:
                self.assertIsNone(ImageChops.difference(full,preview).getbbox())
