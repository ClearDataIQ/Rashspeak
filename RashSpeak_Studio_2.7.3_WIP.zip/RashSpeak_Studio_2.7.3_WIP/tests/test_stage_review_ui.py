import copy
import gc
import tempfile
from pathlib import Path
import threading
import time
import tkinter as tk
import unittest

from gui import create_app
from stage_review import ReviewBridge
from stage_review_ui import StageReviewPanel
from sound_effects import library


class ReviewGuiTests(unittest.TestCase):
    def setUp(self):
        try:self.root=create_app()
        except tk.TclError as exc:self.skipTest(str(exc))
        self.root.withdraw();self.panel=self.root.production;self.folder=tempfile.TemporaryDirectory()
    def tearDown(self):
        self.panel.cancel.set();self.root.destroy();self.panel=None;self.root=None;gc.collect();self.folder.cleanup()
    def request(self,error=None):
        sounds=library(self.folder.name);base=sounds['pop']
        return {'key':'effects','label':'إضافة المؤثرات','data':{'effects':[{**base,'id':'e','timestamp':0,'gain_db':-20,'approved':True}],
                 'library':sounds},'previews':[],'error':error,'work':self.folder.name,'last_good':{'effects':[],'library':sounds},'revision':1}
    def pump(self,until):
        end=time.monotonic()+5
        while not until() and time.monotonic()<end:self.root.update();time.sleep(.01)
        self.assertTrue(until())

    def test_dirty_data_cannot_be_approved_then_fresh_revision_can(self):
        self.panel.busy=True;self.panel.review_bridge=ReviewBridge(self.panel.events,self.panel.cancel);responses=[]
        worker=threading.Thread(target=lambda:responses.append(self.panel.review_bridge(self.request())));worker.start()
        self.pump(lambda:self.panel.stage_review is not None)
        ui=self.panel.stage_review;ui.data['effects'][0]['gain_db']=-12;ui.changed();ui.approve()
        self.assertEqual(responses,[]);self.assertTrue(worker.is_alive())
        ui.revise();worker.join(2)
        self.assertEqual(responses[0]['action'],'revise');self.assertEqual(responses[0]['data']['effects'][0]['gain_db'],-12)
        request=self.request();request['data']=responses[0]['data'];request['revision']=2
        worker=threading.Thread(target=lambda:responses.append(self.panel.review_bridge(request)));worker.start()
        self.pump(lambda:self.panel.stage_review is not ui)
        self.panel.stage_review.approve();worker.join(2)
        self.assertEqual(responses[-1],{'action':'approve'})

    def test_invalid_preview_disables_approval_but_allows_revert(self):
        replies=[];ui=StageReviewPanel(self.panel.content,self.request('مستوى المؤثر غير صالح'),replies.append,lambda p:None,self.panel.cancel)
        ui.approve();self.assertEqual(replies,[])
        ui.revert();self.assertEqual(replies[0]['action'],'revise');self.assertEqual(replies[0]['data']['effects'],[])
        ui.destroy()

    def test_disable_all_memes_or_effects_is_editable_and_requires_preview(self):
        ui=StageReviewPanel(self.panel.content,self.request(),lambda r:None,lambda p:None,self.panel.cancel)
        ui.disable_all('effects')
        self.assertFalse(ui.data['effects'][0]['approved']);self.assertTrue(ui.dirty)
        self.assertEqual(ui.approve_button['state'],'disabled');ui.destroy()

    def test_exact_user_order_has_no_thumbnail_or_upload_stage(self):
        self.assertEqual(list(self.panel.stage_labels),['audio','media','effects','reactions','montage','delivery'])

    def test_short_selection_displays_actual_hook_and_complete_ending(self):
        hook='تخيل أقوى عالم مفتوح.';ending='وهذه خاتمة القصة الكاملة.'
        data={'shorts':[{'start':0.,'end':50.,'approved':True,'hook':hook,'ending':ending}],
              'segments':[{'start':0.,'end':25.,'text':hook},{'start':25.,'end':50.,'text':ending}],
              'caption':{'style':'gaming','font':'Arial'}}
        request={'key':'montage','label':'المونتاج','data':data,'previews':[],
                 'work':self.folder.name,'last_good':copy.deepcopy(data),'revision':1}
        ui=StageReviewPanel(self.panel.content,request,lambda r:None,lambda p:None,self.panel.cancel)
        tree=ui.trees['shorts'];tree.selection_set('0');tree.event_generate('<<TreeviewSelect>>');self.root.update()
        def labels(widget):
            yield widget
            for child in widget.winfo_children():yield from labels(child)
        # The RTL label displays shaped Arabic while retaining the logical source.
        texts=[w.logical_variable.get()for w in labels(ui)if getattr(w,'logical_variable',None)is not None]
        self.assertTrue(any(hook in text and ending in text for text in texts))
        self.assertEqual(ui.collect()['shorts'][0]['ending'],ending);ui.destroy()

    def test_stop_persists_unsent_edits_without_approving_stage(self):
        import json
        request=self.request();path=Path(self.folder.name)/'saved.json'
        request.update(draft_path=str(path),dependency='input-hash')
        replies=[];ui=StageReviewPanel(self.panel.content,request,replies.append,lambda p:None,self.panel.cancel)
        ui.data['effects'][0]['gain_db']=-15;ui.changed();ui.stop()
        stored=json.loads(path.read_text())
        self.assertEqual(stored['data']['effects'][0]['gain_db'],-15)
        self.assertEqual(replies,[{'action':'cancel'}]);self.assertTrue(self.panel.cancel.is_set());ui.destroy()
