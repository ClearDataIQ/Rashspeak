import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

class LegacyWindowsLocaleTests(unittest.TestCase):
    def test_arabic_source_settings_and_cached_choices_survive_non_utf8_default(self):
        code='''
import json,sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import official_sources
from smart_editor import save
from media_director import choose
root=Path(sys.argv[1]);config=root/'settings.json'
save({'channels':{'name':'فيديو سعودي'},'permissions':{}},config)
with patch('official_sources.config_path',return_value=config):
    assert official_sources.settings()['channels']['name']=='فيديو سعودي'
calls=[]
def generate(*args):
    calls.append(1)
    return {'candidate_id':'','source_in':0,'source_out':1,'reason':'فيديو يحتاج مراجعة','scene_verified':False}
client=SimpleNamespace(model='gemini-fixture',generate=generate)
request={'start':0,'end':1,'text':'فيديو سعودي','game':'','event':'','entities':[],'idea':'','kind':'gameplay'}
choose(request,[],client,root/'cache');choose(request,[],client,root/'cache')
assert len(calls)==1
print('verified')
'''
        with tempfile.TemporaryDirectory(prefix='rash-locale-')as folder:
            result=subprocess.run([sys.executable,'-X','utf8=0','-c',code,folder],
                capture_output=True,text=True,encoding='ascii',errors='replace',timeout=20,
                env={**os.environ,'PYTHONUTF8':'0'},creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt'else 0)
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertIn('verified',result.stdout)

if __name__=='__main__':unittest.main()
