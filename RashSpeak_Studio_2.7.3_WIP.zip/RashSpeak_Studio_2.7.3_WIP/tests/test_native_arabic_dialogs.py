"""Logical Unicode at Windows boundaries, named ASR choices, no hidden downloads."""
from pathlib import Path
import gc
import tkinter as tk
import unittest
from unittest.mock import patch

from rtl_ui import dialogs,native_text,visual,Label
from model_setup_ui import ModelChoice,choose_model


class NativeArabicTests(unittest.TestCase):
    def tearDown(self):gc.collect()

    def test_windows_receives_logical_arabic_not_preordered_glyphs(self):
        title='جودة التفريغ المحلي'
        message='نعم: medium أدق، نحو 1.5 GB وأبطأ على CPU.\nتسجيلك يبقى على جهازك.'
        with patch('rtl_ui.sys.platform','win32'),patch('rtl_ui.native_messagebox.showinfo',return_value='ok')as native:
            self.assertEqual(dialogs.showinfo(title,message,detail='الخطأ HTTP 400'),'ok')
        args,kwargs=native.call_args
        self.assertEqual(args[0],title)
        self.assertEqual(args[1].replace('\u202b','').replace('\u202c',''),message)
        self.assertEqual(kwargs['detail'].replace('\u202b','').replace('\u202c',''),'الخطأ HTTP 400')
        self.assertFalse(any('\ufb50'<=c<='\ufeff' for c in args[1]))
        self.assertEqual(native_text('C:/Games/Steam 123'),'C:/Games/Steam 123')

    def test_confirmation_boolean_and_cancel_results_are_preserved(self):
        for result in (True,False,None):
            with self.subTest(result=result),patch('rtl_ui.sys.platform','win32'),patch('rtl_ui.native_messagebox.askyesnocancel',return_value=result):
                self.assertIs(dialogs.askyesnocancel('تأكيد','هل تريد المتابعة؟'),result)

    def test_tk_visual_order_is_protected_without_changing_the_logical_variable(self):
        root=tk.Tk();root.withdraw()
        try:
            text='التنزيل مرة واحدة؛ تسجيلك يبقى على جهازك.\nحجم تقريبي 500 MB.'
            value=tk.StringVar(root,value=text)
            with patch('rtl_ui.sys.platform','win32'):
                label=Label(root,textvariable=value)
                shown=label.display_variable.get()
                self.assertTrue(all(line.startswith('\u202d')and line.endswith('\u202c')for line in shown.split('\n')))
                self.assertEqual(visual(shown),shown)
                self.assertIn('500 MB',shown)
            self.assertEqual(value.get(),text)
        finally:root.destroy()


class ModelChoiceTests(unittest.TestCase):
    def setUp(self):
        self.root=tk.Tk();self.root.withdraw()

    def tearDown(self):self.root.destroy();gc.collect()

    def test_named_buttons_return_the_exact_model_and_cancel_is_none(self):
        for button,result in (('small_button','small'),('medium_button','medium'),('cancel_button',None)):
            with self.subTest(button=button):
                window=ModelChoice(self.root)
                self.assertIn('تنزيل' if result else 'بدون تنزيل',getattr(window,button).logical_text)
                getattr(window,button).invoke()
                self.assertEqual(window.result,result)

    def test_modal_cancel_restores_the_previous_grab(self):
        parent=tk.Toplevel(self.root);parent.grab_set()
        def cancel():
            next(w for w in parent.winfo_children()if isinstance(w,ModelChoice)).cancel_button.invoke()
        parent.after(30,cancel)
        self.assertIsNone(choose_model(parent))
        self.assertEqual(parent.grab_current(),parent)

    def test_cancel_does_not_download_or_change_the_selected_recording(self):
        from production_ui import ProductionPanel
        panel=ProductionPanel(self.root);panel.audio='تسجيل خاص.mp3'
        with patch('model_setup_ui.choose_model',return_value=None),patch('faster_whisper.utils.download_model')as download:
            panel.setup_model();download.assert_not_called()
        self.assertEqual(panel.audio,'تسجيل خاص.mp3')

    def test_named_download_routes_to_that_model_only(self):
        from production_ui import ProductionPanel
        panel=ProductionPanel(self.root)
        for name in ('small','medium'):
            with self.subTest(name=name),patch('model_setup_ui.choose_model',return_value=name),patch('faster_whisper.utils.download_model',return_value='model-path')as download,patch.object(panel,'background',side_effect=lambda work,done:work()):
                panel.cancel.clear();panel.setup_model()
                self.assertEqual(download.call_args.args,(name,))
                self.assertEqual(Path(download.call_args.kwargs['output_dir']).name,name)


if __name__=='__main__':unittest.main()
