"""Recovery tests use declared service fixtures, never claim live source success."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import threading
import tkinter as tk
import unittest
from unittest.mock import Mock,patch

from gemini_client import GeminiUnavailable
from media_context import resolve_context
from production import contextual_cues
from production_diagnostics import summarize,write_report,recovery_text,cause
from tests import test_media_director as director_fixtures


class ContextRecoveryTests(unittest.TestCase):
    def test_real_name_split_across_pages_recovers_context_without_changing_words(self):
        segments=[{'start':0.,'end':4.,'text':'السلام عليكم هذه مقدمة.'},
                  {'start':4.,'end':8.,'text':'نبدأ مع Ghost of'},
                  {'start':8.,'end':12.,'text':'Tsushima القتال جميل.'},
                  {'start':12.,'end':16.,'text':'هنا تفاصيل اللعبة.'}]
        before=deepcopy(segments)
        with tempfile.TemporaryDirectory()as folder:contextual_cues(segments,[],folder)
        self.assertEqual(segments[0]['story_topic'],'')
        self.assertEqual([s['story_topic']for s in segments[1:]],['Ghost of Tsushima']*3)
        self.assertEqual([{k:v for k,v in s.items()if k!='story_topic'}for s in segments],before)

    def test_next_whole_name_does_not_backfill_intro_or_cross_a_long_pause(self):
        for gap in (0.,3.):
            segments=[{'start':0.,'end':4.,'text':'هذه مقدمة.'},
                      {'start':4.+gap,'end':8.+gap,'text':'Ghost of Tsushima قصة ساموراي.'}]
            with tempfile.TemporaryDirectory()as folder:contextual_cues(segments,['Ghost of Tsushima'],folder)
            self.assertEqual(segments[0]['story_topic'],'')

    def test_newly_configured_key_can_retry_context_without_asr_or_audio_work(self):
        segments=[{'start':0.,'end':4.,'text':'Ghost of Tsushima عالم مفتوح.'}]
        result={'model':'gemini-fixture','cached':False,'segments':[{'game':'Ghost of Tsushima','importance':8.,'confidence':.9,'tone':'neutral'}],'shorts':[]}
        with tempfile.TemporaryDirectory()as folder,\
             patch('gemini_client.settings',return_value={'enabled':True,'model':'gemini-fixture'}),\
             patch('gemini_client.api_key',side_effect=['','DECLARED_TEST_KEY']),\
             patch('gemini_context.cached_analysis',side_effect=GeminiUnavailable('No matching cache')),\
             patch('gemini_context.analyse',return_value=result)as analyse,\
             patch('captions.transcribe',side_effect=AssertionError('Do not re-run ASR')),\
             patch('audio_edit.render_audio',side_effect=AssertionError('Do not re-process voice')):
            first=resolve_context('',segments,Path(folder));second=resolve_context('',segments,Path(folder))
        self.assertIsNone(first[1]);self.assertIn('مفتاح',first[2]['reason'])
        self.assertEqual(second[0][0]['semantic']['game'],'Ghost of Tsushima');self.assertEqual(second[2]['status'],'analysed')
        self.assertEqual(analyse.call_count,1)

    def test_genuine_cached_context_does_not_require_a_current_key(self):
        result={'model':'gemini-fixture','cached':True,'segments':[],'shorts':[]}
        with tempfile.TemporaryDirectory()as folder,patch('gemini_client.settings',return_value={'enabled':True,'model':'gemini-fixture'}),\
             patch('gemini_client.api_key',return_value=''),patch('gemini_context.cached_analysis',return_value=result),\
             patch('gemini_context.analyse',side_effect=AssertionError('No network')):
            _,analysis,status=resolve_context('',[],Path(folder))
        self.assertTrue(status['cached']);self.assertEqual(analysis,result)


class DiagnosticsRecoveryTests(unittest.TestCase):
    def test_intro_needs_context_does_not_hide_a_different_failure_for_game_sentences(self):
        plan={'sentences':[{'status':'needs_context','reason':'intro'},
                           {'status':'ai_unavailable','game':'Ghost of Tsushima','reason':'Gemini HTTP 404'}]}
        issues=summarize(plan)
        self.assertEqual({i['code']for i in issues},{'context','model_unavailable'})

    def test_service_presence_is_not_reported_as_a_successful_connection(self):
        from api_connections import service_snapshot
        with patch('api_connections.current_key',side_effect=['DECLARED_GEMINI_KEY','']),\
             patch('gemini_client.settings',return_value={'enabled':True,'model':'gemini-fixture'}):
            state=service_snapshot()
        self.assertTrue(state['gemini']['key_available']);self.assertFalse(state['live_connection_checked'])
        self.assertNotIn('DECLARED_GEMINI_KEY',json.dumps(state))
        self.assertIn('youtube_missing',{i['code']for i in summarize(None,state)})

    def test_actual_source_inspection_failure_is_not_labelled_as_missing_footage(self):
        row={'status':'no_verified_scene','candidates':[{'rights_status':'approved','scene_error':'Gemini HTTP 404'}]}
        self.assertEqual(cause(row),'model_unavailable')
        row['candidates'][0]['scene_error']='Gemini HTTP 403: صلاحية النموذج'
        self.assertEqual(cause(row),'ai_unavailable')

    def test_shareable_diagnostics_redact_query_credentials_and_private_narration(self):
        row={'id':'s0','game':'Ghost of Tsushima','text':'PRIVATE NARRATION','status':'source_unavailable',
             'reason':'https://example.test/?key=PRIVATE_SECRET&part=id','start':0.,'end':4.}
        with tempfile.TemporaryDirectory()as folder:
            report=write_report(director_fixtures.QualityTests().timeline(True),{'sentences':[row]},folder)
            for path in Path(folder).iterdir():
                text=path.read_text(encoding='utf-8-sig');self.assertNotIn('PRIVATE_SECRET',text);self.assertNotIn('PRIVATE NARRATION',text)
        self.assertNotIn('PRIVATE_SECRET',recovery_text(report))

    def test_missing_model_is_a_provider_outage_and_stops_after_one_request(self):
        from gemini_client import GeminiClient
        from tests.test_gemini import HTTP,Response
        http=HTTP(Response({},404));client=GeminiClient(key='DECLARED_TEST_KEY',model='gemini-fixture',http=http)
        with self.assertRaises(GeminiUnavailable)as error:client.request('POST','/models/gemini-fixture:generateContent',{})
        self.assertIn('404',str(error.exception));self.assertEqual(len(http.calls),1)


class StageRetryIntegrationTests(unittest.TestCase):
    def test_retry_context_only_reprocesses_media_without_rerunning_audio_stage(self):
        from media_archive import MediaArchive
        from media_tools import Cancelled
        from production import produce
        from tests.test_production import words,signal
        import audio_edit
        visits=[];available=[False];resolver_calls=[]
        row={'game':'Ghost of Tsushima','confidence':.95,'importance':5.,'tone':'neutral',
             'visual':'gameplay','effect':'none','meme':False,'reason':'Declared fixture','queries':[]}
        def context(script,segments,project,cancel,progress):
            resolver_calls.append(available[0]);out=deepcopy(segments)
            if available[0]:
                for s in out:s['semantic']=deepcopy(row)
                analysis={'segments':[deepcopy(row)for s in out],'shorts':[],'model':'gemini-fixture','cached':False}
                return out,analysis,{'enabled':True,'status':'analysed','provider':'gemini','model':'gemini-fixture'}
            return out,None,{'enabled':True,'status':'gemini_unavailable','reason':'مفتاح Gemini غير متاح'}
        def plan(segments,*args,**kwargs):
            from media_director import sentence_requests
            requests=sentence_requests(segments)
            for r in requests:r.update(status='needs_ai_selection',reason='Declared fixture: no source selection')
            return {'sentences':requests,'source_attempts':[],'cached_count':0,'ready_count':0}
        def review(request):
            visits.append(request['key'])
            if request['key']=='audio':return {'action':'approve'}
            self.assertEqual(request['key'],'media')
            if visits.count('media')==1:
                available[0]=True;data=deepcopy(request['data']);data['refresh_sources']=True
                return {'action':'revise','data':data}
            self.assertEqual(request['data']['ai_status']['status'],'analysed')
            self.assertEqual(request['data']['segments'][0]['semantic']['game'],'Ghost of Tsushima')
            return {'action':'cancel'}
        with tempfile.TemporaryDirectory()as folder:
            root=Path(folder);audio=root/'fixture.wav';units=words('Ghost of Tsushima القتال ممتع.',spacing=.5);signal(audio,units,4.)
            archive=MediaArchive(root/'archive')
            with patch('media_context.resolve_context',side_effect=context),\
                 patch('gemini_client.api_key',side_effect=lambda:'DECLARED_TEST_KEY'if available[0]else''),\
                 patch('gemini_client.GeminiClient'),patch('media_archive.MediaArchive',return_value=archive),\
                 patch('media_director.build_plan',side_effect=plan),patch('image_fallback.extend_plan',side_effect=lambda p,*a,**kw:p),\
                 patch('audio_edit.render_audio',wraps=audio_edit.render_audio)as audio_render,\
                 patch('captions.transcribe',side_effect=AssertionError('ASR fixture must not be re-transcribed')):
                with self.assertRaises(Cancelled):produce(audio,'',project=root/'project',online=False,
                    asr_override={'words':units,'segments':[{'start':0.,'end':4.,'text':'Ghost of Tsushima القتال ممتع.'}]},on_review=review)
            self.assertEqual(audio_render.call_count,1)
        self.assertEqual(visits,['audio','media','media']);self.assertEqual(resolver_calls,[False,True])


class RecoveryUITests(unittest.TestCase):
    def test_blocked_media_opens_recovery_controls_and_retry_preserves_current_data(self):
        from stage_review_ui import StageReviewPanel
        root=tk.Tk();root.geometry('1120x800');replies=[]
        data={'assets':[],'shots':[],'segments':[],
              'quality':{'ready':False,'matching_video_ratio':0.,'blockers':['0% footage']},
              'media_plan':{'sentences':[{'id':'s0','start':0.,'end':4.,'game':'','idea':'','query':'','status':'needs_context'}]},
              'services':{'gemini':{'enabled':True,'key_available':False}}}
        request={'key':'media','label':'تركيب اللقطات','data':data,'previews':[],'last_good':deepcopy(data),'work':'.'}
        try:
            panel=StageReviewPanel(root,request,replies.append,lambda p:None,threading.Event());panel.pack(fill='both',expand=True);root.update()
            self.assertTrue(panel.api_recovery_button.winfo_ismapped());self.assertTrue(panel.media_retry_button.winfo_ismapped())
            self.assertIn('gemini_missing',{i['code']for i in summarize(data['media_plan'],data['services'])})
            with patch.object(panel,'clipboard_clear'),patch.object(panel,'clipboard_append')as clipboard:
                panel.copy_media_report();self.assertIn('Gemini',clipboard.call_args.args[0])
            self.assertEqual(replies,[])
            panel.media_retry_button.invoke()
            self.assertEqual(replies[0]['action'],'revise');self.assertTrue(replies[0]['data']['refresh_sources'])
            self.assertEqual(replies[0]['data']['segments'],data['segments']);self.assertFalse(panel.cancel.is_set())
        finally:root.destroy()

    def test_pending_sources_open_directly_on_rights_tab_and_keep_scope_explicit(self):
        from stage_review_ui import StageReviewPanel
        from official_sources import apply_permission
        candidate={'id':'youtube:abcdefghijk','provider':'youtube','game':'Ghost of Tsushima','title':'Declared fixture',
                   'url':'https://www.youtube.com/watch?v=abcdefghijk','rights_status':'pending',
                   'official_channel_checked':True,'channel_handle':'@DeclaredPublisher'}
        rows=[{'id':f's{i}','start':i*4.,'end':i*4.+4.,'game':'Ghost of Tsushima','idea':'Declared fixture','query':'gameplay',
               'candidates':[deepcopy(candidate)],'status':'needs_source_review'}for i in range(3)]
        data={'quality':{'ready':False,'blockers':['pending fixture']},'media_plan':{'sentences':rows}}
        root=tk.Tk();root.withdraw()
        try:
            panel=StageReviewPanel(root,{'key':'media','label':'تركيب اللقطات','data':data,'previews':[],'last_good':{}},
                lambda r:None,lambda p:None,threading.Event());window=panel.pending_sources();root.update()
            self.assertEqual(len(window.source_tree.get_children()),1)
            from source_ui import open_settings
            with tempfile.TemporaryDirectory()as folder,patch('source_ui.settings',return_value={'permissions':{}}),\
                 patch('source_ui.config_path',return_value=Path(folder)/'settings.json'):
                settings=open_settings(window,candidate);root.update()
                self.assertEqual(settings.source_notebook.select(),str(settings.rights_tab))
                self.assertEqual(settings.rights_fields['source'].get(),candidate['id'])
                settings.grant_button.invoke();self.assertFalse((Path(folder)/'settings.json').exists())
                settings.rights_fields['source'].set('@DeclaredPublisher')
                settings.rights_approved.set(True);settings.grant_button.invoke()
                cfg=json.loads((Path(folder)/'settings.json').read_text())
                self.assertIn('@DeclaredPublisher',cfg['permissions'])
                self.assertEqual(apply_permission(deepcopy(candidate),cfg)['rights_status'],'owner_accepted')
                self.assertEqual(cfg['permissions']['@DeclaredPublisher']['license'],'unknown')
                settings.destroy()
        finally:root.destroy()
