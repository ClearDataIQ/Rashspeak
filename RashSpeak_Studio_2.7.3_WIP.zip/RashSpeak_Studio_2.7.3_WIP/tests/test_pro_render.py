import copy
from pathlib import Path
import tempfile
import threading
import unittest
import zipfile
from PIL import Image

from media_tools import run,probe,Cancelled
from pro_project import new_project,Session,new_clip,import_media,load_project,validate,sequence
from pro_render import render,proxy,frame,package,frame_window


class RenderTests(unittest.TestCase):
    def setUp(self):
        self.folder=tempfile.TemporaryDirectory();self.root=Path(self.folder.name)
        # Moving real encoded frames and real audio, generated locally, no ASR fixture.
        self.video=self.root/'motion.mp4';self.voice=self.root/'voice.wav';self.image=self.root/'blue.png'
        run(['ffmpeg','-v','error','-y','-f','lavfi','-i','testsrc2=size=320x180:rate=30:duration=4','-c:v','libx264','-threads','1',self.video])
        run(['ffmpeg','-v','error','-y','-f','lavfi','-i','sine=frequency=440:sample_rate=48000:duration=4',self.voice])
        Image.new('RGB',(320,180),'blue').save(self.image)
        self.s=Session(new_project(size=(320,180)))
        video=self.s.add_track('video');audio=self.s.add_track('audio');overlay=self.s.add_track('image')
        a=import_media(self.video);b=import_media(self.voice);c=import_media(self.image)
        self.clip=self.s.add(video,new_clip(a['id'],0,120),a);self.s.add(audio,new_clip(b['id'],0,120),b)
        self.overlay=self.s.add(overlay,new_clip(c['id'],30,60,transform={'x':.5,'y':.5,'scale':.5,'opacity':1.}),c)
        self.video_track=video;self.overlay_track=overlay

    def tearDown(self):self.folder.cleanup()

    def pixel(self,video,at,x,y):
        output=self.root/'sample.png';run(['ffmpeg','-v','error','-y','-ss',at,'-i',video,'-frames:v','1',output])
        with Image.open(output) as im:return im.convert('RGB').getpixel((x,y))

    def test_multitrack_move_split_trim_audio_and_visible_export_match(self):
        original=self.video.read_bytes();self.s.split(self.clip,60);self.s.move(self.overlay,0)
        values=[];output=self.root/'edited.mp4';result=render(self.s.project,output,on_progress=values.append)
        self.assertEqual(result['duration'],4);self.assertEqual(values[-1],100)
        rgb=self.pixel(output,.5,250,140);self.assertGreater(rgb[2],180);self.assertLess(rgb[0],30)
        self.s.track_state(self.overlay_track,hidden=True);hidden=self.root/'hidden.mp4';render(self.s.project,hidden)
        self.assertNotEqual(rgb,self.pixel(hidden,.5,250,140));self.assertEqual(original,self.video.read_bytes())
        info=probe(output);self.assertTrue(any(s['codec_type']=='audio' for s in info['streams']))
        # Source offsets are meaningful: a slipped clip must produce another moving frame.
        self.s.slip(self.clip,20);slipped=self.root/'slipped.mp4';render(self.s.project,slipped)
        self.assertNotEqual(self.pixel(hidden,.5,160,90),self.pixel(slipped,.5,160,90))

    def test_proxy_cache_frame_preview_short_and_portable_package(self):
        proxy_path=proxy(self.s.project,self.root/'cache');stat=Path(proxy_path).stat().st_mtime_ns
        self.assertEqual(proxy_path,proxy(self.s.project,self.root/'cache'));self.assertEqual(stat,Path(proxy_path).stat().st_mtime_ns)
        frame(self.s.project,self.root/'frame.png',45)
        with Image.open(self.root/'frame.png') as im:self.assertEqual(im.size,(640,360))
        self.s.make_short(30,90);short=self.root/'short.mp4';render(self.s.project,short,size=(180,320))
        self.assertEqual(float(probe(short)['format']['duration']),2.)
        result=package(self.s.project,self.root/'delivery',[{'path':str(short),'portrait':True}])
        reopened=load_project(Path(result['folder'])/'Project'/'project.rash.json');validate(reopened,files=True)
        unpack=self.root/'unpacked'
        with zipfile.ZipFile(result['zip']) as z:z.extractall(unpack)
        relocated=load_project(unpack/'delivery'/'Project'/'project.rash.json');validate(relocated,files=True)
        self.assertTrue(all(str(unpack) in a['path'] for a in relocated['media']))
        render(relocated,self.root/'reopened.mp4',size=(180,320))

    def test_frame_preview_bounds_a_long_episode_and_keeps_source_project_unchanged(self):
        self.s.trim(self.clip,0,60)
        self.s.move(self.overlay,15000)
        before=copy.deepcopy(self.s.project)
        bounded,at=frame_window(self.s.project,15)
        self.assertEqual(at,15)
        self.assertEqual(__import__('pro_project').length(sequence(bounded)),60)
        self.assertFalse(any(c for t in sequence(bounded)['tracks'] if t['kind'] in ('audio','effect') for c in t['clips']))
        self.assertEqual(frame_window(self.s.project,15),(bounded,at))
        frame(self.s.project,self.root/'bounded.png',15)
        self.assertTrue((self.root/'bounded.png').is_file())
        self.assertEqual(self.s.project,before)

    def test_frame_preview_matches_export_during_fades_keyframes_and_reverse(self):
        from PIL import ImageChops,ImageStat
        self.s.move(self.clip,90)
        self.s.move(self.overlay,120)
        self.s.track_state(self.video_track,hidden=True)
        self.s.properties(self.overlay,fade_in=15,fade_out=15,
            keyframes={'x':[{'frame':0,'value':.2,'easing':'linear'},
                            {'frame':59,'value':.5,'easing':'ease_out'}]})
        self.s.properties(self.clip,reverse=True)
        self.s.track_state(self.video_track,hidden=False)
        reference=self.root/'reference.mp4'
        render(self.s.project,reference,size=(640,360),crf=12)
        for at in (125,170):
            frame(self.s.project,self.root/'bounded.png',at)
            with Image.open(self.root/'bounded.png') as image:actual=image.convert('RGB')
            errors={}
            for offset in (-1,0,1):
                run(['ffmpeg','-v','error','-y','-ss',(at+offset)/30,'-i',reference,'-frames:v','1',self.root/'reference.png'])
                with Image.open(self.root/'reference.png') as image:
                    errors[offset]=max(ImageStat.Stat(ImageChops.difference(actual,image.convert('RGB'))).mean)
            # Independent lossy encodes have different GOP history. Accept small
            # codec noise while requiring the correct frame, not either neighbor.
            self.assertLess(errors[0],3.)
            self.assertLess(errors[0],.6*min(errors[-1],errors[1]))

    def test_cancel_rights_and_changed_source_do_not_replace_output(self):
        output=self.root/'old.mp4';output.write_bytes(b'previous good output');cancel=threading.Event();cancel.set()
        with self.assertRaises(Cancelled):render(self.s.project,output,cancel=cancel)
        self.assertEqual(output.read_bytes(),b'previous good output')
        p=copy.deepcopy(self.s.project);p['media'][0]['usage_approved']=False
        with self.assertRaises(ValueError):render(p,output)
        self.image.write_bytes(b'changed')
        with self.assertRaises(ValueError):render(self.s.project,output)
        self.assertEqual(output.read_bytes(),b'previous good output')

    def test_arabic_caption_edits_and_timing_reach_render(self):
        from PIL import ImageChops
        self.s.track_state(self.overlay_track,hidden=True)
        base=self.root/'base_text.mp4';render(self.s.project,base)
        t=self.s.add_track('text');key=self.s.add(t,new_clip(start=30,duration=60,text='الحين تحديث جديد'))
        self.s.properties(key,text='يا جماعة الحين تحديث جديد')
        output=self.root/'captioned.mp4';render(self.s.project,output)
        def crop(video,at,name):
            file=self.root/name;run(['ffmpeg','-v','error','-y','-ss',at,'-i',video,'-frames:v','1',file])
            with Image.open(file) as im:return im.convert('RGB').crop((0,110,320,180))
        plain=crop(base,1.3,'plain.png');captioned=crop(output,1.3,'captioned.png')
        self.assertIsNotNone(ImageChops.difference(plain,captioned).getbbox())
        early_plain=crop(base,.3,'early_base.png');early=crop(output,.3,'early.png')
        # Compression can differ slightly; captions must create substantially larger differences when active.
        def delta(a,b):return sum(sum(p) for p in ImageChops.difference(a,b).getdata())
        self.assertGreater(delta(plain,captioned),delta(early_plain,early)*3)

    def test_track_gain_and_mute_change_actual_decoded_audio(self):
        import array,math,wave
        audio=next(t for t in self.s.seq['tracks'] if t['kind']=='audio');values=[]
        for i,changes in enumerate(({}, {'gain_db':-12.},{'muted':True})):
            if changes:self.s.track_state(audio['id'],**changes)
            out=self.root/f'audio_{i}.mp4';render(self.s.project,out)
            wavefile=self.root/f'decode_{i}.wav';run(['ffmpeg','-v','error','-y','-i',out,'-map','0:a:0','-c:a','pcm_s16le',wavefile])
            with wave.open(str(wavefile)) as f:samples=array.array('h',f.readframes(f.getnframes()))
            values.append(math.sqrt(sum(x*x for x in samples)/len(samples)))
        self.assertGreater(values[0],1000);self.assertAlmostEqual(values[1]/values[0],10**(-12/20),delta=.04);self.assertLess(values[2],10)

    def test_portrait_cover_reframes_and_packaged_script_relocates(self):
        self.s.track_state(self.overlay_track,hidden=True);self.s.make_short(30,90)
        c=next(c for t in self.s.seq['tracks'] if t['kind']=='video' for c in t['clips'])
        contain=self.root/'contain.mp4';render(self.s.project,contain,size=(180,320))
        self.s.properties(c['id'],fit='cover');cover=self.root/'cover.mp4';render(self.s.project,cover,size=(180,320))
        self.assertNotEqual(self.pixel(contain,.5,90,20),self.pixel(cover,.5,90,20))
        script=self.root/'script.txt';script.write_text('كلام أصلي باللهجة السعودية',encoding='utf-8');self.s.project['provenance']['script']=str(script)
        output=package(self.s.project,self.root/'portable')
        unpack=self.root/'relocated'
        with zipfile.ZipFile(output['zip']) as z:z.extractall(unpack)
        p=load_project(unpack/'portable'/'Project'/'project.rash.json')
        self.assertIn(str(unpack),p['provenance']['script']);self.assertEqual(Path(p['provenance']['script']).read_text(encoding='utf-8'),script.read_text(encoding='utf-8'))
