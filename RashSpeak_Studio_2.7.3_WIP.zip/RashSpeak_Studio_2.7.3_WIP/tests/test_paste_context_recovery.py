"""Declared fixtures only: no real clipboard, credentials or network requests."""
from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace
import gc
import tempfile
import threading
import tkinter as tk
import unittest
from unittest.mock import patch

from gemini_context import analyse,validated_analysis,ContextResponseError
from production_diagnostics import error_cause


def context_fixture():
    segments=[{'start':0.,'end':25.,'text':'تخيل عالم Fortnite واسع.'},
              {'start':25.,'end':50.,'text':'وهذه نهاية القصة كاملة.'}]
    rows=[{'id':f's{i:04}','game':'Fortnite','event':'','idea':'قصة','evidence':s['text'],
           'tone':'neutral','importance':8.,'confidence':.9,'visual':'gameplay','meme':False,
           'effect':'none','queries':['Fortnite gameplay'],'reason':'Declared fixture',
           'hook_score':8.,'ending_complete':True}for i,s in enumerate(segments)]
    short={'first':'s0000','last':'s0001','reason':'Declared complete story','score':8.,
           'hook':'تخيل عالم Fortnite','ending':'نهاية القصة كاملة','complete_ending':True}
    return segments,{'segments':rows,'shorts':[short]}


class ContextIsolationTests(unittest.TestCase):
    def test_invalid_optional_range_does_not_destroy_valid_sentences_or_other_short(self):
        segments,response=context_fixture();good=deepcopy(response['shorts'][0])
        for invalid in ('s9999',17,[],None):
            with self.subTest(invalid=invalid):
                bad={**good,'first':invalid};response['shorts']=[bad,good]
                result=validated_analysis(response,'',segments)
                self.assertEqual(len(result['segments']),2);self.assertEqual(len(result['shorts']),1)
                self.assertEqual((result['shorts'][0]['start'],result['shorts'][0]['end']),(0.,50.))
                self.assertEqual(len(result['short_warnings']),1)

    def test_invalid_grounding_or_missing_sentence_still_blocks_context(self):
        segments,response=context_fixture()
        for mutation in ('evidence','missing','duplicate'):
            bad=deepcopy(response)
            if mutation=='evidence':bad['segments'][0]['evidence']='invented words'
            elif mutation=='missing':bad['segments'].pop()
            else:bad['segments'].append(deepcopy(bad['segments'][0]))
            with self.assertRaises(ContextResponseError):validated_analysis(bad,'',segments)

    def test_duration_completeness_invented_hook_and_overlap_remain_rejected(self):
        segments,response=context_fixture();short=response['shorts'][0]
        for field,value in (('complete_ending',False),('hook','invented opening'),('last','s0000')):
            bad=deepcopy(response);bad['shorts'][0][field]=value
            if field=='last':
                short_segments=deepcopy(segments);short_segments[0]['end']=20.
            else:short_segments=segments
            result=validated_analysis(bad,'',short_segments)
            self.assertEqual(result['shorts'],[]);self.assertTrue(result['short_warnings'])
        response['shorts']=[short,deepcopy(short)]
        self.assertEqual(len(validated_analysis(response,'',segments)['shorts']),1)

    def test_valid_sentence_cache_survives_invalid_short_and_offline_reopen(self):
        segments,response=context_fixture();response['shorts'][0]['first']='s9999'
        class Client:
            model='gemini-fixture';last_usage={};calls=0;schema=None
            def generate(self,system,data,schema):
                self.calls+=1;self.schema=schema;return deepcopy(response)
        client=Client()
        with tempfile.TemporaryDirectory()as folder:
            one=analyse('',segments,folder,client)
            with patch.object(client,'generate',side_effect=AssertionError('No new request')):
                two=analyse('',segments,folder,client)
            self.assertEqual(len(list(Path(folder).glob('*.json'))),1)
        self.assertEqual(client.calls,1);self.assertFalse(one['cached']);self.assertTrue(two['cached'])
        self.assertEqual(two['segments'],one['segments']);self.assertTrue(two['short_warnings'])
        props=client.schema['properties']['shorts']['items']['properties']
        self.assertEqual(props['first']['enum'],['s0000','s0001']);self.assertEqual(props['last']['enum'],props['first']['enum'])

    def test_legacy_error_is_response_problem_not_key_network_or_quota(self):
        self.assertEqual(error_cause('نطاق شورت غير معروف.'),'ai_response')
        self.assertEqual(error_cause(str(ContextResponseError('جمل ناقصة'))),'ai_response')
        self.assertEqual(error_cause('Gemini HTTP 429'),'quota')
        self.assertEqual(error_cause('Gemini [credential]'),'ai_account')


class KeyPasteTests(unittest.TestCase):
    def setUp(self):
        from api_settings_ui import ApiPanel
        self.root=tk.Tk();self.root.withdraw()
        with patch('api_connections.current_key',return_value=''):
            self.panel=ApiPanel(self.root,'youtube')

    def tearDown(self):self.root.destroy();gc.collect()

    def test_button_pastes_masked_dummy_only_without_saving_or_testing(self):
        panel=self.panel
        with patch.object(panel.entry,'clipboard_get',return_value='  DECLARED_PASTE_FIXTURE  \r\n'),\
             patch('api_connections.configure')as save,patch('api_connections.check')as network:
            panel.paste_button.invoke()
        self.assertEqual(panel.key.get(),'DECLARED_PASTE_FIXTURE');self.assertEqual(panel.entry.cget('show'),'•')
        self.assertNotIn('DECLARED_PASTE_FIXTURE',panel.status.get());save.assert_not_called();network.assert_not_called()

    def test_arabic_layout_windows_keycode_and_virtual_paste(self):
        panel=self.panel
        self.root.deiconify();panel.pack(fill='both',expand=True);self.root.update()
        with patch.object(panel.entry,'clipboard_get',return_value='DECLARED_PASTE_FIXTURE')as clip:
            self.assertEqual(panel.key_shortcut(SimpleNamespace(keysym='Arabic_ra',char='ر',keycode=86)),'break')
            self.assertEqual(panel.key.get(),'DECLARED_PASTE_FIXTURE')
            panel.key.set('');panel.entry.event_generate('<<Paste>>');self.root.update()
            self.assertEqual(panel.key.get(),'DECLARED_PASTE_FIXTURE');self.assertEqual(clip.call_count,2)

    def test_invalid_empty_and_unavailable_clipboard_preserve_existing_entry(self):
        panel=self.panel;panel.key.set('DECLARED_EXISTING_FIXTURE')
        for value in ('','invalid embedded spaces','عربي'):
            with patch.object(panel.entry,'clipboard_get',return_value=value):panel.paste_key()
            self.assertEqual(panel.key.get(),'DECLARED_EXISTING_FIXTURE')
        with patch.object(panel.entry,'clipboard_get',side_effect=tk.TclError('unavailable')):panel.paste_key()
        self.assertEqual(panel.key.get(),'DECLARED_EXISTING_FIXTURE')

    def test_busy_paste_never_reads_clipboard(self):
        self.panel.set_busy(True)
        with patch.object(self.panel.entry,'clipboard_get',side_effect=AssertionError('must not read')):
            self.assertEqual(self.panel.paste_key(),'break')
        self.assertEqual(str(self.panel.paste_button.cget('state')),'disabled')

    def test_native_windows_theme_keeps_key_text_and_caret_visible(self):
        entry=self.panel.entry
        self.assertNotEqual(entry.cget('foreground'),entry.cget('background'))
        self.assertNotEqual(entry.cget('insertbackground'),entry.cget('background'))
        self.assertEqual(entry.cget('disabledbackground'),entry.cget('background'))

    def test_nested_modal_settings_receives_focus_and_restores_parent_grab(self):
        from api_settings_ui import open_settings
        parent=tk.Toplevel(self.root);parent.grab_set()
        with patch('api_connections.current_key',return_value=''):
            window=open_settings(parent,'gemini')
        self.root.update();self.assertEqual(window.grab_current(),window)
        self.assertEqual(window.api_panels['gemini'].entry.cget('show'),'•')
        window.destroy();self.root.update();self.assertEqual(parent.grab_current(),parent)

    def test_recovery_actions_visible_at_minimum_window_size(self):
        from stage_review_ui import StageReviewPanel
        self.root.deiconify();self.root.geometry('1040x660')
        data={'assets':[],'shots':[],'segments':[],'quality':{'ready':False,'blockers':['Declared missing media']},
              'ai_status':{'status':'gemini_unavailable','reason':'نطاق شورت غير معروف.'}}
        request={'key':'media','label':'تركيب اللقطات','data':data,'previews':[],'last_good':deepcopy(data),'work':'.'}
        panel=StageReviewPanel(self.root,request,lambda r:None,lambda p:None,threading.Event());panel.pack(fill='both',expand=True)
        self.root.update()
        for button in (panel.api_recovery_button,panel.media_retry_button,panel.pending_sources_button):
            self.assertTrue(button.winfo_ismapped())
            self.assertLessEqual(button.winfo_rootx()+button.winfo_width(),self.root.winfo_rootx()+self.root.winfo_width())
            self.assertLessEqual(button.winfo_rooty()+button.winfo_height(),self.root.winfo_rooty()+self.root.winfo_height())
        self.assertEqual(str(panel.approve_button.cget('state')),'disabled')
        self.assertEqual(panel.data['diagnostics']['issues'][0]['code'],'ai_response')


if __name__=='__main__':unittest.main()
