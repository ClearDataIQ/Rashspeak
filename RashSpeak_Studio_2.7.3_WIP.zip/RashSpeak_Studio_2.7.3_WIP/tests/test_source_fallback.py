"""Fallback integration uses declared synthetic video, never claims real gameplay."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock, patch

from media_tools import Cancelled, duration, run
from source_fallback import CommonsVideos, VideoSources
from official_sources import SourceUnavailable
from media_director import analyse_video, apply_plan, build_plan, choose, materialize
from media_archive import MediaArchive
from media_acquisition import download_excerpt
from smart_editor import import_asset, plan as legacy_plan
from tests.test_media_director import request, source


def metadata(seconds=4):
    return {'provider':'Wikimedia Commons','title':'File:Elden Ring gameplay.webm',
        'url':'https://upload.wikimedia.org/synthetic-test.webm',
        'source':'https://commons.wikimedia.org/wiki/File:Synthetic-test.webm',
        'license':'CC BY 4.0','license_url':'https://creativecommons.org/licenses/by/4.0/',
        'author':'Synthetic test fixture','mime':'video/webm','duration':seconds,'size':None}


def candidates():
    with patch('source_fallback.search',return_value=[metadata()]):
        return CommonsVideos().search(request())


class FallbackTests(unittest.TestCase):
    def test_choice_reuses_validated_ai_cache_and_bounds_encoding_to_sentence(self):
        candidate=source();candidate['reviewed_scenes']=[{'start':0.,'end':50.,'game':'Elden Ring','event':'','entities':[]}]
        client=Mock();client.model='gemini-test'
        client.generate.return_value={'candidate_id':candidate['id'],'source_in':2.,'source_out':40.,'scene_verified':True,'reason':'test'}
        with tempfile.TemporaryDirectory() as folder:
            one=choose(request(),[candidate],client,folder)
            two=choose(request(),[candidate],client,folder)
        self.assertEqual(one['source_out'],5.);self.assertEqual(two,one)
        self.assertTrue(one['scene_verified']);self.assertEqual(client.generate.call_count,1)

    def test_game_alone_cannot_reuse_a_different_idea(self):
        from PIL import Image
        with tempfile.TemporaryDirectory() as folder:
            archive=MediaArchive(folder)
            def download(c,s,e,p,cancel):
                dest=p/'image.png';Image.new('RGB',(24,24)).save(dest);return dest
            context={**request(),'kind':'image'}
            archive.acquire(source(),0,1,download,
                lambda p:import_asset(p,game='Elden Ring',license='Synthetic fixture',source='Synthetic',approved=True),context)
            self.assertTrue(archive.find(context))
            self.assertFalse(archive.find({**context,'idea':'victory after boss fight'}))

    def test_quota_failure_stops_further_ai_requests_but_preserves_all_requests(self):
        from gemini_client import GeminiUnavailable
        primary=Mock();primary.search.side_effect=SourceUnavailable('offline')
        fallback=Mock();fallback.search.return_value=candidates()*3
        client=Mock();client.model='gemini-test'
        segments=[{'start':i*3.,'end':i*3.+3,'text':'حديث','story_topic':'Elden Ring'} for i in range(3)]
        with tempfile.TemporaryDirectory() as folder,patch('media_director.analyse_video',side_effect=GeminiUnavailable('quota reached')) as analyse:
            result=build_plan(segments,MediaArchive(folder),{'youtube':VideoSources(primary,fallback)},client)
        self.assertEqual(analyse.call_count,1);client.generate.assert_not_called()
        self.assertEqual(len(result['sentences']),3)
        self.assertTrue(all(r['status']=='ai_unavailable' for r in result['sentences']))

    def test_analysis_proxy_is_reused_only_for_unchanged_source_bytes(self):
        from internet_video import analysis_proxy
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);original=root/'original.mp4'
            def make(color):
                run(['ffmpeg','-v','error','-y','-f','lavfi','-i',f'color=c={color}:s=160x90:r=8:d=4',
                     '-c:v','libx264','-threads','1',original])
            make('red')
            with patch('internet_video.source_file',return_value=original):
                one,_=analysis_proxy(candidates()[0],root)
                again,_=analysis_proxy(candidates()[0],root)
                self.assertEqual(one,again)
                make('blue');two,_=analysis_proxy(candidates()[0],root)
                self.assertNotEqual(one,two)
                self.assertNotEqual(one.read_bytes(),two.read_bytes())

    def test_fractional_frame_excerpt_covers_requested_time_without_upscaling(self):
        import math
        from internet_video import excerpt
        from media_tools import probe
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);original=root/'source.mp4'
            run(['ffmpeg','-v','error','-y','-f','lavfi','-i','testsrc2=s=160x90:r=30:d=4',
                 '-c:v','libx264','-threads','1',original])
            with patch('internet_video.source_file',return_value=original):
                output=excerpt(candidates()[0],.017,3.457,root)
            video=next(s for s in probe(output)['streams'] if s['codec_type']=='video')
            self.assertEqual(int(video['nb_frames']),math.ceil((3.457-.017)*30-1e-8))
            self.assertGreaterEqual(duration(output)+.001,3.457-.017)
            self.assertEqual((video['width'],video['height']),(160,90))
            run(['ffmpeg','-v','error','-i',output,'-f','null','-'])

    def test_unknown_game_does_not_disable_other_official_channels(self):
        primary=Mock();primary.search.side_effect=[SourceUnavailable('unknown channel',provider_wide=False),[source()]]
        fallback=Mock();fallback.search.return_value=[]
        chain=VideoSources(primary,fallback)
        self.assertFalse(chain.search({**request(),'game':'Unconfigured game'}))
        self.assertTrue(chain.search(request()))
        self.assertEqual(primary.search.call_count,2)

    def test_failed_scene_is_not_sent_again_and_checkpoint_has_diagnostics(self):
        primary=Mock();primary.search.side_effect=SourceUnavailable('offline')
        fallback=Mock();fallback.search.return_value=candidates()
        client=Mock();client.model='gemini-test'
        segments=[{'start':i*3.,'end':i*3.+3,'text':'حديث','story_topic':'Elden Ring'} for i in range(3)]
        from gemini_client import GeminiError
        with tempfile.TemporaryDirectory() as folder,patch('media_director.analyse_video',side_effect=GeminiError('analysis failed')) as analyse:
            p=Path(folder);messages=[]
            result=build_plan(segments,MediaArchive(p/'archive'),{'youtube':VideoSources(primary,fallback)},
                              client,p/'plan.json',on_progress=messages.append)
            self.assertEqual(analyse.call_count,1);client.generate.assert_not_called()
            self.assertTrue(all(r['status']=='no_verified_scene' for r in result['sentences']))
            self.assertIn('scene_error',json.loads((p/'plan.json').read_text())['sentences'][0]['candidates'][0])
            self.assertTrue(any('analysis failed' in m for m in messages))

    def test_outage_is_attempted_once_and_fallback_still_searches_another_game(self):
        primary=Mock();primary.search.side_effect=SourceUnavailable('network blocked')
        fallback=Mock();fallback.search.return_value=candidates()
        chain=VideoSources(primary,fallback)
        self.assertTrue(chain.search(request()))
        self.assertTrue(chain.search({**request(),'game':'The Witcher 3'}))
        self.assertEqual(primary.search.call_count,1)
        self.assertEqual(fallback.search.call_count,2)
        self.assertEqual(chain.attempts[0]['status'],'unavailable')

    def test_pending_primary_cannot_hide_approved_fallback_and_no_primary_download(self):
        pending=source();pending['rights_status']='pending'
        primary=Mock();primary.search.return_value=[pending]*5
        fallback=Mock();fallback.search.return_value=candidates()
        found=VideoSources(primary,fallback).search(request())
        self.assertEqual(found[0]['provider'],'commons_video')
        with patch('media_acquisition.requests.get') as http,self.assertRaises(SourceUnavailable):
            download_excerpt(pending,0,1,Path('/tmp'))
        http.assert_not_called()

    def test_cache_does_not_spend_all_searches_on_one_game_or_change_sentence_context(self):
        primary=Mock();primary.search.side_effect=SourceUnavailable('not configured')
        fallback=Mock();fallback.search.return_value=[]
        chain=VideoSources(primary,fallback)
        segments=[{'start':i*3.,'end':i*3.+3,'text':'حديث','semantic':{
            'game':game,'visual':'gameplay','entities':[f'object {i}'],'queries':[f'unique query {i}']}}
            for i,game in enumerate(['Elden Ring']*30+['Ghost of Tsushima'])]
        original=deepcopy(segments)
        with tempfile.TemporaryDirectory() as folder:
            result=build_plan(segments,MediaArchive(folder),{'youtube':chain})
        self.assertEqual(result['search_count'],2);self.assertEqual(fallback.search.call_count,2)
        self.assertFalse(any(r['status']=='search_budget_reached' for r in result['sentences']))
        self.assertEqual(segments,original)
        self.assertEqual(result['sentences'][20]['entities'],['object 20'])

    def test_commons_pool_cached_but_specific_event_never_invented(self):
        provider=CommonsVideos()
        with patch('source_fallback.search',return_value=[metadata()]) as search:
            one=provider.search(request('new update',['new object']))
            provider.search(request('other update'))
        self.assertEqual(search.call_count,1)
        self.assertEqual(one[0]['event'],'');self.assertEqual(one[0]['entities'],[])
        self.assertEqual(one[0]['scene_status'],'needs_video_review')

    def test_cancellation_never_turns_into_another_source_search(self):
        primary=Mock();primary.search.side_effect=Cancelled('stop');fallback=Mock()
        with self.assertRaises(Cancelled):VideoSources(primary,fallback).search(request())
        fallback.search.assert_not_called()

    def test_only_supplied_source_video_range_can_be_verified(self):
        client=Mock();client.model='gemini-test'
        scene={'start':0.,'end':5.,'game':'Elden Ring','event':'','entities':[],
               'description':'synthetic scene test','confidence':.95}
        client.generate.return_value={'scenes':[scene]}
        candidate=candidates()[0];candidate['duration']=300
        with patch('internet_video.analysis_proxy',return_value=(Path('/tmp/fixture.mp4'),4.)):
            with self.assertRaises(Exception):analyse_video(candidate,request(),client)
            scene['end']=4
            self.assertTrue(analyse_video(candidate,request(),client))
        self.assertIn('video_path',client.generate.call_args.kwargs)
        self.assertNotIn('video_url',client.generate.call_args.kwargs)

    def test_out_of_range_scene_does_not_discard_other_valid_reviewed_scenes(self):
        client=Mock();client.model='gemini-test'
        good={'start':0.,'end':3.,'game':'Elden Ring','event':'','entities':[],
              'description':'synthetic valid scene','confidence':.95}
        bad={**good,'start':3.,'end':8.}
        client.generate.return_value={'scenes':[good,bad]}
        with tempfile.TemporaryDirectory() as folder,patch('internet_video.analysis_proxy',return_value=(Path('/tmp/test.mp4'),4.)):
            self.assertEqual(analyse_video(candidates()[0],request(),client,folder),[good])
            diagnostics=list(Path(folder).glob('*.rejected.json'))
            self.assertEqual(json.loads(diagnostics[0].read_text())['rejected_scenes'],[bad])

    def test_fallback_actual_download_excerpt_timeline_export_and_restart_reuse(self):
        from pro_project import from_legacy
        from pro_render import render
        from tests.test_production import words,signal
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);video=root/'test.webm'
            run(['ffmpeg','-v','error','-y','-f','lavfi','-i','testsrc2=s=320x180:r=30:d=4',
                 '-c:v','libvpx-vp9','-threads','2',video])
            data=video.read_bytes();m=metadata();m['size']=len(data)
            response=Mock();response.status_code=200;response.headers={'Content-Length':str(len(data))}
            response.iter_content.side_effect=lambda _:iter([data]);response.__enter__=Mock(return_value=response)
            response.__exit__=Mock(return_value=False)
            client=Mock();client.model='gemini-test'
            scene={'start':0.,'end':4.,'game':'Elden Ring','event':'','entities':[],
                   'description':'synthetic moving video','confidence':.99}
            cid=candidates()[0]['id']
            client.generate.side_effect=[{'scenes':[scene]}, {'candidate_id':cid,'source_in':0.,
                'source_out':3.,'scene_verified':True,'reason':'Synthetic integration evidence'}]
            segments=[{'start':0.,'end':3.,'text':'إلدن رينج عالم مفتوح','story_topic':'Elden Ring'}]
            primary=Mock();primary.search.side_effect=SourceUnavailable('offline')
            archive=MediaArchive(root/'archive')
            def imported(path,candidate):
                return import_asset(path,game='Elden Ring',license='CC BY 4.0',
                                    source=candidate['source'],approved=True)
            with patch('source_fallback.search',return_value=[m]),patch('licensed_media.requests.get',return_value=response) as network,patch('app_paths.app_dir',return_value=root):
                p=build_plan(segments,archive,{'youtube':VideoSources(primary,CommonsVideos())},client)
                self.assertEqual(p['ready_count'],1)
                result=materialize(p,archive,download_excerpt,imported)
                again=materialize(p,MediaArchive(root/'archive'),download_excerpt,imported)
                self.assertEqual(network.call_count,1)
                self.assertEqual(again['sentences'][0]['status'],'cached')
            audio=root/'voice.wav';signal(audio,words(segments[0]['text']),3)
            timeline=legacy_plan(audio,{'assets':[]},segments)
            apply_plan(timeline,result)
            self.assertEqual(timeline['shots'][0]['asset_id'],result['sentences'][0]['asset_id'])
            doc=from_legacy(timeline)
            for seq in doc['sequences']:seq.update(width=320,height=180)
            output=root/'rendered.mp4';render(doc,output)
            self.assertAlmostEqual(duration(output),3,delta=.08)
            run(['ffmpeg','-v','error','-i',output,'-f','null','-'])


if __name__=='__main__':unittest.main()
