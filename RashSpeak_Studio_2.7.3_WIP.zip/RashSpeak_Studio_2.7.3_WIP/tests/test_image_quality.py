"""Automatic image fallback cannot bypass scene/pixel gates or a Gemini outage."""
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock, patch

from PIL import Image

from image_fallback import extend_plan
from media_archive import MediaArchive
from media_director import analyse_image
from production_quality import assess
from smart_editor import import_asset
from tests import test_media_director as fixture

request, source = fixture.request, fixture.source


class ImageQualityTests(unittest.TestCase):
    def test_brief_bad_image_blocks_final_even_with_enough_matching_video(self):
        timeline=fixture.QualityTests().timeline()
        timeline['assets'][0].update(scene_verified=True,width=1920,height=1080)
        image={**timeline['assets'][0],'id':'picture','kind':'image','width':320,'height':240}
        timeline['assets'].append(image)
        timeline['shots']=[{'start':0.,'end':11.,'asset_id':'a','source_offset':0.},
                           {'start':11.,'end':12.,'asset_id':'picture','source_offset':0.}]
        timeline.update(require_scene_evidence=True,source_quality={'min_source_height':720,'enforced':True})
        self.assertGreater(assess(timeline)['matching_video_ratio'],.8)
        self.assertFalse(assess(timeline)['ready'])
        self.assertEqual(assess(timeline)['low_resolution_ranges'][0]['kind'],'image')
        image.update(width=1920,height=1080,scene_verified=False)
        self.assertFalse(assess(timeline)['ready'])
        self.assertTrue(assess(timeline)['unverified_scene_ranges'])
        image['scene_verified']=True
        self.assertTrue(assess(timeline)['ready'])

    def test_low_resolution_image_cache_is_not_reused_for_hd_request(self):
        with tempfile.TemporaryDirectory()as folder:
            archive=MediaArchive(folder);candidate={**source(),'id':'image:fixture'}
            row={**request(),'kind':'image','min_source_height':720,'require_scene_evidence':True}
            def download(c,a,b,d,cancel):
                path=d/'small.png';Image.new('RGB',(320,240)).save(path);return path
            def imported(path):
                return import_asset(path,game=row['game'],license='Fixture',source='Synthetic fixture',approved=True)
            asset,_=archive.acquire(candidate,0.,1.,download,imported,row)
            archive.annotate(asset['source_key'],{'scene_verified':True})
            self.assertEqual(archive.find(row),[])
            self.assertEqual(len(archive.find({**row,'min_source_height':0})),1)

    def test_actual_downloaded_pixels_are_checked_before_spending_image_analysis(self):
        with tempfile.TemporaryDirectory()as folder:
            archive=MediaArchive(folder);client=Mock()
            candidate={**source(),'id':'image:fixture','width':1920,'height':1080}
            row={**request(),'kind':'image','min_source_height':720}
            def download(c,a,b,d,cancel):
                path=d/'small.png';Image.new('RGB',(320,240)).save(path);return path
            with patch('media_acquisition.download_excerpt',side_effect=download):
                self.assertEqual(analyse_image(candidate,row,client,archive),[])
            client.generate.assert_not_called()
            self.assertEqual(candidate['height'],240)
            self.assertIn('scene_error',candidate)

    def test_quota_failure_skips_live_retries_but_still_finds_later_cached_image(self):
        first={**request(),'kind':'gameplay','role':'clip','status':'ai_unavailable',
               'reason':'Gemini quota exhausted','min_source_height':720,'require_scene_evidence':True}
        second={**first,'id':'s0001','start':3.,'end':6.,'text':'ثانية'}
        archive=Mock();archive.find.side_effect=[[],[{'id':'cached','kind':'image','game':'Elden Ring'}]]
        provider=Mock();client=Mock()
        result=extend_plan({'sentences':[first,second],'ai_unavailable':True,'ai_error':first['reason']},
                           [],archive,{'images':provider},client)
        self.assertEqual(result['sentences'][-2]['status'],'ai_unavailable')
        self.assertEqual(result['sentences'][-1]['status'],'cached')
        provider.search.assert_not_called();client.generate.assert_not_called()
        for call in archive.find.call_args_list:
            self.assertTrue(call.args[0]['require_scene_evidence'])
            self.assertEqual(call.args[0]['min_source_height'],720)
