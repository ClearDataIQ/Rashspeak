from copy import deepcopy
import json
import threading
import time
import tkinter as tk
import unittest
from unittest.mock import patch,Mock

import api_connections
import gemini_client
import gemini_context
from gemini_client import GeminiClient,GeminiError,GeminiUnavailable
from production_diagnostics import summarize,recovery_text
from steam_sources import SteamOfficial
from official_sources import SourceUnavailable
import test_steam_sources as steam_fixture


class Response:
    def __init__(self,value,status=200):
        self.status_code=status;self.data=json.dumps(value).encode();self.closed=False
    def iter_content(self,size):
        for i in range(0,len(self.data),size):yield self.data[i:i+size]
    def close(self):self.closed=True


def failure(message,details=None):
    return Response({'error':{'code':400,'message':message,'details':details or[]}},400)


def success(value):
    return Response({'candidates':[{'finishReason':'STOP','content':{'parts':[{'text':json.dumps(value)}]}}]})


class HTTP:
    def __init__(self,*responses):self.responses=list(responses);self.calls=[]
    def request(self,*args,**kwargs):
        self.calls.append((args,deepcopy(kwargs)));return self.responses.pop(0)


class ProtocolTests(unittest.TestCase):
    def client(self,http,model='gemini-fixture'):
        return GeminiClient(key='DECLARED_FAKE_KEY',model=model,http=http)

    def test_schema_complexity_retries_once_with_same_model_inputs_and_explicit_json_contract(self):
        rejected=failure('The response schema is too complex; too many states.')
        http=HTTP(rejected,success({'ok':True}),success({'ok':True}))
        client=self.client(http);schema={'type':'OBJECT','properties':{'ok':{'type':'BOOLEAN'}},'required':['ok']}
        self.assertEqual(client.generate('system',{'sentence':'بيانات تجريبية فقط'},schema),{'ok':True})
        self.assertTrue(rejected.closed);self.assertEqual(client.last_response_mode,'json_schema_prompt')
        first,second=[call[1]['json']for call in http.calls]
        self.assertIn('responseSchema',first['generationConfig']);self.assertNotIn('responseSchema',second['generationConfig'])
        self.assertEqual(first['contents'],second['contents']);self.assertEqual(http.calls[0][0],http.calls[1][0])
        self.assertIn(json.dumps(schema,ensure_ascii=False),second['systemInstruction']['parts'][0]['text'])
        self.assertEqual(second['generationConfig']['responseMimeType'],'application/json')
        client.generate('system',{},schema);self.assertEqual(len(http.calls),3)
        self.assertNotIn('responseSchema',http.calls[2][1]['json']['generationConfig'])

    def test_unknown_400_never_retries_or_prints_server_echoed_secret_prompt_or_url(self):
        private='DECLARED_FAKE_KEY a private narration https://example.test/?key=othersecret'
        response=failure(private);http=HTTP(response)
        with self.assertRaises(GeminiUnavailable)as error:self.client(http).generate('system',{}, {'type':'OBJECT'})
        self.assertEqual(len(http.calls),1);self.assertTrue(response.closed)
        self.assertIn('[unknown]',str(error.exception))
        for text in ['DECLARED_FAKE_KEY','narration','othersecret','example.test']:self.assertNotIn(text,str(error.exception))

    def test_invalid_key_and_billing_400_are_not_schema_fallbacks(self):
        cases=[('API key not valid.',[],'credential'),('API key was reported as leaked.',[],'credential'),
               ('billing is not enabled',[],'account'),('response_mime_type is not supported',[],'json_unsupported'),
               ('Bad request',[{'reason':'API_KEY_INVALID','metadata':{'secret':'DECLARED_FAKE_KEY'}}],'credential')]
        for message,details,kind in cases:
            with self.subTest(kind=kind):
                http=HTTP(failure(message,details))
                with self.assertRaises(GeminiUnavailable)as error:self.client(http).generate('s',{}, {'type':'OBJECT'})
                self.assertIn('['+kind+']',str(error.exception));self.assertEqual(len(http.calls),1)
                self.assertNotIn('DECLARED_FAKE_KEY',str(error.exception))

    def test_explicit_unsupported_thinking_removes_only_that_optional_setting(self):
        http=HTTP(failure('thinking_config.thinking_level is not supported'),success({'ok':True}))
        self.client(http,'gemini-3-flash-preview').generate('s',{}, {'type':'OBJECT'})
        first,second=[call[1]['json']['generationConfig']for call in http.calls]
        self.assertIn('thinkingConfig',first);self.assertNotIn('thinkingConfig',second)
        self.assertEqual(first['responseSchema'],second['responseSchema'])

    def test_bad_media_is_source_specific_and_does_not_disable_other_sources(self):
        http=HTTP(failure('Failed to fetch video file_uri.'))
        with self.assertRaises(GeminiError)as error:
            self.client(http).generate('s',{}, {'type':'OBJECT'},video_url='https://www.youtube.com/watch?v=abcdefghijk')
        self.assertNotIsInstance(error.exception,GeminiUnavailable)
        self.assertIn('[media_input]',str(error.exception));self.assertEqual(len(http.calls),1)

    def test_error_body_is_bounded_and_closed_even_if_not_json(self):
        for content in [b'not json',b'['*(65536+1)]:
            response=Response({});response.status_code=400;response.data=content
            with self.assertRaises(GeminiUnavailable)as error:self.client(HTTP(response)).models()
            self.assertTrue(response.closed);self.assertIn('[unknown]',str(error.exception))

    def test_only_recognized_field_paths_are_exposed(self):
        details=[{'fieldViolations':[{'field':'generation_config.response_schema','description':'response_schema is not supported'},
                                    {'field':'DECLARED_FAKE_KEY','description':'private narration'}]}]
        http=HTTP(failure('Bad payload',details),failure('Unknown failure'))
        with self.assertRaises(GeminiUnavailable)as error:self.client(http).generate('s',{}, {'type':'OBJECT'})
        self.assertNotIn('DECLARED_FAKE_KEY',str(error.exception));self.assertNotIn('private narration',str(error.exception))
        self.assertEqual(len(http.calls),2)

    def test_failed_fallback_is_not_a_success_or_an_endless_retry(self):
        http=HTTP(failure('response_schema is not supported'),failure('response_schema is not supported'))
        with self.assertRaises(GeminiUnavailable):self.client(http).generate('s',{}, {'type':'OBJECT'})
        self.assertEqual(len(http.calls),2)

    def test_context_validator_still_rejects_fabricated_ids_after_schema_fallback(self):
        http=HTTP(failure('response schema is too complex'),success({'segments':[{'id':'invented'}],'shorts':[]}))
        with self.assertRaises(GeminiError):
            gemini_context.analyse('',[{'start':0,'end':3,'text':'نص تجريبي'}],client=self.client(http))
        self.assertEqual(len(http.calls),2)

    def test_incomplete_non_json_generation_after_fallback_is_rejected(self):
        response=Response({'candidates':[{'finishReason':'MAX_TOKENS'}]})
        http=HTTP(failure('response schema is too complex'),response)
        with self.assertRaises(GeminiError):self.client(http).generate('s',{}, {'type':'OBJECT'})


class SteamIdentityTests(unittest.TestCase):
    def test_trademark_spelling_matches_exact_app_but_never_grants_rights(self):
        data=steam_fixture.listing();data['1174180']['data']['name']='Red Dead Redemption™ 2®'
        items,_=steam_fixture.search(data=data)
        self.assertEqual(len(items),1);self.assertEqual(items[0]['rights_status'],'pending')

    def test_number_edition_appid_or_type_mismatch_still_rejected(self):
        for field,value in [('name','Red Dead Redemption 3'),('name','Red Dead Redemption 2 Ultimate Edition'),('steam_appid',292030),('type','dlc')]:
            with self.subTest(field=field,value=value):
                data=steam_fixture.listing();data['1174180']['data'][field]=value
                with self.assertRaises(SourceUnavailable)as error:steam_fixture.search(data=data)
                self.assertFalse(error.exception.provider_wide);self.assertIn('[identity_mismatch]',str(error.exception))

    def test_region_unavailable_and_malformed_listing_are_not_identity_mismatches(self):
        for entry,code in [({'success':False},'listing_unavailable'),({'success':True,'data':[]},'listing_invalid')]:
            with self.assertRaises(SourceUnavailable)as error:steam_fixture.search(data={'1174180':entry})
            self.assertIn('['+code+']',str(error.exception));self.assertFalse(error.exception.provider_wide)


class DiagnosticTests(unittest.TestCase):
    def test_request_and_listing_errors_get_specific_actions_not_proxy_advice(self):
        plan={'sentences':[{'status':'ai_unavailable','reason':'Gemini HTTP 400 [unknown]'}],
              'source_attempts':[{'provider':'steam','status':'unavailable','reason':'Steam [identity_mismatch]'},
                                 {'provider':'steam','status':'unavailable','reason':'Steam [listing_unavailable]'}]}
        issues=summarize(plan);self.assertEqual({i['code']for i in issues},{'ai_request','source_identity','source_listing'})
        text=recovery_text({'issues':issues});self.assertIn('اختبار تحليل فعلي',text);self.assertNotIn('رفض الوكيل',text)

    def test_bad_account_stays_distinct_from_unknown_format_400(self):
        issues=summarize({},ai_status={'status':'gemini_unavailable','reason':'Gemini HTTP 400 [credential]'})
        self.assertEqual([i['code']for i in issues],['ai_account'])


class GenerationProbeTests(unittest.TestCase):
    def test_probe_runs_production_schema_and_validator_on_test_text_not_owner_project(self):
        def analysed(script,segments,**kwargs):
            self.assertEqual(script,'');self.assertEqual(len(segments),12)
            self.assertIn('تجربة تقنية',segments[1]['text']);self.assertNotIn('cache',kwargs)
            self.assertIs(kwargs['client'],client.return_value)
            return {'segments':[]}
        with patch('gemini_client.GeminiClient')as client,patch('gemini_context.analyse',side_effect=analysed)as analysis:
            client.return_value.model='gemini-fixture';client.return_value.last_response_mode='response_schema'
            result=api_connections.check_generation('DECLARED_FAKE_KEY','gemini-fixture')
            self.assertTrue(result['generation_checked']);self.assertEqual(result['model'],'gemini-fixture')
            self.assertEqual(analysis.call_count,1)

    def test_generation_error_is_not_relabelled_success(self):
        with patch('gemini_client.GeminiClient',side_effect=GeminiUnavailable('Gemini HTTP 400 [unknown]')):
            with self.assertRaises(api_connections.ConnectionError)as error:api_connections.check_generation('DECLARED_FAKE_KEY')
        self.assertIn('HTTP 400',str(error.exception))


class GenerationUITests(unittest.TestCase):
    def test_explicit_button_runs_off_tk_thread_and_keeps_model_choices(self):
        from api_settings_ui import open_settings
        root=tk.Tk();root.withdraw()
        try:
            with patch('api_connections.current_key',return_value='DECLARED_FAKE_KEY'):
                window=open_settings(root,'gemini')
            panel=window.api_panels['gemini'];choices=panel.combo.cget('values');thread_ids=[]
            panel.key.set('DECLARED_FAKE_KEY')
            def check(*args,**kwargs):
                thread_ids.append(threading.get_ident());return {'message':'generation fixture','generation_checked':True}
            with patch('api_connections.check_generation',side_effect=check)as generation,patch('api_connections.check')as listing:
                panel.generation_button.invoke();deadline=time.monotonic()+5
                while panel.busy and time.monotonic()<deadline:root.update();time.sleep(.01)
                root.update();self.assertFalse(panel.busy)
                self.assertEqual(panel.status.get(),'generation fixture');self.assertEqual(panel.combo.cget('values'),choices)
                self.assertNotEqual(thread_ids,[threading.get_ident()]);self.assertEqual(generation.call_count,1);listing.assert_not_called()
        finally:root.destroy()


if __name__=='__main__':unittest.main()
