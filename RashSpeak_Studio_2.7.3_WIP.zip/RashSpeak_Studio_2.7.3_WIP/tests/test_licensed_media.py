import copy
import tempfile
from pathlib import Path
import threading
import unittest
from unittest.mock import patch

from licensed_media import candidate, credits_text, download, gather, topics
from media_tools import Cancelled


def page():
    values={'LicenseShortName':'CC BY 4.0','LicenseUrl':'https://creativecommons.org/licenses/by/4.0/',
            'Artist':'Creator','ImageDescription':'Fortnite gameplay recorded by creator'}
    return {'title':'File:Fortnite.webm','imageinfo':[{'url':'https://upload.wikimedia.org/a.webm',
            'descriptionurl':'https://commons.wikimedia.org/wiki/File:Fortnite.webm',
            'mime':'video/webm','size':1000,'width':1280,'height':720,
            'extmetadata':{k:{'value':v} for k,v in values.items()}}]}


class MediaTests(unittest.TestCase):
    def test_pending_license_review_is_retained_but_not_downloaded_automatically(self):
        p=page();p['imageinfo'][0]['extmetadata']['Categories']={'value':'Media from YouTube|License review needed (video)'}
        item=candidate(p,'Fortnite');self.assertTrue(item['rights_review_required'])
        with tempfile.TemporaryDirectory() as folder,patch('licensed_media.requests.get')as network,self.assertRaises(ValueError):
            download(item,folder)
        network.assert_not_called()

    def test_music_keyword_tags_do_not_turn_generic_visuals_into_gameplay(self):
        p=page();p['title']='File:Original song.webm'
        p['imageinfo'][0]['extmetadata']['ImageDescription']={'value':'I wanted to create a song in a futuristic world. Tags Fortnite gameplay.'}
        self.assertIsNone(candidate(p,'Fortnite'))

    def test_accepts_attribution_only_license_with_evidence(self):
        item=candidate(page(),'Fortnite')
        self.assertEqual(item['author'],'Creator')
        self.assertIn('LicenseShortName',item['retrieved_metadata'])

    def test_restrictive_unknown_and_mismatched_licenses_rejected(self):
        for name in ['CC BY-SA 4.0','CC BY-NC 4.0','CC BY-ND 4.0','Unknown','CC0']:
            p=page();p['imageinfo'][0]['extmetadata']['LicenseShortName']['value']=name
            self.assertIsNone(candidate(p,'Fortnite'))
        p=page();p['imageinfo'][0]['extmetadata']['LicenseUrl']['value']='https://creativecommons.org/licenses/by-nc/4.0/'
        self.assertIsNone(candidate(p,'Fortnite'))

    def test_restrictions_missing_author_and_other_game_rejected(self):
        for key,value in [('Restrictions','Copyrighted game design'),('Artist','Unknown'),('Artist','')]:
            p=page();p['imageinfo'][0]['extmetadata'][key]={'value':value}
            self.assertIsNone(candidate(p,'Fortnite'))
        self.assertIsNone(candidate(page(),'Minecraft'))

    def test_untrusted_download_destination_rejected_before_network(self):
        with tempfile.TemporaryDirectory() as folder,patch('licensed_media.requests.get') as get:
            for url in ['http://upload.wikimedia.org/a.webm','https://evil.test/a.webm','https://upload.wikimedia.org:8443/a.webm']:
                with self.assertRaises(ValueError):download({'url':url},folder)
            get.assert_not_called()

    def test_cancellation_propagates_without_fallback(self):
        cancel=threading.Event();cancel.set()
        with self.assertRaises(Cancelled):gather('فورتنايت',None,cancel=cancel)

    def test_unavailable_source_returns_explicit_warning(self):
        with patch('licensed_media.search',side_effect=RuntimeError('offline')):
            result=gather('فورتنايت',None,logger=lambda x:None)
        self.assertEqual(result['assets'],[]);self.assertTrue(result['warnings'])

    def test_no_script_or_recording_sent_to_provider(self):
        with patch('licensed_media.search',return_value=[]) as search:
            gather('فورتنايت هذا نص خاص لا نرسله',None,logger=lambda x:None)
        self.assertEqual(search.call_args.args[0],'Fortnite')
        self.assertNotIn('نص خاص',str(search.call_args))

    def test_credits_preserve_author_license_and_modifications(self):
        item=candidate(page(),'Fortnite');text=credits_text([item,item])
        self.assertEqual(text.count('المصدر:'),1)
        for part in ['Creator','CC BY 4.0','قص وتحجيم','creativecommons.org']:self.assertIn(part,text)
