"""Owner-policy regressions; provider scene evidence here is explicitly synthetic."""
from copy import deepcopy
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock,patch

from production import complete_shorts
from media_director import sentence_requests,validate_selection,build_plan
from media_archive import MediaArchive
from visual_choices import choose_batch
from visual_beats import entity_key
from visual_diversity import analysis_windows
from production_quality import assess
from tests import test_media_director as fixture


def sources():
    result=[]
    for key in ('a','b','c'):
        item={**fixture.source(),'id':key,'duration':120.,'url':f'https://publisher.example/{key}'}
        item['reviewed_scenes']=[{'start':10.,'end':30.,'game':'Elden Ring','event':'','entities':['swords']}]
        result.append(item)
    return result


def choice(key,a=12.,b=15.):
    return {'candidate_id':key,'source_in':a,'source_out':b,'scene_verified':True,'reason':'Declared synthetic sword scene'}


class ShortPolicyTests(unittest.TestCase):
    def test_short_recording_is_not_padded_or_looped_to_reach_25(self):
        self.assertEqual(complete_shorts([{'start':0.,'end':24.9,'text':'نهاية.'}],24.9),[])

    def test_only_whole_contiguous_sentences_between_25_and_60(self):
        segments=[{'start':i*5.,'end':(i+1)*5.,'text':'خبر جديد.','sentence_end':True,'story_topic':'one'}for i in range(30)]
        before=deepcopy(segments);shorts=complete_shorts(segments,150.)
        self.assertTrue(shorts)
        self.assertTrue(all(25<=s['end']-s['start']<=60 for s in shorts))
        self.assertTrue(all(s['start']%5==s['end']%5==0 for s in shorts));self.assertEqual(segments,before)

    def test_different_topics_do_not_fill_an_underlength_story(self):
        segments=[{'start':0.,'end':20.,'text':'اللعبة الأولى.','story_topic':'a'},
                  {'start':20.,'end':40.,'text':'اللعبة الثانية.','story_topic':'b'}]
        self.assertEqual(complete_shorts(segments,40.),[])

    def test_latest_range_accepts_25_through_60_and_rejects_both_outside(self):
        from short_policy import duration_allowed
        self.assertTrue(duration_allowed(25.));self.assertTrue(duration_allowed(60.))
        self.assertFalse(duration_allowed(24.99));self.assertFalse(duration_allowed(60.01))
        for seconds in (25.,30.,44.,60.):
            short=complete_shorts([{'start':0.,'end':seconds,'text':'تخيل تجربة قوية وهذه نهايتها.'}],seconds)
            self.assertEqual([(s['start'],s['end'])for s in short],[(0.,seconds)])

    def test_over_one_minute_story_is_skipped_for_another_complete_idea(self):
        segments=[{'start':0.,'end':45.,'text':'تخيل لعبة رائعة لكن','story_topic':'a'},
                  {'start':45.,'end':61.,'text':'تحتاج هذه التكملة.','story_topic':'a'},
                  {'start':61.,'end':91.,'text':'هل تعرف اللعبة المجانية؟ هذه قصتها كاملة.','story_topic':'b'}]
        self.assertEqual([(s['start'],s['end'])for s in complete_shorts(segments,91.)],[(61.,91.)])

    def test_dangling_ending_waits_for_the_actual_payoff(self):
        segments=[{'start':0.,'end':45.,'text':'تخيل لعبة عالم مفتوح رائعة لكن.','sentence_end':True},
                  {'start':45.,'end':55.,'text':'الأفضل فيها حرية الاختيار.','sentence_end':True}]
        shorts=complete_shorts(segments,55.)
        self.assertEqual([(s['start'],s['end'])for s in shorts],[(0.,55.)])
        self.assertIn('حرية الاختيار',shorts[0]['ending'])

    def test_duration_limit_never_cuts_off_a_dangling_story(self):
        segments=[{'start':0.,'end':45.,'text':'تخيل عالم رائع عشان','sentence_end':True},
                  {'start':45.,'end':61.,'text':'تعيش تجربة مكتملة.','sentence_end':True}]
        self.assertEqual(complete_shorts(segments,61.),[])

    def test_compelling_existing_hook_is_preferred_without_reordering_voice(self):
        segments=[{'start':0.,'end':50.,'text':'تفاصيل اللعبة اليومية.','story_topic':'a','sentence_end':True},
                  {'start':50.,'end':100.,'text':'تخيل أقوى مفاجأة في هذا العالم.','story_topic':'b','sentence_end':True}]
        short=complete_shorts(segments,100.,count=1)[0]
        self.assertEqual((short['start'],short['end']),(50.,100.));self.assertEqual(short['hook'],segments[1]['text'])

    def test_word_or_caption_boundary_alone_cannot_justify_a_mid_thought_cut(self):
        from short_policy import review_range
        cues=[{'start':0.,'end':45.,'text':'تخيل هذا العالم لكن','sentence_end':False},
              {'start':45.,'end':50.,'text':'التجربة تستحق.','sentence_end':True}]
        for a,b in [(0.,45.),(1.,50.)]:
            with self.assertRaises(ValueError):review_range(cues,a,b,50.)
        self.assertIn('تستحق',review_range(cues,0.,50.,50.)['ending'])

    def test_semantic_incomplete_flag_overrides_punctuation_and_pause(self):
        segments=[{'start':0.,'end':45.,'text':'تخيل قوة هذه اللعبة.','sentence_end':True,
                   'semantic':{'ending_complete':False}},
                  {'start':47.,'end':55.,'text':'هذا هو السبب الكامل.','sentence_end':True}]
        self.assertEqual([(s['start'],s['end'])for s in complete_shorts(segments,55.)],[(0.,55.)])

    def test_gemini_hook_and_ending_must_be_grounded_and_complete(self):
        from gemini_context import validate_context
        from gemini_client import GeminiError
        segments=[{'start':0.,'end':25.,'text':'تخيل عالم Fortnite واسع.'},
                  {'start':25.,'end':50.,'text':'وهذه نهاية القصة كاملة.'}]
        rows=[{'id':f's{i:04}','game':'Fortnite','event':'','idea':'قصة','evidence':s['text'],'tone':'neutral',
               'importance':8.,'confidence':.9,'visual':'gameplay','meme':False,'effect':'none','queries':['Fortnite gameplay'],
               'reason':'Declared semantic fixture','hook_score':8.,'ending_complete':True}for i,s in enumerate(segments)]
        item={'first':'s0000','last':'s0001','reason':'A direct hook and completed payoff','score':8.,
              'hook':'تخيل عالم Fortnite','ending':'نهاية القصة كاملة','complete_ending':True}
        response={'segments':rows,'shorts':[item]};script=' '.join(s['text']for s in segments)
        self.assertEqual(len(validate_context(response,script,segments)['shorts']),1)
        bad=deepcopy(response);bad['shorts'][0]['complete_ending']=False
        self.assertEqual(validate_context(bad,script,segments)['shorts'],[])
        bad=deepcopy(response);bad['shorts'][0]['hook']='Invented spoken introduction'
        with self.assertRaises(GeminiError):validate_context(bad,script,segments)


class ActionTimingTests(unittest.TestCase):
    def segment(self):
        words=[{'text':w,'start':i*.8,'end':i*.8+.6}for i,w in enumerate('تقدر تستخدم السيوف والسحر'.split())]
        return {'start':0.,'end':3.2,'text':'تقدر تستخدم السيوف والسحر','words':words,'story_topic':'Elden Ring'}

    def test_sword_and_magic_are_separate_visual_requests_at_real_word_time(self):
        segment=self.segment();before=deepcopy(segment);rows=sentence_requests([segment])
        self.assertEqual(len(rows),2)
        self.assertEqual(rows[0]['entities'],['swords']);self.assertEqual(rows[1]['entities'],['magic'])
        self.assertAlmostEqual(rows[1]['start'],2.4);self.assertAlmostEqual(rows[0]['end'],2.4)
        self.assertEqual(segment,before)

    def test_magic_cannot_be_accepted_during_the_sword_beat(self):
        row=sentence_requests([self.segment()])[0];candidate=sources()[0]
        candidate['reviewed_scenes'][0]['entities']=['magic']
        selected=validate_selection(row,[candidate],choice('a',12.,12.+row['end']-row['start']))
        self.assertFalse(selected['scene_verified'])

    def test_aliases_preserve_specific_item_identity(self):
        self.assertEqual(entity_key('والسيوف'),entity_key('sword combat'))
        self.assertNotEqual(entity_key('السيوف'),entity_key('السحر'))
        self.assertNotEqual(entity_key('silver sword'),entity_key('steel sword'))

    def test_no_word_time_is_invented_when_only_sentence_timing_exists(self):
        row=self.segment();row.pop('words')
        requests=sentence_requests([row]);self.assertEqual(len(requests),1)
        self.assertNotIn('word_anchor',requests[0])

    def test_anchored_sword_sequence_cannot_include_magic_only_shots(self):
        from visual_choices import validate_sequence
        from gemini_client import GeminiError
        row={**fixture.request(entities=['swords']),'end':4.,'word_anchor':'swords'}
        sword,magic=sources()[:2];magic['reviewed_scenes'][0]['entities']=['magic']
        with self.assertRaises(GeminiError):
            validate_sequence(row,[sword,magic],{'id':row['id'],'shots':[choice('b',12.,14.),choice('a',12.,14.)]})

    def test_variation_retains_exact_action_evidence_when_scenes_overlap(self):
        from visual_choices import spread_within_reviewed_scene
        row=fixture.request(entities=['swords']);candidate=sources()[0]
        candidate['reviewed_scenes'].insert(0,{'start':0.,'end':120.,'game':'Elden Ring','event':'','entities':['magic']})
        selected=validate_selection(row,[candidate],choice('a'))
        output=spread_within_reviewed_scene([selected],{},seed=7)[0]
        self.assertGreaterEqual(output['source_in'],10.);self.assertLessEqual(output['source_out'],30.)


class VarietyTests(unittest.TestCase):
    def rows(self):
        return [{**fixture.request(entities=['swords']),'id':f's{i:04d}','start':i*3.,'end':i*3.+3.,'candidates':sources()}for i in range(3)]

    def response(self):
        return {'selections':[{'id':r['id'],'shots':[choice('a')],
                              'alternatives':[{'shots':[choice('b')]},{'shots':[choice('c')]}]}for r in self.rows()]}

    def test_alternatives_use_multiple_sources_and_saved_seed_reproduces_cache(self):
        client=Mock();client.model='declared-fixture';client.generate.return_value=self.response()
        with tempfile.TemporaryDirectory()as folder:
            first=choose_batch(self.rows(),client,folder,variation_seed=42)
            again=choose_batch(self.rows(),client,folder,variation_seed=42)
            changed=choose_batch(self.rows(),client,folder,variation_seed=77)
        self.assertEqual(client.generate.call_count,1);self.assertEqual(first,again)
        self.assertEqual(len({r['selections'][0]['candidate']['id']for r in first}),3)
        self.assertNotEqual(first,changed)
        for row in changed:
            selected=row['selections'][0]
            self.assertGreaterEqual(selected['source_in'],10.);self.assertLessEqual(selected['source_out'],30.)

    def test_wrong_entity_alternative_is_not_used_to_create_fake_variety(self):
        rows=self.rows();response=self.response()
        for row in rows:
            row['candidates'][1]['reviewed_scenes'][0]['entities']=['magic']
            row['candidates'][2]['rights_status']='pending'
        client=Mock();client.model='fixture';client.generate.return_value=response
        result=choose_batch(rows,client,variation_seed=1)
        self.assertEqual({r['selections'][0]['candidate']['id']for r in result},{'a'})

    def test_alternative_excerpts_of_one_source_do_not_defeat_source_rotation(self):
        from visual_diversity import choose_options,source_id
        a,b,c=sources();b['url']=a['url']
        options=[[{'candidate':candidate,'source_in':12.,'source_out':15.}]for candidate in (b,c)]
        # A different excerpt id belonging to the same original remains used.
        selected=choose_options(options,{'a':[(12.,15.)]},seed=42,previous_source=source_id(a))
        self.assertEqual(selected[0]['candidate']['id'],'c')

    def test_analysis_samples_early_middle_and_late_not_only_first_minutes(self):
        a=analysis_windows(900.,123,'source');self.assertEqual(set(a),{0.,360.,720.})
        self.assertEqual(a,analysis_windows(900.,123,'source'))
        self.assertEqual(analysis_windows(70.,123,'source'),[0.])

    def test_analysis_budget_is_shared_between_games_and_multiple_source_videos(self):
        games=('Elden Ring','The Witcher 3')
        segments=[{'start':i*3.,'end':i*3.+3.,'text':game,'story_topic':game}for i,game in enumerate(games)]
        provider=Mock()
        def search(r):return [{**fixture.source(),'id':r['game']+str(i),'game':r['game']}for i in range(4)]
        provider.search.side_effect=search
        def analysed(candidate,r,*args,**kw):return [{'start':0.,'end':10.,'game':r['game'],'event':'','entities':[]}]
        def generate(system,payload,schema):
            return {'selections':[{'id':s['id'],'shots':[choice(s['candidate_ids'][0],0.,3.)]}for s in payload['sentences']]}
        client=Mock();client.model='fixture';client.generate.side_effect=generate
        with tempfile.TemporaryDirectory()as folder,patch('media_director.analyse_video',side_effect=analysed)as inspect:
            plan=build_plan(segments,MediaArchive(folder),{'youtube':provider},client,batch_size=8,max_scene_analyses=6,variation_seed=22)
        calls={g:set()for g in games}
        for call in inspect.call_args_list:calls[call.args[1]['game']].add(call.args[0]['id'])
        self.assertTrue(all(len(calls[g])>=2 for g in games));self.assertLessEqual(inspect.call_count,6)


class VarietyGateTests(unittest.TestCase):
    def timeline(self,first=30.):
        a={'id':'a','kind':'video','duration':120,'game':'Elden Ring','usage_approved':True,'license':'Fixture','source':'https://publisher.example/video-a','scene_verified':True}
        b={**a,'id':'b','source':'https://publisher.example/video-b'}
        return {'duration':60.,'assets':[a,b],'segments':[{'start':0.,'end':60.,'text':'حديث متصل عن اللعبة.','story_topic':'Elden Ring'}],
                'shots':[{'start':0.,'end':first,'asset_id':'a','source_offset':0.},
                         {'start':first,'end':60.,'asset_id':'b','source_offset':0.}],
                'source_variety':{'enforced':True,'minimum_sources':2,'target_sources':3,'min_seconds':25}}

    def test_different_excerpts_from_one_original_video_do_not_count_as_many_sources(self):
        timeline=self.timeline();timeline['assets'][1]['source']=timeline['assets'][0]['source']
        report=assess(timeline);self.assertFalse(report['ready'])
        self.assertEqual(report['source_variety'][0]['source_count'],1)

    def test_real_source_variety_passes_and_a_tiny_flash_cannot_fake_it(self):
        self.assertTrue(assess(self.timeline())['ready'])
        self.assertFalse(assess(self.timeline(59.5))['ready'])

    def test_short_is_checked_separately_from_the_long_video(self):
        timeline=self.timeline(45.)
        self.assertTrue(assess(timeline)['ready'])
        timeline['shorts']=[{'start':0.,'end':45.,'approved':True}]
        report=assess(timeline);self.assertFalse(report['ready'])
        self.assertTrue(any('short:'in reason for reason in report['blockers']))


class ShortRenderTests(unittest.TestCase):
    def test_fifty_second_short_exports_two_actual_sources_and_reopens_unchanged(self):
        """Encoded colour/audio fixtures verify duration/cuts, never Gemini quality."""
        import hashlib
        from PIL import Image
        from media_tools import run,probe
        from smart_editor import import_asset
        from pro_project import from_legacy,Session,load_project
        from pro_render import render
        with tempfile.TemporaryDirectory()as folder:
            root=Path(folder);assets=[];hashes={}
            for color in ('red','blue'):
                path=root/(color+'.mp4')
                run(['ffmpeg','-v','error','-y','-f','lavfi','-i',f'color={color}:s=320x180:r=30:d=30',
                     '-c:v','libx264','-threads','1',path])
                hashes[path]=hashlib.sha256(path.read_bytes()).hexdigest()
                asset=import_asset(path,game='Elden Ring',license='Synthetic test fixture',source=f'fixture:{color}',approved=True)
                asset['scene_verified']=True;assets.append(asset)
            audio=root/'tone.wav'
            run(['ffmpeg','-v','error','-y','-f','lavfi','-i','sine=frequency=440:sample_rate=48000:duration=50',audio])
            hashes[audio]=hashlib.sha256(audio.read_bytes()).hexdigest()
            segments=[{'start':i*10.,'end':(i+1)*10.,'text':'جملة اختبار مكتملة.','story_topic':'Elden Ring','sentence_end':True}for i in range(5)]
            shorts=complete_shorts(segments,50.);self.assertEqual(len(shorts),1);shorts[0]['approved']=True
            timeline={'audio':str(audio),'duration':50.,'assets':assets,'segments':segments,'shorts':shorts,
                'shots':[{'start':0.,'end':25.,'asset_id':assets[0]['id'],'source_offset':5.},
                         {'start':25.,'end':50.,'asset_id':assets[1]['id'],'source_offset':5.}],
                'source_variety':{'enforced':True,'minimum_sources':2,'target_sources':3,'min_seconds':25}}
            self.assertTrue(assess(timeline)['ready'])
            session=Session(from_legacy(timeline));project_path=root/'project.rash.json';session.save(project_path)
            reopened=load_project(project_path);short=reopened['sequences'][1]
            output=root/'fifty.mp4';render(reopened,output,sequence_id=short['id'],size=(180,320))
            info=probe(output);self.assertAlmostEqual(float(info['format']['duration']),50.,delta=.08)
            self.assertEqual([s['nb_frames']for s in info['streams']if s['codec_type']=='video'],['1500'])
            self.assertTrue(any(s['codec_type']=='audio'for s in info['streams']))
            colors=[]
            for at in (10,35):
                frame=root/f'{at}.png';run(['ffmpeg','-v','error','-y','-ss',at,'-i',output,'-frames:v','1',frame])
                with Image.open(frame)as image:colors.append(image.convert('RGB').getpixel((90,160)))
            self.assertGreater(colors[0][0],colors[0][2]+100);self.assertGreater(colors[1][2],colors[1][0]+100)
            self.assertEqual(hashes,{path:hashlib.sha256(path.read_bytes()).hexdigest()for path in hashes})
