"""Conservative caption spelling alignment; never writes narration or invents times."""
from copy import deepcopy
from difflib import SequenceMatcher
import re
import unicodedata


def token(text):
    text=''.join(c for c in str(text)if unicodedata.category(c)not in ('Mn','Cf'))
    text=text.lower().translate(str.maketrans('أإآىة','ااايه'))
    return ''.join(c for c in text if c.isalnum())


def reconcile(words,script=''):
    result=deepcopy(words);source=[token(w['text'])for w in words]
    written=re.findall(r'\S+',script);target=[token(w)for w in written]
    changes=[];proposals=[]
    matcher=SequenceMatcher(None,source,target,autojunk=False)
    ops=matcher.get_opcodes() if target else []
    for n,(tag,a,b,c,d)in enumerate(ops):
        if tag=='equal':
            for i,j in zip(range(a,b),range(c,d)):
                if words[i]['text']!=written[j]:
                    result[i].setdefault('original_text',words[i]['text']);result[i]['text']=written[j]
                    changes.append({'index':i,'before':words[i]['text'],'after':written[j],'reason':'matching_script_spelling'})
        elif tag=='replace' and b-a==d-c and 0<b-a<=3:
            # Two nearby exact words on both sides ground a spelling correction.
            left=ops[n-1]if n else None;right=ops[n+1]if n+1<len(ops)else None
            anchored=bool(left and right and left[0]==right[0]=='equal' and left[2]-left[1]>=2 and right[2]-right[1]>=2)
            for i,j in zip(range(a,b),range(c,d)):
                old,new=source[i],target[j]
                similarity=SequenceMatcher(None,old,new,autojunk=False).ratio()
                digits=lambda value:''.join(c for c in value if c.isdigit())
                safe=(anchored and len(old)>=3 and len(new)>=3 and similarity>=.72
                      and words[i].get('probability',1)<.85 and digits(old)==digits(new))
                item={'index':i,'before':words[i]['text'],'after':written[j],'reason':'anchored_spelling'if safe else'requires_listening'}
                if safe:
                    result[i].setdefault('original_text',words[i]['text']);result[i]['text']=written[j];changes.append(item)
                else:proposals.append(item)
    uncertain=[{'index':i,'start':w['start'],'end':w['end'],'text':w['text'],'probability':w.get('probability',0)}
               for i,w in enumerate(result)if w.get('probability',1)<.65]
    return result,{'reference':'owner_script'if script.strip()else'none','applied':changes,'proposals':proposals,
                   'needs_listening':uncertain,'words_added':0,'words_removed':0,
                   'note':'Spelling suggestions are not acoustic proof. Original words/times and recording are retained.'}
