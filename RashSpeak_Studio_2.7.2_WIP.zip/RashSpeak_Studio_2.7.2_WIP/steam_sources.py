"""Public Steam listing metadata; a store trailer does not confer reuse rights."""
import hashlib
import json
from pathlib import Path
from urllib.parse import urlparse

import requests

from licensed_media import game_key
from media_tools import Cancelled,probe
from official_sources import SourceUnavailable,_get_json,apply_permission,settings
from smart_editor import normalize,save

APPS={game_key(k):v for k,v in {
    'Ghost of Tsushima':(2215430,"Ghost of Tsushima DIRECTOR'S CUT"),
    'The Witcher 3':(292030,'The Witcher 3: Wild Hunt'),
    'Elden Ring':(1245620,'ELDEN RING'),
    'Red Dead Redemption 2':(1174180,'Red Dead Redemption 2'),
    'Cyberpunk 2077':(1091500,'Cyberpunk 2077'),
    "Assassin's Creed Mirage":(3035570,"Assassin's Creed Mirage"),
    'Battlefield 2042':(1517290,'Battlefield 2042'),
}.items()}
HOSTS=('video.fastly.steamstatic.com','video.akamai.steamstatic.com','cdn.akamai.steamstatic.com',
       'cdn.cloudflare.steamstatic.com','shared.fastly.steamstatic.com','shared.akamai.steamstatic.com',
       'steamcdn-a.akamaihd.net','steamvideo-a.akamaihd.net')
MAX_BYTES=250_000_000
# Exact alternate display title observed in the official AppID 292030 listing.
# The immutable AppID and type still have to agree; no fuzzy title/edition match.
LISTING_TITLES={292030:('The Witcher 3: Wild Hunt — Remastered',)}


def listing_name(value):
    # Remove trademark glyphs before NFKC turns ™ into the letters "TM".
    # Keep full title/edition/number equality; never accept substring/fuzzy matches.
    return normalize(value.translate(str.maketrans('','','™®©')))if isinstance(value,str)else''


def valid_video_url(value):
    try:
        p=urlparse(value)
        return (p.scheme=='https' and p.hostname in HOSTS and not p.username and not p.password
            and p.port in (None,443) and p.path.startswith('/store_trailers/')
            and p.path.lower().endswith(('.mp4','.webm')))
    except (TypeError,ValueError):return False


class SteamOfficial:
    def __init__(self,config=None,http=requests,cancel=None):
        self.config=settings() if config is None else config;self.http=http;self.cancel=cancel;self.cache={}

    def search(self,request):
        if request.get('role','clip')!='clip':return []
        app=APPS.get(game_key(request['game']))
        if app is None:return []
        appid,name=app
        if appid not in self.cache:
            data=_get_json('https://store.steampowered.com/api/appdetails',{'appids':appid,'l':'english'},self.http,self.cancel)
            entry=data.get(str(appid),{})
            if not isinstance(entry,dict)or entry.get('success')is not True:
                raise SourceUnavailable(f'Steam [listing_unavailable]: لا بيانات متاحة للعبة AppID {appid}؛ قد يكون السبب توفر المتجر أو المنطقة. لم يُثبت تطابق الهوية.',provider_wide=False)
            item=entry.get('data',{})
            if not isinstance(item,dict):
                raise SourceUnavailable(f'Steam [listing_invalid]: رد بيانات غير صالح للعبة AppID {appid}.',provider_wide=False)
            accepted_names={listing_name(title)for title in (name,*LISTING_TITLES.get(appid,()))}
            if (type(item.get('steam_appid'))is not int or item['steam_appid']!=appid
                    or listing_name(item.get('name',''))not in accepted_names or item.get('type')!='game'):
                raise SourceUnavailable(f'Steam [identity_mismatch]: لم يطابق رقم اللعبة أو اسمها أو نوعها الهوية المتوقعة AppID {appid}؛ رُفض المصدر.',provider_wide=False)
            self.cache[appid]=item
        item=self.cache[appid];result=[]
        for movie in item.get('movies',[])[:12]:
            if type(movie.get('id'))is not int:continue
            urls=[movie.get(kind,{}).get(size,'') for kind in ('mp4','webm')for size in ('max','480')]
            url=next((u for u in urls if isinstance(u,str) and valid_video_url(u)),None)
            if not url:continue  # HLS/DRM/login are not converted into unrestricted downloads.
            source='https://store.steampowered.com/app/'+str(appid)+'/'
            candidate={'id':f'steam:{appid}:{movie["id"]}','provider':'steam','url':url,'source':source,
                'title':str(movie.get('name',''))[:300],'game':request['game'],'event':'','entities':[],
                'author':', '.join(item.get('publishers',[])),'duration':None,'license':'unknown',
                'role':'clip','mood':'','rights_status':'pending','scene_status':'needs_video_review',
                'permission_scope':f'steam-app:{appid}','official_listing_checked':True,
                'steam_app_id':appid,'acquisition_version':'cfr30-1'}
            result.append(apply_permission(candidate,self.config))
        return result


def download_source(candidate,folder,cancel=None):
    from media_acquisition import permission
    grant=permission(candidate);url=candidate['url']
    if cancel and cancel.is_set():raise Cancelled('أُلغي تنزيل فيديو المصدر.')
    if not valid_video_url(url) or not candidate.get('official_listing_checked'):
        raise SourceUnavailable('رابط فيديو Steam ليس من قائمة المضيفين المعتمدة.')
    if urlparse(url).hostname not in grant.get('download_hosts',[]):
        raise SourceUnavailable('تصريح المصدر لا يشمل مضيف تنزيل الفيديو.')
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    key=hashlib.sha256((url+'|'+grant['license']+'|'+grant['evidence_url']).encode()).hexdigest()
    target=folder/(key+Path(urlparse(url).path).suffix);evidence=target.with_suffix('.rights.json')
    cached=False
    if target.is_file() and evidence.is_file():
        try:cached=hashlib.sha256(target.read_bytes()).hexdigest()==json.loads(evidence.read_text(encoding='utf-8'))['sha256']
        except (ValueError,OSError,KeyError):pass
    pending=target.with_suffix(target.suffix+'.pending')
    if not cached:
        sha=hashlib.sha256();total=0
        try:
            with requests.get(url,stream=True,timeout=(8,25),allow_redirects=False) as response:
                if response.status_code!=200:raise SourceUnavailable('مصدر Steam رفض تنزيل الملف؛ لا تجاوز أو تسجيل دخول.')
                announced=response.headers.get('Content-Length')
                if announced is not None and not 0<int(announced)<=MAX_BYTES:raise SourceUnavailable('فيديو المصدر يتجاوز حد250MB.')
                with pending.open('wb')as dest:
                    for block in response.iter_content(65536):
                        if cancel and cancel.is_set():raise Cancelled('أُلغي تنزيل فيديو المصدر.')
                        total+=len(block)
                        if total>MAX_BYTES:raise SourceUnavailable('فيديو المصدر يتجاوز حد250MB.')
                        dest.write(block);sha.update(block)
                if not total or announced is not None and int(announced)!=total:
                    raise SourceUnavailable('لم يكتمل تنزيل فيديو المصدر.')
            pending.replace(target)
            save({'title':candidate['title'],'source':candidate['source'],'url':url,'license':grant['license'],
                  'license_url':grant['evidence_url'],'author':candidate['author'],'credit':candidate['title'],
                  'downloaded_size':total,'sha256':sha.hexdigest()},evidence)
        except requests.RequestException:
            raise SourceUnavailable('تعذر اتصال مضيف فيديو Steam؛ لم تُتبع تحويلات أو قيود دخول.') from None
        finally:pending.unlink(missing_ok=True)
    info=probe(target);video=next((s for s in info['streams'] if s.get('codec_type')=='video'),None)
    seconds=float(info.get('format',{}).get('duration',0))
    if video is None or not .1<seconds<=1800 or max(video['width'],video['height'])>8192:
        raise SourceUnavailable('فيديو المصدر خارج حدود الحجم الزمني أو الأبعاد أو النوع.')
    candidate['duration']=seconds;candidate['license']=grant['license']
    return target
