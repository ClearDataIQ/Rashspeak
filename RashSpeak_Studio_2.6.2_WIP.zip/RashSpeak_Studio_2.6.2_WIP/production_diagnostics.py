"""Explain missing footage separately from API outages, rights and bad selections."""
from collections import Counter,defaultdict
import csv
from pathlib import Path

from production_quality import assess
from smart_editor import save

ACTION={
 'missing_source':'توسيع مصادر اللعبة أو إضافة لقطاتك المحلية؛ لا تستخدم لعبة أخرى لسد النقص.',
 'no_visual_match':'المصادر موجودة لكن المشاهد لا تطابق الفكرة؛ راجع مصدرًا آخر أو جزءًا لاحقًا.',
 'invalid_selection':'مراجعة حدود اللقطات أو تقسيم الجملة مرئيًا إلى لقطات قصيرة؛ التسجيل لا يتغير.',
 'quota':'متابعة الاختيارات غير المكتملة بعد توفر حصة Gemini؛ النتائج الصحيحة محفوظة.',
 'ai_unavailable':'التحقق من اتصال Gemini وإعداده؛ لا تُعد التفريغ أو حذف الأصول المنجزة.',
 'rights_review':'مراجعة تصريح الاستخدام والتنزيل من الناشر؛ وجود الفيديو على الإنترنت لا يثبت الإذن.',
 'source_unavailable':'فحص الوصول الفعلي للمضيف؛ رفض الوكيل قبل المصادقة لا يثبت أن المفتاح خطأ.',
 'download_failed':'مراجعة خطأ تنزيل المقتطف وإعادة الناقص؛ الأجزاء السليمة باقية في الأرشيف.',
 'search_budget':'متابعة البحث للجمل المتبقية أو إضافة مصدر محلي مطابق؛ لا يعني نفاد الميزانية عدم وجود الفيديو.',
 'ai_selection':'تفعيل Gemini لاختيار النتائج الموجودة بعد فحص المشاهد؛ لا تعتمد توقيتًا من العنوان وحده.',
 'context':'تحديد سياق الجملة العام قبل اختيار اللقطات.',
 'pending':'متابعة معالجة هذا الطلب المحفوظ.',
}


def cause(row):
    status=row.get('status','planned');reason=row.get('reason','')
    if status in ('cached','downloaded'):return None
    if status=='needs_source_review':return 'rights_review'
    if status=='needs_context':return 'context'
    if status=='source_unavailable':return 'source_unavailable'
    if status in ('download_failed','partial_media'):return 'download_failed'
    if status=='search_budget_reached':return 'search_budget'
    if status in ('needs_ai_selection','pending_ai_selection'):return 'ai_selection'
    if status=='no_verified_scene':return 'no_visual_match'
    if status=='selection_invalid' or any(t in reason for t in ('المقتطف أقصر','توقيت المقتطف','نطاق المشهد')):
        return 'invalid_selection'
    if status=='ai_unavailable':
        return 'quota' if any(t in reason for t in ('حد الاستخدام','حصة','429')) else 'ai_unavailable'
    if status=='no_match':return 'no_visual_match' if row.get('candidates') else 'missing_source'
    return 'pending'


def write_report(timeline,plan,folder):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True);groups=defaultdict(Counter);unresolved=[]
    for row in (plan or {}).get('sentences',[]):
        category=cause(row)
        if category is None or row.get('role','clip')!='clip':continue
        game=row.get('game') or 'سياق عام';groups[game][category]+=1
        unresolved.append({k:row.get(k,'')for k in ('id','game','event','start','end','query','status','reason')}
                         | {'cause':category,'next_action':ACTION[category]})
    report={'quality':assess(timeline),'games':dict(groups),'unresolved_count':len(unresolved),
            'causes':dict(Counter(cause(r)for r in (plan or {}).get('sentences',[]) if cause(r))),
            'source_attempts':(plan or {}).get('source_attempts',[]),'actions':ACTION,
            'note':'Counts describe sentence requests; coverage uses actual timeline duration. Original narration is untouched.'}
    save(report,folder/'media_diagnostics.json')
    csv_path=folder/'missing_media.csv'
    with csv_path.open('w',encoding='utf-8-sig',newline='')as dest:
        fields=['id','game','event','start','end','query','status','cause','reason','next_action']
        writer=csv.DictWriter(dest,fieldnames=fields);writer.writeheader();writer.writerows(unresolved)
    lines=['# أسباب توقف الفيديو الطويل','',f'تغطية الفيديو المطابق: {report["quality"]["matching_video_ratio"]:.1%}',
           '', '| اللعبة | الطلبات غير المكتملة |','| --- | --- |']
    for game,counts in groups.items():lines.append('| '+game+' | '+'؛ '.join(f'{k}: {v}'for k,v in counts.items())+' |')
    lines+=['','## إجراءات المتابعة','']+[f'- {key}: {value}'for key,value in ACTION.items() if key in report['causes']]
    lines+=['','التفاصيل في media_diagnostics.json، وطلبات المصادر في missing_media.csv. لا تعني سلامة التصدير اكتمال اللقطات.']
    (folder/'media_diagnostics.md').write_text('\n'.join(lines),encoding='utf-8')
    return report
