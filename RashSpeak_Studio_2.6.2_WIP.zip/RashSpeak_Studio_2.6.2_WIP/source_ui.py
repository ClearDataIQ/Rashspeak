"""One-time source setup and the shared downloadable-media archive."""
import tkinter as tk
from tkinter import ttk
from pathlib import Path

from rtl_ui import Label, Button, visual
from official_sources import credential, configure_credential, settings, config_path
from smart_editor import save


def open_path(path):
    import os,subprocess,sys
    path=Path(path).resolve()
    if not path.exists():return
    if os.name=='nt':os.startfile(str(path))
    else:subprocess.Popen(['open' if sys.platform=='darwin' else 'xdg-open',str(path)])


def open_settings(parent,candidate=None):
    window=tk.Toplevel(parent);window.title('مصادر اللقطات والأرشيف');window.geometry('760x720')
    body=ttk.Frame(window,padding=16);body.pack(fill='both',expand=True)
    Label(body,text='القنوات الرسمية • خطة لكل جملة • أرشيف مشترك',font=('Segoe UI',15,'bold')).pack(anchor='e')
    Label(body,text='YouTube للقناة الرسمية، وSteam وCommons مصادر بديلة دون مفتاح بحث إضافي. فيديوهات Steam تنتظر تصريح الاستخدام والتنزيل. تُفحص مشاهد الفيديو نفسه وتُحفظ التنزيلات لإعادة استخدامها. يظهر نقص التغطية بدل ملئه بلقطات عشوائية.',wraplength=700,justify='right').pack(fill='x',pady=8)
    book=ttk.Notebook(body);book.pack(fill='both',expand=True)
    api=ttk.Frame(book,padding=12);book.add(api,text=visual('الاتصال'))
    from api_settings_ui import ApiPanel
    ApiPanel(api,'youtube').pack(fill='both',expand=True)
    note=tk.StringVar(value='لا تحفظ المفاتيح داخل المشروع أو ملف الأرشيف.')
    rights=ttk.Frame(book,padding=12);book.add(rights,text=visual('تصاريح المصادر'))
    Label(rights,text='سجّل تصريحًا راجعته من الناشر يسمح بالاستخدام والتنزيل؛ عرض الفيديو في متجر لا يثبت الإذن. أمثلة المعرف: @Battlefield أو youtube:VIDEO_ID أو steam-app:1174180. تصريح steam-app يشمل قائمة اللعبة المعتمدة فقط؛ أضف مضيف التنزيل كما يظهر في المصدر.',wraplength=690,justify='right').pack(fill='x',pady=5)
    fields={}
    for key,label in [('source','معرّف الأصل أو القناة الرسمية'),('license','اسم الرخصة أو الإذن'),('evidence_url','رابط التصريح من المصدر'),('download_hosts','مضيفو تنزيل الوسائط المسموحون، مفصولون بفواصل')]:
        default=(candidate or {}).get('id','') if key=='source' else ''
        Label(rights,text=label).pack(anchor='e');var=tk.StringVar(value=default);fields[key]=var
        ttk.Entry(rights,textvariable=var).pack(fill='x',pady=4)
    approved=tk.BooleanVar(value=False)
    ttk.Checkbutton(rights,text=visual('راجعت الإذن وهو يسمح بهذا الاستخدام والتنزيل'),variable=approved).pack(anchor='e',pady=8)
    def save_grant():
        from media_acquisition import permission
        from official_sources import SourceUnavailable
        try:
            key=fields['source'].get().strip()
            if not key:raise ValueError()
            grant={'license':fields['license'].get().strip(),'evidence_url':fields['evidence_url'].get().strip(),
                   'usage_approved':approved.get(),'download_allowed':approved.get(),
                   'download_hosts':[h.strip().lower() for h in fields['download_hosts'].get().split(',') if h.strip()]}
            permission({'rights_status':'approved','permission':grant})
            cfg=settings();cfg.setdefault('permissions',{})[key]=grant;save(cfg,config_path())
            note.set('حُفظ تصريح المصدر. تبقى مطابقة المشهد وتوقيته مطلوبة لكل جملة.')
        except (ValueError,SourceUnavailable):note.set('أدخل معرّف المصدر ورخصة ورابط HTTPS لإذن يسمح بالاستخدام والتنزيل.')
    Button(rights,text='حفظ تصريح المصدر',command=save_grant).pack(anchor='e',pady=8)
    channels=ttk.Frame(book,padding=12);book.add(channels,text=visual('القنوات المعتمدة'))
    Label(channels,text='يمكن إضافة قناة لأي لعبة أو ناشر. اعتمد الحساب الذي يشير إليه الموقع الرسمي؛ التحقق عبر API يطابق معرّف الحساب المختار ولا يحوّل حسابًا عشوائيًا إلى ناشر رسمي.',wraplength=690,justify='right').pack(fill='x',pady=8)
    game=tk.StringVar();handle=tk.StringVar()
    Label(channels,text='اللعبة أو الناشر').pack(anchor='e');ttk.Entry(channels,textvariable=game).pack(fill='x',pady=5)
    Label(channels,text='اسم القناة مثل @Battlefield').pack(anchor='e');ttk.Entry(channels,textvariable=handle).pack(fill='x',pady=5)
    def save_channel():
        import re
        from licensed_media import game_key
        value=handle.get().strip()
        if not game.get().strip() or not re.fullmatch(r'@[A-Za-z0-9_.-]{2,80}',value):
            note.set('أدخل اسم اللعبة واسم حساب القناة بصيغة @handle.');return
        cfg=settings();cfg.setdefault('channels',{})[game_key(game.get())]=[value];save(cfg,config_path())
        note.set('حُفظت القناة المعتمدة للعبة. تصريح الاستخدام والتنزيل مستقل عن اختيار القناة.')
    Button(channels,text='اعتماد القناة لهذه اللعبة',command=save_channel).pack(anchor='e',pady=8)
    archive=ttk.Frame(book,padding=12);book.add(archive,text=visual('أرشيف التحميلات'))
    Label(archive,text='كل أصل نُزّل يُحفظ مرة واحدة مع SHA256 والمصدر والقناة واللعبة والحدث والعناصر ونطاقه الأصلي. تفحص المشاريع الجديدة هذا الأرشيف قبل البحث والتنزيل. لا يُعاد استخدام أصل لخبر مختلف لمجرد تطابق اسم اللعبة.',wraplength=690,justify='right').pack(fill='x',pady=10)
    def show_archive():
        from media_archive import MediaArchive
        catalog=MediaArchive();open_path(catalog.root/'catalog.json')
    def show_folder():
        from media_archive import MediaArchive
        open_path(MediaArchive().root)
    Button(archive,text='فتح فهرس كل التحميلات',command=show_archive).pack(anchor='e',pady=8)
    Button(archive,text='فتح مجلد الملفات المحفوظة',command=show_folder).pack(anchor='e',pady=8)
    Label(body,textvariable=note,wraplength=700,justify='right').pack(fill='x',pady=8)
    return window
