"""Durable downloads + a human-readable catalog, shared by all projects."""
from copy import deepcopy
from contextlib import contextmanager
import hashlib
import json
from pathlib import Path
import re
import shutil
import sqlite3
import tempfile
import threading

from app_paths import app_dir
from licensed_media import same_game
from media_library import digest
from smart_editor import fingerprint, licensed, normalize, save

_LOCK = threading.RLock()


class MediaArchive:
    def __init__(self, root=None):
        self.root = Path(root or app_dir() / 'output' / 'media_archive').resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.database = self.root / 'catalog.sqlite3'
        self._verified = {}
        with self.connect() as db:
            db.execute('CREATE TABLE IF NOT EXISTS downloads '
                       '(source_key TEXT PRIMARY KEY, sha TEXT NOT NULL, data TEXT NOT NULL)')
        self.rebuild_index()

    @contextmanager
    def connect(self):
        db=sqlite3.connect(self.database,timeout=30)
        try:
            with db:yield db
        finally:db.close()

    @staticmethod
    def source_key(candidate, start, end):
        identity=[candidate['id'], round(start, 3), round(end, 3),candidate.get('role','clip')]
        if candidate.get('acquisition_version'):identity.append(candidate['acquisition_version'])
        return hashlib.sha256(json.dumps(identity,
                                       separators=(',', ':')).encode()).hexdigest()

    def get(self, key):
        with self.connect() as db:
            row = db.execute('SELECT data FROM downloads WHERE source_key=?', (key,)).fetchone()
        if not row:
            return None
        asset = json.loads(row[0]); path = Path(asset['path'])
        if not path.is_file() or fingerprint(path) != asset['fingerprint'] or not licensed(asset):
            return None
        stamp=(str(path),asset['fingerprint']['size'],asset['fingerprint']['mtime_ns'],asset['sha256'])
        if stamp not in self._verified:
            if digest(path) != asset['sha256']:return None
            self._verified[stamp]=True
        return asset

    def find(self, request):
        with self.connect() as db:
            rows = db.execute('SELECT source_key,data FROM downloads ORDER BY rowid DESC').fetchall()
        result = []
        for key,data in rows:
            asset=json.loads(data)
            if asset.get('scene_verified') is False:continue
            if not same_game(asset.get('game'), request['game']):
                continue
            if asset.get('role','clip')!=request.get('role','clip'):continue
            if request.get('role')=='meme' and asset.get('mood')!=request.get('mood'):continue
            if request['event'] and normalize(asset.get('event', '')) != normalize(request['event']):
                continue
            entities = {normalize(e) for e in request['entities']}
            if not entities <= {normalize(e) for e in asset.get('entities', [])}:
                continue
            if request.get('idea') and normalize(asset.get('idea',''))!=normalize(request['idea']):
                continue
            if request['kind'] == 'gameplay' and asset['kind'] not in ('video', 'animation'):
                continue
            if request['kind'] == 'image' and asset['kind'] != 'image':
                continue
            verified=self.get(key)
            if verified:result.append(verified)
        return result

    def annotate(self,key,changes):
        allowed={'scene_verified','scene_description','scene_provider'}
        if set(changes)-allowed:raise ValueError('خصائص تحليل أصل غير مسموحة.')
        with _LOCK,self.connect() as db:
            row=db.execute('SELECT data FROM downloads WHERE source_key=?',(key,)).fetchone()
            if row is None:raise ValueError('أصل غير محفوظ.')
            asset=json.loads(row[0]);asset.update(deepcopy(changes))
            db.execute('UPDATE downloads SET data=? WHERE source_key=?',(json.dumps(asset,ensure_ascii=False),key))
        self.rebuild_index();return asset

    def acquire(self, candidate, start, end, downloader, importer, context, cancel=None):
        key = self.source_key(candidate, start, end)
        # Serialize acquisition so concurrent projects cannot download the same range twice.
        with _LOCK:
            cached = self.get(key)
            if cached:
                return cached, True
            with tempfile.TemporaryDirectory(prefix='download_', dir=self.root) as folder:
                path = Path(downloader(candidate, start, end, Path(folder), cancel))
                if not path.is_file() or not path.resolve().is_relative_to(Path(folder).resolve()):
                    raise ValueError('المنزّل لم يُنتج ملفًا داخل مجلد المهمة.')
                sha = digest(path, cancel)
                suffix = path.suffix.lower()
                if suffix not in ('.mp4', '.webm', '.mkv', '.mov', '.png', '.jpg', '.jpeg', '.webp', '.gif'):
                    raise ValueError('نوع ملف التنزيل غير معتمد.')
                target = self.root / 'files' / sha[:2] / (sha + suffix)
                target.parent.mkdir(parents=True, exist_ok=True)
                if not target.exists() or digest(target, cancel) != sha:
                    pending = target.with_suffix(suffix + '.pending')
                    shutil.copyfile(path, pending); pending.replace(target)
                asset = importer(target)
                if not licensed(asset):
                    raise ValueError('لا تُفهرس الوسائط غير المعتمدة كأصول جاهزة للاستخدام.')
                asset.update({k: deepcopy(context[k]) for k in ('game', 'event', 'entities')})
                asset['idea']=context.get('idea','')
                asset.update(sha256=sha, source_key=key, original_source_id=candidate['id'],
                             source_in=start, source_out=end, provider=candidate['provider'],
                             source_url=candidate['url'], fingerprint=fingerprint(target))
                with self.connect() as db:
                    db.execute('INSERT OR REPLACE INTO downloads VALUES (?,?,?)',
                               (key, sha, json.dumps(asset, ensure_ascii=False)))
                self.rebuild_index()
                return deepcopy(asset), False

    def rebuild_index(self):
        # SQLite is authoritative; the JSON file can always be rebuilt after a crash.
        with _LOCK, self.connect() as db:
            rows = [json.loads(r[0]) for r in db.execute('SELECT data FROM downloads ORDER BY source_key')]
            sources=[]
            for evidence in sorted((self.root/'internet_sources'/'sources').glob('*.rights.json')):
                try:
                    value=json.loads(evidence.read_text(encoding='utf-8'))
                    sources.append({k:value.get(k) for k in ('title','source','url','license','license_url',
                                                            'author','credit','downloaded_size','sha256')}
                                   | {'evidence_file':str(evidence),'purpose':'Source analysis; not automatically selected footage'})
                except (OSError,ValueError):continue
            save({'version': 1, 'download_count': len(rows), 'assets': rows,
                  'internet_source_count':len(sources),'internet_sources':sources}, self.root / 'catalog.json')
