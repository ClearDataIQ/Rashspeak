# Latest owner task — long-video diagnosis, source repair and authorized previews (2026-10-15)

Read docs/LONG_VIDEO_FAILURE_REPAIR_AR.md first. The owner explicitly asked to publish the partial real previews on GitHub and fix/explain the long-video failure; this supersedes older upload freezes for the requested previews and clearly labelled tested source work. Partial previews were published and remotely hash-verified at main commit54970a2 (previews_2026_10_15). They are NOT completed episodes/Shorts. Never overwrite or relabel rejected2.5 outputs.

Current2.6.2 WIP adds visual_choices.py (8-sentence batches, up to4 validated visual parts per sentence, individual retry caches, same-reviewed-scene variation), steam_sources.py (strict public listing identity/CDN, explicit rights before download, no new API key), later source-analysis windows, license-pending/music-spam filtering, cached grounded context recovery without credentials, and actionable production_diagnostics.py reports. Preserve six review gates, source voice/order, shared Auto/Pro project and3cropped overlays; no AI-generated images/video, mandatory music/thumbnail or automatic publishing.

Latest actual verification is recorded in TEST_RESULTS_2.6.2_WIP.txt. Genuine cached real-audio replay uses no keys, no ASR/assets overrides and no new Gemini requests; editable draft retained, original SHA unchanged, final blocked at needs_media with12.856% matching footage. New live batch/Steam integration remains UNVERIFIED. Automatic approval review rejected entering the Gemini key into an escalated terminal, describing a network-boundary bypass; the key was not entered and that runner was cancelled. Do not try another file/env/terminal route to evade that rejection. Reuse the configured managed secret route only after settings are actually applied and connectivity is verified. Do not request another chat key. Steam hosts are saved only in a draft, not proven active. Full professional montage/style acceptance is still outstanding.

Restore point /workspace/restore-points/pre_long_video_repair_20261015.tar.gz. Source checkout is unborn/untracked; do not reset. Upload clone /workspace/github-delivery/public-upload, existing native Git auth, no PAT needed. Source ZIP must whitelist code/docs/tests only; exclude recordings, settings, media/archive/model caches, all secrets and private projects. Do not create worktrees or spawn agents without an explicit applicable instruction.

---

# Latest continuation — internet fallback real-audio test (2026-10-15)

Read docs/INTERNET_FALLBACK_REAL_TEST_AR.md first. Current source adds source_fallback.py/internet_video.py, actual downloaded-video Gemini analysis, source/choice caching, idea-sensitive archive reuse, CFR excerpt length repair, and audible multi-SFX mixing.232 tests pass. Actual owner recording tested; full run remains needs_media. After mechanical CFR repair matching footage is12.856%, NOT a finished episode. Partial source-backed diagnostic previews and a real SFX audio review are under RashSpeak_Downloads/Real_Test_Internet_Fallback. No new upload/release, no fabricated approvals, no AI-generated media, no source audio mutation. Preserve original audio/Whisper/Gemini caches and real test evidence in /workspace/quality-audit/fallback_2_6_2. Full recording acceptance still fails due missing footage, Gemini quota, and blocked YouTube; never present old2.5 or these partial previews as a corrected finished long/Short production.

# Current owner request — Studio 2.6.1

Owner explicitly requested uploading the updated TOOL now and adding YouTube/Gemini API entry options. This supersedes the earlier source-upload freeze for this tested source release. Keep the video-quality gate; no new final video is approved or produced. Add independent credential UI and safe per-provider connection tests,verify and publish the source ZIP in the existing authorized GitHub repository. Never include actual credentials/recordings/cache/local profiles. No repeat permission needed.

# Latest acceptance instruction — 2026-10-15

Owner requires real-recording testing BEFORE further upload. Read docs/REAL_AUDIO_ACCEPTANCE_2.6_AR.md. Real final-mode test ran and stopped at needs_media; no new final video/Shorts.200 tests pass locally after fixes to game-name labels,stage status,and bounded active-clip frame preview. Existing public2.6 ZIP predates these fixes. Do not upload again until actual official-source long/Short montage passes acceptance. Preserve original recording,Whisper cache,and output/acceptance_2_6_20261015_verified. Runtime network/secure-key activation is the external blocker.

# Active owner update —2.6

Read CLOUD_HANDOFF.md and docs/SOURCE_DIRECTOR_2.6_AR.md first. Owner rejected the2.5 card-based delivery; do not claim it is acceptable montage. Implemented sentence media direction, official YouTube metadata/source analysis, free keyless Commons images, persistent archive/cache, and final coverage gate. Owner forbids ANY AI-generated images/video; Gemini only understands/selects/edits existing genuine media. Source policy rejects declared AI media. Entities and source requests are general, not limited to weapons/maps. Do not request cx or paid image-search APIs. New Google API key was provided in chat; never reproduce/save it in files or source. Native Git delivery is authorized public in the existing repository; old assets stay unchanged. Actual YouTube API access is blocked before authentication, so the key and full new montage are not live-tested. Missing footage must save an editable draft and stop final export.

# RashSpeak Studio — Codex engineering instructions

Current continuation is **2.5**, with real uploaded-audio production and final visual-audit fixes. The owner explicitly authorized completing this test without review stops; do not ask again or fabricate human approvals. Read CLOUD_HANDOFF.md and docs/FULL_REAL_PRODUCTION_AR.md for actual output status. Gemini/context/assistant, Pro effects/word editing/player/queue/library are implemented. Keep six review gates in the app for normal projects, three cropped GIF/meme overlays, manual file publication, and no mandatory thumbnail/music. Direct YouTube remains blocked; the uploaded MP3 exists and must not be replaced by synthetic evidence. Preserve the current source and its restore points.

You are the lead developer continuing an **existing** Python 3 desktop application; do **not** discard or rewrite it without strong justification. Read `README_AR.md`, `CODEX_IMPLEMENTATION_PLAN.md`, `publisher.py`, `gui.py`, `studio.py`, and tests before editing. The product's intended user is the Arabic-speaking owner of YouTube gaming-news channel **@RashSpeak**, working on **Windows 11 with NVIDIA RTX 4060** and limited time. Core workflow: owner records his real voice; the tool helps turn legal gameplay footage into a polished news video and short clips, then submits to selected platforms with review and explicit approval.

## Strict scope
- Target platforms **only**: YouTube videos + Shorts, Instagram Reels, TikTok videos. Do not add X, Facebook, or any other social platform.
- Preserve the user's original voice and authorship; never turn this into a mass content scraper, a bulk spammer, or a copyrighted footage downloader.
- Use **official APIs and OAuth** with least required scopes. The app must **never ask for platform passwords** or bypass API audits/restrictions. Do not make platform publishing claims unless exercised in a real authorized sandbox/account.
- Explicit user consent before external publication. Default YouTube uploads to `private`, TikTok to inbox/draft when direct publishing is not approved, and Instagram to review-ready state if real publishing is unavailable. Show concrete API/app-approval prerequisites.
- Never commit credentials, access tokens, client secrets, local profile data, OAuth redirect URLs containing codes, or test media from third parties. Keep secrets in Windows Credential Manager using `keyring`, consider key lifecycle, refresh, revocation and disconnect.
- Do not send, publish, or schedule content from the user's accounts during development except when the user explicitly authorizes a specific test/action.
- UI in natural Arabic with RTL-aware layouts; clean professional desktop design. Keep project operable offline for editing/rendering and tolerant of missing API credentials.
- Focus on minimal cost; report genuinely necessary paid services separately. Any hosted-file requirement for Instagram must be explicit.

## Project state at handoff (do not overclaim)
- Python/tkinter GUI, FFmpeg rough-cut renderer, cue-tag CSV scene mapping, first-35s short generation, optional faster-whisper Arabic SRT support.
- OAuth and publishing **adapters** for YouTube, Instagram, TikTok in `publisher.py`; platform developer setup and real OAuth/publishing **not end-to-end validated**. There is no approved developer app or connected end-user account bundled here.
- TikTok has draft inbox upload and a Direct Post code path that needs permissions/approval. Instagram currently relies on a directly accessible HTTPS media URL; video hosting is not built.
- Five publisher mock tests passed in the source before packaging, but coverage is thin; there is no production readiness claim.
- `README_AR.md` may omit newer TikTok Direct Post code paths; reconcile docs against the implementation.
- No real scheduling service, semantic audio-to-shot matching, YouTube thumbnail automation, custom EXE installer, or real-account live testing is present yet.

## Approach
1. Audit and run tests before modifying code; enumerate bugs/security issues, especially OAuth state/PKCE, expiry and retry safety, HTTP upload handling, UI threading, media input validation, account mismatch, publication status, rate limits and duplicate posting prevention.
2. Refactor into testable modular architecture incrementally. Keep existing functionality working and leave a migration path for stored preferences and tokens.
3. Build a polished clear workflow: `Project -> Narration -> Media/cues -> Smart rough cut -> Short clip selection -> Review -> Platform-specific metadata -> Submit/schedule -> Status`. Progress, cancel, retry, logs, and previews.
4. Build actionable features, not empty mock buttons. Each screen must show real status and handle missing platform approvals gracefully.
5. Add automated unit/integration tests with API mocks and FFmpeg smoke tests using generated synthetic media. No credentials in test suite. Use `python -m unittest discover -s tests -v` or a documented pytest equivalent.
6. Build Windows distributable packaging only after app launches and tests pass. Include dependency check and FFmpeg setup instructions. Do not claim EXE as signed.
7. Produce concise change log and a checklist separating completed work, tested simulated functionality, and functionality blocked on owner/API review.

## Completion policy
Do not stop at a plan. Implement the highest priority vertical slice and keep going through the backlog as time/tools allow. If blocked by an external platform, complete code plus mocked tests and give the exact owner action required. Never ask the user to paste secret values in chat; use local UI and OAuth/browser flow instead.
