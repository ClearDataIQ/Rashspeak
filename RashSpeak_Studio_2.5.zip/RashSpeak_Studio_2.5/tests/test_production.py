"""Automatic production regression tests; media/ASR fixtures are synthetic."""
import array
import hashlib
import json
import math
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch
import wave

from PIL import Image
import audio_edit as a
import captions
from media_tools import Cancelled, duration, run
from production import complete_shorts, contextual_cues, produce
from smart_editor import import_asset, save


def words(text,spacing=.4,start=.1):
    return [{'start':start+i*spacing,'end':start+i*spacing+.3,'text':text,'probability':.95}
            for i,text in enumerate(text.split())]


def signal(path,units,limit):
    rate=48000
    samples=array.array('h',[0])*round(limit*rate)
    for word in units:
        for i in range(round(word['start']*rate),round(word['end']*rate)):
            samples[i]=round(7000*math.sin(i*2*math.pi*240/rate))
    with wave.open(str(path),'wb') as f:
        f.setnchannels(1);f.setsampwidth(2);f.setframerate(rate);f.writeframes(samples.tobytes())


class AudioTests(unittest.TestCase):
    def cleaned(self,script,text):
        units=words(text);limit=units[-1]['end']+.2
        data=a.analyse(script,units,[],limit)
        clean=a.remap_words(units,data['keeps'])
        return ' '.join(w['text'] for w in clean),data,units

    def test_full_retake_selects_last_source_words(self):
        text,data,source=self.cleaned('اليوم خبر جديد.','اليوم خبر جديد اليوم خبر جديد.')
        self.assertEqual(text,'اليوم خبر جديد.')
        self.assertFalse(any(lo<=w['start'] and w['end']<=hi for w in source[:3] for lo,hi in data['keeps']))

    def test_three_partial_attempts_keep_final_consecutive_sentence(self):
        text,data,_=self.cleaned('اليوم خبر جديد وممتع.','اليوم خبر اليوم خبر جديد اليوم خبر جديد وممتع.')
        self.assertEqual(text,'اليوم خبر جديد وممتع.')

    def test_incomplete_last_take_never_reverts_to_complete_first(self):
        text,data,_=self.cleaned('اليوم خبر جديد وممتع.','اليوم خبر جديد وممتع. اليوم خبر')
        self.assertEqual(text,'اليوم خبر')
        self.assertTrue(any('غير مكتملة' in w for w in data['warnings']))

    def test_intentional_repeated_script_words_preserved(self):
        text,data,_=self.cleaned('مرة مرة جميل.','مرة مرة جميل.')
        self.assertEqual(text,'مرة مرة جميل.')
        self.assertFalse(data['edits'])

    def test_script_repeats_two_sentences_preserved(self):
        text,data,_=self.cleaned('اليوم خبر. اليوم خبر.','اليوم خبر. اليوم خبر.')
        self.assertEqual(text,'اليوم خبر. اليوم خبر.')
        self.assertFalse(data['edits'])

    def test_single_word_retakes_keep_last(self):
        text,data,_=self.cleaned('اليوم خبر جديد.','اليوم اليوم اليوم خبر جديد.')
        self.assertEqual(text,'اليوم خبر جديد.')

    def test_restart_wrong_word_is_removed_before_last_take(self):
        text,data,_=self.cleaned('التحديث مجاني اليوم.','التحديث قديم اقصد التحديث مجاني اليوم.')
        self.assertEqual(text,'التحديث مجاني اليوم.')

    def test_single_prefix_corrected_take_keeps_last_not_wrong_price(self):
        for text in ['السعر سبعين السعر ستين ريال.','السعر سبعين لا اقصد السعر ستين ريال.']:
            clean,_,_=self.cleaned('السعر ستين ريال.',text)
            self.assertEqual(clean,'السعر ستين ريال.')

    def test_partial_single_word_last_take_is_not_completed_from_first(self):
        units=words('اليوم خبر جديد. اليوم',spacing=.8)
        data=a.analyse('اليوم خبر جديد.',units,[],3.2)
        self.assertEqual(' '.join(w['text'] for w in a.remap_words(units,data['keeps'])),'اليوم')
        self.assertTrue(any('غير مكتملة' in w for w in data['warnings']))

    def test_intervening_story_never_swallowed_by_repeat_cut(self):
        text,data,_=self.cleaned('اليوم خبر جديد. ثاني خبر مختلف.','اليوم خبر جديد. ثاني خبر مختلف. اليوم خبر')
        self.assertIn('ثاني خبر مختلف.',text)
        for cut in data['edits']:
            if cut['action']=='remove':self.assertLessEqual(cut['end']-cut['start'],1.2)

    def test_asr_mismatch_alone_is_kept(self):
        text,data,_=self.cleaned('التحديث مجاني اليوم.','التحديث مجدي اليوم.')
        self.assertEqual(text,'التحديث مجدي اليوم.')
        self.assertTrue(all(e['action']=='keep' for e in data['edits']))

    def test_quiet_words_inside_detected_silence_are_protected(self):
        units=words('كلام هادي هنا.')
        data=a.analyse('كلام هادي هنا.',units,[(0,1.8)],2)
        self.assertEqual(data['keeps'],[[0,2]])
        self.assertTrue(data['warnings'])

    def test_restore_earlier_attempt_and_original_timestamps(self):
        _,data,source=self.cleaned('اليوم خبر جديد.','اليوم خبر اليوم خبر جديد.')
        overrides={e['id']:'keep' for e in data['edits']}
        restored=a.analyse('اليوم خبر جديد.',source,[],source[-1]['end']+.2,overrides)
        self.assertEqual(a.remap_words(source,restored['keeps']),source)

    def test_overlapping_and_nonfinite_words_rejected(self):
        for units in [[{'start':0,'end':1,'text':'أ'},{'start':.95,'end':2,'text':'ب'}],
                      [{'start':float('nan'),'end':2,'text':'أ'}]]:
            with self.assertRaises(ValueError):a.analyse('أ ب',units,[],3)

    def test_partial_word_cuts_cannot_generate_fragmented_captions(self):
        with self.assertRaisesRegex(ValueError,'كلمة'):a.remap_words(words('صوت'),[[0,.2],[.3,1]])

    def test_short_kept_intervals_not_dropped(self):
        self.assertEqual(a.keep_ranges([{'start':.02,'end':1,'action':'remove'}],2),[[0,.02],[1,2]])

    def test_no_words_only_silence_edit_and_warning(self):
        data=a.analyse('السكربت.',[],[(1,3)],4)
        self.assertEqual(len(data['edits']),1)
        self.assertTrue(any('توقيتات كلمات' in w for w in data['warnings']))


class ShortTests(unittest.TestCase):
    def test_caption_pages_cannot_start_mid_sentence(self):
        segments=[{'start':0,'end':5,'text':'تحديث مجاني','sentence_end':False},
                  {'start':5,'end':10,'text':'للعبة الجديدة.','sentence_end':True}]
        self.assertEqual([(s['start'],s['end']) for s in complete_shorts(segments,10)],[(0,10)])

    def test_no_mid_sentence_or_overlong_fallback(self):
        for segments in [[{'start':0,'end':100,'text':'جملة طويلة.'}],
                         [{'start':0,'end':20,'text':'جملة ناقصة'}]]:
            self.assertEqual(complete_shorts(segments,100),[])

    def test_sensitive_or_cta_inside_candidate_rejects_whole_range(self):
        segments=[{'start':0,'end':5,'text':'تحديث جديد.'},{'start':5,'end':10,'text':'تسريح موظفين.'},
                  {'start':10,'end':15,'text':'اشترك في القناة.'}]
        shorts=complete_shorts(segments,15)
        self.assertEqual([(s['start'],s['end']) for s in shorts],[(0,5)])

    def test_topics_and_count_boundaries(self):
        segments=[{'start':i*8,'end':(i+1)*8,'text':'خبر جديد.','story_topic':str(i)} for i in range(7)]
        shorts=complete_shorts(segments,56)
        self.assertEqual(len(shorts),3)
        self.assertTrue(all(s['end']-s['start']==8 for s in shorts))


class ProductionTests(unittest.TestCase):
    def test_real_pipeline_keeps_original_delivers_decodable_files_and_restore(self):
        with tempfile.TemporaryDirectory(prefix='rash_إنتاج_') as folder:
            root=Path(folder);audio=root/'original.wav'
            text='فورتنايت خبر فورتنايت خبر جديد. التحديث مجاني وممتع. هههه ضحكت مرة.'
            script='فورتنايت خبر جديد. التحديث مجاني وممتع. هههه ضحكت مرة.'
            units=words(text,spacing=.65,start=.2);limit=units[-1]['end']+1.2
            signal(audio,units,limit);digest=hashlib.sha256(audio.read_bytes()).hexdigest()
            image=root/'footage.png';Image.new('RGB',(640,360),'#335578').save(image)
            clip=import_asset(image,game='Fortnite',license='own',source='synthetic fixture',approved=True)
            meme=import_asset(image,role='meme',mood='humor',license='own',source='synthetic fixture',approved=True)
            detailed={'words':units,'segments':[{'start':units[0]['start'],'end':units[-1]['end'],'text':text}]}
            events=[]
            result=produce(audio,script,root/'project',online=False,asr_override=detailed,
                           assets_override=[clip,meme],sizes={'size':(640,360),'portrait_size':(360,640)},on_event=events.append)
            self.assertEqual(result['status'],'ready_for_review')
            self.assertEqual(result['reaction_count'],1)
            self.assertGreaterEqual(len(result['files']),2)
            self.assertEqual(hashlib.sha256(audio.read_bytes()).hexdigest(),digest)
            delivery=Path(result['delivery'])
            self.assertTrue((delivery/'short_01.srt').is_file())
            self.assertFalse((delivery/'thumbnail.jpg').exists())
            self.assertIsNone(result['thumbnail'])
            self.assertTrue((delivery/'stage_reviews.json').is_file())
            transcript=json.loads((delivery.parent/'transcript.json').read_text())
            self.assertEqual(' '.join(s['text'] for s in transcript),script)
            captions.validate(transcript,result['clean_duration'])
            for item in result['files']:run(['ffmpeg','-v','error','-i',item['path'],'-f','null','-'])
            self.assertTrue(all(v=='done' for v in result['stages'].values()))
            self.assertEqual(events[-1]['type'],'complete')
            analysis=json.loads((delivery/'audio_edits.json').read_text())
            save({e['id']:'keep' for e in analysis['edits'] if e['kind']=='repeat'},root/'project/cut_overrides.json')
            with patch('production.captions.transcribe',side_effect=AssertionError('ASR cache should be used')):
                restored=produce(audio,script,root/'project',online=False,assets_override=[clip,meme],
                                 sizes={'size':(640,360),'portrait_size':(360,640)})
            self.assertNotEqual(restored['delivery'],result['delivery'])
            self.assertGreater(restored['clean_duration'],result['clean_duration'])
            self.assertTrue((delivery/'long_video.mp4').is_file())

    def test_measured_waveform_and_source_cut_preview(self):
        with tempfile.TemporaryDirectory() as folder:
            file=Path(folder)/'voice.wav';signal(file,words('كلام',start=1),3)
            envelope=a.waveform(file,bins=60)
            self.assertEqual(len(envelope['peaks']),60)
            self.assertAlmostEqual(envelope['duration'],3)
            self.assertEqual(envelope['peaks'][0],0)
            self.assertGreater(max(envelope['peaks']),.1)
            cut={'start':1,'end':1.3}
            a.preview_cut(file,cut,Path(folder)/'preview.wav',context=.2)
            self.assertAlmostEqual(duration(Path(folder)/'preview.wav'),.7,places=2)

    def test_cancellation_records_cancelled_without_delivery(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);file=root/'voice.wav';signal(file,words('كلام'),2)
            cancel=threading.Event();cancel.set()
            with self.assertRaises(Cancelled):produce(file,'كلام.',root/'project',cancel=cancel)
            data=json.loads((root/'project/production.json').read_text())
            self.assertEqual(data['status'],'cancelled')
            self.assertNotIn('delivery',data)

    def test_changed_script_cannot_reuse_old_cut_decisions(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);file=root/'voice.wav';signal(file,words('كلام'),2)
            cancel=threading.Event();cancel.set()
            with self.assertRaises(Cancelled):produce(file,'كلام.',root/'project',cancel=cancel)
            with self.assertRaisesRegex(ValueError,'تغيّر'):produce(file,'سكربت مختلف.',root/'project')

    def test_unavailable_licensed_media_produces_explicit_cards(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);file=root/'voice.wav';units=words('فورتنايت تحديث مجاني.',spacing=1)
            signal(file,units,4)
            result=produce(file,'فورتنايت تحديث مجاني.',root/'project',online=False,
                           asr_override={'words':units,'segments':[]},sizes={'size':(640,360),'portrait_size':(360,640)})
            self.assertEqual(result['cards_used'],['Fortnite'])
            self.assertEqual(result['reaction_count'],0)
            self.assertTrue(any('بطاقات' in w for w in result['warnings']))
            self.assertEqual(result['status'],'ready_for_review')
