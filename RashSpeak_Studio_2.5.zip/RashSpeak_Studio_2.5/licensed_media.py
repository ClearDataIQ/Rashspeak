"""Commons metadata + bounded downloads. Ambiguous rights are not auto-approved."""
import hashlib
from pathlib import Path
import re
from urllib.parse import urlparse, unquote

import requests
from newsroom import plain
from smart_editor import import_asset, save, normalize, contains
from media_tools import Cancelled

API='https://commons.wikimedia.org/w/api.php'
HEADER={'User-Agent':'RashSpeakStudio/2.2 (source-attributed creator media lookup)'}
KNOWN=['Ghost of Tsushima','The Witcher 3','Elden Ring','Red Dead Redemption 2','Zelda BOTW','GTA 6',
       'GTA','Helldivers 2','Fortnite','Minecraft','Call of Duty','Cyberpunk 2077','Hogwarts Legacy',
       'Starfield','Assassin Creed',"Assassin's Creed Mirage",'The Last of Us','Nintendo Switch','PlayStation','Xbox','Steam',
       'SuperTuxKart','0 A.D.']


def visual_suitable(asset, visual):
    """Reject known non-gameplay search results; manual imports stay available."""
    text=normalize(unquote(' '.join(str(asset.get(k,'')) for k in ('source','title','description'))).replace('_',' '))
    if any(phrase in text for phrase in ('cosplayer','cosplay','كوسبلاي')):
        return False
    if visual=='gameplay' and any(phrase in text for phrase in (
            'behind the scenes','behind scenes','orchestra','in the studio','interview',
            'voice actor','voice acting','كواليس','مقابله','اوركسترا')):
        return False
    return True


def topics(script):
    result=[name for name in KNOWN if contains(script,name)]
    if 'GTA 6' in result and 'GTA' in result:result.remove('GTA')
    return result[:8]


def candidate(page,topic,role='clip',mood=''):
    info=(page.get('imageinfo') or [{}])[0];metadata=info.get('extmetadata',{})
    get=lambda key:plain(str(metadata.get(key,{}).get('value','')))
    license_name=get('LicenseShortName');license_url=get('LicenseUrl')
    url=info.get('url','');parsed=urlparse(url)
    if parsed.scheme!='https' or parsed.hostname!='upload.wikimedia.org' or parsed.username or parsed.password:return None
    # Only CC0, Public Domain or attribution-only CC BY. SA/NC/ND and restrictions fail closed.
    license_key=license_name.lower()
    allowed=license_key in ('cc0','cc0 1.0','public domain') or bool(re.fullmatch(r'cc by [1-4]\.0',license_key))
    if not allowed or get('Restrictions') or get('Permission') or not license_url:return None
    license_link=urlparse(license_url)
    if license_link.scheme!='https' or license_link.hostname!='creativecommons.org' or license_link.username or license_link.password or license_link.port not in (None,443):return None
    if license_key.startswith('cc by'):
        if license_link.path.rstrip('/')!=f'/licenses/by/{license_key.split()[-1]}':return None
    elif license_key.startswith('cc0'):
        if license_link.path.rstrip('/')!='/publicdomain/zero/1.0':return None
    elif license_link.path.rstrip('/') not in ('/publicdomain/mark/1.0','/publicdomain/zero/1.0'):return None
    artist=get('Artist')
    if license_key.startswith('cc by') and (not artist or normalize(artist) in ('unknown','غير معروف')):return None
    mime=info.get('mime','')
    if mime not in ('video/webm','video/ogg','video/mp4','image/jpeg','image/png','image/gif','image/webp'):return None
    if role=='meme' and not mime.startswith('video/'):return None
    if int(info.get('size',0))<=0 or int(info.get('size',0))>50_000_000 or min(info.get('width',0),info.get('height',0))<200:return None
    title=page.get('title','');description=get('ImageDescription')
    text=title+' '+description
    if role=='clip' and not contains(text,topic):return None
    if role=='clip' and not visual_suitable({'title':title,'description':description},
                                           'gameplay' if mime.startswith('video/') else 'image'):
        return None
    if role=='meme':
        if any(t in text.lower() for t in ('emoji','smiley','cartoon','virtual','child','baby','animal','bird','kookaburra')):return None
        if not any(x in text.lower() for x in {'humor':['laugh','laughter'],'surprise':['surprise','surprised'],'frustration':['frustrat','disappoint']}.get(mood,[])):return None
    source=info.get('descriptionurl','')
    source_link=urlparse(source)
    if source_link.scheme!='https' or source_link.hostname!='commons.wikimedia.org' or source_link.username or source_link.password or source_link.port not in (None,443):return None
    return {'provider':'Wikimedia Commons','title':title,'url':url,'source':source,'license':license_name,
            'license_url':license_url,'author':artist,'credit':get('Credit'),'mime':mime,'size':info['size'],
            'topic':topic,'role':role,'mood':mood,'retrieved_metadata':metadata}


def search(topic,role='clip',mood='',cancel=None,images=False,hint=''):
    query=f'"{topic}"'+(' '+hint if hint else '')+(' filetype:bitmap' if images else ' filetype:video')
    params={'action':'query','generator':'search','gsrsearch':query,'gsrnamespace':6,'gsrlimit':6,
            'prop':'imageinfo','iiprop':'url|mime|size|extmetadata','format':'json'}
    if cancel and cancel.is_set():raise Cancelled('أُلغي البحث عن الوسائط.')
    response=requests.get(API,params=params,headers=HEADER,timeout=(8,18),allow_redirects=False)
    if response.status_code!=200:raise RuntimeError('مصدر الوسائط غير متاح: '+str(response.status_code))
    if len(response.content)>2_000_000:raise ValueError('بيانات المصدر أكبر من الحد.')
    data=response.json()
    if 'error' in data:raise RuntimeError('المصدر رفض البحث.')
    results=[]
    for page in sorted(data.get('query',{}).get('pages',{}).values(),key=lambda p:p.get('index',99)):
        item=candidate(page,topic,role,mood)
        if item:results.append(item)
    return results


def download(item,folder,cancel=None):
    parsed=urlparse(item['url'])
    if parsed.scheme!='https' or parsed.hostname!='upload.wikimedia.org' or parsed.username or parsed.password or parsed.port not in (None,443):
        raise ValueError('رابط تنزيل غير معتمد.')
    folder=Path(folder).resolve();folder.mkdir(parents=True,exist_ok=True)
    suffix={'video/ogg':'.ogv','video/webm':'.webm','video/mp4':'.mp4','image/jpeg':'.jpg',
            'image/png':'.png','image/gif':'.gif','image/webp':'.webp'}[item['mime']]
    file=folder/(hashlib.sha256(item['source'].encode()).hexdigest()[:20]+suffix)
    evidence=file.with_suffix('.rights.json')
    if file.exists() and evidence.exists():
        import json
        old=json.loads(evidence.read_text(encoding='utf-8'))
        if all(old.get(k)==item.get(k) for k in ('source','url','author','license','license_url','size')) and old.get('sha256')==hashlib.sha256(file.read_bytes()).hexdigest():return file
    pending=file.with_suffix(file.suffix+'.pending');total=0;sha=hashlib.sha256()
    try:
        with requests.get(item['url'],headers=HEADER,timeout=(8,25),allow_redirects=False,stream=True) as response:
            if response.status_code!=200:raise RuntimeError('تعذر تنزيل الأصل المرخص.')
            with pending.open('wb') as dest:
                for block in response.iter_content(65536):
                    if cancel and cancel.is_set():raise Cancelled('أُلغي تنزيل الوسائط.')
                    total+=len(block)
                    if total>50_000_000:raise ValueError('الملف يتجاوز حد التنزيل.')
                    dest.write(block);sha.update(block)
        if total!=int(item['size']):raise ValueError('حجم الملف تغيّر عن بيانات الرخصة؛ أعد البحث.')
        pending.replace(file)
        save({**item,'sha256':sha.hexdigest()},evidence)
        return file
    finally:
        pending.unlink(missing_ok=True)


def gather(script,folder,logger=print,cancel=None,reactions=True,semantic=None):
    """Search topic names only; never transmit recording or full private script."""
    assets=[];warnings=[];credits=[]
    requests_to_make=[(topic,'clip','') for topic in topics(script)[:5]]
    hints={}
    for row in (semantic or {}).get('segments',[]):
        if row['confidence']>=.75 and row['game'] and contains(script,row['game']) and row['queries']:
            hints.setdefault(row['game'],row['queries'][0])
    if reactions:
        from smart_editor import REACTIONS
        for mood,terms in REACTIONS.items():
            if any(contains(script,t) for t in terms):
                requests_to_make.append(({'humor':'laughing man','surprise':'surprised man','frustration':'frustrated man'}[mood],'meme',mood))
    for topic,role,mood in requests_to_make:
        if cancel and cancel.is_set():raise Cancelled('أُلغي جمع الوسائط.')
        logger('بحث مرخص: '+topic)
        found=False
        try:
            from media_library import for_topic,remember
            has_specific_query=any(contains(k,topic) or contains(topic,k) for k in hints)
            reused=for_topic(topic) if role=='clip' and not has_specific_query else []
            if reused:
                for asset in reused[:2]:
                    asset.setdefault('role','clip');asset.setdefault('width',640);asset.setdefault('height',360)
                    assets.append(asset)
                    if asset.get('rights'):credits.append(asset['rights'])
                continue
            hint=next((v for k,v in hints.items() if contains(k,topic) or contains(topic,k)),'') if role=='clip' else ''
            items=search(topic,role,mood,cancel,hint=hint) if hint else search(topic,role,mood,cancel)
            if not items and role=='clip':items=search(topic,role,mood,cancel,images=True,hint=hint) if hint else search(topic,role,mood,cancel,images=True)
            for item in items[:2]:
                file=download(item,folder,cancel)
                asset=import_asset(file,role=role,game=topic if role=='clip' else '',tags=[topic],mood=mood,
                                   license=item['license'],source=item['source'],approved=True,
                                   previews=Path(folder)/'previews',cancel=cancel)
                asset['rights']={k:item[k] for k in ('provider','author','source','license','license_url','credit')}
                asset.update(title=item['title'],description=plain(str(item['retrieved_metadata'].get('ImageDescription',{}).get('value',''))))
                asset=remember(asset,cancel=cancel)
                assets.append(asset);credits.append(asset['rights']);found=True
        except (requests.RequestException,RuntimeError,ValueError) as exc:
            if isinstance(exc,Cancelled):raise
            warnings.append(topic+': '+str(exc)[:180])
        if not found:warnings.append(topic+': لا أصل مناسب واضح الرخصة؛ لن تُستخدم لقطات غير موثقة.')
    return {'assets':assets,'credits':credits,'warnings':warnings}


def credits_text(credits):
    rows=['مصادر الوسائط المستخدمة — احتفظ بالنسب عند النشر','']
    seen=set()
    for c in credits:
        if c['source'] in seen:continue
        seen.add(c['source'])
        rows += [c.get('author') or c.get('provider',''),'المصدر: '+c['source'],
                 'الرخصة: '+c['license']+' '+c['license_url'],'التعديل: قص وتحجيم وكتم صوت الأصل وتركيب ضمن الحلقة.','']
    return '\n'.join(rows)
