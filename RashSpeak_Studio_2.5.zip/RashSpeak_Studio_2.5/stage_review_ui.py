"""Owner edits structured phase decisions; edits require a fresh real preview."""
import copy
from pathlib import Path
import queue
import threading
import textwrap
import tkinter as tk
from tkinter import ttk, filedialog

from rtl_ui import Label, Button, Treeview, visual, dialogs as messagebox
from smart_editor import import_asset, fingerprint, save
from media_tools import duration
from sound_effects import TYPES

BG='#0b1220';CARD='#132138';TEXT='#eef5ff';MUTED='#91a9c4';CYAN='#08BEED'
SCHEMAS={
    'words':[('start','البداية',float),('end','النهاية',float),('text','الكلمة',str)],
    'edits':[('start','البداية',float),('end','النهاية',float),('action','القرار',('keep','remove')),('text','الكلام',str)],
    'shots':[('start','البداية',float),('end','النهاية',float),('asset_id','اللقطة','asset'),('source_offset','البداية من الأصل',float),('transition','الوصلة',('cut','fade'))],
    'effects':[('timestamp','التوقيت',float),('type','المؤثر','effect'),('duration','المدة',float),('gain_db','المستوى dB',float),('approved','مفعّل',bool)],
    'memes':[('timestamp','التوقيت',float),('asset_id','الأصل','asset'),('duration','المدة',float),('approved','مفعّل',bool)],
    'shorts':[('start','البداية',float),('end','النهاية',float),('approved','تصديره',bool)],
    'segments':[('start','البداية',float),('end','النهاية',float),('text','الترجمة',str),('mode','السياق',('auto','factual','sensitive','crucial','cta','humor','frustration','surprise'))],
}
LABELS={'words':'الكلمات والتوقيت','edits':'قرارات القص','shots':'اللقطات على الكلام','effects':'المؤثرات الصوتية',
        'memes':'الميمز الاختيارية','shorts':'الشورتات','segments':'الترجمة والسياق'}
HELP={
    'audio':'اسمع الأصل والمنظف. توقيت القص على الأصل؛ باقي المراحل على الصوت المنظف. تعديل الكلمات يعيد تحليل المحاولات؛ اختر بعدها القص المناسب.',
    'media':'شاهد مطابقة اللقطة للكلام. بدّل الأصل وعدّل التوقيت وبداية اللقطة؛ يجب تغطية الصوت دون فجوات. البطاقة تعني نقص لقطات مناسبة.',
    'effects':'اسمع المؤثرات مع صوتك. فعّل أو عطّل، بدّل النوع، حرّك التوقيت وخفّض المستوى. لا موسيقى ولا مؤثر فوق معلومة مهمة.',
    'reactions':'الميمز اختيارية. اتركها فارغة إن لم تخدم المعنى، أو أضف أصلًا تملك حقه وعدّل التوقيت. لا تُضاف وجوه عشوائية.',
    'montage':'شاهد الطويل وكل شورت. عدّل النطاقات والترجمة؛ حافظ على اكتمال الفكرة. الإيقاع يتكيف مع الكلام والموضوع، وليس توقيت المقاطع المرجعية.',
    'delivery':'هذه ملفات للرفع بنفسك. عدّل العنوان والوصف، وراجع مصادر الوسائط. لا ثامنيل ولا رفع تلقائي.'}


class StageReviewPanel(tk.Frame):
    def __init__(self,parent,request,submit,open_file,cancel):
        super().__init__(parent,bg=BG,padx=14,pady=12)
        self.request=request;self.data=copy.deepcopy(request['data']);self.submit=submit;self.open_file=open_file;self.cancel=cancel
        self.dirty=False;self.sent=False;self.importing=False;self.events=queue.Queue();self.poll=None
        self.trees={};self.collections={};self.controls={}
        self.columnconfigure(0,weight=1);self.rowconfigure(3,weight=1)
        Label(self,text='مراجعة: '+request['label'],bg=BG,fg=TEXT,font=('Segoe UI',20,'bold'),anchor='e').grid(row=0,column=0,sticky='ew')
        Label(self,text=HELP[request['key']],bg=BG,fg=MUTED,font=('Segoe UI',10),wraplength=1000,justify='right',anchor='e').grid(row=1,column=0,sticky='ew',pady=6)
        previews=tk.Frame(self,bg=BG);previews.grid(row=2,column=0,sticky='ew',pady=5)
        for item in request['previews']:
            self.button(previews,item['label'],lambda path=item['path']:open_file(path)).pack(side='right',padx=3)
        book=ttk.Notebook(self);book.grid(row=3,column=0,sticky='nsew',pady=6)
        if request['key']=='delivery':
            tab=tk.Frame(book,bg=CARD,padx=14,pady=10);book.add(tab,text=visual('بيانات الملفات'))
            for key,label,height in [('title','عنوان المقطع',1),('description','الوصف',6)]:
                Label(tab,text=label,bg=CARD,fg=CYAN).pack(anchor='e')
                editor=tk.Text(tab,height=height,wrap='word',font=('Segoe UI',11));editor.insert('1.0',self.data[key]);editor.pack(fill='both',expand=key=='description',pady=5)
                editor.bind('<KeyRelease>',lambda e:self.changed());self.controls[key]=editor
            self.button(tab,'افتح ملف النسب',lambda:open_file(Path(request['work'])/'delivery_credits.txt')).pack(anchor='e')
        else:
            for collection in SCHEMAS:
                if collection in self.data:self.add_table(book,collection)
            settings=tk.Frame(book,bg=CARD,padx=14,pady=12)
            if request['key']=='audio':
                book.add(settings,text=visual('معالجة الصوت'))
                for key,label in [('highpass','مرشح الصوت (0 لإيقافه)'),('noise_floor','تخفيف الضوضاء dB'),('loudness','الجهارة المستهدفة LUFS')]:
                    Label(settings,text=label,bg=CARD,fg=TEXT).pack(anchor='e')
                    var=tk.StringVar(value=str(self.data['processing'][key]));entry=ttk.Entry(settings,textvariable=var);entry.pack(fill='x',pady=5)
                    var.trace_add('write',lambda *a:self.changed());self.controls[key]=var
                var=tk.BooleanVar(value=self.data['processing']['denoise']);ttk.Checkbutton(settings,text=visual('تخفيف الضوضاء'),variable=var,command=self.changed).pack(anchor='e');self.controls['denoise']=var
            if request['key']=='montage':
                book.add(settings,text=visual('عرض الترجمة'))
                for key,label,choices in [('style','نمط الترجمة',('gaming','cinematic')),('font','اسم الخط',None)]:
                    Label(settings,text=label,bg=CARD,fg=TEXT).pack(anchor='e')
                    var=tk.StringVar(value=self.data['caption'][key]);self.controls[key]=var
                    if choices:ttk.Combobox(settings,textvariable=var,values=choices,state='readonly').pack(fill='x',pady=5)
                    else:ttk.Entry(settings,textvariable=var).pack(fill='x',pady=5)
                    var.trace_add('write',lambda *a:self.changed())
        if request.get('script'):
            script_tab=tk.Frame(book,bg=CARD,padx=10,pady=10);book.add(script_tab,text=visual('السكربت للمقارنة'))
            script_box=tk.Text(script_tab,wrap='none',font=('Segoe UI',11),bg=BG,fg=TEXT)
            script_box.tag_configure('rtl',justify='right')
            lines=[visual(part) for line in request['script'].split('\n') for part in (textwrap.wrap(line,width=65,break_long_words=False) or [''])]
            script_box.insert('1.0','\n'.join(lines),'rtl');script_box.configure(state='disabled');script_box.pack(fill='both',expand=True)
        if self.data.get('semantic'):
            tab=tk.Frame(book,bg=CARD,padx=10,pady=10);book.add(tab,text='Gemini')
            columns=('game','event','idea','tone','visual','meme','effect','confidence')
            tree=Treeview(tab,columns=columns,show='headings',height=10)
            labels=('اللعبة','الحدث','الفكرة','النبرة','الصورة','ميم','مؤثر','الثقة')
            for key,label in zip(columns,labels):tree.heading(key,text=label);tree.column(key,width=120)
            for row in self.data['semantic']['segments']:tree.insert('','end',values=[row[k] for k in columns])
            tree.pack(fill='both',expand=True)
            Label(tab,text='اقتراح Gemini من النص والتوقيت. عدّل النبرة في جدول السياق، وراجع اللقطات والمؤثرات في معايناتها.',bg=CARD,fg=MUTED,wraplength=900).pack(fill='x',pady=6)
        self.status=tk.StringVar(value=request.get('error') or 'شاهد أو اسمع الناتج، ثم اعتمد المرحلة أو عدّل وأعد المعاينة.')
        Label(self,textvariable=self.status,bg=BG,fg='#FFD24C',wraplength=1000,anchor='e',justify='right').grid(row=4,column=0,sticky='ew',pady=5)
        bar=tk.Frame(self,bg=BG);bar.grid(row=5,column=0,sticky='ew')
        self.approve_button=self.button(bar,'مناسبة — اعتمد وانتقل',self.approve,primary=True);self.approve_button.pack(side='right',padx=4)
        self.button(bar,'طبّق التعديلات وأعد المعاينة',self.revise).pack(side='right',padx=4)
        self.button(bar,'تراجع عن التعديلات',self.revert).pack(side='right',padx=4)
        self.button(bar,'إيقاف وحفظ المراجعة',self.stop).pack(side='left')
        if request.get('error'):self.approve_button.configure(state='disabled')
        self.poll=self.after(80,self.drain);self.bind('<Destroy>',self.close,add='+')

    def button(self,parent,label,fn,primary=False):
        return Button(parent,text=label,command=fn,bg=CYAN if primary else '#223b58',fg='#071322' if primary else TEXT,
                      relief='flat',font=('Segoe UI',10,'bold'),padx=10,pady=7)

    def changed(self):
        self.dirty=True;self.approve_button.configure(state='disabled')
        self.status.set('تعديلات غير معاينة؛ طبّقها وشاهد النسخة الجديدة قبل الاعتماد.')

    def asset_label(self,asset_id):
        a=next((a for a in self.data.get('assets',[]) if a['id']==asset_id),None)
        return (a.get('game') or a.get('mood') or '')+' / '+Path(a['path']).name if a else asset_id

    def add_table(self,book,key):
        tab=tk.Frame(book,bg=CARD,padx=8,pady=8);book.add(tab,text=visual(LABELS[key]));tab.rowconfigure(0,weight=1);tab.columnconfigure(0,weight=1)
        fields=SCHEMAS[key];columns=[f[0] for f in fields]+['reason']
        tree=Treeview(tab,columns=columns,show='headings',selectmode='browse');self.trees[key]=tree
        scroll=ttk.Scrollbar(tab,orient='vertical',command=tree.yview);tree.configure(yscrollcommand=scroll.set)
        tree.grid(row=0,column=0,sticky='nsew');scroll.grid(row=0,column=1,sticky='ns')
        for field,label,kind in fields:tree.heading(field,text=label);tree.column(field,width=100 if field!='text' else 250,stretch=True)
        tree.heading('reason',text='سبب الاقتراح / الثقة');tree.column('reason',width=260)
        row=tk.Frame(tab,bg=CARD);row.grid(row=1,column=0,columnspan=2,sticky='ew',pady=5)
        self.button(row,'عدّل المحدد',lambda:self.edit_row(key)).pack(side='right',padx=3)
        if key!='words':
            self.button(row,'أضف',lambda:self.edit_row(key,add=True)).pack(side='right',padx=3)
            self.button(row,'احذف المحدد',lambda:self.remove_row(key)).pack(side='right',padx=3)
        if key=='edits':
            self.button(row,'استرجع المحدد',lambda:self.set_cut('keep')).pack(side='right',padx=3)
            self.button(row,'احذف المحدد من الصوت',lambda:self.set_cut('remove')).pack(side='right',padx=3)
        if key in ('shots','memes','effects'):self.button(row,'أضف أصلًا محليًا مرخصًا',lambda:self.import_local(key)).pack(side='left')
        if key in ('memes','effects'):self.button(row,'عطّل الكل',lambda:self.disable_all(key)).pack(side='right',padx=3)
        self.populate(key)

    def populate(self,key):
        tree=self.trees[key];tree.delete(*tree.get_children())
        for i,item in enumerate(self.data[key]):
            vals=[]
            for field,label,kind in SCHEMAS[key]:
                value=item.get(field,False if kind is bool else '')
                if field=='asset_id':value=self.asset_label(value)
                elif field=='type':value=TYPES.get(value,'مؤثر محلي')
                elif kind is bool:value='نعم' if value else 'لا'
                elif field=='action':value='احتفاظ' if value=='keep' else 'حذف'
                vals.append(value)
            confidence=item.get('confidence',item.get('probability'))
            vals.append(item.get('reason','')+(' • '+str(round(confidence,2)) if confidence is not None else ''))
            tree.insert('','end',iid=str(i),values=vals)

    def set_cut(self,action):
        tree=self.trees['edits']
        if tree.selection():self.data['edits'][int(tree.selection()[0])]['action']=action;self.populate('edits');self.changed()

    def disable_all(self,key):
        for item in self.data[key]:item['approved']=False
        self.populate(key);self.changed()

    def remove_row(self,key):
        tree=self.trees[key]
        if tree.selection():self.data[key].pop(int(tree.selection()[0]));self.populate(key);self.changed()

    def edit_row(self,key,add=False):
        if self.sent:return
        tree=self.trees[key]
        if not add and not tree.selection():return
        index=len(self.data[key]) if add else int(tree.selection()[0])
        item=copy.deepcopy(self.data[key][index]) if not add else {}
        window=tk.Toplevel(self);window.title(visual('تعديل '+LABELS[key]));window.transient(self.winfo_toplevel());window.grab_set();window.configure(bg=CARD)
        fields={}
        for row,(field,label,kind) in enumerate(SCHEMAS[key]):
            Label(window,text=label,bg=CARD,fg=TEXT).grid(row=row,column=1,padx=10,pady=6,sticky='e')
            if kind=='asset':
                role='meme' if key=='memes' else 'clip';assets=[a for a in self.data.get('assets',[]) if a['role']==role]
                choices={self.asset_label(a['id']):a['id'] for a in assets}
                var=tk.StringVar(value=self.asset_label(item.get(field,'')));widget=ttk.Combobox(window,textvariable=var,values=list(choices),state='readonly')
                fields[field]=(var,kind,choices)
            elif kind=='effect':
                choices={TYPES[k]:k for k in self.data.get('library',{})}
                if item.get('type')=='custom':choices['مؤثر محلي']='custom'
                var=tk.StringVar(value=next((label for label,k in choices.items() if k==item.get('type')),''));widget=ttk.Combobox(window,textvariable=var,values=list(choices),state='readonly');fields[field]=(var,kind,choices)
            elif kind is bool:
                var=tk.BooleanVar(value=item.get(field,True));widget=ttk.Checkbutton(window,variable=var);fields[field]=(var,kind,None)
            else:
                default=item.get(field,0 if kind is float else kind[0] if isinstance(kind,tuple) else '')
                var=tk.StringVar(value=str(default));widget=ttk.Combobox(window,textvariable=var,values=kind,state='readonly') if isinstance(kind,tuple) else ttk.Entry(window,textvariable=var,width=45)
                fields[field]=(var,kind,None)
            widget.grid(row=row,column=0,padx=10,pady=6,sticky='ew')
        def apply():
            try:
                for field,(var,kind,choices) in fields.items():
                    value=var.get()
                    if choices:value=choices[value]
                    elif kind is float:value=float(value)
                    item[field]=value
                if key=='effects':
                    if item['type']!='custom':item.update({k:v for k,v in self.data['library'][item['type']].items() if k!='duration'})
                    if add:item['id']='manual_'+str(index)+'_'+str(item['timestamp'])
                    item['reason']='حدده صاحب المقطع'
                if key=='edits' and add:item.update(id='manual_cut_'+str(index)+'_'+str(item['start']),kind='manual',manual=True,confidence=1,reason='قص حدده صاحب المقطع')
                if key=='memes' and add:item.update(region=[.04,.09,.22,.22],confidence=1,reason='حدده صاحب المقطع')
                if key=='shots' and add:item.update(confidence=1,manual=True,reason='حدده صاحب المقطع',topic='')
                if key=='shorts' and add:item.update(score=0,reason='نطاق راجعه صاحب المقطع',manual_context_reviewed=True)
                if key=='words':self.data['reanalyse']=True
                if add:self.data[key].append(item)
                else:self.data[key][index]=item
                self.populate(key);self.changed();window.destroy()
            except (ValueError,KeyError) as exc:messagebox.showerror('البيانات','أدخل قيمًا صحيحة واختر الأصل: '+str(exc),parent=window)
        self.button(window,'احفظ التعديل',apply,True).grid(row=len(fields),column=0,columnspan=2,pady=12)

    def import_local(self,key):
        if self.importing:return
        types=[('Audio','*.wav *.mp3 *.flac *.ogg *.m4a')] if key=='effects' else [('Media','*.mp4 *.mov *.webm *.ogv *.png *.jpg *.gif *.webp')]
        file=filedialog.askopenfilename(filetypes=types)
        if not file:return
        from tkinter import simpledialog
        license=simpledialog.askstring(visual('رخصة الأصل'),visual('اكتب الرخصة أو «ملكي» إن كنت تملك حقوقه:'),parent=self)
        if not license:return
        if not messagebox.askyesno('حق الاستخدام','هل تملك حق استخدام هذا الأصل وتوافق على إضافته؟',parent=self):return
        mood='humor'
        if key=='memes':
            mood=simpledialog.askstring('Mood',visual('humor أو surprise أو frustration'),parent=self)
            if mood not in ('humor','surprise','frustration'):return
        self.importing=True;self.approve_button.configure(state='disabled');self.status.set('جاري قراءة الأصل المحلي…')
        def work():
            try:
                if key=='effects':
                    item={'id':'local_'+Path(file).stem,'type':'custom','path':str(Path(file).resolve()),'fingerprint':fingerprint(file),
                          'timestamp':0,'duration':min(1.2,duration(file,'audio')),'gain_db':-20,'approved':True,
                          'license':license,'source':'Owner supplied: '+Path(file).name,'usage_approved':True,'reason':'حدده صاحب المقطع'}
                else:item=import_asset(file,role='meme' if key=='memes' else 'clip',license=license,source='Owner supplied: '+Path(file).name,approved=True,mood=mood if key=='memes' else '',cancel=self.cancel)
                self.events.put(('imported',key,item))
            except Exception as exc:self.events.put(('error',str(exc)))
        threading.Thread(target=work,daemon=True).start()

    def drain(self):
        while not self.events.empty():
            event=self.events.get();self.importing=False
            if event[0]=='imported':
                _,key,item=event
                if key=='effects':self.data['effects'].append(item);self.populate('effects')
                else:
                    index=next((i for i,a in enumerate(self.data['assets']) if a['id']==item['id']),None)
                    if index is None:self.data['assets'].append(item)
                    else:self.data['assets'][index]=item
                    self.status.set('الأصل جاهز. أضف لقطة أو ميمًا واختَره من قائمة الأصول.')
                self.changed()
            else:self.status.set(event[1])
        self.poll=self.after(80,self.drain)

    def collect(self):
        data=copy.deepcopy(self.data);key=self.request['key']
        if key=='audio':
            for name,var in self.controls.items():data['processing'][name]=var.get() if name=='denoise' else float(var.get())
        elif key=='montage':
            for name,var in self.controls.items():data['caption'][name]=var.get()
        elif key=='delivery':
            for name,editor in self.controls.items():data[name]=editor.get('1.0','end').strip()
        return data

    def approve(self):
        if self.dirty or self.importing or self.request.get('error') or self.sent:return
        self.sent=True;self.submit({'action':'approve'});self.lock_controls()

    def revise(self):
        if self.importing or self.sent:return
        try:data=self.collect()
        except ValueError:messagebox.showerror('معالجة الصوت','أدخل إعدادات رقمية صحيحة.',parent=self);return
        self.sent=True;self.submit({'action':'revise','data':data});self.lock_controls()
        self.status.set('تُعاد المعالجة والمعاينة؛ المرحلة التالية ما زالت متوقفة.')

    def lock_controls(self):
        def walk(widget):
            for child in widget.winfo_children():
                if isinstance(child,(Button,ttk.Entry,ttk.Combobox,ttk.Checkbutton,tk.Text)):child.configure(state='disabled')
                walk(child)
        walk(self)

    def revert(self):
        if self.sent:return
        self.sent=True;self.submit({'action':'revise','data':copy.deepcopy(self.request['last_good'])});self.lock_controls()

    def stop(self):
        if self.request.get('draft_path'):
            try:data=self.collect()
            except ValueError:
                data=copy.deepcopy(self.data)
                if self.request['key']=='audio':
                    for name,var in self.controls.items():data['processing'][name]=var.get()
            save({'dependency':self.request['dependency'],'data':data},self.request['draft_path'])
        self.cancel.set();self.submit({'action':'cancel'})

    def close(self,event):
        if event.widget is self and self.poll:self.after_cancel(self.poll);self.poll=None
