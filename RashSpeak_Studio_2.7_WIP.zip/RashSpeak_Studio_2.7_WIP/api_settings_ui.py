"""One visible settings window for independent YouTube and Gemini keys."""
import queue
import threading
import tkinter as tk
from tkinter import ttk

import api_connections
from gemini_client import settings,save_settings,validate_settings
from rtl_ui import Label,Button,visual

BG='#0b1220';CARD='#132138';TEXT='#eef5ff';MUTED='#91a9c4';CYAN='#08BEED'


class ApiPanel(tk.Frame):
    def __init__(self,parent,provider):
        super().__init__(parent,bg=BG)
        self.canvas=tk.Canvas(self,bg=BG,highlightthickness=0)
        scrollbar=ttk.Scrollbar(self,orient='vertical',command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side='right',fill='y');self.canvas.pack(side='left',fill='both',expand=True)
        form=tk.Frame(self.canvas,bg=BG,padx=16,pady=14);self.form=form
        item=self.canvas.create_window((0,0),window=form,anchor='nw')
        form.bind('<Configure>',lambda event:self.canvas.configure(scrollregion=self.canvas.bbox('all')))
        self.canvas.bind('<Configure>',lambda event:self.canvas.itemconfigure(item,width=event.width))
        self.provider=provider;self.closed=False;self.busy=False;self.timer=None
        style=ttk.Style(self)
        style.configure('RashApi.TEntry',fieldbackground=CARD,foreground=TEXT,insertcolor=TEXT)
        style.configure('RashApi.TCombobox',fieldbackground=CARD,foreground=TEXT,arrowcolor=CYAN)
        style.map('RashApi.TCombobox',fieldbackground=[('disabled',CARD),('readonly',CARD)],foreground=[('disabled',MUTED)])
        style.configure('RashApi.TCheckbutton',background=BG,foreground=TEXT)
        style.map('RashApi.TCheckbutton',background=[('active',BG)],foreground=[('disabled',MUTED)])
        style.configure('RashApi.TCheckbutton',font=('Segoe UI',10))
        style.layout('RashApi.TCheckbutton',[('Checkbutton.padding',{'sticky':'nswe','children':[
            ('Checkbutton.indicator',{'side':'right','sticky':''}),('Checkbutton.focus',{'side':'right','sticky':'w',
            'children':[('Checkbutton.label',{'sticky':'nswe'})]})]})])
        self.cancel=threading.Event();self.events=queue.Queue()
        self.key=tk.StringVar();self.remember=tk.BooleanVar(value=False);self.reveal=tk.BooleanVar(value=False)
        title='YouTube Data API' if provider=='youtube' else 'مزوّد فهم المحتوى'
        Label(form,text=title,bg=BG,fg=CYAN,font=('Segoe UI',17,'bold')).pack(anchor='e',pady=(0,10))
        help_text=('للبحث عن الفيديوهات داخل القنوات الرسمية. المفتاح لا يمنح تصريح استخدام أو تنزيل الفيديو.'
                   if provider=='youtube' else
                   'لتحليل النص والتوقيت واختيار مشاهد حقيقية ومساعد التحرير. يبقى التسجيل محليًا؛ قد تُرسل وسائط المصادر للتحليل.')
        Label(form,text=help_text,bg=BG,fg=MUTED,wraplength=660,justify='right').pack(fill='x',pady=6)
        Label(form,text='ألصق مفتاح هذه الخدمة',bg=BG,fg=TEXT).pack(anchor='e',pady=(12,4))
        self.entry=ttk.Entry(form,textvariable=self.key,show='•',justify='left',font=('Consolas',11),style='RashApi.TEntry');self.entry.pack(fill='x',pady=5)
        self.show=ttk.Checkbutton(form,text=visual('إظهار المفتاح'),variable=self.reveal,style='RashApi.TCheckbutton',
                                  command=lambda:self.entry.configure(show='' if self.reveal.get() else '•'))
        self.show.pack(anchor='e',pady=3)
        self.persist=ttk.Checkbutton(form,text=visual('حفظ في خزنة النظام للاستخدام بعد إغلاق البرنامج'),variable=self.remember,style='RashApi.TCheckbutton')
        self.persist.pack(anchor='e',pady=6)
        Label(form,text='الحقل الفارغ يحافظ على المفتاح الموجود. الحفظ غير مفعّل افتراضيًا؛ يُستخدم المفتاح للجلسة الحالية.',
              bg=BG,fg=MUTED,wraplength=660,justify='right').pack(fill='x',pady=6)
        self.model=None;self.combo=None;self.ai_provider=None;self.base_url=None;self.media_buttons=[];self.resume_button=None
        if provider=='gemini':
            cfg=settings();self.model=tk.StringVar(value=cfg['model']);self.enabled=tk.BooleanVar(value=cfg['enabled'])
            self.ai_provider=tk.StringVar(value=cfg['provider']);self.base_url=tk.StringVar(value=cfg['base_url'])
            Label(form,text='المزوّد — اختر جهة إصدار المفتاح، لا اسم النموذج',bg=BG,fg=TEXT).pack(anchor='e')
            self.provider_combo=ttk.Combobox(form,textvariable=self.ai_provider,values=['google','openrouter'],state='readonly',style='RashApi.TCombobox')
            self.provider_combo.pack(fill='x',pady=4);self.provider_combo.bind('<<ComboboxSelected>>',self.provider_changed)
            Label(form,text='google: Google مباشرة | openrouter: بوابة OpenRouter — مفاتيح منفصلة',bg=BG,fg=MUTED).pack(anchor='e')
            self.endpoint_entry=ttk.Entry(form,textvariable=self.base_url,state='readonly',justify='left',style='RashApi.TEntry');self.endpoint_entry.pack(fill='x',pady=4)
            self.enable=ttk.Checkbutton(form,text=visual('تفعيل فهم المحتوى في الإنتاج'),variable=self.enabled,style='RashApi.TCheckbutton')
            self.enable.pack(anchor='e',pady=5)
            Label(form,text='النموذج',bg=BG,fg=TEXT).pack(anchor='e')
            self.combo=ttk.Combobox(form,textvariable=self.model,values=[cfg['model']],style='RashApi.TCombobox')
            self.combo.pack(fill='x',pady=5)
        row=tk.Frame(form,bg=BG);row.pack(fill='x',pady=14)
        self.save_button=Button(row,text='حفظ إعداد الخدمة',command=self.save,bg='#223b58',fg=TEXT,relief='flat',padx=12,pady=8)
        self.save_button.pack(side='right',padx=4)
        self.test_button=Button(row,text='اختبار الاتصال',command=self.test,bg=CYAN,fg=BG,relief='flat',padx=12,pady=8)
        self.test_button.pack(side='right',padx=4)
        self.generation_button=None
        if provider=='gemini':
            self.generation_button=Button(row,text='اختبار تحليل فعلي',command=lambda:self.test(generation=True),bg='#223b58',fg=TEXT,relief='flat',padx=12,pady=8)
            self.generation_button.pack(side='right',padx=4)
            Label(form,text='اختبار التحليل يرسل نصًا تجريبيًا قصيرًا فقط ويستهلك طلب API؛ لا يرسل تسجيلك أو مشروعك.',bg=BG,fg=MUTED,wraplength=660,justify='right').pack(fill='x')
            probes=tk.Frame(form,bg=BG);probes.pack(fill='x',pady=5)
            for kind,label in (('image','اختبار صورة'),('video','اختبار فيديو')):
                b=Button(probes,text=label,command=lambda k=kind:self.test(media=k),bg='#223b58',fg=TEXT,relief='flat',padx=12,pady=7)
                b.pack(side='right',padx=3);self.media_buttons.append(b)
            self.resume_button=Button(probes,text='استئناف الطلبات',command=self.resume_requests,bg='#223b58',fg=TEXT,relief='flat',padx=12,pady=7);self.resume_button.pack(side='right',padx=3)
            Label(form,text='الصورة والفيديو اصطناعيان للاختبار فقط. لا ترسل هذه الأزرار تسجيلك. نجاح القائمة لا يثبت دعم الوسائط أو مجانية حساب Google.',bg=BG,fg=MUTED,wraplength=660,justify='right').pack(fill='x')
        self.status=tk.StringVar(value='مفتاح متاح؛ يمكنك فحصه أو استبداله.' if api_connections.current_key(provider) else 'لم يُضف مفتاح لهذه الخدمة بعد.')
        Label(form,textvariable=self.status,bg=BG,fg=TEXT,wraplength=660,justify='right').pack(fill='x',pady=8)
        self.bind('<Destroy>',self.destroyed,add='+')

    def save(self):
        if self.busy:return
        try:
            cfg=self.ai_config()if self.model else None
            if cfg:validate_settings(cfg)
            changed=api_connections.configure(self.ai_provider.get()if self.ai_provider else self.provider,self.key.get(),self.remember.get())
            if cfg:save_settings(cfg)
            self.key.set('');self.reveal.set(False);self.entry.configure(show='•')
            if changed:self.status.set('حُفظ المفتاح في خزنة النظام.' if self.remember.get() else 'تم استخدام المفتاح لهذه الجلسة. اختبر الاتصال للتحقق منه.')
            else:self.status.set('بقي المفتاح الموجود؛ حُفظت إعدادات الخدمة.')
        except (ValueError,OSError):self.status.set('تعذر الحفظ؛ راجع المفتاح والنموذج وإتاحة خزنة النظام. استخدم إعداد الجلسة إن تعذر الحفظ الدائم.')

    def ai_config(self):
        return {'enabled':self.enabled.get(),'model':self.model.get(),'provider':self.ai_provider.get(),'base_url':self.base_url.get()}

    def provider_changed(self,event=None):
        from ai_runtime import endpoint
        self.key.set('');self.reveal.set(False);self.entry.configure(show='•');self.remember.set(False)
        self.base_url.set(endpoint(self.ai_provider.get()));self.model.set('');self.combo['values']=[]
        self.status.set('اختر نموذجًا من «اختبار الاتصال». لن يُنقل مفتاح المزوّد السابق إلى هذا المزوّد.')

    def resume_requests(self):
        if self.busy:return
        from ai_runtime import resume
        key=api_connections.validate_key(self.key.get())or api_connections.current_key(self.ai_provider.get())
        if not key:self.status.set('لا يوجد مفتاح لهذا المزوّد.');return
        resume(self.ai_provider.get(),key)
        self.status.set('رُفع توقف الحصة محليًا. اختبر التحليل مرة واحدة بعد تجدد الحصة؛ هذا الزر لا يزيد حصة الخدمة.')

    def set_busy(self,value):
        self.busy=value;state='disabled' if value else 'normal'
        for widget in (self.entry,self.save_button,self.test_button,self.show,self.persist):widget.configure(state=state)
        if self.generation_button:self.generation_button.configure(state=state)
        if self.combo:self.combo.configure(state=state);self.enable.configure(state=state)
        for widget in self.media_buttons:widget.configure(state=state)
        if self.resume_button:self.resume_button.configure(state=state)
        if self.ai_provider:self.provider_combo.configure(state='disabled'if value else'readonly')

    def test(self,generation=False,media=None):
        if self.busy:return
        try:
            value=api_connections.validate_key(self.key.get())
            model=self.model.get() if self.model else None
            if model:validate_settings(self.ai_config())
            if (generation or media)and self.model and not model:raise ValueError()
            if not value and not api_connections.current_key(self.ai_provider.get()if self.ai_provider else self.provider):raise ValueError()
        except ValueError:
            self.status.set('أدخل مفتاحًا صالحًا لهذه الخدمة ونموذج Gemini صالحًا عند اختياره.');return
        self.set_busy(True);self.status.set('جارٍ اختبار اتصال الخدمة…');self.cancel.clear()
        extra={}
        if self.ai_provider:extra={'ai_provider':self.ai_provider.get(),'base_url':self.base_url.get()}
        def work():
            try:
                if media:
                    from ai_capabilities import check_media
                    result=check_media(media,value,model,self.cancel,**extra)
                else:result=api_connections.check_generation(value,model,self.cancel,**extra)if generation else api_connections.check(self.provider,value,model,self.cancel,**extra)
                self.events.put((True,result))
            except api_connections.ConnectionError as exc:self.events.put((False,str(exc)))
            except Exception:self.events.put((False,'تعذر فحص الاتصال؛ لم تُحفظ أو تُعرض بيانات المفتاح.'))
        self.worker=threading.Thread(target=work,daemon=True);self.worker.start();self.poll()

    def poll(self):
        if self.closed:return
        self.timer=None
        try:
            ok,value=self.events.get_nowait();self.set_busy(False)
            self.status.set(value['message'] if ok else value)
            if ok and self.combo is not None and 'models'in value:self.combo['values']=value['models']
        except queue.Empty:self.timer=self.after(60,self.poll)

    def destroyed(self,event):
        if event.widget is not self:return
        self.closed=True;self.cancel.set()
        if self.timer:
            try:self.after_cancel(self.timer)
            except tk.TclError:pass


def open_settings(parent,provider='youtube'):
    window=tk.Toplevel(parent);window.title('مفاتيح YouTube ومزوّد الذكاء');window.geometry(f'800x{min(850,max(650,window.winfo_screenheight()-100))}');window.minsize(720,650);window.configure(bg=BG)
    Label(window,text='إعداد مفاتيح الخدمات',bg=BG,fg=CYAN,font=('Segoe UI',19,'bold')).pack(anchor='e',padx=20,pady=14)
    book=ttk.Notebook(window);book.pack(fill='both',expand=True,padx=16,pady=(0,16))
    panels={}
    for name,label in (('youtube','YouTube Data API'),('gemini',visual('فهم المحتوى / API'))):
        panel=ApiPanel(book,name);book.add(panel,text=label);panels[name]=panel
    book.select(panels.get(provider,panels['youtube']))
    window.api_panels=panels;window.api_notebook=book
    return window
