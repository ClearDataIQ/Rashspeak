"""RashSpeak 2.7 WIP: provider boundaries, checkpoints and local GPU runtime."""
import subprocess
import sys
import tkinter as tk
from tkinter import ttk

from rtl_ui import Label, Button, Treeview, visual, dialogs as messagebox
from app_paths import app_dir
from production_ui import ProductionPanel, BG, TEXT, MUTED, CYAN


def create_app():
    root=tk.Tk()
    root.title('RashSpeak Studio 2.7 WIP | Auto Studio + Pro Editor')
    width=min(1380,max(1040,root.winfo_screenwidth()-80))
    height=min(900,max(660,root.winfo_screenheight()-130))
    root.geometry(f'{width}x{height}');root.minsize(1040,660);root.configure(bg=BG)
    style=ttk.Style(root);style.theme_use('clam')
    style.configure('TProgressbar',background=CYAN,troughcolor='#1b2d43',borderwidth=0)
    style.configure('Treeview',background='#132138',fieldbackground='#132138',foreground=TEXT,rowheight=30)
    style.configure('Treeview.Heading',background='#223b58',foreground=TEXT,font=('Segoe UI',10,'bold'))
    style.map('Treeview',background=[('selected','#285778')])
    bar=tk.Frame(root,bg=BG,padx=24,pady=10);bar.pack(fill='x')
    Label(bar,text='RASH / STUDIO 2.7 WIP',bg=BG,fg=CYAN,font=('Segoe UI',15,'bold')).pack(side='left')
    Label(bar,text='إنتاج محلي • تسليم ملفات',bg=BG,fg=MUTED,font=('Segoe UI',10)).pack(side='left',padx=18)
    panel=ProductionPanel(root);panel.pack(fill='both',expand=True)

    def advanced():
        if getattr(sys,'frozen',False):command=[sys.executable,'--advanced']
        else:command=[sys.executable,str(app_dir()/'gui.py'),'--advanced']
        subprocess.Popen(command,cwd=app_dir())

    def profile():
        from dashboard_ui import ProfilePanel
        window=tk.Toplevel(root);window.title('أسلوب القناة');window.geometry('1040x740')
        ProfilePanel(window).pack(fill='both',expand=True)

    menu=tk.Menu(root,tearoff=False)
    from api_settings_ui import open_settings as api_settings
    menu.add_command(label=visual('مفاتيح YouTube ومزوّد الذكاء'),command=lambda:api_settings(root))
    menu.add_command(label=visual('تجهيز التفريغ المحلي (مرة واحدة)'),command=panel.setup_model)
    menu.add_command(label=visual('أسلوب القناة'),command=profile)
    from gemini_ui import open_settings as gemini_settings
    menu.add_command(label=visual('Gemini — إعداد المفتاح والنموذج'),command=lambda:gemini_settings(root))
    from source_ui import open_settings as media_settings
    menu.add_command(label=visual('مصادر اللقطات والأرشيف'),command=lambda:media_settings(root))
    def pro_editor():
        from pro_editor_ui import open_editor
        from tkinter import filedialog
        path=filedialog.askopenfilename(parent=root,title=visual('افتح مشروع Pro Editor أو timeline.json'),filetypes=[('RashSpeak','*.json')])
        try:open_editor(root,path or None)
        except (ValueError,OSError,KeyError) as exc:messagebox.showerror('Pro Editor',str(exc),parent=root)
    menu.add_command(label=visual('Pro Editor — فتح مشروع أو إنشاء جديد'),command=pro_editor)
    menu.add_separator()
    menu.add_command(label=visual('المحرر والأخبار وتوب فايف — أدوات إضافية'),command=advanced)
    button=Button(bar,text='إعدادات وأدوات إضافية',bg='#223b58',fg=TEXT,relief='flat',padx=14,pady=7,
                     command=lambda:menu.tk_popup(button.winfo_rootx(),button.winfo_rooty()+button.winfo_height()))
    button.pack(side='right')
    root.api_button=Button(bar,text='مفاتيح YouTube ومزوّد الذكاء',bg='#223b58',fg=TEXT,relief='flat',padx=14,pady=7,
                           command=lambda:api_settings(root))
    root.api_button.pack(side='right',padx=8)

    closing=False
    def close():
        nonlocal closing
        if not closing and panel.busy and not messagebox.askyesno('معالجة جارية','إيقاف المعالجة وإغلاق البرنامج؟',parent=root):return
        closing=True;panel.stop()
        editors=[w.editor for w in root.winfo_children() if hasattr(w,'editor')]
        for editor in editors:editor.cancel.set()
        workers=[getattr(panel,'worker',None),*[getattr(e,'worker',None) for e in editors]]
        if any(w and w.is_alive() for w in workers):root.after(50,close);return
        for editor in editors:editor.session.autosave()
        root.destroy()
    root.protocol('WM_DELETE_WINDOW',close)
    root.production=panel
    return root


def main():
    if '--pro' in sys.argv:
        from pro_editor_ui import ProEditor
        root=tk.Tk();root.title('RashSpeak • Pro Editor');root.geometry('1440x1000');root.configure(bg=BG)
        path=sys.argv[sys.argv.index('--pro')+1] if len(sys.argv)>sys.argv.index('--pro')+1 else None
        editor=ProEditor(root,path);editor.pack(fill='both',expand=True)
        def close_pro():
            editor.cancel.set()
            if hasattr(editor,'worker') and editor.worker.is_alive():root.after(50,close_pro);return
            editor.session.autosave();root.destroy()
        root.protocol('WM_DELETE_WINDOW',close_pro);root.mainloop()
    elif '--advanced' in sys.argv or '--project' in sys.argv:
        import advanced_gui
    else:create_app().mainloop()


if __name__=='__main__':main()
