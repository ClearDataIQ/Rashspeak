"""Usable Tk multitrack editor backed by pro_project and pro_render."""
from copy import deepcopy
import json
import math
import os
from pathlib import Path
import queue
import subprocess
import sys
import threading
import tkinter as tk
from tkinter import ttk,filedialog,simpledialog

from PIL import Image,ImageTk
from rtl_ui import Label,Button,Treeview,visual,dialogs as messagebox
from app_paths import app_dir
from media_tools import Cancelled,tool
from smart_editor import save as save_json
from pro_project import SCHEMA,Session,new_project,new_clip,import_media,load_project,length,sequence,uid,write_project,edit_digest,retime_animation
import pro_render

BG='#0b1220';CARD='#132138';TEXT='#eef5ff';MUTED='#91a9c4';CYAN='#08BEED'
COLORS={'video':'#245477','image':'#356866','audio':'#406349','effect':'#746030','text':'#655383'}
DEFAULT_KEYS={'undo':'<Control-z>','redo':'<Control-Shift-Z>','save':'<Control-s>','split':'<Control-b>',
              'delete':'<Delete>','ripple':'<Shift-Delete>','copy':'<Control-c>','paste':'<Control-v>',
              'group':'<Control-g>','ungroup':'<Control-Shift-G>','play':'<space>','left':'<Left>','right':'<Right>'}


class ProEditor(tk.Frame):
    def __init__(self,parent,path=None,project=None,exports=None):
        super().__init__(parent,bg=BG,padx=12,pady=10)
        self.events=queue.Queue();self.cancel=threading.Event();self.busy=False;self.selected=[];self.selected_track=None
        self.playhead=0;self.zoom=tk.DoubleVar(value=80);self.snap=tk.BooleanVar(value=True);self.drag=None;self.image=None
        self.exported=[];self.closed=False;self.preview_revision=None;self.scrub_timer=None
        self.export_options={'codec':'h264','encoder':'cpu','crf':21,'bitrate':None}
        self.preview_at=None
        from preview_player import PreviewPlayer
        self.player=PreviewPlayer(self.events);self.playback_digest=None
        self.status=tk.StringVar(value='التعديلات تحفظ تلقائيًا؛ المصادر الأصلية تبقى محفوظة.')
        self.progress=tk.IntVar(value=0);self.shortcuts=dict(DEFAULT_KEYS)
        self.work=app_dir()/'output'/'pro_editor';self.work.mkdir(parents=True,exist_ok=True)
        self.keys_file=self.work/'shortcuts.json'
        if self.keys_file.exists():
            try:self.shortcuts.update({k:v for k,v in json.loads(self.keys_file.read_text(encoding='utf-8')).items() if k in DEFAULT_KEYS})
            except (ValueError,OSError):pass
        if path:
            data=load_project(path);self.session=Session(data,path if json.loads(Path(path).read_text(encoding='utf-8-sig')).get('schema')==SCHEMA else None)
            if not self.session.path:self.session.save(Path(path).parent/'project.rash.json')
            self.recover()
        else:
            self.session=Session(project or new_project())
            if project is None:
                self.session.add_track('video','الفيديو الأساسي')
                for i in range(1,4):self.session.add_overlay(f'Overlay {i} — ميم / GIF')
                self.session.add_track('text','الترجمة');self.session.add_track('audio','التعليق');self.session.add_track('effect','المؤثرات')
                self.session.undo_stack.clear()
            self.session.save(self.work/self.session.project['id']/'project.rash.json')
        from smart_editor import fingerprint
        for i,item in enumerate(exports or []):
            try:
                if item.get('model_digest')==edit_digest(self.session.project) and fingerprint(item['path'])==item.get('fingerprint'):
                    self.exported.append({**item,'portrait':item.get('kind')=='short','sequence':self.session.project['sequences'][i]['id']})
            except (OSError,IndexError):pass
        from job_queue import ExportQueue
        self.queue=ExportQueue(self.session.path.parent/'jobs',self.events)
        self.build();self.bind_keys();self.refresh()
        self.timer=self.after(70,self.drain)
        self.queue.start()
        self.bind('<Destroy>',self.destroyed,add='+')

    def button(self,parent,text,command,primary=False):
        return Button(parent,text=text,command=command,bg=CYAN if primary else '#223b58',fg=BG if primary else TEXT,
                      relief='flat',padx=10,pady=6,font=('Segoe UI',10,'bold'))

    def build(self):
        bar=tk.Frame(self,bg=BG);bar.pack(fill='x')
        Label(bar,text='RASH / PRO EDITOR',bg=BG,fg=CYAN,font=('Segoe UI',16,'bold')).pack(side='left',padx=(0,16))
        self.button(bar,'Gemini',self.ai_tools).pack(side='left',padx=3)
        from api_settings_ui import open_settings as api_settings
        self.button(bar,'مفاتيح API',lambda:api_settings(self)).pack(side='left',padx=3)
        self.button(bar,'المهام',self.jobs_window).pack(side='left',padx=3)
        for text,fn in [('فتح',self.open_project),('حفظ',self.save),('Undo',lambda:self.command(self.session.undo)),('Redo',lambda:self.command(self.session.redo)),
                        ('معاينة وتشغيل',self.play),('تصدير MP4',self.export),('تجهيز ZIP',self.bundle)]:self.button(bar,text,fn).pack(side='right',padx=3)
        row=tk.Frame(self,bg=BG);row.pack(fill='x',pady=8)
        self.seqvar=tk.StringVar();self.seqbox=ttk.Combobox(row,textvariable=self.seqvar,state='readonly',width=28)
        self.seqbox.pack(side='right');self.seqbox.bind('<<ComboboxSelected>>',self.change_sequence)
        for text,fn in [('شورت متصل',self.short),('أدوات احترافية',self.professional_tools),('Crop / Keyframes',self.visual_tools),('Slip / Slide / Roll',self.precise),('اختصارات',self.edit_keys),('إعدادات التسلسل',self.sequence_settings)]:self.button(row,text,fn).pack(side='right',padx=3)
        self.time_label=Label(row,text='',bg=BG,fg=MUTED);self.time_label.pack(side='left')
        bottom=tk.Frame(self,bg=BG);bottom.pack(side='bottom',fill='x',pady=5)
        Label(bottom,textvariable=self.status,bg=BG,fg=MUTED,anchor='e').pack(side='right',fill='x',expand=True)
        ttk.Progressbar(bottom,variable=self.progress,maximum=100,length=180).pack(side='left')
        self.button(bottom,'إلغاء المهمة',self.cancel.set).pack(side='left',padx=5)
        self.workspace_panes=tk.PanedWindow(self,orient='vertical',bg=BG,sashwidth=8)
        self.workspace_panes.pack(fill='both',expand=True)
        upper=tk.PanedWindow(self.workspace_panes,orient='horizontal',bg=BG,sashwidth=7)
        self.workspace_panes.add(upper,minsize=250,height=430,stretch='always')
        library=tk.Frame(upper,bg=CARD,padx=8,pady=8);upper.add(library,minsize=210,width=250,stretch='never')
        Label(library,text='مكتبة المشروع',bg=CARD,fg=TEXT,font=('Segoe UI',13,'bold')).pack(anchor='e')
        library_actions=tk.Frame(library,bg=CARD);library_actions.pack(side='bottom',fill='x')
        ttk.Style(self).configure('ProLibrary.Treeview',background=CARD,fieldbackground=CARD,foreground=TEXT,rowheight=28)
        self.media_tree=Treeview(library,style='ProLibrary.Treeview',columns=('type',),show='tree headings',selectmode='browse',height=7)
        self.media_tree.heading('#0',text=visual('الملف'));self.media_tree.heading('type',text=visual('نوع'))
        self.media_tree.column('#0',width=135);self.media_tree.column('type',width=50);self.media_tree.pack(fill='both',expand=True,pady=6)
        self.media_tree.bind('<ButtonRelease-1>',self.library_drop)
        self.button(library_actions,'استيراد وسائط',self.import_file).pack(fill='x',pady=3)
        self.button(library_actions,'أضف المحدد عند المؤشر',self.add_selected_media).pack(fill='x',pady=3)
        self.button(library_actions,'أضف صوت الوسيط',self.add_media_audio).pack(fill='x',pady=3)
        self.button(library_actions,'استبدال أصل المقطع',self.replace_media).pack(fill='x',pady=3)
        self.button(library_actions,'المكتبة المحلية',self.library_window).pack(fill='x',pady=3)
        viewer=tk.Frame(upper,bg='#070d16',padx=8,pady=8);upper.add(viewer,minsize=350,width=620,stretch='always')
        self.preview=Label(viewer,text='حرّك المؤشر ثم اضغط معاينة الإطار\nالمعاينة والتصدير يستخدمان محرك التركيب نفسه.',bg='#070d16',fg=MUTED)
        controls=tk.Frame(viewer,bg='#070d16');controls.pack(side='bottom',fill='x')
        self.preview.pack(fill='both',expand=True)
        self.button(controls,'◀ إطار',lambda:self.seek(self.playhead-1)).pack(side='left')
        self.button(controls,'إطار ▶',lambda:self.seek(self.playhead+1)).pack(side='left')
        self.button(controls,'معاينة الإطار',self.preview_frame).pack(side='right')
        self.button(controls,'تشغيل / إيقاف',self.play).pack(side='left')
        self.button(controls,'مشغل خارجي',self.external_play).pack(side='left')
        self.revision_label=Label(controls,text='',bg='#070d16',fg=MUTED);self.revision_label.pack(side='right',padx=10)
        property_panel=tk.Frame(upper,bg=CARD);upper.add(property_panel,minsize=260,width=290,stretch='never')
        self.property_canvas=tk.Canvas(property_panel,bg=CARD,highlightthickness=0,width=270)
        property_scroll=ttk.Scrollbar(property_panel,orient='vertical',command=self.property_canvas.yview)
        property_scroll.pack(side='right',fill='y');self.property_canvas.pack(fill='both',expand=True)
        self.property_canvas.configure(yscrollcommand=property_scroll.set)
        props=tk.Frame(self.property_canvas,bg=CARD,padx=8,pady=8)
        property_window=self.property_canvas.create_window(0,0,window=props,anchor='nw')
        props.bind('<Configure>',lambda e:self.property_canvas.configure(scrollregion=self.property_canvas.bbox('all')))
        self.property_canvas.bind('<Configure>',lambda e:self.property_canvas.itemconfigure(property_window,width=e.width))
        Label(props,text='خصائص المقطع — إطارات',bg=CARD,fg=TEXT,font=('Segoe UI',13,'bold')).pack(anchor='e')
        self.props={}
        for key,label in [('start','البداية'),('end','النهاية'),('in','بداية المصدر'),('gain_db','الصوت dB'),('fade_in','دخول تدريجي'),('fade_out','خروج تدريجي'),('x','الموقع X'),('y','الموقع Y'),('scale','الحجم'),('opacity','الشفافية')]:
            r=tk.Frame(props,bg=CARD);r.pack(fill='x',pady=1);v=tk.StringVar();self.props[key]=v
            Label(r,text=label,bg=CARD,fg=MUTED,width=15,anchor='e').pack(side='right')
            tk.Entry(r,textvariable=v,bg=BG,fg=TEXT,insertbackground=TEXT,width=9).pack(side='left',fill='x',expand=True)
        self.loop=tk.BooleanVar();tk.Checkbutton(props,text=visual('تكرار المصدر'),variable=self.loop,bg=CARD,fg=TEXT,selectcolor=BG).pack(anchor='e')
        self.caption=tk.Text(props,height=3,bg=BG,fg=TEXT,insertbackground=TEXT,wrap='word');self.caption.pack(fill='x',pady=3)
        self.button(props,'تطبيق الخصائص',self.apply_properties,True).pack(fill='x',pady=3)
        edits=tk.Frame(props,bg=CARD);edits.pack(fill='x',pady=3)
        self.button(edits,'تقسيم',self.split).pack(side='right',fill='x',expand=True,padx=2)
        self.button(edits,'حذف',lambda:self.delete(False)).pack(side='right',fill='x',expand=True,padx=2)
        self.button(props,'Ripple Delete',lambda:self.delete(True)).pack(fill='x',pady=2)
        timeline_panel=tk.Frame(self.workspace_panes,bg=BG)
        self.workspace_panes.add(timeline_panel,minsize=150,height=325,stretch='always')
        toolbar=tk.Frame(timeline_panel,bg=BG);toolbar.pack(fill='x',pady=(8,3))
        for kind,label in [('video','فيديو'),('image','صور'),('audio','صوت'),('effect','مؤثر'),('text','ترجمة')]:
            self.button(toolbar,'+ '+label,lambda k=kind:self.add_track(k)).pack(side='right',padx=2)
        self.button(toolbar,'نص عند المؤشر',self.add_text).pack(side='right',padx=2)
        self.button(toolbar,'طبقات الميمز / GIF',self.overlay_slots).pack(side='right',padx=2)
        tk.Checkbutton(toolbar,text='Snapping',variable=self.snap,bg=BG,fg=TEXT,selectcolor=CARD).pack(side='left')
        tk.Scale(toolbar,variable=self.zoom,from_=15,to=250,orient='horizontal',length=160,showvalue=False,bg=BG,fg=TEXT,
                 highlightthickness=0,command=lambda _:self.draw()).pack(side='left')
        lower=tk.Frame(timeline_panel,bg=BG);lower.pack(fill='both',expand=True)
        ttk.Style(self).configure('ProTimeline.Treeview',rowheight=46,background=CARD,fieldbackground=CARD,foreground=TEXT)
        self.track_list=Treeview(lower,style='ProTimeline.Treeview',columns=('kind','state'),show='tree headings',height=6,selectmode='browse')
        self.track_list.heading('#0',text=visual('المسار'));self.track_list.column('#0',width=100)
        self.track_list.heading('kind',text='Type');self.track_list.column('kind',width=55)
        self.track_list.heading('state',text='L / H / M');self.track_list.column('state',width=65)
        self.track_list.pack(side='left',fill='y');self.track_list.bind('<<TreeviewSelect>>',self.select_track);self.track_list.bind('<Button-3>',self.track_menu)
        canvasholder=tk.Frame(lower,bg=BG);canvasholder.pack(side='left',fill='both',expand=True)
        self.canvas=tk.Canvas(canvasholder,bg='#101c2e',height=270,highlightthickness=0)
        horizontal=ttk.Scrollbar(canvasholder,orient='horizontal',command=self.canvas.xview);vertical=ttk.Scrollbar(canvasholder,orient='vertical',command=self.timeline_yview)
        self.canvas.configure(xscrollcommand=horizontal.set,yscrollcommand=vertical.set)
        vertical.pack(side='right',fill='y');self.canvas.pack(fill='both',expand=True);horizontal.pack(fill='x')
        self.canvas.bind('<Button-1>',self.press);self.canvas.bind('<B1-Motion>',self.motion);self.canvas.bind('<ButtonRelease-1>',self.release)
        self.canvas.bind('<Double-Button-1>',lambda e:self.preview_frame())

    def recover(self):
        file=self.session.path.with_suffix('.autosave.json')
        if file.exists() and file.stat().st_mtime_ns>self.session.path.stat().st_mtime_ns:
            try:
                recovered=load_project(file)
                if recovered!=self.session.project:
                    self.session.undo_stack.append(('استعادة الحفظ التلقائي',deepcopy(self.session.project)))
                    self.session.project=recovered;self.session.dirty=True;self.status.set('استُعيد آخر حفظ تلقائي. Undo يرجع للنسخة المحفوظة يدويًا.')
            except (ValueError,OSError,KeyError):self.status.set('الحفظ التلقائي غير صالح؛ فُتحت النسخة المحفوظة.')

    def command(self,fn):
        if self.busy:return
        try:fn();self.refresh();self.status.set('تم التعديل وحُفظ تلقائيًا؛ حدّث المعاينة لرؤية النتيجة.')
        except (ValueError,OSError,KeyError,StopIteration) as exc:messagebox.showerror('تعذر التعديل',str(exc),parent=self)

    def refresh(self):
        if self.player.running and self.playback_digest!=edit_digest(self.session.project):self.player.stop()
        existing={c['id'] for t in self.session.seq['tracks'] for c in t['clips']};self.selected=[key for key in self.selected if key in existing]
        if self.selected_track not in [t['id'] for t in self.session.seq['tracks']]:self.selected_track=next((t['id'] for t in self.session.seq['tracks']),None)
        for tree in (self.track_list,self.media_tree):tree.delete(*tree.get_children())
        for t in self.session.seq['tracks']:
            state=' / '.join(k[0].upper() for k in ('locked','hidden','muted') if t[k])
            self.track_list.insert('', 'end',iid=t['id'],text=t['name'],values=(t['kind'],state))
        if self.selected_track:self.track_list.selection_set(self.selected_track)
        for a in self.session.project['media']:self.media_tree.insert('','end',iid=a['id'],text=Path(a['path']).name,values=(a['kind'],))
        seqs=self.session.project['sequences'];self.seqbox['values']=[visual(s['name']) for s in seqs]
        self.seqbox.current(next(i for i,s in enumerate(seqs) if s['id']==self.session.project['active_sequence']))
        self.playhead=max(0,min(self.playhead,length(self.session.seq)-1));self.draw();self.show_properties()
        self.update_preview_status()

    def update_preview_status(self):
        current=self.preview_revision==self.session.project['revision'] and self.preview_at==(self.session.project['active_sequence'],self.playhead)
        self.revision_label.configure(text=visual('المعاينة محدّثة' if current else 'المعاينة تحتاج تحديثًا'))

    def draw(self):
        if not hasattr(self,'canvas'):return
        self.canvas.delete('all');fps=self.session.project['fps'];px=self.zoom.get()/fps;limit=length(self.session.seq)
        step=max(1,round(100/self.zoom.get()));width=max(1000,(limit+fps*5)*px)
        for second in range(0,int(limit/fps)+6,step):
            x=second*self.zoom.get();self.canvas.create_line(x,0,x,32+len(self.session.seq['tracks'])*46,fill='#1e3046')
            self.canvas.create_text(x+4,12,text=f'{second}s',fill=MUTED,anchor='w')
        for row,t in enumerate(self.session.seq['tracks']):
            top=32+row*46;self.canvas.create_line(0,top,width,top,fill='#293c54')
            for c in sorted(t['clips'],key=lambda c:c['start']):
                left=c['start']*px;right=(c['start']+c['duration'])*px
                selected=c['id'] in self.selected;fill=COLORS[t['kind']] if not t['hidden'] and not t['muted'] else '#29313d'
                tags=('clip',c['id']);self.canvas.create_rectangle(left,top+4,right,top+40,fill=fill,outline=CYAN if selected else '#4d647b',width=2 if selected else 1,tags=tags)
                title=c['text'] if t['kind']=='text' else Path(next(a['path'] for a in self.session.project['media'] if a['id']==c['media_id'])).stem
                if right-left>30:self.canvas.create_text(left+6,top+22,text=visual(title[:max(3,int((right-left)/8))]),fill=TEXT,anchor='w',tags=tags)
                self.canvas.create_line(left+3,top+10,left+3,top+34,fill='#abc2d5',tags=tags);self.canvas.create_line(right-3,top+10,right-3,top+34,fill='#abc2d5',tags=tags)
        x=self.playhead*px;self.canvas.create_line(x,0,x,32+len(self.session.seq['tracks'])*46,fill='#ffcc55',width=2)
        self.canvas.configure(scrollregion=(0,0,width,max(270,32+len(self.session.seq['tracks'])*46)))
        self.time_label.configure(text=f'{self.playhead//fps//60:02}:{self.playhead//fps%60:02}:{self.playhead%fps:02} / {limit/fps:.2f}s • {fps}fps')

    def timeline_yview(self,*args):self.canvas.yview(*args);self.track_list.yview(*args)

    def position(self,event):
        x=self.canvas.canvasx(event.x);y=self.canvas.canvasy(event.y)
        row=int((y-32)//46);track=self.session.seq['tracks'][row]['id'] if 0<=row<len(self.session.seq['tracks']) else None
        return max(0,round(x*self.session.project['fps']/self.zoom.get())),track,x

    def press(self,event):
        if self.busy:return
        frame,track,x=self.position(event);hits=self.canvas.find_overlapping(x,self.canvas.canvasy(event.y),x,self.canvas.canvasy(event.y))
        key=next((self.canvas.gettags(i)[1] for i in reversed(hits) if 'clip' in self.canvas.gettags(i)),None)
        self.selected_track=track or self.selected_track
        if not key:self.selected=[];self.seek(frame);self.refresh();return
        if event.state&4:
            if key in self.selected:self.selected.remove(key)
            else:self.selected.append(key)
        elif key not in self.selected:self.selected=[key]
        t,c=self.session.clip(key);px=self.zoom.get()/self.session.project['fps']
        mode='trim_left' if abs(x-c['start']*px)<7 else 'trim_right' if abs(x-(c['start']+c['duration'])*px)<7 else 'move'
        self.drag={'key':key,'frame':frame,'start':c['start'],'end':c['start']+c['duration'],'mode':mode,'track':track}
        self.draw();self.show_properties()

    def motion(self,event):
        if not self.drag:return
        frame,track,_=self.position(event);self.status.set(f'{self.drag["mode"]} • {frame} frame');self.canvas.delete('drag_marker')
        self.canvas.create_line(frame*self.zoom.get()/self.session.project['fps'],0,frame*self.zoom.get()/self.session.project['fps'],270,fill=CYAN,tags='drag_marker')

    def release(self,event):
        if not self.drag:return
        drag=self.drag;self.drag=None;frame,track,_=self.position(event);delta=frame-drag['frame']
        if delta==0 and track==drag['track']:return
        if drag['mode']=='move':self.command(lambda:self.session.move(drag['key'],drag['start']+delta,track,self.snap.get(),self.selected))
        else:self.command(lambda:self.session.trim(drag['key'],drag['start']+delta if drag['mode']=='trim_left' else drag['start'],drag['end']+delta if drag['mode']=='trim_right' else drag['end']))

    def seek(self,value):
        self.playhead=max(0,min(int(value),length(self.session.seq)-1));self.draw();self.update_preview_status()
        if self.player.running:self.player.start(self.player.path,self.playhead/self.session.project['fps'])

    def show_properties(self):
        for v in self.props.values():v.set('')
        self.caption.delete('1.0','end')
        if not self.selected:return
        t,c=self.session.clip(self.selected[0])
        for k,v in self.props.items():v.set(str(c['start']+c['duration'] if k=='end' else c['transform'][k] if k in c['transform'] else c[k]))
        self.loop.set(c['loop']);self.caption.insert('1.0',c['text'])

    def apply_properties(self):
        if not self.selected:return
        key=self.selected[0]
        def change():
            ints={k:int(self.props[k].get()) for k in ('start','end','in','fade_in','fade_out')};tr={k:float(self.props[k].get()) for k in ('x','y','scale','opacity')}
            t,c=self.session.clip(key);self.session.editable(t)
            if ints['start']!=c['start'] or ints['end']!=c['start']+c['duration']:retime_animation(c,ints['start']-c['start'],ints['end']-ints['start'])
            c.update(start=ints['start'],duration=ints['end']-ints['start'],**{'in':ints['in']},fade_in=ints['fade_in'],fade_out=ints['fade_out'],
                    gain_db=float(self.props['gain_db'].get()),transform=tr,loop=self.loop.get(),text=self.caption.get('1.0','end-1c'))
        self.command(lambda:self.session.edit('خصائص المقطع',change))

    def select_track(self,event=None):
        values=self.track_list.selection()
        if values:self.selected_track=values[0]

    def track_menu(self,event):
        key=self.track_list.identify_row(event.y)
        if not key:return
        self.selected_track=key;track=self.session.track(key);menu=tk.Menu(self,tearoff=False)
        for prop,label in [('locked','قفل / فتح'),('hidden','إخفاء / إظهار'),('muted','كتم / تشغيل')]:
            menu.add_command(label=visual(label),command=lambda k=prop:self.command(lambda:self.session.track_state(key,**{k:not track[k]})))
        menu.add_command(label=visual('جهارة المسار dB'),command=lambda:self.track_gain(key))
        menu.add_command(label=visual('طبقة إلى الأمام'),command=lambda:self.command(lambda:self.session.reorder_track(key,1)))
        menu.add_command(label=visual('طبقة إلى الخلف'),command=lambda:self.command(lambda:self.session.reorder_track(key,-1)))
        menu.tk_popup(event.x_root,event.y_root)

    def track_gain(self,key):
        value=simpledialog.askfloat('Track gain','dB (-60 .. 12)',initialvalue=self.session.track(key)['gain_db'],parent=self)
        if value is not None:self.command(lambda:self.session.track_state(key,gain_db=value))

    def add_track(self,kind):
        def add():self.selected_track=self.session.add_track(kind)
        self.command(add)

    def ai_tools(self):
        from gemini_ui import open_assistant
        open_assistant(self)

    def jobs_window(self):
        w=tk.Toplevel(self);w.title('المهام المحفوظة');w.geometry('780x500');w.configure(bg=BG)
        tree=Treeview(w,columns=('status','progress','tries','error'),show='tree headings',height=12)
        tree.heading('#0',text='ID');tree.column('#0',width=100)
        for k,label,width in [('status','الحالة',120),('progress','التقدم',60),('tries','المحاولات',60),('error','الخطأ',340)]:tree.heading(k,text=label);tree.column(k,width=width)
        tree.pack(fill='both',expand=True,padx=12,pady=12)
        pending={'id':None}
        def refresh():
            if not w.winfo_exists():return
            selected=tree.selection();tree.delete(*tree.get_children())
            for j in self.queue.rows():tree.insert('','end',iid=j['id'],text=j['id'][:8],values=(j['status'],j['progress'],j['attempts'],j['error']))
            if selected and tree.exists(selected[0]):tree.selection_set(selected[0])
            pending['id']=w.after(700,refresh)
        def retry():
            if not tree.selection():return
            try:self.queue.retry(tree.selection()[0])
            except ValueError as exc:messagebox.showerror('المهمة',str(exc),parent=w)
        row=tk.Frame(w,bg=BG);row.pack(fill='x',padx=12,pady=8)
        self.button(row,'إعادة المحاولة',retry).pack(side='right',padx=3)
        self.button(row,'إلغاء المحدد',lambda:self.queue.cancel_job(tree.selection()[0]) if tree.selection() else None).pack(side='right',padx=3)
        self.button(row,'متابعة القائمة',self.queue.start).pack(side='right',padx=3);refresh()
        self.button(row,'إعدادات التصدير',self.export_settings).pack(side='right',padx=3)
        def close(event):
            if event.widget is w and pending['id']:w.after_cancel(pending['id'])
        w.bind('<Destroy>',close,add='+')

    def export_settings(self):
        w=tk.Toplevel(self);w.title('إعدادات التصدير');w.geometry('550x420');w.configure(bg=BG)
        variables={k:tk.StringVar(value=str(v) if v is not None else 'auto') for k,v in self.export_options.items()}
        for key,label,choices in [('codec','الترميز',['h264','h265']),('encoder','المشفّر',['cpu','nvenc']),('crf','CRF / CQ — 12–35',None),('bitrate','Bitrate bits/sec — auto أو 1M–100M',None)]:
            Label(w,text=label,bg=BG,fg=TEXT).pack(anchor='e',padx=16,pady=(8,2))
            if choices:ttk.Combobox(w,textvariable=variables[key],values=choices,state='readonly').pack(fill='x',padx=16)
            else:tk.Entry(w,textvariable=variables[key],bg=CARD,fg=TEXT,insertbackground=TEXT).pack(fill='x',padx=16)
        Label(w,text='الدقة وFPS من إعدادات التسلسل. NVENC يحتاج GPU وتعريف NVIDIA متوافقًا.\nالافتراضي CPU/H.264؛ لا يُستبدل خيار GPU بصمت إذا تعذر.',bg=BG,fg=MUTED,wraplength=520).pack(fill='x',padx=16,pady=12)
        def save():
            try:
                opts={k:v.get() for k,v in variables.items()};opts['crf']=int(opts['crf']);opts['bitrate']=None if opts['bitrate']=='auto' else int(opts['bitrate'])
                if not 12<=opts['crf']<=35 or (opts['bitrate'] is not None and not 1000000<=opts['bitrate']<=100000000):raise ValueError('قيمة جودة أو Bitrate خارج النطاق.')
                self.export_options=opts;w.destroy();self.status.set('إعدادات التصدير محفوظة لهذه الجلسة.')
            except ValueError as exc:messagebox.showerror('التصدير',str(exc),parent=w)
        self.button(w,'تطبيق إعدادات التصدير',save).pack(fill='x',padx=16,pady=8)

    def professional_tools(self):
        from pro_tools_ui import open_tools
        open_tools(self)

    def overlay_slots(self):
        def ensure():
            overlays=[t for t in self.session.seq['tracks'] if t.get('role')=='overlay']
            for i in range(len(overlays),3):
                key=self.session.add_overlay(f'Overlay {i+1} — ميم / GIF');overlays.append(self.session.track(key))
            self.selected_track=next((t['id'] for t in overlays if not t['clips']),overlays[0]['id'])
        self.command(ensure)
        self.status.set('ثلاث طبقات فوق الفيديو. اسحب صورة أو GIF من المكتبة إلى الطبقة المطلوبة؛ Crop / Keyframes يعدّل الجزء الظاهر والحركة.')

    def import_file(self,replace=False):
        if self.busy:return
        path=filedialog.askopenfilename(parent=self,title=visual('اختر وسيطًا تملك حق استخدامه'))
        if not path:return
        if not messagebox.askyesno('حقوق الوسائط','هل تملك حق استخدام هذا الملف في فيديوهاتك؟\nستُحفظ موافقتك مع المشروع.',parent=self):return
        key=self.selected[0] if replace and self.selected else None
        def accept(media):
            def change():
                if not any(a['id']==media['id'] for a in self.session.project['media']):self.session.project['media'].append(media)
                if key:
                    t,c=self.session.clip(key);self.session.editable(t);c['media_id']=media['id'];c['in']=0
            self.command(lambda:self.session.edit('استيراد / استبدال وسيط',change))
        def load():
            from media_library import remember
            return remember(import_media(path),cancel=self.cancel)
        self.task(load,accept,'فحص الملف وفهرسته')

    def replace_media(self):
        if self.selected:self.import_file(True)

    def library_window(self):
        from media_library import search,remember
        w=tk.Toplevel(self);w.title('RashSpeak • المكتبة المحلية');w.geometry('760x540');w.configure(bg=BG)
        query=tk.StringVar();tk.Entry(w,textvariable=query,bg=CARD,fg=TEXT,insertbackground=TEXT).pack(fill='x',padx=12,pady=10)
        tree=Treeview(w,columns=('game','kind','rights'),show='tree headings',height=10)
        tree.heading('#0',text=visual('الوسيط'));tree.column('#0',width=280)
        for k,label in [('game','اللعبة'),('kind','النوع'),('rights','الحقوق')]:tree.heading(k,text=label);tree.column(k,width=125)
        tree.pack(fill='both',expand=True,padx=12);records={}
        def refresh(*args):
            tree.delete(*tree.get_children());records.clear()
            for a in search(query.get()):
                records[a['id']]=a;tree.insert('','end',iid=a['id'],text=Path(a['path']).name,values=(a.get('game',''),a['kind'],'معتمد' if a.get('usage_approved') else 'انتظار الموافقة'))
        def use():
            if not tree.selection() or self.busy:return
            a=deepcopy(records[tree.selection()[0]])
            if a['kind']=='animation':a['kind']='video'
            a.setdefault('has_audio',a['kind']=='audio')
            self.command(lambda:self.session.edit('إعادة استخدام وسيط',lambda:self.session.project['media'].append(a) if not any(m['id']==a['id'] for m in self.session.project['media']) else None))
            self.insert_media(a['id'],self.playhead,self.selected_track)
        def tag():
            if not tree.selection():return
            a=deepcopy(records[tree.selection()[0]]);value=simpledialog.askstring('اللعبة / الموضوع',visual('اسم اللعبة لربط الوسيط بالمحتوى'),initialvalue=a.get('game',''),parent=w)
            if value is not None:a['game']=value;a['tags']=[value];remember(a);refresh()
        row=tk.Frame(w,bg=BG);row.pack(fill='x',padx=12,pady=10)
        self.button(row,'أضف عند المؤشر',use).pack(side='right',padx=3);self.button(row,'تعديل اللعبة / الموضوع',tag).pack(side='right',padx=3)
        self.button(row,'تحديث',refresh).pack(side='right',padx=3);query.trace_add('write',refresh);refresh()

    def add_selected_media(self):
        values=self.media_tree.selection()
        if not values:return
        self.insert_media(values[0],self.playhead,self.selected_track)

    def add_media_audio(self):
        values=self.media_tree.selection()
        if not values:return
        key=values[0];a=next(a for a in self.session.project['media'] if a['id']==key)
        if not a.get('has_audio'):
            messagebox.showerror('الصوت','هذا الوسيط لا يحتوي على مسار صوت.',parent=self);return
        def add():
            track=self.selected_track
            if not track or self.session.track(track)['kind'] not in ('audio','effect'):track=self.session.add_track('audio')
            c=new_clip(key,self.playhead,max(1,math.ceil(a['duration']*self.session.project['fps'])))
            self.selected=[self.session.add(track,c)];self.selected_track=track
        self.command(add)

    def insert_media(self,key,at,track=None):
        a=next(a for a in self.session.project['media'] if a['id']==key);fps=self.session.project['fps']
        def add():
            nonlocal track
            expected=('audio','effect') if a['kind']=='audio' else ('video','image') if a['kind']=='image' else ('video',)
            if not track or self.session.track(track)['kind'] not in expected:track=self.session.add_track(expected[0])
            c=new_clip(key,int(at),max(1,math.ceil(a['duration']*fps)) if a['kind']!='image' else fps*5)
            if self.session.track(track).get('role')=='overlay':
                overlays=[t['id'] for t in self.session.seq['tracks'] if t.get('role')=='overlay'];slot=overlays.index(track)%3
                positions=[(.64,.10),(.06,.10),(.35,.46)]
                c['transform'].update(x=positions[slot][0],y=positions[slot][1],scale=.30)
            self.selected=[self.session.add(track,c)];self.selected_track=track
        self.command(add)

    def library_drop(self,event):
        widget=self.winfo_containing(event.x_root,event.y_root)
        if widget is not self.canvas:return
        values=self.media_tree.selection()
        if not values:return
        local=type('Position',(),{'x':event.x_root-self.canvas.winfo_rootx(),'y':event.y_root-self.canvas.winfo_rooty()})()
        at,track,_=self.position(local);self.insert_media(values[0],at,track)

    def add_text(self):
        text=simpledialog.askstring('نص / ترجمة',visual('اكتب النص كما قيل في التسجيل'),parent=self)
        if not text:return
        def add():
            track=self.selected_track
            if not track or self.session.track(track)['kind']!='text':track=self.session.add_track('text')
            c=new_clip(start=self.playhead,duration=self.session.project['fps']*3,text=text);self.selected=[self.session.add(track,c)];self.selected_track=track
        self.command(add)

    def split(self):
        if self.selected:self.command(lambda:self.session.split(self.selected[0],self.playhead))

    def delete(self,ripple=False):self.command(lambda:self.session.delete(self.selected,ripple))

    def short(self):
        fps=self.session.project['fps'];start=simpledialog.askinteger('Short','Start frame',initialvalue=self.playhead,minvalue=0,parent=self)
        if start is None:return
        end=simpledialog.askinteger('Short','End frame',initialvalue=min(length(self.session.seq),start+fps*45),minvalue=start+1,parent=self)
        if end is not None:
            from short_policy import duration_allowed
            if not duration_allowed((end-start)/self.session.project['fps']):
                messagebox.showerror('مدة الشورت','اختر نطاقًا متصلًا بين25و60ثانية. تبقى المشاريع القديمة قابلة للفتح.',parent=self)
                return
            self.command(lambda:self.session.make_short(start,end))

    def precise(self):
        if not self.selected:return
        mode=simpledialog.askstring('Slip / Slide / Roll / Crossfade','slip, slide, roll, crossfade',initialvalue='slip',parent=self)
        if mode not in ('slip','slide','roll','crossfade'):return
        delta=simpledialog.askinteger(mode,'Delta frames (+/-)',initialvalue=1,parent=self)
        if delta is None:return
        key=self.selected[0]
        def edit():
            if mode=='slip':return self.session.slip(key,delta)
            t,c=self.session.clip(key);ordered=sorted(t['clips'],key=lambda c:c['start']);i=next(i for i,c in enumerate(ordered) if c['id']==key)
            if mode in ('roll','crossfade'):
                if i+1>=len(ordered):raise ValueError('لا يوجد مقطع مجاور يمينًا.')
                if mode=='crossfade':return self.session.crossfade(key,ordered[i+1]['id'],delta)
                return self.session.roll(key,ordered[i+1]['id'],delta)
            if i==0 or i+1>=len(ordered):raise ValueError('Slide يحتاج جارًا على كل جانب.')
            return self.session.slide(key,ordered[i-1]['id'],ordered[i+1]['id'],delta)
        self.command(edit)

    def visual_tools(self):
        if not self.selected or self.busy:return
        key=self.selected[0];track,clip=self.session.clip(key)
        if track['kind'] not in ('video','image'):
            self.status.set('اختر لقطة أو ميم أو GIF لتحرير الصورة.');return
        window=tk.Toplevel(self);window.title('Crop / Keyframes');window.geometry('580x560');window.configure(bg=BG)
        tabs=ttk.Notebook(window);tabs.pack(fill='both',expand=True,padx=10,pady=10)
        crop_page=tk.Frame(tabs,bg=CARD,padx=12,pady=12);motion_page=tk.Frame(tabs,bg=CARD,padx=12,pady=12)
        tabs.add(crop_page,text='Crop');tabs.add(motion_page,text='Keyframes')
        Label(crop_page,text='قص حدود المصدر، ثم تحريك الجزء الظاهر فوق الفيديو.\nالنسب بين 0 و0.95. الشفافية الأصلية في PNG / GIF تبقى محفوظة.',bg=CARD,fg=TEXT).pack(fill='x',pady=10)
        fields={};crop=clip.get('crop',{'left':0,'top':0,'right':0,'bottom':0})
        for k,label in [('left','اليسار'),('top','الأعلى'),('right','اليمين'),('bottom','الأسفل')]:
            row=tk.Frame(crop_page,bg=CARD);row.pack(fill='x',pady=6);fields[k]=tk.StringVar(value=str(crop[k]))
            Label(row,text=label,bg=CARD,fg=TEXT).pack(side='right');tk.Entry(row,textvariable=fields[k],bg=BG,fg=TEXT,insertbackground=TEXT).pack(side='left')
        fit=tk.StringVar(value=clip.get('fit','contain'));ttk.Combobox(crop_page,textvariable=fit,values=['contain','cover'],state='readonly').pack(fill='x',pady=8)
        Label(crop_page,text='contain يحفظ الصورة كاملة. cover يملأ الإطار ويقص الأطراف؛ راجع العناصر المهمة.',bg=CARD,fg=MUTED,wraplength=480).pack(fill='x')
        self.button(crop_page,'تطبيق Crop',lambda:self.command(lambda:self.session.properties(key,crop={k:float(v.get()) for k,v in fields.items()},fit=fit.get())),True).pack(fill='x',pady=10)
        Label(motion_page,text='الإطار محسوب من بداية المقطع. X/Y نسبة من مساحة الفيديو.\nتظهر الحركة في المعاينة والتصدير بعد التحديث.',bg=CARD,fg=TEXT).pack(fill='x',pady=8)
        tree=Treeview(motion_page,columns=('property','frame','value','easing'),show='headings',height=7)
        for k in ('property','frame','value','easing'):tree.heading(k,text=k);tree.column(k,width=105)
        tree.pack(fill='x',pady=6);prop=tk.StringVar(value='x');at=tk.StringVar(value=str(max(0,self.playhead-clip['start'])));value=tk.StringVar(value=str(clip['transform']['x']));ease=tk.StringVar(value='linear')
        def refresh():
            tree.delete(*tree.get_children());_,current=self.session.clip(key)
            for p,keys in current.get('keyframes',{}).items():
                for k in keys:tree.insert('','end',iid=f'{p}:{k["frame"]}',values=(p,k['frame'],k['value'],k['easing']))
        row=tk.Frame(motion_page,bg=CARD);row.pack(fill='x')
        for var,choices in [(prop,['x','y','scale','opacity']),(ease,['linear','ease_in','ease_out'])]:ttk.Combobox(row,textvariable=var,values=choices,state='readonly',width=11).pack(side='right',padx=3)
        for var in (at,value):tk.Entry(row,textvariable=var,width=8,bg=BG,fg=TEXT,insertbackground=TEXT).pack(side='left',padx=3)
        def select(event=None):
            if tree.selection():
                p,f,v,e=tree.item(tree.selection()[0],'values');prop.set(p);at.set(f);value.set(v);ease.set(e)
        tree.bind('<<TreeviewSelect>>',select)
        def apply(remove=False):
            def edit():
                _,current=self.session.clip(key);keys=deepcopy(current.get('keyframes',{}));p=prop.get();f=int(at.get())
                keys[p]=[k for k in keys.get(p,[]) if k['frame']!=f]
                if not remove:keys[p].append({'frame':f,'value':float(value.get()),'easing':ease.get()})
                keys[p].sort(key=lambda k:k['frame']);self.session.properties(key,keyframes=keys)
            self.command(edit);refresh()
        self.button(motion_page,'إضافة / تعديل Keyframe',apply,True).pack(fill='x',pady=8)
        self.button(motion_page,'حذف Keyframe',lambda:apply(True)).pack(fill='x');refresh()

    def change_sequence(self,event=None):
        if self.busy:self.refresh();return
        key=self.session.project['sequences'][self.seqbox.current()]['id']
        self.session.project['active_sequence']=key;self.session.autosave();self.selected=[];self.selected_track=None;self.playhead=0;self.preview_revision=None;self.refresh()

    def sequence_settings(self):
        value=simpledialog.askstring('Sequence','Width x Height (1920x1080 / 1080x1920 / 3840x2160)',initialvalue=f'{self.session.seq["width"]}x{self.session.seq["height"]}',parent=self)
        if value:
            def update():
                w,h=map(int,value.lower().split('x'));self.session.seq.update(width=w,height=h)
            self.command(lambda:self.session.edit('أبعاد التسلسل',update))
        fps=simpledialog.askinteger('Frame rate','24 / 25 / 30 / 50 / 60',initialvalue=self.session.project['fps'],parent=self)
        if fps is not None:self.command(lambda:self.session.set_fps(fps))

    def save(self):
        if self.busy:return
        self.command(self.session.save)
        self.status.set('حُفظ المشروع: '+str(self.session.path))

    def open_project(self):
        if self.busy:return
        path=filedialog.askopenfilename(parent=self,filetypes=[('RashSpeak project','*.json')])
        if not path:return
        try:
            data=load_project(path);target=Path(path) if json.loads(Path(path).read_text(encoding='utf-8-sig')).get('schema') else Path(path).parent/'project.rash.json'
            self.session.autosave();self.queue.close();self.session=Session(data,target)
            if not target.exists():self.session.save()
            from job_queue import ExportQueue
            self.queue=ExportQueue(self.session.path.parent/'jobs',self.events);self.queue.start()
            self.recover();self.selected=[];self.selected_track=None;self.exported=[];self.preview_revision=None;self.refresh()
        except (ValueError,OSError,KeyError) as exc:messagebox.showerror('فتح المشروع',str(exc),parent=self)

    def task(self,work,done,label):
        if self.busy:return
        self.busy=True;self.cancel.clear();self.progress.set(0);self.status.set(label)
        job_path=self.session.path.parent/'jobs'/(uid()+'.json');job={'task':label,'status':'running','revision':self.session.project['revision']}
        events=self.events
        def worker():
            try:
                save_json(job,job_path);result=work();job['status']='completed';save_json(job,job_path);events.put(('done',result,done))
            except Exception as exc:
                job.update(status='cancelled' if isinstance(exc,Cancelled) else 'failed',error=str(exc))
                try:save_json(job,job_path)
                except OSError:pass
                events.put(('cancelled' if isinstance(exc,Cancelled) else 'error',str(exc),None))
        self.worker=threading.Thread(target=worker,daemon=True);self.worker.start()

    def drain(self):
        try:
            while True:
                kind,value,done=self.events.get_nowait()
                if kind=='progress':self.progress.set(value);continue
                if kind.startswith('queue_'):
                    if kind=='queue_progress':self.progress.set(value['progress'])
                    elif kind=='queue_done':
                        result=value['result'];seq=next((s for s in self.session.project['sequences'] if s['id']==value['sequence']),None)
                        if seq:result.update(portrait=seq['height']>seq['width'],sequence=seq['id']);self.exported.append(result)
                        self.status.set('اكتمل التصدير: '+result['path'])
                    elif value.get('error'):self.status.set(value['error'])
                    continue
                if kind.startswith('player_'):
                    if value['token']!=self.player.token:continue
                    if kind=='player_frame':
                        self.image=ImageTk.PhotoImage(value['image']);self.preview.configure(image=self.image,text='')
                        self.playhead=min(length(self.session.seq)-1,round(value['seconds']*self.session.project['fps']))
                        self.preview_at=(self.session.project['active_sequence'],self.playhead);self.draw();self.update_preview_status()
                    elif kind=='player_status':self.status.set('معاينة داخلية بصوت متزامن.' if value['audio'] else 'معاينة داخلية بدون صوت: جهاز الصوت غير متاح في البيئة. التشغيل الخارجي متاح.')
                    elif kind=='player_error':self.status.set(value['message'])
                    continue
                self.busy=False
                if kind=='cancelled':self.status.set(value)
                elif kind=='error':self.status.set(value);messagebox.showerror('مهمة المعالجة',value,parent=self)
                else:
                    try:done(value)
                    except Exception as exc:self.status.set(str(exc));messagebox.showerror('نتيجة المعالجة',str(exc),parent=self)
        except queue.Empty:pass
        if not self.closed:self.timer=self.after(20,self.drain)

    def preview_frame(self):
        if self.busy:return
        p=deepcopy(self.session.project);at=self.playhead;seq=p['active_sequence'];revision=p['revision'];target=self.session.path.parent/'cache'/f'frame_{uid()}.png'
        def done(path):
            with Image.open(path) as image:
                image.thumbnail((620,350));self.image=ImageTk.PhotoImage(image)
            self.preview.configure(image=self.image,text='');self.preview_revision=revision;self.preview_at=(seq,at);self.refresh();self.status.set(f'إطار {at} من نفس تركيب التصدير.')
        self.task(lambda:pro_render.frame(p,target,at,seq,cancel=self.cancel),done,'تحديث الإطار من تركيب المسارات')

    def play(self):
        if self.player.running:self.player.stop();self.status.set('المعاينة متوقفة.');return
        if self.busy:return
        p=deepcopy(self.session.project);revision=p['revision'];at=self.playhead/p['fps']
        def done(path):
            self.preview_revision=revision;self.playback_digest=edit_digest(p);self.refresh();self.player.start(path,at)
        self.task(lambda:pro_render.proxy(p,self.session.path.parent/'cache',cancel=self.cancel,on_progress=lambda n:self.events.put(('progress',n,None))),done,'تركيب Proxy من قرارات التحرير الحالية')

    def external_play(self):
        if self.busy:return
        p=deepcopy(self.session.project);at=self.playhead/p['fps']
        def done(path):
            try:subprocess.Popen([tool('ffplay'),'-autoexit','-ss',str(at),'-window_title','RashSpeak preview',path])
            except RuntimeError:self.open_file(path)
        self.task(lambda:pro_render.proxy(p,self.session.path.parent/'cache',cancel=self.cancel),done,'تجهيز المعاينة الخارجية')

    def export(self):
        if self.busy:return
        path=filedialog.asksaveasfilename(parent=self,defaultextension='.mp4',filetypes=[('MP4','*.mp4')])
        if not path:return
        p=deepcopy(self.session.project);seq=sequence(p)
        try:
            key=self.queue.enqueue(p,path,{'sequence_id':seq['id'],**self.export_options});self.status.set('أضيف التصدير إلى القائمة المحفوظة: '+key[:8])
        except ValueError as exc:messagebox.showerror('التصدير',str(exc),parent=self)

    def bundle(self):
        if self.busy:return
        parent=filedialog.askdirectory(parent=self,title=visual('مجلد حفظ المشروع والنتائج'))
        if not parent:return
        self.session.save();p=deepcopy(self.session.project);dest=Path(parent)/('RashSpeak_Project_'+uid()[:6])
        exports=[e for e in self.exported if e['model_digest']==edit_digest(p)]
        self.task(lambda:pro_render.package(p,dest,exports,cancel=self.cancel),lambda r:self.status.set('جاهز: '+r['zip']),'نسخ المصادر وتنظيم المشروع وZIP')

    def open_file(self,path):
        if os.name=='nt':os.startfile(str(path))
        else:subprocess.Popen(['open' if sys.platform=='darwin' else 'xdg-open',str(path)])

    def key_action(self,event,action):
        if isinstance(event.widget,(tk.Entry,tk.Text,ttk.Entry,ttk.Combobox)):return
        if self.busy:return 'break'
        commands={'undo':lambda:self.command(self.session.undo),'redo':lambda:self.command(self.session.redo),'save':self.save,'split':self.split,
                  'delete':lambda:self.delete(False),'ripple':lambda:self.delete(True),'copy':lambda:self.session.copy(self.selected),
                  'paste':lambda:self.command(lambda:self.session.paste(self.playhead)),
                  'group':lambda:self.command(lambda:self.session.group(self.selected)),'ungroup':lambda:self.command(lambda:self.session.group(self.selected,True)),
                  'play':self.play,'left':lambda:self.seek(self.playhead-1),'right':lambda:self.seek(self.playhead+1)}
        commands[action]();return 'break'

    def bind_keys(self):
        window=self.winfo_toplevel()
        for key in DEFAULT_KEYS.values():window.unbind(key)
        for action,key in self.shortcuts.items():
            try:window.bind(key,lambda e,a=action:self.key_action(e,a))
            except tk.TclError:self.status.set('اختصار غير صالح: '+key)

    def edit_keys(self):
        action=simpledialog.askstring('Shortcuts',', '.join(DEFAULT_KEYS),parent=self)
        if action not in DEFAULT_KEYS:return
        key=simpledialog.askstring('Shortcut','Tk key sequence, e.g. <Control-b>',initialvalue=self.shortcuts[action],parent=self)
        if not key:return
        try:
            self.winfo_toplevel().bind(key,lambda e:'break');old=self.shortcuts[action];self.winfo_toplevel().unbind(old)
            self.shortcuts[action]=key;self.keys_file.write_text(json.dumps(self.shortcuts,indent=2),encoding='utf-8');self.bind_keys()
        except (OSError,tk.TclError) as exc:messagebox.showerror('Shortcut',str(exc),parent=self)

    def destroyed(self,event):
        if event.widget is not self:return
        self.closed=True;self.cancel.set()
        self.player.stop()
        self.queue.close()
        if hasattr(self,'timer'):self.after_cancel(self.timer)
        self.session.autosave()


def open_editor(parent,path=None,project=None,exports=None):
    window=tk.Toplevel(parent);window.title('RashSpeak • Pro Editor');window.geometry('1440x1000');window.minsize(1150,850)
    editor=ProEditor(window,path,project,exports);editor.pack(fill='both',expand=True);window.editor=editor
    def close():
        editor.cancel.set()
        if hasattr(editor,'worker') and editor.worker.is_alive():window.after(50,close);return
        editor.session.autosave();window.destroy()
    window.protocol('WM_DELETE_WINDOW',close)
    return window
