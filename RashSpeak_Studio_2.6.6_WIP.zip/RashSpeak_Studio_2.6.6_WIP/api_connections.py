"""Provider-specific credentials and safe, read-only connection checks."""
import gemini_client
import official_sources


class ConnectionError(ValueError):
    """A user-facing error which never includes a credential value."""


def validate_key(value):
    value=value.strip()
    if value and (len(value)>4096 or not value.isascii()
                  or any(c.isspace() or ord(c)<33 or ord(c)>126 for c in value)):
        raise ConnectionError('المفتاح يحتوي مسافات أو أحرف غير صالحة؛ الصق قيمته فقط.')
    return value


def current_key(provider):
    if provider=='youtube':return official_sources.credential('youtube')
    if provider=='gemini':return gemini_client.api_key()
    raise ConnectionError('خدمة غير معروفة.')


def service_snapshot(online=True):
    """Configuration presence only; never claims a live connection or returns a key."""
    cfg=gemini_client.settings()
    return {'online':bool(online),
            'gemini':{'enabled':cfg['enabled'],'key_available':bool(current_key('gemini')),'model':cfg['model']},
            'youtube':{'key_available':bool(current_key('youtube'))},
            'live_connection_checked':False}


def configure(provider,value,remember=False):
    if provider not in ('youtube','gemini'):raise ConnectionError('خدمة غير معروفة.')
    value=validate_key(value)
    if not value:return False  # An empty field always keeps the existing key.
    try:
        if provider=='youtube':official_sources.configure_credential('youtube',value,persist=remember)
        else:
            if remember:gemini_client.save_key(value)
            gemini_client.use_session_key(value)
    except Exception:
        raise ConnectionError('تعذر الحفظ في خزنة النظام. يمكنك استخدام المفتاح للجلسة دون الحفظ الدائم.') from None
    return True


def check(provider,value='',model=None,cancel=None):
    # A newly typed key is tested directly, never silently replaced by an old key.
    key=validate_key(value) or current_key(provider)
    if not key:raise ConnectionError('أدخل مفتاح هذه الخدمة أولًا.')
    try:
        if provider=='youtube':
            official_sources.YouTubeOfficial(key=key,cancel=cancel).request(
                'channels',part='id',forHandle='@Battlefield')
            return {'provider':provider,'message':'نجح اتصال YouTube Data API. هذا فحص للبحث والبيانات، وليس اختبار تنزيل فيديو.'}
        if provider=='gemini':
            models=gemini_client.GeminiClient(key=key,model=model,cancel=cancel).models()
            allowed=[]
            for name in models:
                try:gemini_client.validate_settings({'enabled':True,'model':name})
                except ValueError:continue
                allowed.append(name)
            message=f'نجح اتصال Gemini؛ {len(allowed)} نموذجًا متاحًا. فحص القائمة لا يختبر حصة التحليل.'
            if model and model not in allowed:message+=' النموذج المختار غير ظاهر في القائمة؛ اختر نموذجًا متاحًا.'
            return {'provider':provider,'message':message,'models':allowed}
        raise ConnectionError('خدمة غير معروفة.')
    except (gemini_client.GeminiError,official_sources.SourceUnavailable) as exc:
        # These adapters already discard raw HTTP exceptions and response bodies.
        raise ConnectionError(str(exc)) from None
    except ConnectionError:raise
    except Exception:
        raise ConnectionError('تعذر فحص الاتصال. تحقق من الشبكة وإعداد الخدمة ثم أعد المحاولة.') from None


def check_generation(value='',model=None,cancel=None):
    """Explicit small text-only probe using the production context schema/validator."""
    key=validate_key(value)or current_key('gemini')
    if not key:raise ConnectionError('أدخل مفتاح Gemini أولًا.')
    import gemini_context
    sentences=[{'start':0.,'end':4.,'text':'في لعبة فورتنايت نراجع تجربة اللعب.','asr_confidence':1.},
               {'start':4.,'end':8.,'text':'هذه تجربة تقنية قصيرة لاختبار تحليل النص فقط.','asr_confidence':1.}]
    try:
        client=gemini_client.GeminiClient(key=key,model=model,cancel=cancel)
        gemini_context.analyse('',sentences,client=client,cancel=cancel)
        return {'provider':'gemini','generation_checked':True,'model':client.model,
                'response_mode':client.last_response_mode,
                'message':'نجح تحليل نص تجريبي ببنية المحرر والتحقق من نتيجته. لم يُرسل تسجيلك؛ لا يثبت هذا جودة المونتاج أو تنزيل المصادر.'}
    except gemini_client.GeminiError as exc:raise ConnectionError(str(exc))from None
    except Exception:raise ConnectionError('تعذر اختبار التحليل الفعلي؛ لم يُرسل تسجيلك أو يُحفظ المفتاح.')from None
