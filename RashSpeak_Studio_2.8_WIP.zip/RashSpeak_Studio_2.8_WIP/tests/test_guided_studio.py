"""Declared fixtures: no live API, owner approvals, clipboard or private project writes."""
from copy import deepcopy
import gc
import threading
import tkinter as tk
from tkinter import ttk
import unittest
from unittest.mock import patch

from episode_background import intro_ranges,mark,fill
from source_usage import pending_candidates,approve_candidates,accepted
from official_sources import apply_permission
from recovery_guide import describe


def candidate(n='abcdefghijk'):
    return {'id':'youtube:'+n,'provider':'youtube','official_channel_checked':True,
            'channel_handle':'@DeclaredFixture','title':'Declared fixture','rights_status':'pending',
            'url':'https://www.youtube.com/watch?v='+n}


def blocked(quota=True):
    c=candidate()
    row={'id':'s0','start':0.,'end':4.,'game':'Elden Ring','idea':'Declared fixture','query':'gameplay',
         'status':'ai_unavailable'if quota else'needs_source_review','reason':'Gemini HTTP 429'if quota else'',
         'candidates':[c,deepcopy(c)]}
    data={'assets':[],'shots':[],'segments':[], 'media_plan':{'sentences':[row]},
          'quality':{'ready':False,'blockers':['Declared missing footage']},
          'ai_status':{'status':'analysed'},'services':{'gemini':{'enabled':True,'key_available':True}}}
    return {'key':'media','label':'مراجعة اللقطات','data':data,'previews':[],
            'last_good':deepcopy(data),'work':'.'}


class BulkSourceTests(unittest.TestCase):
    def test_deduplicates_and_grants_only_this_attempt_without_mutating_input(self):
        one=candidate();two=candidate('lmnopqrstuv');cfg={'permissions':{}}
        rows=[{'candidates':[one,deepcopy(one),two]}];before=deepcopy(rows)
        pending=pending_candidates(rows);self.assertEqual(len(pending),2)
        new,ids=approve_candidates(pending,cfg)
        self.assertEqual(set(ids),{one['id'],two['id']});self.assertEqual(cfg,{'permissions':{}})
        self.assertEqual(rows,before)
        for c in pending:
            applied=apply_permission(deepcopy(c),new);self.assertTrue(accepted(applied))
            self.assertEqual(applied['permission']['license'],'unknown')
            self.assertFalse(applied.get('scene_verified',False))
            self.assertEqual(applied['permission']['owner_decision']['scope'],c['id'])
        self.assertFalse(accepted(apply_permission(candidate('otherunused'),new)))
        same,ids=approve_candidates(pending,new);self.assertEqual(ids,[]);self.assertEqual(same,new)

    def test_does_not_approve_unverified_channel_or_unsupported_provider(self):
        unverified={**candidate(),'official_channel_checked':False}
        unsupported={**candidate('lmnopqrstuv'),'provider':'unknown'}
        new,ids=approve_candidates([unverified,unsupported],{})
        self.assertEqual(ids,[]);self.assertEqual(new['permissions'],{})


class IntroTests(unittest.TestCase):
    def segments(self):
        return [{'start':0.,'end':5.,'text':'مرحبا بكم','semantic':{'game':'','entities':[],
                 'search_intent':'general','confidence':.9,'idea':'Intro'}},
                {'start':5.,'end':10.,'text':'Elden Ring','story_topic':'Elden Ring','semantic':{'game':'Elden Ring'}}]

    def footage(self,**kw):
        return {'id':'asset1','kind':'video','game':'Elden Ring','scene_verified':True,'usage_approved':True,
                'license':'Declared fixture','source':'https://publisher.example/fixture','duration':8.,
                'width':1920,'height':1080,**kw}

    def plan(self,**kw):
        return {'sentences':[{'id':'intro','start':0.,'end':5.,'game':'','status':'awaiting_episode_footage',
                             'background_policy':'episode_montage','min_source_height':720},
                            {'id':'game','start':5.,'end':10.,'game':'Elden Ring','status':'downloaded',
                             'asset':self.footage(**kw)}]}

    def test_generic_intro_marked_without_assigning_game_or_changing_words(self):
        s=self.segments();before=deepcopy(s);self.assertEqual(intro_ranges(s),{(0.,5.)})
        plan={'sentences':[{'id':'intro','start':0.,'end':5.,'game':'','status':'needs_context'}]}
        mark(plan,s);self.assertEqual(plan['sentences'][0]['status'],'awaiting_episode_footage')
        self.assertEqual(s,before);self.assertEqual(plan['sentences'][0]['game'],'')
        s[0]['semantic']['entities']=['sword'];self.assertEqual(intro_ranges(s),set())

    def test_intro_fills_only_from_real_verified_episode_excerpt_and_bounds(self):
        p=fill(self.plan());row=p['sentences'][0]
        self.assertEqual(row['status'],'cached');self.assertEqual(row['game'],'')
        self.assertEqual(sum(r['end']-r['start']for r in row['visual_parts']),5.)
        for part in row['visual_parts']:
            self.assertLessEqual(part['asset_source_offset']+part['end']-part['start'],part['asset']['duration'])
            self.assertLessEqual(part['end']-part['start'],3.6)

    def test_legacy_generic_title_confidence_is_not_a_game_assignment(self):
        s=self.segments();s[0]['semantic'].update(confidence=.5,visual='title',queries=[])
        self.assertEqual(intro_ranges(s),{(0.,5.)})
        from media_director import sentence_requests,build_plan,materialize
        from unittest.mock import Mock
        archive=Mock();archive.find.return_value=[]
        plan=build_plan(s,archive,{})
        self.assertEqual(plan['sentences'][0]['status'],'awaiting_episode_footage')
        self.assertEqual(plan['sentences'][0]['game'],'')
        self.assertEqual(sentence_requests(s)[0]['background_policy'],'episode_montage')
        s[0]['semantic']['confidence']=.49;self.assertEqual(intro_ranges(s),set())
        s[0]['semantic'].update(confidence=.5,queries=['specific claimed event'])
        self.assertEqual(intro_ranges(s),set())

    def test_no_coverage_invented_from_unverified_low_quality_or_short_asset(self):
        for mutation in ({'scene_verified':False},{'usage_approved':False},{'visual_suitable':False},
                         {'height':240,'width':426},{'duration':2.}):
            with self.subTest(mutation=mutation):
                row=fill(self.plan(**mutation))['sentences'][0]
                self.assertEqual(row['status'],'awaiting_episode_footage');self.assertNotIn('visual_parts',row)


class GuidedLayoutTests(unittest.TestCase):
    def setUp(self):
        from gui import create_app
        self.root=create_app();self.root.geometry('1040x660');self.root.update()

    def tearDown(self):self.root.destroy();self.root=None;gc.collect()

    def review(self,quota=True):
        self.replies=[]
        class Bridge:
            def submit(_,token,response):self.replies.append(response)
        p=self.root.production;p.review_bridge=Bridge()
        self.request=blocked(quota);p.show_stage_review({'token':1,'request':self.request});self.root.update()
        return p.stage_review

    def test_modern_theme_and_minimum_size_default_has_one_recovery_action(self):
        panel=self.review()
        self.assertEqual(ttk.Style(self.root).theme_use(),'clam')
        self.assertFalse(panel.review_book.winfo_ismapped());self.assertFalse(panel.edit_actions.winfo_ismapped())
        self.assertFalse(panel.recovery_extras.winfo_ismapped())
        self.assertEqual(panel.recovery_guide.description['code'],'quota')
        self.assertFalse(panel.approve_button.winfo_ismapped())
        for w in (panel.primary_recovery_button,panel.more_recovery_button,panel.manual_button):
            self.assertTrue(w.winfo_ismapped());self.assertGreaterEqual(w.winfo_height(),w.winfo_reqheight())
            self.assertLessEqual(w.winfo_rooty()+w.winfo_height(),self.root.winfo_rooty()+self.root.winfo_height())
        self.assertFalse(self.root.production.header.winfo_ismapped())
        self.assertFalse(self.root.production.footer.winfo_ismapped())
        self.assertEqual(str(panel.approve_button['state']),'disabled')
        panel.manual_button.invoke();self.root.update()
        self.assertTrue(panel.review_book.winfo_ismapped());self.assertTrue(panel.edit_actions.winfo_ismapped())
        panel.manual_button.invoke();self.root.update();self.assertTrue(panel.guide_view.winfo_ismapped())

    def test_quota_beats_context_and_unknown_reset_stays_unknown(self):
        d=describe({'issues':[{'code':'context','label':'context'},{'code':'quota','label':'quota'}]})
        self.assertEqual(d['code'],'quota');self.assertFalse(d['quota_reset_time_known'])

    def test_only_explicit_bulk_button_saves_scoped_decisions_then_retries_media(self):
        with patch('stage_review_ui.save')as save,patch('ai_runtime.resume')as resume,\
             patch('official_sources.settings',return_value={'permissions':{}}):
            panel=self.review(False);save.assert_not_called();resume.assert_not_called()
            self.assertIs(panel.primary_recovery_button,panel.bulk_source_button)
            self.assertEqual(panel.recovery_guide.description['code'],'rights_review')
            panel.bulk_source_button.invoke();self.root.update()
            save.assert_called_once();cfg=save.call_args.args[0]
            self.assertEqual(set(cfg['permissions']),{candidate()['id']});resume.assert_not_called()
            self.assertEqual(self.replies[0]['action'],'revise')
            self.assertTrue(self.replies[0]['data']['refresh_sources'])
            self.assertEqual(self.replies[0]['data']['segments'],self.request['data']['segments'])
            self.assertFalse(self.root.production.cancel.is_set())

    def test_source_save_failure_keeps_review_without_submitting(self):
        panel=self.review(False)
        with patch('stage_review_ui.save',side_effect=OSError('Declared fixture')),\
             patch('official_sources.settings',return_value={'permissions':{}}):panel.bulk_source_button.invoke()
        self.assertEqual(self.replies,[]);self.assertFalse(panel.sent)

    def test_guided_settings_does_not_send_request_or_clear_quota_when_opened(self):
        panel=self.review()
        with patch('api_connections.current_key',return_value='DECLARED_FIXTURE'),\
             patch('ai_runtime.paused',return_value=True),patch('ai_runtime.resume')as resume,\
             patch('api_connections.check')as check,patch('api_connections.configure')as configure:
            panel.api_recovery_button.invoke();self.root.update()
            windows=[w for w in panel.winfo_children()if hasattr(w,'api_panels')]
            settings=windows[0].api_panels['gemini']
            self.assertEqual(len(settings.recovery_buttons),3);self.assertIn('429',settings.status.get())
            self.assertEqual(settings.entry.cget('show'),'•')
            resume.assert_not_called();check.assert_not_called();configure.assert_not_called()
            windows[0].destroy()
