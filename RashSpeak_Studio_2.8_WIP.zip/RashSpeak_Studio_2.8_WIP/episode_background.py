"""Intro backgrounds come only from verified footage already used by this episode."""
from copy import deepcopy
from smart_editor import licensed,normalize
from media_tools import source_resolution_ok


def intro_ranges(segments):
    first=next((s['start']for s in segments if(s.get('semantic')or{}).get('game')or s.get('story_topic')),None)
    if first is None or not 0<first<=60:return set()
    markers=('intro','host','hook','immersive','call to action','topic','series','transition','مقدمة','ترحيب','تقديم','القناة','تشويق','افتتاح')
    return {(s['start'],s['end'])for s in segments if s['end']<=first
            and not(s.get('semantic')or{}).get('game')and not s.get('story_topic')
            and not(s.get('semantic')or{}).get('entities')
            and(s.get('semantic')or{}).get('search_intent')=='general'
            and ((s.get('semantic')or{}).get('confidence',0)>=.75
                 or ((s.get('semantic')or{}).get('visual')=='title'
                     and not(s.get('semantic')or{}).get('queries')
                     and(s.get('semantic')or{}).get('confidence',0)>=.5))
            and any(normalize(m)in normalize((s.get('semantic')or{}).get('idea',''))for m in markers)}


def mark(plan,segments):
    ranges=intro_ranges(segments)
    for row in plan.get('sentences',[]):
        if row.get('status')=='needs_context'and(row['start'],row['end'])in ranges:
            row.update(background_policy='episode_montage',status='awaiting_episode_footage',reason='مقدمة عامة؛ تنتظر لقطات الحلقة المفحوصة ولا تحتاج تحديد لعبة.')
    return plan


def fill(plan):
    pool={}
    minimum=max((r.get('min_source_height',0) for r in plan['sentences'] if r.get('background_policy')=='episode_montage'),default=0)
    for row in plan['sentences']:
        for part in row.get('visual_parts')or[row]:
            a=part.get('asset',{})
            if(part.get('status')in('cached','downloaded')and part.get('role','clip')=='clip'and part.get('game')
               and a.get('kind')in('video','animation')and a.get('scene_verified')is True and licensed(a)
               and not a.get('editorial_card')and a.get('visual_suitable',True)is not False
               and source_resolution_ok(a,minimum)):pool.setdefault(a['id'],a)
    games={}
    for a in sorted(pool.values(),key=lambda a:(a.get('game',''),a['id'])):games.setdefault(a.get('game',''),[]).append(a)
    ordered=[]
    while any(games.values()):
        for values in games.values():
            if values:ordered.append(values.pop(0))
    used={};cursor=0
    for row in plan['sentences']:
        if row.get('background_policy')!='episode_montage'or row.get('status')not in('awaiting_episode_footage','planned'):continue
        at=row['start'];parts=[];local_used=deepcopy(used)
        while at<row['end']-.001 and ordered:
            eligible=[a for a in ordered if a.get('duration',0)-local_used.get(a['id'],0)>=min(.6,row['end']-at)]
            if not eligible:break
            a=eligible[cursor%len(eligible)];cursor+=1;offset=local_used.get(a['id'],0)
            seconds=min(3.6,row['end']-at,a['duration']-offset)
            parts.append({**deepcopy(row),'id':row['id']+':intro'+str(len(parts)),'parent_sentence_id':row['id'],
                          'start':at,'end':at+seconds,'status':'cached','asset':deepcopy(a),'asset_id':a['id'],'asset_source_offset':offset,
                          'reason':'خلفية مقدمة عامة من لقطات الحلقة المفحوصة؛ لا تُنسب لعبة إلى هذا الكلام.'})
            local_used[a['id']]=offset+seconds;at+=seconds
        if at>=row['end']-.001:
            row.update(status='cached',visual_parts=parts,reason='مقدمة عامة بخلفية من مشاهد الحلقة المتحققة.')
            if parts:row.update(asset=deepcopy(parts[0]['asset']),asset_id=parts[0]['asset_id'])
            used=local_used
    return plan
