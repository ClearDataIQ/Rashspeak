"""Explicit owner decisions are distinct from documented publisher permissions."""
from copy import deepcopy
from datetime import datetime,timezone
from urllib.parse import urlparse

OWNER='owner_responsibility'


def valid_decision(value):
    if not isinstance(value,dict) or value.get('accepted')is not True:return False
    scope=value.get('scope')
    if not isinstance(scope,str)or not 1<=len(scope)<=200 or '*'in scope or any(c.isspace()for c in scope):return False
    try:
        at=datetime.fromisoformat(value['at'])
        return at.tzinfo is not None and at.timestamp()<=datetime.now(timezone.utc).timestamp()+300
    except (KeyError,ValueError,TypeError,OverflowError):return False


def owner_grant(scope,hosts=()):
    import re
    hosts=list(dict.fromkeys(h.strip().lower()for h in hosts if h.strip()))
    if any(not re.fullmatch(r'(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9-]+',h)for h in hosts):
        raise ValueError('أدخل اسم المضيف فقط دون https أو مسار، أو اتركه تلقائيًا.')
    decision={'scope':scope.strip(),'accepted':True,'at':datetime.now(timezone.utc).isoformat()}
    if not valid_decision(decision):raise ValueError('حدد مصدرًا أو قناة بعينها.')
    return {'usage_basis':OWNER,'owner_decision':decision,'usage_approved':True,'download_allowed':True,
            'license':'unknown','evidence_url':'','download_hosts':hosts}


def owner_permission(candidate):
    grant=candidate.get('permission',{})
    if grant.get('usage_basis')!=OWNER or not valid_decision(grant.get('owner_decision')):return False
    scopes={candidate.get('id')}
    if candidate.get('official_channel_checked'):scopes.add(candidate.get('channel_handle'))
    if candidate.get('official_listing_checked'):scopes.add(candidate.get('permission_scope'))
    return (grant['owner_decision']['scope']in scopes and grant.get('usage_approved')is True
            and grant.get('download_allowed')is True)


def accepted(candidate):
    return candidate.get('rights_status')=='approved' or (candidate.get('rights_status')=='owner_accepted'and owner_permission(candidate))


def evidence(grant):
    if grant.get('usage_basis')==OWNER and valid_decision(grant.get('owner_decision')):
        return {'usage_basis':OWNER,'owner_decision':deepcopy(grant['owner_decision']),
                'publisher_permission_verified':False}
    return {}


def attach_hosts(candidate,grant):
    """Only bind the actual candidate host; acquisition still validates provider/TLS."""
    grant=deepcopy(grant)
    if grant.get('usage_basis')==OWNER and not grant.get('download_hosts')and candidate.get('provider')!='youtube':
        url=urlparse(candidate.get('url',''))
        grant['download_hosts']=[url.hostname.lower()]if url.scheme=='https'and url.hostname and not url.username and not url.password and url.port in (None,443)else[]
    return grant


def label(candidate):
    if candidate.get('rights_status')=='owner_accepted':return 'بقرار المالك — ترخيص غير موثق'
    if candidate.get('rights_status')=='approved':return 'تصريح مسجل'
    return 'ينتظر اختيار طريقة الاستخدام'


def pending_candidates(rows):
    from source_policy import ai_generated
    result={}
    for row in rows:
        for c in row.get('candidates',[]):
            if not c.get('id')or accepted(c)or ai_generated(c):continue
            if c.get('provider')=='youtube'and not c.get('official_channel_checked'):continue
            if c.get('provider')=='steam'and not c.get('official_listing_checked'):continue
            if c.get('provider')not in ('youtube','steam','commons_video','commons_images','google_images'):continue
            result.setdefault(c['id'],c)
    return list(result.values())


def approve_candidates(candidates,config):
    """Called only by the explicit bulk-use button; never grants visual verification."""
    from official_sources import apply_permission
    cfg=deepcopy(config);permissions=cfg.setdefault('permissions',{});created=[]
    for c in pending_candidates([{'candidates':candidates}]):
        if accepted(apply_permission(deepcopy(c),cfg)):continue
        permissions[c['id']]=owner_grant(c['id']);created.append(c['id'])
    return cfg,created
