"""Shared dark desktop theme; logical Arabic, editable keys and data stay untouched."""
from tkinter import ttk

BG='#0b1220';CARD='#132138';TEXT='#eef5ff';MUTED='#a4b9cf';ACCENT='#08beed'


def dark_titlebar(window):
    """Opt into this window's supported Windows dark chrome; no OS setting change."""
    import sys
    if sys.platform!='win32':return
    try:
        import ctypes
        from ctypes import wintypes
        parent=ctypes.windll.user32.GetParent
        parent.argtypes=[wintypes.HWND];parent.restype=wintypes.HWND
        hwnd=parent(window.winfo_id())or window.winfo_id()
        flag=ctypes.c_int(1)
        setter=ctypes.windll.dwmapi.DwmSetWindowAttribute
        setter.argtypes=[wintypes.HWND,wintypes.DWORD,ctypes.c_void_p,wintypes.DWORD]
        setter.restype=ctypes.c_long
        setter(hwnd,20,ctypes.byref(flag),ctypes.sizeof(flag))
    except (AttributeError,OSError):pass


def apply(root):
    style=ttk.Style(root);style.theme_use('clam')
    root.option_add('*Background',BG);root.option_add('*Foreground',TEXT)
    root.option_add('*Font','{Segoe UI} 10');root.option_add('*insertBackground',ACCENT)
    root.option_add('*selectBackground','#245a83');root.option_add('*selectForeground',TEXT)
    style.configure('.',background=BG,foreground=TEXT,font=('Segoe UI',10),bordercolor='#263b53',lightcolor=BG,darkcolor=BG)
    style.configure('TFrame',background=BG);style.configure('TLabel',background=BG,foreground=TEXT)
    style.configure('TNotebook',background=BG,borderwidth=0,tabmargins=0)
    style.configure('TNotebook.Tab',background=CARD,foreground=MUTED,padding=(12,8),borderwidth=0)
    style.map('TNotebook.Tab',background=[('selected','#1e4058'),('active','#1a3048')],foreground=[('selected',TEXT)])
    for name in ('TEntry','TCombobox','TSpinbox'):
        style.configure(name,fieldbackground=CARD,foreground=TEXT,insertcolor=ACCENT,arrowcolor=MUTED,padding=7)
        style.map(name,fieldbackground=[('readonly',CARD),('disabled','#111d2e')],foreground=[('readonly',TEXT),('disabled',MUTED)])
    for name in ('TCheckbutton','TRadiobutton'):
        style.configure(name,background=BG,foreground=TEXT,padding=5)
        style.map(name,background=[('active',CARD)],foreground=[('disabled',MUTED)])
    style.configure('TButton',background=CARD,foreground=TEXT,padding=(12,8),borderwidth=0)
    style.map('TButton',background=[('active','#25465f')],foreground=[('disabled',MUTED)])
    style.configure('Treeview',background=CARD,fieldbackground=CARD,foreground=TEXT,rowheight=32,borderwidth=0)
    style.configure('Treeview.Heading',background='#1c3049',foreground=MUTED,padding=8,borderwidth=0,font=('Segoe UI',10,'bold'))
    style.map('Treeview',background=[('selected','#245a83')])
    style.configure('TScrollbar',background='#263b53',troughcolor=BG,borderwidth=0,arrowcolor=MUTED)
    style.configure('TProgressbar',background=ACCENT,troughcolor=CARD,borderwidth=0)
    root.bind('<Map>',lambda event:dark_titlebar(root)if event.widget is root else None,add='+')
    return style
