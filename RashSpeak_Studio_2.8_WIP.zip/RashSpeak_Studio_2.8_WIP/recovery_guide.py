"""One current blocker, an honest saved-state summary, and concrete owner actions."""
import tkinter as tk
from tkinter import ttk
from rtl_ui import Label

BG='#132138';TEXT='#eef5ff';MUTED='#a4b9cf';CYAN='#08beed';YELLOW='#ffd24c'
GUIDES={
 'quota':('حصة الذكاء متوقفة','الصوت والتفريغ محفوظان؛ اختيار المشاهد ينتظر تجدد الحصة.',
          ['انتظر تجدد الحصة لدى المزوّد.','افتح إعدادات الحصة، ثم استأنف الطلبات بعد تجددها.','اختبر التحليل مرة واحدة، ثم اضغط متابعة اللقطات.'],'api','فتح إعدادات الحصة'),
 'gemini_missing':('أضف مفتاح خدمة الفهم','لا يوجد مفتاح متاح للمزوّد المختار.',
          ['افتح إعدادات الذكاء واختر جهة إصدار المفتاح.','الصق المفتاح واحفظه، ثم اختبر التحليل.','ارجع واضغط متابعة اللقطات.'],'api','إضافة المفتاح'),
 'gemini_disabled':('فهم المحتوى معطّل','يلزم تفعيله لفحص المشاهد الجديدة.',
          ['افتح إعدادات الذكاء وفعّل فهم المحتوى.','احفظ الإعداد، ثم ارجع واضغط متابعة اللقطات.'],'api','تفعيل فهم المحتوى'),
 'rights_review':('اعتماد المصادر بضغطة واحدة','الزر يعتمد المصادر الموجودة في هذه المحاولة على مسؤوليتك.',
          ['اضغط اعتماد مصادر المحاولة والمتابعة.','لمراجعة مصدر بعينه افتح اختيار المصادر من خيارات أخرى.'],'sources','اختيار المصادر'),
 'source_unavailable':('تعذر الوصول إلى مصدر لقطات','اتصال المصدر أو تنزيله لم يكتمل.',
          ['افتح مصدرًا من القائمة وتحقق أنه يعمل عندك.','جرّب مصدرًا آخر أو أضف لقطاتك المحلية.','أعد متابعة اللقطات بعد حل الوصول.'],'sources','فحص المصادر'),
 'download_failed':('لم يكتمل تنزيل أحد المصادر','الملفات السليمة باقية في الأرشيف.',
          ['افتح المصدر وتحقق من رابط الملف والمضيف الاختياري.','جرّب مصدرًا آخر إذا رفض الموقع التنزيل.','اضغط متابعة اللقطات لإكمال الناقص.'],'sources','فحص المصدر'),
 'context':('السياق يحتاج مراجعة','بعض الكلام يحتاج خلفية مناسبة دون إلصاق لعبة به.',
          ['راجع الجملة في تفاصيل اللقطات.','المقدمة العامة تستخدم خلفية من لقطات الحلقة المتحققة.'],'details','عرض الجمل المحتاجة للمراجعة'),
 'episode_background':('المقدمة تنتظر لقطات الحلقة','لا تحتاج تحديد لعبة للترحيب أو الكلام العام.',
          ['أكمل توفير لقطات الألعاب أولًا.','تُركّب خلفية المقدمة من لقطات الحلقة التي فُحصت بالفعل.'],'sources','اختيار مصادر الحلقة'),
 'no_visual_match':('لم تكتمل اللقطات المطابقة','المصادر المتاحة لم تثبت مشاهد تغطي الكلام.',
          ['راجع المصادر أو أضف لقطات محلية مطابقة.','اضغط متابعة اللقطات لفحص المصادر الجديدة.'],'sources','مراجعة المصادر'),
 'missing_source':('نحتاج مصدر لقطات إضافيًا','لم يظهر مصدر مناسب لبعض أجزاء الكلام.',
          ['اختر مصدرًا آخر للعبة أو أضف لقطاتك.','اضغط متابعة اللقطات بعد الإضافة.'],'sources','اختيار مصدر آخر'),
}
PRIORITY=['quota','ai_account','gemini_missing','gemini_disabled','model_unavailable','ai_request','ai_unavailable','ai_response',
          'rights_review','source_unavailable','download_failed','invalid_selection','missing_source','no_visual_match','context','episode_background']


def describe(report):
    issues=report.get('issues',[])
    ordered=sorted(issues,key=lambda i:PRIORITY.index(i['code'])if i['code']in PRIORITY else 999)
    code=ordered[0]['code']if ordered else'no_visual_match'
    fallback=('نحتاج مراجعة اتصال خدمة الفهم','التسجيل والصوت المنظف محفوظان.',
              ['افتح إعدادات الذكاء واقرأ نتيجة الاختبار.','عالج السبب الظاهر ثم ارجع لمتابعة اللقطات.'],'api','فحص اتصال الذكاء')
    title,summary,steps,action,button=GUIDES.get(code,fallback)
    return {'code':code,'title':title,'summary':summary,'steps':steps,'action':action,'button':button,
            'other_issues':[i['label']for i in ordered[1:]],'quota_reset_time_known':False}


class RecoveryGuide(tk.Frame):
    def __init__(self,parent,report):
        super().__init__(parent,bg=BG)
        self.description=describe(report)
        canvas=tk.Canvas(self,bg=BG,highlightthickness=0);self.canvas=canvas
        scroll=ttk.Scrollbar(self,orient='vertical',command=canvas.yview)
        canvas.configure(yscrollcommand=scroll.set);scroll.pack(side='right',fill='y');canvas.pack(side='left',fill='both',expand=True)
        body=tk.Frame(canvas,bg=BG,padx=18,pady=12);self.body=body
        item=canvas.create_window((0,0),window=body,anchor='nw')
        body.bind('<Configure>',lambda e:canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>',lambda e:canvas.itemconfigure(item,width=e.width))
        Label(body,text='توقّف مؤقت — تحتاج خطوة منك',bg=BG,fg=YELLOW,font=('Segoe UI',11,'bold')).pack(anchor='e')
        Label(body,text=self.description['title'],bg=BG,fg=TEXT,font=('Segoe UI',21,'bold')).pack(anchor='e',pady=(4,8))
        Label(body,text=self.description['summary'],bg=BG,fg=TEXT,font=('Segoe UI',11),justify='right',wraplength=840).pack(anchor='e')
        Label(body,text='محفوظ: الصوت المنظف • التفريغ • قرارات القص',bg=BG,fg='#6fe3aa',font=('Segoe UI',10)).pack(anchor='e',pady=9)
        self.step_labels=[]
        for i,step in enumerate(self.description['steps'],1):
            label=Label(body,text=f'{i}.  {step}',bg=BG,fg=TEXT,font=('Segoe UI',12),justify='right',wraplength=840)
            label.pack(anchor='e',pady=5);self.step_labels.append(label)
        if self.description['code']=='quota':
            Label(body,text='موعد تجدد الحصة غير متاح في الرد؛ زر الاستئناف لا يزيد الحصة.',bg=BG,fg=MUTED,font=('Segoe UI',10),wraplength=840,justify='right').pack(anchor='e',pady=6)
        others=self.description['other_issues']
        if others:Label(body,text='بعدها: '+' • '.join(dict.fromkeys(others)),bg=BG,fg=MUTED,font=('Segoe UI',10),wraplength=840,justify='right').pack(anchor='e',pady=6)
        def wheel(event):canvas.yview_scroll(-int(event.delta/120),'units');return 'break'
        def bind_scroll(widget):
            widget.bind('<MouseWheel>',wheel)
            for child in widget.winfo_children():bind_scroll(child)
        bind_scroll(body);canvas.bind('<MouseWheel>',wheel)
