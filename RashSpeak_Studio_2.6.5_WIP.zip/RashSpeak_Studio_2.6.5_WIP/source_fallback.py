"""Free internet video fallback, with per-run provider health and shared searches."""
from copy import deepcopy
import hashlib

import requests

from licensed_media import game_key, search
from media_tools import Cancelled
from official_sources import FreeImages, SourceUnavailable, YouTubeOfficial


class CommonsVideos:
    def __init__(self, cancel=None):
        self.cancel=cancel
        self.cache={}

    def search(self, request):
        role=request.get('role','clip');mood=request.get('mood','')
        topic=request['game']
        if role=='meme':
            topic={'humor':'laughing man','surprise':'surprised man','frustration':'frustrated man'}.get(mood,'reaction')
        # Broad game discovery is reusable. Exact sentence/entity matching happens on
        # the real video afterwards, never on a title or a query alone.
        key=(game_key(topic),role,mood)
        if key not in self.cache:
            try:
                self.cache[key]=search(topic,role,mood,self.cancel)
            except Cancelled:
                raise
            except (requests.RequestException,RuntimeError,ValueError):
                raise SourceUnavailable('مصدر فيديوهات Commons المجاني غير متاح مؤقتًا.') from None
        result=[]
        for item in self.cache[key]:
            seconds=item.get('duration',0)
            if not 0<seconds<=1800:
                continue
            candidate={'id':'commons-video:'+hashlib.sha256(item['source'].encode()).hexdigest()[:20],
                'provider':'commons_video','url':item['url'],'source':item['source'],'title':item['title'],
                'acquisition_version':'cfr30-hd2-'+hashlib.sha256(item['url'].encode()).hexdigest()[:12],
                'game':request['game'],'event':'','entities':[], 'role':role,'mood':mood,
                'author':item['author'],'license':item['license'],'duration':seconds,
                'rights_status':'pending' if item.get('rights_review_required') else 'approved','scene_status':'needs_video_review',
                'commons_metadata':deepcopy(item),
                'permission':{'usage_approved':not item.get('rights_review_required',False),'download_allowed':not item.get('rights_review_required',False),'license':item['license'],
                              'evidence_url':item['license_url'],'download_hosts':['upload.wikimedia.org']}}
            if item.get('rights_review_required'):
                from official_sources import apply_permission
                candidate=apply_permission(candidate)
            result.append(candidate)
        return result


class VideoSources:
    """YouTube first; always offer the free pool for scene/rights rejection too.

    A provider outage is attempted once per run, rather than spending the entire
    search budget on the same network/credential failure for every sentence.
    """
    def __init__(self, primary=None, fallback=None, cancel=None,alternatives=None):
        self.primary=primary or YouTubeOfficial(cancel=cancel)
        self.fallback=fallback or CommonsVideos(cancel=cancel)
        self.failures={};self.attempts=[]
        self.alternatives=alternatives or []

    def cache_key(self, request):
        return (game_key(request['game']),request['event'],
                request['kind'],request.get('role','clip'),request.get('mood',''))

    def search(self, request):
        candidates=[];errors=[]
        routes=[('youtube',self.primary),*self.alternatives,('commons_video',self.fallback)]
        for name,provider in routes:
            if name in self.failures:
                errors.append(self.failures[name]);continue
            try:
                discovery=deepcopy(request)
                if name=='youtube' and not request['event'] and request.get('role','clip')=='clip':
                    discovery['query']=request['game']+' official gameplay'
                found=provider.search(discovery)
                self.attempts.append({'provider':name,'game':request['game'],
                                      'count':len(found),'status':'ok'})
                # Interleave usable sources so pending YouTube rights do not hide
                # the actual fallback behind the scene-analysis candidate limit.
                candidates.extend(found[:5])
            except SourceUnavailable as exc:
                message=str(exc)
                if exc.provider_wide:self.failures[name]=message
                errors.append(message)
                self.attempts.append({'provider':name,'game':request['game'],
                                      'count':0,'status':'unavailable','reason':message})
        if not candidates and len(errors)==len(routes):
            raise SourceUnavailable(' | '.join(errors))
        # Discovery is broader than acquisition; only verified, approved excerpts download.
        unique={c['id']:c for c in candidates}
        return sorted(unique.values(),key=lambda c:c.get('rights_status')!='approved')[:15]


def providers(cancel=None):
    from steam_sources import SteamOfficial
    return {'youtube':VideoSources(cancel=cancel,alternatives=[('steam',SteamOfficial(cancel=cancel))]),'images':FreeImages(cancel=cancel)}
