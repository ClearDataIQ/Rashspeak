"""Reproducible variation among already verified alternatives, never random relevance."""
from copy import deepcopy
import hashlib
import math
import random


def rng_for(seed, key=''):
    value=hashlib.sha256(f'{seed}|{key}'.encode()).hexdigest()
    return random.Random(int(value,16))


def source_id(asset):
    from urllib.parse import urlsplit,urlunsplit
    value=asset.get('source_family')or asset.get('original_source_id')or asset.get('id','')
    if asset.get('source_family')or asset.get('original_source_id'):return value
    link=asset.get('rights',{}).get('source')or asset.get('source')or asset.get('url','')
    if link.startswith(('https://','http://')):
        parsed=urlsplit(link);return urlunsplit((parsed.scheme,parsed.netloc,parsed.path,parsed.query if 'youtube.com'in parsed.netloc else'', ''))
    return value


def choose_options(options, used, seed=None, previous_source=None):
    if not options:return []
    choices=list(options)
    rng_for(seed,'source-choice').shuffle(choices)
    families={s['candidate']['id']:source_id(s['candidate'])for sequence in choices for s in sequence}
    family_usage={}
    for key,ranges in used.items():
        family=families.get(key,key)
        family_usage[family]=family_usage.get(family,0)+sum(max(0,b-a)for a,b in ranges)
    def rank(sequence):
        keys=[source_id(s['candidate'])for s in sequence]
        repeat=bool(keys and keys[0]==families.get(previous_source,previous_source))
        usage=sum(family_usage.get(k,0)for k in keys)
        overlap=sum(max(0,min(b,s['source_out'])-max(a,s['source_in']))
                    for s in sequence for a,b in used.get(s['candidate']['id'],[]))
        return repeat,usage,overlap
    return deepcopy(min(choices,key=rank))


def spread(selections, used, seed=None):
    result=[]
    for index,item in enumerate(selections):
        selected=deepcopy(item);source=selected['candidate'];key=source['id']
        seconds=selected['source_out']-selected['source_in'];occupied=used.setdefault(key,[])
        overlaps=any(a<selected['source_out']and b>selected['source_in']for a,b in occupied)
        if overlaps or seed is not None:
            # Shifting is bounded by the very same verified action scene.
            scene=selected.get('verified_scene')
            if scene is None:
                scene=next((s for s in source.get('reviewed_scenes',[])if s['start']<=selected['source_in']and selected['source_out']<=s['end']),None)
            if scene:
                windows=[];cursor=scene['start']
                for lo,hi in sorted(occupied):
                    if hi<=cursor or lo>=scene['end']:continue
                    if lo-cursor>=seconds-.000001:windows.append((cursor,lo-seconds))
                    cursor=max(cursor,hi)
                if scene['end']-cursor>=seconds-.000001:windows.append((cursor,scene['end']-seconds))
                if windows:
                    if seed is None:start=windows[0][0]
                    else:
                        rng=rng_for(seed,f'{key}:{index}');lo,hi=rng.choice(windows)
                        first,last=math.ceil(lo*30-1e-8),math.floor(hi*30+1e-8)
                        start=rng.randint(first,last)/30 if first<=last else lo
                    selected.update(source_in=start,source_out=start+seconds)
                    selected['reason']+='؛ جزء غير مستخدم داخل مشهد الفعل المراجع نفسه'
                elif overlaps:selected['reason']+='؛ لم يتوفر جزء آخر مطابق دون تكرار'
        occupied.append((selected['source_in'],selected['source_out']));result.append(selected)
    return result


def analysis_windows(duration, seed=None, key='', span=180.):
    last=max(0.,duration-span)
    starts=list(dict.fromkeys(round(x,3)for x in (0.,last/2,last)))
    if seed is not None:rng_for(seed,key).shuffle(starts)
    return starts


def source_stats(ranges,start,end):
    by_source={}
    for row in ranges:
        a,b=max(start,row['start']),min(end,row['end'])
        if b>a:by_source.setdefault(row['source_id'],[]).append((a,b))
    def covered(spans):
        total=0.;cursor=-float('inf')
        for a,b in sorted(spans):
            total+=max(0.,b-max(a,cursor));cursor=max(cursor,b)
        return total
    seconds={key:covered(spans)for key,spans in by_source.items()}
    total=covered([span for spans in by_source.values()for span in spans])
    meaningful={k:v for k,v in seconds.items()if v>=max(2.,(end-start)*.05)-.001}
    return {'source_count':len(meaningful),'source_seconds':seconds,
            'covered_seconds':total,'dominant_source_ratio':max(seconds.values(),default=0)/max(.001,total)}
