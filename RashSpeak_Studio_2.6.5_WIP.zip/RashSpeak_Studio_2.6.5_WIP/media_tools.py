"""Local media tools, with cancellation and bounded subprocess execution."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
from app_paths import app_dir


class Cancelled(RuntimeError):
    pass


def source_resolution_ok(asset, minimum=0):
    """Check native source pixels, never the dimensions of an upscaled export."""
    if minimum <= 0:
        return True
    height = asset.get('height', 0)
    if asset.get('kind') == 'image':
        return min(asset.get('width', 0), height) >= minimum
    return height >= minimum


def tool(name):
    explicit = os.getenv('RASH_' + name.upper())
    candidates = [explicit, shutil.which(name),
                  str(app_dir() / 'tools' / (name + '.exe'))]
    # Reuse an installed local tool on this device; no machine-wide PATH changes.
    if os.name == 'nt':
        candidates.append(str(Path(os.getenv('LOCALAPPDATA', '')) / 'Programs/Stremio' / (name + '.exe')))
    for path in candidates:
        if path and Path(path).is_file():
            return str(Path(path).resolve())
    raise RuntimeError(f'{name} غير موجود. ضع FFmpeg وffprobe في مجلد tools أو أضفهما إلى PATH.')


def run(args, cwd=None, cancel=None, timeout=600):
    args = [str(x) for x in args]
    if args[0] in ('ffmpeg', 'ffprobe'):
        args[0] = tool(args[0])
        args[1:1] = ['-protocol_whitelist', 'file,pipe']
    if cancel and cancel.is_set():
        raise Cancelled('أُلغي التنفيذ.')
    process = subprocess.Popen(args, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                               creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
    deadline = time.monotonic() + timeout
    try:
        while True:
            if cancel and cancel.is_set():
                raise Cancelled('أُلغي التنفيذ.')
            if time.monotonic() > deadline:
                raise TimeoutError('انتهت مهلة معالجة الوسائط.')
            try:
                stdout, stderr = process.communicate(timeout=.2)
                break
            except subprocess.TimeoutExpired:
                continue
    except BaseException:
        process.kill()
        process.communicate()
        raise
    if process.returncode:
        tail = stderr.decode('utf-8', errors='replace').splitlines()[-12:]
        raise RuntimeError('تعذرت معالجة الوسائط:\n' + '\n'.join(tail))
    return stdout.decode('utf-8', errors='replace')


def probe(path):
    return json.loads(run(['ffprobe', '-v', 'error', '-show_format', '-show_streams', '-of', 'json', path], timeout=30))


def duration(path, stream_type=None):
    info = probe(path)
    if stream_type and not any(s['codec_type'] == stream_type for s in info['streams']):
        raise ValueError('الملف لا يحتوي على المسار المطلوب: ' + stream_type)
    value = float(info.get('format', {}).get('duration', 0))
    if not 0 < value < 24 * 3600:
        raise ValueError('مدة الوسائط غير صالحة.')
    return value


def thumbnail(source, output, at=0, cancel=None):
    Path(output).parent.mkdir(parents=True, exist_ok=True)
    run(['ffmpeg', '-v', 'error', '-y', '-ss', str(at), '-i', source,
         '-frames:v', '1', '-vf', 'scale=480:270:force_original_aspect_ratio=decrease,pad=480:270:(ow-iw)/2:(oh-ih)/2', output], cancel=cancel)
    return str(output)
