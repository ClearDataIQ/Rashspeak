import array
import math
from pathlib import Path
import tempfile
import tkinter as tk
import unittest
from unittest.mock import Mock,patch
import wave

from audio_edit import render_audio
from audio_preview import Audition
from rtl_ui import visual


def write_wave(path,samples,channels=1,rate=48000):
    with wave.open(str(path),'wb')as f:
        f.setnchannels(channels);f.setsampwidth(2);f.setframerate(rate);f.writeframes(samples.tobytes())


def read_wave(path):
    with wave.open(str(path),'rb')as f:return f.getnchannels(),array.array('h',f.readframes(f.getnframes()))


class VoiceProcessingTests(unittest.TestCase):
    def test_delayed_stereo_voice_channels_are_not_summed_into_an_echo(self):
        with tempfile.TemporaryDirectory()as folder:
            root=Path(folder);source=root/'stereo.wav';output=root/'clean.wav'
            samples=array.array('h',[0])*(48000*2)
            samples[9600*2]=12000;samples[12960*2+1]=12000
            write_wave(source,samples,2);before=source.read_bytes()
            analysis={'keeps':[[0.,1.]],'clean_duration':1.}
            render_audio(source,analysis,output,processing={'highpass':0,'denoise':False,'normalize':False})
            channels,actual=read_wave(output)
            self.assertEqual(channels,2);self.assertEqual(actual,samples);self.assertEqual(source.read_bytes(),before)

    def test_loud_and_quiet_speech_receive_the_same_fixed_gain_without_tail_pumping(self):
        samples=array.array('h',(round((6000 if i<48000 else 1200 if i<96000 else 200)*math.sin(i*2*math.pi*280/48000))for i in range(144000)))
        with tempfile.TemporaryDirectory()as folder:
            root=Path(folder);source=root/'voice.wav';output=root/'clean.wav';write_wave(source,samples)
            analysis={'keeps':[[0.,3.]],'clean_duration':3.}
            render_audio(source,analysis,output,processing={'highpass':0,'denoise':False})
            channels,actual=read_wave(output);gain=10**(analysis['audio_processing']['fixed_gain_db']/20)
            self.assertEqual(channels,1);self.assertEqual(len(actual),len(samples))
            for start in (10000,60000,110000):
                self.assertLess(max(abs(actual[i]-round(samples[i]*gain))for i in range(start,start+500)),3)
            self.assertLessEqual(max(abs(v)for v in actual),round(32768*.8))

    def test_optional_noise_filter_is_gentle_and_preserves_timing(self):
        samples=array.array('h',(round(5000*math.sin(i*2*math.pi*240/48000))for i in range(96000)))
        with tempfile.TemporaryDirectory()as folder:
            root=Path(folder);source=root/'tone.wav';output=root/'clean.wav';write_wave(source,samples)
            render_audio(source,{'keeps':[[0.,2.]],'clean_duration':2.},output,
                         processing={'highpass':0,'denoise':True,'noise_floor':-50,'normalize':False})
            _,actual=read_wave(output);self.assertEqual(len(actual),len(samples))
            self.assertGreater(max(abs(v)for v in actual[24000:48000]),3500)


class AuditionTests(unittest.TestCase):
    def test_switching_original_and_clean_stops_previous_owned_player_first(self):
        events=[];processes=[]
        def spawn(command,**kwargs):
            self.assertNotIn('shell',kwargs);events.append('start')
            p=Mock();p.poll.return_value=None;p.terminate.side_effect=lambda:events.append('stop');p.wait.side_effect=lambda **kw:events.append('wait');processes.append(p);return p
        with tempfile.TemporaryDirectory()as folder:
            original=Path(folder)/'original.wav';clean=Path(folder)/'clean.wav';original.touch();clean.touch()
            player=Audition(spawn=spawn,executable='/declared/ffplay')
            player.start(original);player.start(clean);player.stop()
        self.assertEqual(events,['start','stop','wait','start','stop','wait'])
        self.assertTrue(all(p.terminate.call_count==1 for p in processes))

    def test_original_mp4_in_audio_review_uses_same_exclusive_player(self):
        from types import SimpleNamespace
        from production_ui import ProductionPanel
        root=tk.Tk();root.withdraw();panel=ProductionPanel(root)
        try:
            panel.stage_review=SimpleNamespace(request={'key':'audio'})
            with tempfile.TemporaryDirectory()as folder:
                path=Path(folder)/'voice.mp4';path.touch()
                with patch('audio_preview.open_preview',return_value='owned-player')as preview,patch('production_ui.subprocess.Popen')as external:
                    self.assertEqual(panel.open(path),'owned-player');preview.assert_called_once_with(panel,path);external.assert_not_called()
        finally:panel.stage_review=None;root.destroy()


class ArabicServiceUITests(unittest.TestCase):
    def test_latin_service_name_does_not_reverse_arabic_paragraph_or_crash_on_isolates(self):
        from arabic_reshaper import reshape
        from bidi.algorithm import get_display
        text='Gemini HTTP 404: تعذر الاتصال بالنموذج'
        self.assertEqual(visual(text),get_display(reshape(text),base_dir='R'))
        self.assertIn('Gemini HTTP 404',visual(text))
        self.assertIn('HTTP 404',visual('تعذر Gemini \u2066HTTP 404\u2069 اتصال'))

    def test_gemini_input_keeps_raw_key_and_status_keeps_logical_arabic(self):
        from api_settings_ui import open_settings
        root=tk.Tk();root.withdraw()
        try:
            with patch('api_connections.current_key',return_value=''):
                window=open_settings(root,'gemini');panel=window.api_panels['gemini'];root.update()
            panel.key.set('DECLARED_TEST_KEY-_123');self.assertEqual(panel.entry.get(),'DECLARED_TEST_KEY-_123')
            self.assertEqual(panel.entry.cget('justify'),'left');self.assertTrue(panel.entry.cget('show'))
            panel.status.set('Gemini جاهز للاختبار — HTTP 200');root.update()
            self.assertEqual(panel.status.get(),'Gemini جاهز للاختبار — HTTP 200')
            self.assertEqual(window.api_notebook.select(),str(panel))
        finally:root.destroy()

    def test_natural_voice_reset_disables_fft_denoise_and_preserves_boolean_controls(self):
        from stage_review_ui import StageReviewPanel
        import threading
        root=tk.Tk();root.withdraw()
        try:
            data={'processing':{'highpass':65,'denoise':True,'noise_floor':-25,'loudness':-16},'words':[],'edits':[]}
            panel=StageReviewPanel(root,{'key':'audio','label':'تعديل الصوت','data':data,'previews':[],'last_good':data},
                lambda r:None,lambda p:None,threading.Event())
            panel.natural_voice_button.invoke();panel.controls['normalize'].set(False)
            collected=panel.collect()['processing']
            self.assertIs(collected['denoise'],False);self.assertIs(collected['normalize'],False)
            self.assertEqual(collected['noise_floor'],-50);self.assertTrue(panel.dirty)
        finally:root.destroy()
