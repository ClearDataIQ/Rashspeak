"""RashSpeak 2.1 deterministic, reviewable offline editing pipeline."""
import csv
import hashlib
import json
import math
from pathlib import Path
import re
import unicodedata

import captions
from media_tools import duration, probe, thumbnail

VIDEO = {'.mp4', '.mov', '.mkv', '.webm', '.avi', '.m4v', '.ogv'}
IMAGE = {'.png', '.jpg', '.jpeg', '.gif', '.webp'}
SYNONYMS = {'بلايستيشن': 'playstation', 'بلاي ستيشن': 'playstation', 'ps5': 'playstation',
            'اكس بوكس': 'xbox', 'اكسبوكس': 'xbox', 'إكس بوكس': 'xbox', 'ستيم': 'steam',
            'كول اوف ديوتي': 'cod', 'call of duty': 'cod', 'ماين كرافت': 'minecraft',
            'ماينكرافت': 'minecraft', 'فورت نايت': 'fortnite', 'فورتنايت': 'fortnite'}
SYNONYMS.update({'جوست اوف تسوشيما':'ghost of tsushima','غوست اوف تسوشيما':'ghost of tsushima',
                 'ذا ويتشر 3':'the witcher 3','ويتشر 3':'the witcher 3','the witcher 3 wild hunt':'the witcher 3',
                 'الدن رينج':'elden ring','الدن رين':'elden ring','إلدن رينغ':'elden ring',
                 'ريدد ريدمبشن 2':'red dead redemption 2','ريد ديد ريدمبشن 2':'red dead redemption 2',
                 'بريث اوف ذا وايلد':'zelda botw','the legend of zelda breath of the wild':'zelda botw',
                 'جي تي اي 6':'gta 6','gta6':'gta 6','هيلدايفرز 2':'helldivers 2','هيل دايفرز 2':'helldivers 2'})
SYNONYMS.update({'ردد ردمشن تو':'red dead redemption 2',
                 'كوست of tsushima':'ghost of tsushima',
                 'ريد ديد ريدمبشن تو':'red dead redemption 2',
                 'سيبر بنك':'cyberpunk','سيبر بانك':'cyberpunk','سايبر بانك':'cyberpunk',
                 'اساسن كريد ميراج':"assassin's creed mirage",'باتلفيلد':'battlefield','باتل فيلد':'battlefield',
                 'باتلفيل':'battlefield','باتل فيل':'battlefield'})
SENSITIVE = ('وفاه', 'وفاة', 'مات', 'ضحايا', 'حرب', 'كارثه', 'تسريح', 'اغلاق', 'انتحار', 'تحرش', 'مرض', 'عزاء')
CRUCIAL = ('سعر', 'موعد', 'تاريخ', 'تحذير', 'رسمي', 'مؤكد', 'اشترك', 'تابع القناه', 'رابط', 'اعلان', 'مصدر', 'تقرير', 'اطلاق', 'اصدار')
REACTIONS = {'humor': ('هههه', 'مزحه', 'نكت', 'يضحك', 'ضحكت'),
             'frustration': ('قهر', 'جلطني', 'محبط'), 'surprise': ('مفاجاه', 'ما توقعت', 'انصدمت')}
IMPORTANT_FORMS=('السعر','الاسعار','الموعد','التاريخ','التحذير','الضحايا','الوفاه','التسريح',
                 'دولار','ريال','ستين','سبعين','ثمانين','تسعين','مليون','مليار','اشتركوا','تابعونا')


def normalize(text):
    text = unicodedata.normalize('NFKC', str(text)).lower()
    text = re.sub('[\u064b-\u065f\u0670\u0640]', '', text)
    text = text.translate(str.maketrans('أإآىة', 'ااايه'))
    for key, value in sorted(SYNONYMS.items(), key=lambda kv: -len(kv[0])):
        key = key.translate(str.maketrans('أإآىة', 'ااايه'))
        text = re.sub(r'(?<!\w)' + re.escape(key) + r'(?!\w)', value, text)
    return ' '.join(re.findall(r'[\w]+', text))


def contains(text, term):
    return (' ' + normalize(term) + ' ') in (' ' + normalize(text) + ' ')


def licensed(asset):
    from source_policy import ai_generated
    if ai_generated(asset):return False
    return asset.get('usage_approved') is True and bool(asset.get('license', '').strip()) and bool(asset.get('source', '').strip()) and normalize(asset['license']) not in ('unknown', 'غير معروف')


def fingerprint(path):
    stat = Path(path).stat()
    return {'size': stat.st_size, 'mtime_ns': stat.st_mtime_ns}


def save(data, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    temp.replace(path)


def import_asset(path, role='clip', tags=None, game='', mood='', license='', source='', approved=False,
                 previews=None, cancel=None):
    path = Path(path).resolve()
    if not path.is_file() or path.suffix.lower() not in VIDEO | IMAGE:
        raise ValueError('اختر فيديو أو PNG/JPG/GIF/WebP محليًا.')
    if role not in ('clip', 'meme'):
        raise ValueError('نوع أصل غير صالح.')
    animated = path.suffix.lower() in {'.gif', '.webp'}
    still = path.suffix.lower() in {'.png', '.jpg', '.jpeg'}
    if path.suffix.lower() in IMAGE:
        from PIL import Image
        with Image.open(path) as image:
            width, height = image.size
            still = getattr(image, 'n_frames', 1) == 1
            seconds = 0
            if not still:
                for index in range(image.n_frames):
                    image.seek(index)
                    image.load()
                    seconds += image.info.get('duration', 100) / 1000
            if previews:
                image.seek(0)
                preview = image.convert('RGBA')
    else:
        info = probe(path)
        stream = next((s for s in info['streams'] if s['codec_type'] == 'video'), None)
        if not stream:
            raise ValueError('الملف لا يحتوي على صورة أو فيديو قابل للقراءة.')
        width, height = int(stream['width']), int(stream['height'])
        seconds = float(info.get('format', {}).get('duration') or 0)
    asset_id = hashlib.sha256((str(path) + ':' + role).encode()).hexdigest()[:16]
    asset = {'id': asset_id, 'path': str(path), 'kind': 'image' if still else 'animation' if animated else 'video',
             'role': role, 'game': game.strip(), 'tags': list(tags or []), 'mood': mood.strip(),
             'license': license.strip(), 'source': source.strip(), 'usage_approved': bool(approved),
             'width': width, 'height': height, 'duration': seconds,
             'fingerprint': fingerprint(path), 'thumbnail': ''}
    if not still and (not math.isfinite(seconds) or seconds <= .05):
        raise ValueError('مدة أصل غير صالحة.')
    if previews:
        preview_path = Path(previews) / f'{asset_id}.png'
        if path.suffix.lower() in IMAGE:
            preview_path.parent.mkdir(parents=True, exist_ok=True)
            preview.thumbnail((480, 270))
            preview.save(preview_path)
            asset['thumbnail'] = str(preview_path.resolve())
        else:
            asset['thumbnail'] = thumbnail(path, preview_path, cancel=cancel)
    return asset


def match(text, assets, cue=''):
    candidates = []
    for asset in assets:
        if asset['role'] != 'clip' or not licensed(asset):
            continue
        tags = [asset.get('game', ''), *asset.get('tags', [])]
        if cue:
            hits = [tag for tag in tags if normalize(tag) == normalize(cue)]
            score = 1.0 if hits else 0
        else:
            # A named game must match too, even if a generic scene tag overlaps.
            if asset.get('game') and not contains(text, asset['game']):
                continue
            hits = [tag for tag in tags if tag and contains(text, tag)]
            score = min(.98, .70 + .09 * len(hits)) if hits else 0
        if score:
            candidates.append((score, asset['id'], asset, hits))
    return sorted(candidates, key=lambda x: (-x[0], x[1]))


def read_cues(path, limit):
    if not path:
        return []
    with open(path, encoding='utf-8-sig', newline='') as file:
        reader = csv.DictReader(file)
        if not {'start', 'end', 'tag'} <= set(reader.fieldnames or []):
            raise ValueError('cues.csv يحتاج start,end,tag')
        values = [{'start': float(r['start']), 'end': float(r['end']), 'tag': r['tag'].strip()} for r in reader]
    values.sort(key=lambda x: x['start'])
    previous = 0
    for cue in values:
        if not all(math.isfinite(cue[k]) for k in ('start', 'end')) or not previous <= cue['start'] < cue['end'] <= limit or not cue['tag']:
            raise ValueError('توقيت cues متداخل أو خارج الصوت أو وسم فارغ.')
        previous = cue['end']
    return values


def meme_cap(limit):
    return max(1, math.ceil(limit / 90))


def reaction(text, mode='auto'):
    if any(contains(text, x) for x in SENSITIVE + CRUCIAL + IMPORTANT_FORMS) or re.search(r'\d', text) or mode in ('sensitive', 'factual', 'cta', 'crucial'):
        return None
    if any(contains(text,x) for x in ('ما ضحكت','مو مضحك','مو مزحه','بدون مزح','ليس مضحكا','مو مفاجاه','مافي مفاجاه','بحسب','حسب المصدر')):
        return None
    if mode in REACTIONS:
        return mode
    for mood, terms in REACTIONS.items():
        if any(contains(text, t) for t in terms):
            return mood
    return None


def suggest_memes(segments, assets, limit, enabled, spacing=45, meme_duration=1.4):
    result = []
    if not enabled:
        return result
    last = -spacing
    for s in segments:
        if s.get('semantic') and not s['semantic']['meme']:continue
        if s.get('asr_confidence',1)<.65 or s.get('editorial_confidence',1)<.75:continue
        mood = reaction(s['text'], s.get('mode', 'auto'))
        choices = sorted((a for a in assets if a['role'] == 'meme' and licensed(a) and a.get('mood') == mood), key=lambda a: a['id']) if mood else []
        if not choices or s['start'] - last < spacing or len(result) >= meme_cap(limit) or s['end'] - s['start'] < .6:
            continue
        cue=next((w for w in s.get('words',[]) if any(contains(w['text'],t) for t in REACTIONS.get(mood,()))),None)
        at = cue['start'] if cue and s['end']-cue['start']>=.6 else s['start']
        result.append({'asset_id': choices[0]['id'], 'timestamp': at, 'duration': min(meme_duration, s['end'] - at),
                       'reason': f'رد فعل {mood}، تفريغ واضح وسياق غير حساس؛ يحتاج اعتمادًا', 'confidence': min(.9,s.get('asr_confidence',.85)),
                       'approved': False, 'region': [.04, .09, .22, .22]})
        last = at
    return result


def select_shorts(segments,limit,count=2,length=50):
    from short_policy import select,MIN_SECONDS,MAX_SECONDS
    return select(segments,limit,count,target=max(MIN_SECONDS,min(MAX_SECONDS,length)))


def plan(audio, manifest, segments=None, script='', cues='', memes_enabled=False,adaptive=False):
    from channel_style import load_profile
    profile = load_profile()
    audio = str(Path(audio).resolve())
    limit = duration(audio, 'audio')
    segments = captions.validate(segments or [], limit)
    assets = manifest.get('assets', [])
    manual = read_cues(cues, limit)
    boundaries = sorted({0, limit, *(s[k] for s in segments for k in ('start', 'end')),
                         *(c[k] for c in manual for k in ('start', 'end'))})
    shots, warnings = [], []
    last_id = None
    for begin, end in zip(boundaries, boundaries[1:]):
        s = next((s for s in segments if s['start'] <= begin + .001 < s['end']), None)
        c = next((c for c in manual if c['start'] <= begin + .001 < c['end']), None)
        # Script is a matching hint only; never fabricate timestamps or subtitle text.
        text = s['text'] if s else script if not segments else ''
        matches = match(text, assets, c['tag'] if c else '')
        if not segments and not script and not c:
            # Clips-only workflow is explicit manual sequence, never presented as semantic matching.
            matches = [(0.0, a['id'], a, ['تتابع يدوي بلا نص']) for a in sorted(assets, key=lambda a: a['id']) if a['role'] == 'clip' and licensed(a)]
        selected = next((m for m in matches if m[1] != last_id), matches[0] if matches else None)
        if not selected:
            warnings.append(f'{begin:.2f}–{end:.2f}: لا أصل مرخص مطابق؛ خلفية محايدة. راجع الربط.')
        at = begin
        scene_seconds=profile['editing']['scene_seconds']
        if adaptive and s:
            if reaction(text,s.get('mode','auto')):scene_seconds=max(3,scene_seconds*.75)
            elif any(contains(text,x) for x in SENSITIVE+CRUCIAL) or re.search(r'\d',text):scene_seconds=min(12,scene_seconds*1.4)
        count = max(1, math.ceil((end - begin) / scene_seconds))
        for i in range(count):
            selected = next((m for m in matches if m[1] != last_id), matches[0] if matches else None)
            stop = end if i == count - 1 else begin + (end - begin) * (i + 1) / count
            asset = selected[2] if selected else None
            offset = 0
            if asset and asset['kind'] != 'image' and asset['duration'] > stop - at:
                offset = round((at * .37) % max(.001, asset['duration'] - (stop - at)), 3)
            shots.append({'start': round(at, 6), 'end': round(stop, 6),
                          'asset_id': asset['id'] if asset else None, 'source_offset': offset,
                          'confidence': selected[0] if selected else 0,
                          'reason': ('cues يدوي: ' if c else 'تطابق وسوم: ') + ', '.join(selected[3]) if selected else 'لا تطابق؛ خلفية محايدة',
                          'topic': c['tag'] if c else asset.get('game', '') if asset else '',
                          'manual': bool(c), 'transition': 'cut'})
            at = stop
            last_id = selected[1] if selected else None
    if not segments:
        warnings.append('لا توجد ترجمة موقّتة؛ لن تُحرق ترجمة. النص الاختياري لا يحدد توقيت الكلام.')
        if script:
            warnings.append('النص غير موقّت؛ المطابقة تعتمد سياق النص كله. راجع أصل كل مشهد يدويًا.')
    shorts = select_shorts(segments, limit)
    if not shorts:
        warnings.append('لا توجد لحظة Short مؤهلة؛ حدّد البداية والنهاية يدويًا.')
    return {'version': '2.1', 'channel_profile': profile['version'], 'audio': audio, 'audio_fingerprint': fingerprint(audio), 'duration': limit,
            'assets': assets, 'segments': segments, 'script': script, 'shots': shots,
            'memes_enabled': bool(memes_enabled), 'memes': suggest_memes(segments, assets, limit, memes_enabled, profile['editing']['meme_spacing'], profile['editing']['meme_duration']),
            'shorts': shorts, 'warnings': warnings, 'review': None,
            'caption': {'font': profile['editing']['caption_font'], 'style': profile['editing']['caption_style'], 'region': profile['editing']['caption_region']},
            'reserved_regions': [[.72, .08, .24, .25], [.30, .20, .40, .50], [0, 0, 1, .07]],
            'music': None}


def intersects(a, b):
    return a[0] < b[0] + b[2] and a[0] + a[2] > b[0] and a[1] < b[1] + b[3] and a[1] + a[3] > b[1]


def rectangle(value):
    if len(value) != 4 or not all(math.isfinite(float(x)) for x in value):
        raise ValueError('منطقة العرض غير صالحة.')
    x, y, w, h = value
    if not 0 <= x < 1 or not 0 <= y < 1 or not 0 < w <= 1 - x + .00001 or not 0 < h <= 1 - y + .00001:
        raise ValueError('منطقة العرض خارج الإطار.')


def validate_timeline(timeline, files=True):
    limit = float(timeline['duration'])
    if not math.isfinite(limit) or not 0 < limit < 86400:
        raise ValueError('مدة الخط الزمني غير صالحة.')
    captions.validate(timeline['segments'], limit)
    assets = {a['id']: a for a in timeline['assets']}
    if len(assets) != len(timeline['assets']):
        raise ValueError('معرّفات الأصول مكررة.')
    if files and fingerprint(timeline['audio']) != timeline['audio_fingerprint']:
        raise ValueError('تغير الصوت؛ أعد التحليل والمراجعة.')
    def asset_for(asset_id, role):
        a = assets.get(asset_id)
        if not a or a['role'] != role or not licensed(a):
            raise ValueError('أصل مفقود أو غير معتمد الحقوق.')
        if files and (Path(a['path']).suffix.lower() not in VIDEO | IMAGE or fingerprint(a['path']) != a['fingerprint']):
            raise ValueError('تغير أصل؛ أعد استيراده والمراجعة.')
        return a
    previous = 0.0
    if not timeline['shots']:
        raise ValueError('الخط الزمني لا يحتوي على مشاهد.')
    for shot in timeline['shots']:
        start, end = float(shot['start']), float(shot['end'])
        if not all(math.isfinite(x) for x in (start, end)) or abs(start - previous) > .002 or not start < end <= limit + .002:
            raise ValueError('المشاهد يجب أن تغطي الصوت دون تداخل أو فجوات.')
        if shot['asset_id']:
            a = asset_for(shot['asset_id'], 'clip')
            offset = float(shot.get('source_offset', 0))
            if not math.isfinite(offset) or offset < 0 or (a['kind'] != 'image' and offset >= a['duration']):
                raise ValueError('بداية اللقطة خارج الأصل.')
        previous = end
    if abs(previous - limit) > .002:
        raise ValueError('المشاهد لا تغطي نهاية الصوت.')
    region = timeline['caption']['region']
    rectangle(region)
    if timeline['caption'].get('portrait_region'):rectangle(timeline['caption']['portrait_region'])
    reserved = timeline.get('reserved_regions', [])
    for r in reserved:
        rectangle(r)
        if intersects(r, region):
            raise ValueError('منطقة الترجمة تتقاطع مع الوجه/الموضوع/HUD المحجوز؛ غيّر المنطقة.')
    approved = sorted((m for m in timeline['memes'] if m.get('approved')), key=lambda m: m['timestamp'])
    if approved and not timeline.get('memes_enabled'):
        raise ValueError('اقتراحات الميمز غير مفعلة.')
    if len(approved) > meme_cap(limit):
        raise ValueError('عدد الميمز يتجاوز الحد المحافظ.')
    last = -45
    for m in approved:
        asset = asset_for(m['asset_id'], 'meme')
        at, seconds = float(m['timestamp']), float(m['duration'])
        if not all(math.isfinite(x) for x in (at, seconds)) or not 0 <= at < at + seconds <= limit or not .6 <= seconds <= 2 or at - last < 45:
            raise ValueError('توقيت الميم أو مدته أو تباعده غير مسموح.')
        related = [s for s in timeline['segments'] if s['start'] < at + seconds and s['end'] > at]
        if not related or not any(s['start'] <= at and s['end'] >= at + seconds for s in related) or any(reaction(s['text'], s.get('mode', 'auto')) != asset.get('mood') for s in related):
            raise ValueError('الميم خارج رد فعل ملائم أو فوق خبر حساس/معلومة مهمة.')
        rectangle(m['region'])
        if any(intersects(m['region'], r) for r in [region, *reserved]):
            raise ValueError('الميم يتقاطع مع الترجمة أو منطقة الوجه/الموضوع/HUD.')
        last = at
    for s in timeline['shorts']:
        if not all(math.isfinite(float(s[k])) for k in ('start', 'end')) or not 0 <= s['start'] < s['end'] <= limit:
            raise ValueError('توقيت Short خارج الصوت.')
    if timeline.get('sound_effects'):
        from sound_effects import validate
        validate(timeline['sound_effects'],limit,timeline['segments'],files)
    if timeline.get('music'):
        raise ValueError('الموسيقى معطلة بطلب صاحب القناة. احذف music من الخط الزمني أو اجعلها null.')
    return timeline


def digest(timeline):
    value = {k: v for k, v in timeline.items() if k != 'review'}
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def approve(timeline, accept_warnings=False):
    validate_timeline(timeline)
    if timeline['warnings'] and not accept_warnings:
        raise ValueError('راجع التحذيرات واقبلها صراحة قبل الاعتماد.')
    timeline['review'] = {'approved': True, 'digest': digest(timeline), 'warnings_accepted': bool(accept_warnings)}
    return timeline


def require_approval(timeline):
    validate_timeline(timeline)
    review = timeline.get('review') or {}
    if not review.get('approved') or review.get('digest') != digest(timeline) or (timeline['warnings'] and not review.get('warnings_accepted')):
        raise ValueError('اعتمد النسخة الحالية بعد مشاهدة المسودة؛ أي تعديل يلغي الاعتماد.')
