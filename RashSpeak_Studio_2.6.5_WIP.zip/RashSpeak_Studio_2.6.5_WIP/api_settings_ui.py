"""One visible settings window for independent YouTube and Gemini keys."""
import queue
import threading
import tkinter as tk
from tkinter import ttk

import api_connections
from gemini_client import settings,save_settings,validate_settings
from rtl_ui import Label,Button,visual

BG='#0b1220';CARD='#132138';TEXT='#eef5ff';MUTED='#91a9c4';CYAN='#08BEED'


class ApiPanel(tk.Frame):
    def __init__(self,parent,provider):
        super().__init__(parent,bg=BG,padx=16,pady=14)
        self.provider=provider;self.closed=False;self.busy=False;self.timer=None
        style=ttk.Style(self)
        style.configure('RashApi.TEntry',fieldbackground=CARD,foreground=TEXT,insertcolor=TEXT)
        style.configure('RashApi.TCombobox',fieldbackground=CARD,foreground=TEXT,arrowcolor=CYAN)
        style.map('RashApi.TCombobox',fieldbackground=[('disabled',CARD),('readonly',CARD)],foreground=[('disabled',MUTED)])
        style.configure('RashApi.TCheckbutton',background=BG,foreground=TEXT)
        style.map('RashApi.TCheckbutton',background=[('active',BG)],foreground=[('disabled',MUTED)])
        style.configure('RashApi.TCheckbutton',font=('Segoe UI',10))
        style.layout('RashApi.TCheckbutton',[('Checkbutton.padding',{'sticky':'nswe','children':[
            ('Checkbutton.indicator',{'side':'right','sticky':''}),('Checkbutton.focus',{'side':'right','sticky':'w',
            'children':[('Checkbutton.label',{'sticky':'nswe'})]})]})])
        self.cancel=threading.Event();self.events=queue.Queue()
        self.key=tk.StringVar();self.remember=tk.BooleanVar(value=False);self.reveal=tk.BooleanVar(value=False)
        title='YouTube Data API' if provider=='youtube' else 'Gemini API'
        Label(self,text=title,bg=BG,fg=CYAN,font=('Segoe UI',17,'bold')).pack(anchor='e',pady=(0,10))
        help_text=('للبحث عن الفيديوهات داخل القنوات الرسمية. المفتاح لا يمنح تصريح استخدام أو تنزيل الفيديو.'
                   if provider=='youtube' else
                   'لتحليل النص والتوقيت واختيار مشاهد حقيقية ومساعد التحرير. يبقى التسجيل محليًا؛ قد تُرسل وسائط المصادر للتحليل.')
        Label(self,text=help_text,bg=BG,fg=MUTED,wraplength=660,justify='right').pack(fill='x',pady=6)
        Label(self,text='ألصق مفتاح هذه الخدمة',bg=BG,fg=TEXT).pack(anchor='e',pady=(12,4))
        self.entry=ttk.Entry(self,textvariable=self.key,show='•',justify='left',font=('Consolas',11),style='RashApi.TEntry');self.entry.pack(fill='x',pady=5)
        self.show=ttk.Checkbutton(self,text=visual('إظهار المفتاح'),variable=self.reveal,style='RashApi.TCheckbutton',
                                  command=lambda:self.entry.configure(show='' if self.reveal.get() else '•'))
        self.show.pack(anchor='e',pady=3)
        self.persist=ttk.Checkbutton(self,text=visual('حفظ في خزنة النظام للاستخدام بعد إغلاق البرنامج'),variable=self.remember,style='RashApi.TCheckbutton')
        self.persist.pack(anchor='e',pady=6)
        Label(self,text='الحقل الفارغ يحافظ على المفتاح الموجود. الحفظ غير مفعّل افتراضيًا؛ يُستخدم المفتاح للجلسة الحالية.',
              bg=BG,fg=MUTED,wraplength=660,justify='right').pack(fill='x',pady=6)
        self.model=None;self.combo=None
        if provider=='gemini':
            cfg=settings();self.model=tk.StringVar(value=cfg['model']);self.enabled=tk.BooleanVar(value=cfg['enabled'])
            self.enable=ttk.Checkbutton(self,text=visual('تفعيل Gemini في الإنتاج'),variable=self.enabled,style='RashApi.TCheckbutton')
            self.enable.pack(anchor='e',pady=5)
            Label(self,text='النموذج',bg=BG,fg=TEXT).pack(anchor='e')
            self.combo=ttk.Combobox(self,textvariable=self.model,values=['gemini-3.1-flash-lite','gemini-flash-latest','gemini-pro-latest'],style='RashApi.TCombobox')
            self.combo.pack(fill='x',pady=5)
        row=tk.Frame(self,bg=BG);row.pack(fill='x',pady=14)
        self.save_button=Button(row,text='حفظ إعداد الخدمة',command=self.save,bg='#223b58',fg=TEXT,relief='flat',padx=12,pady=8)
        self.save_button.pack(side='right',padx=4)
        self.test_button=Button(row,text='اختبار الاتصال',command=self.test,bg=CYAN,fg=BG,relief='flat',padx=12,pady=8)
        self.test_button.pack(side='right',padx=4)
        self.status=tk.StringVar(value='مفتاح متاح؛ يمكنك فحصه أو استبداله.' if api_connections.current_key(provider) else 'لم يُضف مفتاح لهذه الخدمة بعد.')
        Label(self,textvariable=self.status,bg=BG,fg=TEXT,wraplength=660,justify='right').pack(fill='x',pady=8)
        self.bind('<Destroy>',self.destroyed,add='+')

    def save(self):
        if self.busy:return
        try:
            if self.model:validate_settings({'enabled':self.enabled.get(),'model':self.model.get()})
            changed=api_connections.configure(self.provider,self.key.get(),self.remember.get())
            if self.model:save_settings({'enabled':self.enabled.get(),'model':self.model.get()})
            self.key.set('');self.reveal.set(False);self.entry.configure(show='•')
            if changed:self.status.set('حُفظ المفتاح في خزنة النظام.' if self.remember.get() else 'تم استخدام المفتاح لهذه الجلسة. اختبر الاتصال للتحقق منه.')
            else:self.status.set('بقي المفتاح الموجود؛ حُفظت إعدادات الخدمة.')
        except (ValueError,OSError):self.status.set('تعذر الحفظ؛ راجع المفتاح والنموذج وإتاحة خزنة النظام. استخدم إعداد الجلسة إن تعذر الحفظ الدائم.')

    def set_busy(self,value):
        self.busy=value;state='disabled' if value else 'normal'
        for widget in (self.entry,self.save_button,self.test_button,self.show,self.persist):widget.configure(state=state)
        if self.combo:self.combo.configure(state=state);self.enable.configure(state=state)

    def test(self):
        if self.busy:return
        try:
            value=api_connections.validate_key(self.key.get())
            model=self.model.get() if self.model else None
            if model:validate_settings({'enabled':True,'model':model})
            if not value and not api_connections.current_key(self.provider):raise ValueError()
        except ValueError:
            self.status.set('أدخل مفتاحًا صالحًا لهذه الخدمة ونموذج Gemini صالحًا عند اختياره.');return
        self.set_busy(True);self.status.set('جارٍ اختبار اتصال الخدمة…');self.cancel.clear()
        def work():
            try:self.events.put((True,api_connections.check(self.provider,value,model,self.cancel)))
            except api_connections.ConnectionError as exc:self.events.put((False,str(exc)))
            except Exception:self.events.put((False,'تعذر فحص الاتصال؛ لم تُحفظ أو تُعرض بيانات المفتاح.'))
        self.worker=threading.Thread(target=work,daemon=True);self.worker.start();self.poll()

    def poll(self):
        if self.closed:return
        self.timer=None
        try:
            ok,value=self.events.get_nowait();self.set_busy(False)
            self.status.set(value['message'] if ok else value)
            if ok and self.combo is not None:self.combo['values']=value.get('models',[])
        except queue.Empty:self.timer=self.after(60,self.poll)

    def destroyed(self,event):
        if event.widget is not self:return
        self.closed=True;self.cancel.set()
        if self.timer:
            try:self.after_cancel(self.timer)
            except tk.TclError:pass


def open_settings(parent,provider='youtube'):
    window=tk.Toplevel(parent);window.title('مفاتيح YouTube وGemini');window.geometry('780x690');window.minsize(720,650);window.configure(bg=BG)
    Label(window,text='إعداد مفاتيح الخدمات',bg=BG,fg=CYAN,font=('Segoe UI',19,'bold')).pack(anchor='e',padx=20,pady=14)
    book=ttk.Notebook(window);book.pack(fill='both',expand=True,padx=16,pady=(0,16))
    panels={}
    for name,label in (('youtube','YouTube Data API'),('gemini','Gemini')):
        panel=ApiPanel(book,name);book.add(panel,text=label);panels[name]=panel
    book.select(panels.get(provider,panels['youtube']))
    window.api_panels=panels;window.api_notebook=book
    return window
