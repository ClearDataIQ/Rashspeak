"""Six ordered owner-reviewed stages. No thumbnail creation or publication."""
import copy
import hashlib
import json
from pathlib import Path
import shutil

import audio_edit
import captions
import sound_effects
from app_paths import app_dir
from channel_style import load_profile, long_description
from licensed_media import gather, topics, credits_text
from media_tools import Cancelled, duration
from production import STAGES, new_project, load_json, topic_card, contextual_cues, complete_shorts
from smart_editor import save, plan, fingerprint, validate_timeline, suggest_memes, contains
from timeline_render import render
from production_quality import assess as assess_quality, MissingFootage


def digest(data):
    return hashlib.sha256(json.dumps(data,sort_keys=True,ensure_ascii=False,allow_nan=False).encode()).hexdigest()


def enrich(segments,words,script):
    """Confidence comes from recognition evidence, not an invented AI score."""
    for s in segments:
        related=[w for w in words if w['start']<s['end'] and w['end']>s['start']]
        s['words']=related
        probabilities=[w['probability'] for w in related if 'probability' in w]
        s['asr_confidence']=sum(probabilities)/len(probabilities) if probabilities else .7
        spoken=audio_edit.tokens(s['text']);expected=set(audio_edit.tokens(script))
        match=sum(t in expected for t in spoken)/max(1,len(spoken))
        s['editorial_confidence']=min(s['asr_confidence'],.6+.4*match)
    return segments


def polish_shots(timeline):
    """Keep pauses on the current shot; avoid tiny filler-card flashes.

    This follows the recording, topic boundaries and general readability. It
    never imports a reference video's cut timings or sequences.
    """
    assets={a['id']:a for a in timeline['assets']};result=[]
    for shot in timeline['shots']:
        short=shot['end']-shot['start']<.6
        filler=assets.get(shot['asset_id'],{}).get('editorial_card') and not shot.get('topic')
        if result and short and filler:
            result[-1]['end']=shot['end'];result[-1]['reason']+='؛ الوقفة على نفس اللقطة';continue
        if result and result[-1]['asset_id']==shot['asset_id'] and result[-1].get('topic')==shot.get('topic') and shot['end']-result[-1]['start']<=8:
            result[-1]['end']=shot['end'];continue
        result.append(copy.deepcopy(shot))
    if len(result)>1 and result[0]['end']-result[0]['start']<.6 and assets.get(result[0]['asset_id'],{}).get('editorial_card') and not result[0].get('topic'):
        result[1]['start']=0;result.pop(0)
    timeline['shots']=result
    return timeline


def run_production(audio,script,project,online,model,cancel,on_event,asr_override,assets_override,sizes,on_review,quality_mode='final'):
    if quality_mode not in ('final','draft'):raise ValueError('وضع الجودة غير صالح.')
    project=Path(project or new_project()).resolve();project.mkdir(parents=True,exist_ok=True)
    audio=Path(audio).resolve()
    if not audio.is_file():raise ValueError('اختر تسجيلًا صوتيًا موجودًا.')
    if not audio_edit.tokens(script) or len(script)>80_000:raise ValueError('أدخل سكربتًا واضحًا حتى 80 ألف حرف.')
    limit=duration(audio,'audio')
    if limit>7200:raise ValueError('التسجيل أطول من ساعتين؛ قسّمه إلى حلقات.')
    identity={'audio':str(audio),'fingerprint':fingerprint(audio),'script_sha256':digest(script)}
    previous=load_json(project/'production.json',{})
    # Recognize the original 2.2 script identity when opening an existing project.
    old_identity={**identity,'script_sha256':hashlib.sha256(script.encode()).hexdigest()}
    if previous.get('input') and previous['input'] not in (identity,old_identity):
        raise ValueError('الصوت أو السكربت تغيّر؛ ابدأ مشروعًا جديدًا حتى لا تطبق قرارات قص قديمة.')
    identity=old_identity
    profile=load_profile()
    state={'version':'2.3','status':'running','project':str(project),'input':identity,'stages':{},'warnings':[],
           'stage_reviews':{},'review_mode':'owner' if on_review else 'automatic_test_or_cli','published':False}
    save(state,project/'production.json');(project/'script.txt').write_text(script,encoding='utf-8')
    number=max((int(p.name[4:]) for p in (project/'runs').glob('run_*') if p.name[4:].isdigit()),default=0)+1
    work=project/'runs'/f'run_{number:03}';work.mkdir(parents=True)
    deliver=work/'delivery';stage_key='';accepted={};preview_counts={}
    def emit(event):
        if on_event:on_event(event)
    def preview_folder(key):
        preview_counts[key]=preview_counts.get(key,0)+1
        folder=work/'previews'/key/f'revision_{preview_counts[key]:03}'
        folder.mkdir(parents=True,exist_ok=True);return folder
    def check():
        if cancel and cancel.is_set():raise Cancelled('أوقفت الإنتاج؛ المصدر والمراجعات ونسخ العمل محفوظة.')
        if fingerprint(audio)!=identity['fingerprint']:raise ValueError('تغيّر التسجيل أثناء المراجعة؛ ابدأ مشروعًا من النسخة الجديدة.')
    def begin(key,detail):
        nonlocal stage_key
        stage_key=key;check();state['status']='running';state['stages'][key]='working';save(state,project/'production.json')
        emit({'type':'stage','key':key,'detail':detail,'progress':round(100*next(i for i,s in enumerate(STAGES) if s[0]==key)/len(STAGES))})
    cut_overrides=load_json(project/'cut_overrides.json',{})
    def dependency():return digest({'identity':identity,'profile':profile,'accepted':accepted,'cut_overrides':cut_overrides,'ai':state.get('ai',{})})
    def stored(key):
        value=load_json(project/'stage_drafts'/f'{key}.json',{})
        return value.get('data') if value.get('dependency')==dependency() else None
    def gate(key,data,prepare):
        fallback=copy.deepcopy(data);data=copy.deepcopy(stored(key) or data);last_good=None;previews=[];revision=0;error=None
        while True:
            check()
            try:
                data,previews=prepare(copy.deepcopy(data));last_good=copy.deepcopy(data);error=None;revision+=1
            except Cancelled:raise
            except (ValueError,RuntimeError,OSError) as exc:
                error=str(exc)
                if last_good is None:
                    if on_review is None or data==fallback:raise
                    last_good,previews=prepare(copy.deepcopy(fallback));revision+=1
            request={'key':key,'label':dict(STAGES)[key],'data':copy.deepcopy(data),'last_good':copy.deepcopy(last_good),
                     'previews':previews,'revision':revision,'error':error,'work':str(work),'source_audio':str(audio),
                     'draft_path':str(project/'stage_drafts'/f'{key}.json'),'dependency':dependency(),'script':script}
            preview_fingerprints={p['path']:fingerprint(p['path']) for p in previews}
            state['status']='waiting_for_review' if on_review else 'running';state['stages'][key]='waiting_for_review' if on_review else 'working'
            save(state,project/'production.json');save(request,work/'reviews'/f'{key}_pending.json')
            save(request,work/'reviews'/f'{key}_revision_{preview_counts.get(key,revision):03}.json')
            save({'dependency':dependency(),'data':data},project/'stage_drafts'/f'{key}.json')
            response=on_review(request) if on_review else {'action':'approve'}
            check()
            action=response.get('action') if isinstance(response,dict) else None
            if action=='cancel':raise Cancelled('أوقفت الإنتاج عند مراجعة المرحلة.')
            if action=='revise':data=copy.deepcopy(response['data']);continue
            if action!='approve':raise ValueError('قرار مراجعة غير صالح؛ لم تُعتمد المرحلة.')
            if key=='media' and quality_mode=='final' and not data.get('quality',{}).get('ready'):
                raise MissingFootage(data['quality'])
            if error:raise ValueError('التعديلات غير صالحة؛ صححها وأعد المعاينة قبل الاعتماد.')
            if 'data' in response and digest(response['data'])!=digest(data):
                raise ValueError('تغيرت البيانات بعد المعاينة؛ أعد المعاينة قبل الاعتماد.')
            if any(fingerprint(path)!=fp for path,fp in preview_fingerprints.items()):
                raise ValueError('ملف المعاينة تغيّر؛ أعد المعالجة والمراجعة قبل الاعتماد.')
            accepted[key]=digest(data)
            state['stage_reviews'][key]={'revision':revision,'digest':accepted[key],'approved_by_owner':bool(on_review)}
            state['stages'][key]='done';state['status']='running'
            save({**request,'approved_by_owner':bool(on_review),'approved':True},work/'reviews'/f'{key}_approved.json')
            save(state,project/'production.json');return data

    def preview_video(timeline,key):
        if on_review is None:return []  # Batch mode renders the final project once.
        preview=copy.deepcopy(timeline);preview['shorts']=[]
        results=render(preview,preview_folder(key),size=(640,360),portrait_size=(360,640),cancel=cancel,
                       logger=lambda msg:emit({'type':'log','message':msg}),cache_dir=work/'render_cache')
        return [{'label':'شاهد نسخة المرحلة','path':results[0]['path']}]

    try:
        begin('audio','تفريغ محلي، مراجعة السكربت، ثم قص ومعالجة الصوت')
        cached=load_json(project/'asr_cache.json',{})
        if cached.get('input') in (identity,old_identity):detailed=cached['result'];asr_source=cached.get('source','local_whisper_cache')
        else:
            detailed=asr_override if asr_override is not None else captions.transcribe(audio,model or app_dir()/'models/small',
                        logger=lambda m:emit({'type':'log','message':m}),cancel=cancel,vocabulary=topics(script),return_words=True)
            asr_source='synthetic_test_fixture' if asr_override is not None else 'local_whisper'
            save({'input':identity,'result':detailed,'source':asr_source},project/'asr_cache.json')
        state['asr_source']=asr_source
        if asr_source=='synthetic_test_fixture':state['warnings'].append('تفريغ اصطناعي للاختبار؛ لا يمثل صوتك أو دقة التعرّف.')
        silences=audio_edit.detect_silences(audio,limit,cancel)
        base=audio_edit.analyse(script,detailed['words'],silences,limit,load_json(project/'cut_overrides.json',{}))
        audio_context={}
        def prepare_audio(data):
            units=data['words'];audio_edit.word_units(units,limit)
            analysis=audio_edit.analyse(script,units,silences,limit)
            if data.pop('reanalyse',False):data['edits']=analysis['edits']
            edits=data['edits'];ids=set()
            for e in edits:
                if e['id'] in ids or e.get('action') not in ('keep','remove'):raise ValueError('قرار قص مكرر أو غير صالح.')
                ids.add(e['id'])
                if e['action']=='remove' and any(w['start']<e['start']<w['end']-.001 or w['start']+.001<e['end']<w['end'] for w in units):
                    raise ValueError('القص يقطع كلمة؛ صحح الحدود أو استرجع الجزء.')
            analysis['edits']=edits;analysis['keeps']=audio_edit.keep_ranges(edits,limit)
            analysis['clean_duration']=sum(b-a for a,b in analysis['keeps'])
            clean=audio_edit.render_audio(audio,analysis,preview_folder('audio')/'narration_clean.wav',cancel,data['processing'])
            clean_limit=duration(clean,'audio');words=audio_edit.remap_words(units,analysis['keeps'])
            segments=audio_edit.segments_from_words(words)
            if not segments:
                for s in detailed['segments']:
                    a=audio_edit.source_time(s['start'],analysis['keeps']);b=audio_edit.source_time(s['end'],analysis['keeps'])
                    if a is not None and b is not None and b>a:segments.append({**s,'start':a,'end':b,'mode':'auto'})
            for s in segments:s['end']=min(s['end'],clean_limit)
            segments=captions.validate(segments,clean_limit)
            if not segments:raise ValueError('لا جمل موقّتة موثوقة؛ صحح التفريغ قبل المونتاج.')
            enrich(segments,words,script)
            audio_context.update(analysis=analysis,clean=clean,limit=clean_limit,segments=segments,words=words)
            save(analysis,project/'audio_edits.json')
            data.update(coverage=analysis['coverage'],warnings=analysis['warnings'],clean_duration=clean_limit)
            return data,[{'label':'اسمع الصوت المنظف','path':clean},{'label':'اسمع الأصل','path':str(audio)}]
        audio_data=gate('audio',{'words':detailed['words'],'edits':base['edits'],
                        'processing':{'highpass':65,'denoise':True,'noise_floor':-25,'loudness':-16}},prepare_audio)
        analysis=audio_context['analysis'];clean=audio_context['clean'];clean_limit=audio_context['limit'];segments=audio_context['segments']
        state['warnings']+=analysis['warnings']

        begin('media','تركيب اللقطات على الكلام مع إيقاع أسلوب القناة')
        semantic=None
        from gemini_client import settings as gemini_settings,api_key,GeminiError
        if gemini_settings()['enabled'] and api_key():
            from gemini_context import analyse as gemini_analyse,enrich as semantic_enrich
            emit({'type':'log','message':'Gemini يحلل النص والتوقيت؛ لا يُرسل التسجيل أو الفيديو.'})
            try:
                semantic=gemini_analyse(script,segments,cache=project/'gemini_cache',cancel=cancel)
                segments=semantic_enrich(segments,semantic);save(semantic,work/'gemini_context.json')
                state['ai']={'provider':'gemini','model':semantic['model'],'status':'analysed',
                             'planning_digest':digest({'revision':3,'segments':semantic['segments'],'shorts':semantic['shorts']})}
            except GeminiError as exc:
                state['warnings'].append(str(exc));state['ai']={'provider':'local_rules','status':'gemini_unavailable'}
        else:state['ai']={'provider':'local_rules','status':'gemini_not_configured'}
        prior_media=stored('media')
        if prior_media is not None:assets=prior_media['assets']
        else:
            if assets_override is not None:media={'assets':assets_override,'warnings':[]}
            elif online:
                from official_sources import settings as source_settings
                media=gather(script,project/'media',lambda m:emit({'type':'log','message':m}),cancel,semantic=semantic) if source_settings().get('commons_fallback') else {'assets':[],'warnings':[]}
            else:media={'assets':[],'warnings':['جمع الإنترنت معطل؛ بطاقات معلنة للمواضيع غير المغطاة.']}
            assets=list(media['assets']);state['warnings']+=media['warnings']
            retained=load_json(project/'stage_drafts/media.json',{}).get('data',{}).get('assets',[])
            for asset in retained:
                try:
                    if asset.get('usage_approved') and fingerprint(asset['path'])==asset['fingerprint'] and not any(a['id']==asset['id'] for a in assets):assets.append(asset)
                except OSError:pass
            for i,topic in enumerate(topics(script) or ['RashSpeak']):
                if not any(a['role']=='clip' and contains(a.get('game',''),topic) for a in assets):assets.append(topic_card(topic,work/'cards',i,cancel))
        cues=contextual_cues(segments,topics(script) or ['RashSpeak'],work)
        timeline=plan(clean,{'assets':assets},segments,cues=str(cues),memes_enabled=True,adaptive=True)
        timeline['shorts']=[];timeline['memes']=[];timeline['sound_effects']=[];timeline['audio_processed']=True
        timeline['caption']['portrait_region']=[.10,.70,.74,.12]
        for shot in timeline['shots']:
            if shot['asset_id'] is None:
                card=next((a for a in assets if a.get('editorial_card')),None)
                if card is None:card=topic_card('RashSpeak',work/'cards',99,cancel);assets.append(card)
                shot.update(asset_id=card['id'],source_offset=0,confidence=0,reason='بطاقة معلنة عندما لا توجد لقطة مطابقة')
        polish_shots(timeline)
        if semantic:
            from gemini_context import apply_visual_plan
            apply_visual_plan(timeline,lambda title,i:topic_card(title,work/'cards',100+i,cancel))
        if assets_override is None:
            from media_archive import MediaArchive
            from media_director import build_plan,materialize,apply_plan
            from official_sources import YouTubeOfficial,FreeImages
            from gemini_client import GeminiClient
            from media_acquisition import download_excerpt
            from smart_editor import import_asset
            archive=MediaArchive()
            providers={'youtube':YouTubeOfficial(cancel=cancel),'images':FreeImages(cancel=cancel)} if online else {}
            source_plan=build_plan(segments,archive,providers,GeminiClient(cancel=cancel) if api_key() else None,
                                   work/'sentence_media_plan.json',cancel,archive.root/'scene_analysis')
            def importer(path,candidate):
                grant=candidate['permission']
                asset=import_asset(path,role=candidate.get('role','clip'),mood=candidate.get('mood',''),
                                   game=candidate['game'],license=grant['license'],source=candidate.get('source',candidate['url']),approved=True)
                asset['rights']={'provider':candidate['provider'],'author':candidate.get('author',''),
                                 'source':candidate.get('source',candidate['url']),'license':grant['license'],
                                 'license_url':grant['evidence_url'],'credit':candidate.get('title','')}
                return asset
            source_plan=materialize(source_plan,archive,download_excerpt,importer,work/'sentence_media_plan.json',cancel)
            apply_plan(timeline,source_plan)
            state['media_plan']=str(work/'sentence_media_plan.json');state['media_archive']=str(archive.root/'catalog.json')
            emit({'type':'log','message':f"خطة اللقطات: {source_plan['cached_count']} من الأرشيف؛ {source_plan['ready_count']} جملة لها أصل جاهز."})
        else:source_plan=None
        def prepare_media(data):
            data.setdefault('segments',segments)
            current=captions.validate(data['segments'],clean_limit)
            timeline['segments']=current
            timeline.update(assets=data['assets'],shots=data['shots'])
            if data.pop('refresh_sources',False) and assets_override is None:
                providers={'youtube':YouTubeOfficial(cancel=cancel),'images':FreeImages(cancel=cancel)} if online else {}
                refreshed=build_plan(current,archive,providers,GeminiClient(cancel=cancel) if api_key() else None,
                                     work/'sentence_media_plan.json',cancel,archive.root/'scene_analysis')
                refreshed=materialize(refreshed,archive,download_excerpt,importer,work/'sentence_media_plan.json',cancel)
                apply_plan(timeline,refreshed)
                data.update(assets=timeline['assets'],shots=timeline['shots'],media_plan=refreshed)
            validate_timeline(timeline)
            data['quality']=assess_quality(timeline);state['quality']=data['quality']
            data['quality_enforced']=quality_mode=='final'
            from pro_project import from_legacy,write_project
            draft=work/'media_draft.rash.json';write_project(from_legacy(timeline,origin=str(work/'timeline.json')),draft)
            state['pro_project']=str(draft);data['draft_pro_project']=str(draft)
            save(timeline,work/'timeline.json');save(data['quality'],work/'media_quality.json')
            return data,preview_video(timeline,'media') if data['quality']['ready'] or quality_mode=='draft' else []
        media_data=gate('media',{'assets':timeline['assets'],'shots':timeline['shots'],'segments':segments,'semantic':semantic,
                               'media_plan':source_plan},prepare_media)
        segments=media_data['segments']

        begin('effects','مؤثرات قصيرة عند الوقفات والنبرة المناسبة؛ خفض تحت صوتك')
        available=sound_effects.library(project/'sound_library')
        effects=sound_effects.suggest(timeline,available)
        def prepare_effects(data):
            sound_effects.validate(data['effects'],clean_limit,segments)
            timeline['sound_effects']=data['effects']
            mixed=sound_effects.preview(clean,data['effects'],preview_folder('effects_audio')/'effects_preview.wav',clean_limit,cancel,already_processed=True)
            return data,[{'label':'اسمع المؤثرات مع صوتك','path':mixed},*preview_video(timeline,'effects')]
        effects_data=gate('effects',{'effects':effects,'library':available},prepare_effects)

        begin('reactions','الميمز اختيارية؛ لا اقتراح عشوائي ولا ميم فوق معلومة مهمة')
        memes=suggest_memes(segments,timeline['assets'],clean_limit,True,profile['editing']['meme_spacing'],profile['editing']['meme_duration'])
        for m in memes:m['approved']=True
        def prepare_reactions(data):
            timeline['assets']=data['assets'];timeline['memes']=data['memes'];validate_timeline(timeline)
            return data,preview_video(timeline,'reactions')
        reactions_data=gate('reactions',{'assets':timeline['assets'],'memes':memes},prepare_reactions)

        begin('montage','المونتاج الطويل والشورتات: جمل مكتملة، صوت واضح، ومراجعة فعلية')
        shorts=semantic['shorts'] if semantic else complete_shorts(segments,clean_limit)
        for s in shorts:s['approved']=True
        rendered=[];pro_document={}
        def prepare_montage(data):
            current_segments=captions.validate(data['segments'],clean_limit)
            for short in data['shorts']:
                if not 2<=short['end']-short['start']<=55:raise ValueError('الشورت بين ثانيتين و55 ثانية.')
                bounds=[0,clean_limit,*[w[k] for w in audio_context['words'] for k in ('start','end')]]
                if any(min((abs(at-b) for b in bounds),default=0)>.005 for at in (short['start'],short['end'])):
                    raise ValueError('ابدأ الشورت وأنهِه عند حدود الكلمات.')
            timeline.update(segments=current_segments,caption=data['caption'],shorts=[s for s in data['shorts'] if s.get('approved')])
            validate_timeline(timeline)
            from pro_project import from_legacy,sequence,write_project,import_media
            from pro_render import render as render_pro
            from media_tools import thumbnail
            document=from_legacy(timeline,origin=str(work/'timeline.json'))
            raw=import_media(audio);document['media'].append(raw)
            document['provenance'].update(original_audio_id=raw['id'],script=str(project/'script.txt'))
            folder=preview_folder('montage');folder.mkdir(parents=True,exist_ok=True);result=[]
            for i,seq in enumerate(document['sequences']):
                size=(sizes or {}).get('size' if i==0 else 'portrait_size',(1920,1080) if i==0 else (1080,1920))
                seq.update(width=size[0],height=size[1])
            for i,seq in enumerate(document['sequences']):
                dest=folder/('draft_long.mp4' if i==0 else f'draft_short_{i:02}.mp4')
                emit({'type':'log','message':'تركيب مسارات المشروع: '+seq['name']})
                item=render_pro(document,dest,seq['id'],cancel=cancel,
                    on_progress=lambda n,i=i:emit({'type':'render_progress','sequence':seq['name'],'progress':n,
                        'overall':round(100*(4+(i+n/100)/len(document['sequences']))/len(STAGES))}))
                item.update(sequence=seq['id'],portrait=seq['height']>seq['width']);result.append(item)
                if i:
                    text=[{'start':c['start']/document['fps'],'end':(c['start']+c['duration'])/document['fps'],'text':c['text']} for t in seq['tracks'] if t['kind']=='text' for c in t['clips']]
                    captions.write_srt(sorted(text,key=lambda c:c['start']),dest.with_suffix('.srt'))
            thumbnail(result[0]['path'],folder/'draft_after.png',cancel=cancel)
            pro_document.clear();pro_document.update(document)
            write_project(document,folder/'project.rash.json')
            rendered[:]=result
            return data,[{'label':'شاهد المقطع الطويل' if i==0 else f'شاهد الشورت {i}','path':r['path']} for i,r in enumerate(result)]
        montage_data=gate('montage',{'shorts':shorts,'segments':segments,'caption':timeline['caption']},prepare_montage)

        begin('delivery','تجهيز الملفات للنشر اليدوي؛ لا ثامنيل ولا اتصال بمنصة')
        title=' '.join(next((s.strip() for s in script.splitlines() if s.strip()),'RashSpeak').split()[:10])
        used={s['asset_id'] for s in timeline['shots']}|{m['asset_id'] for m in timeline['memes'] if m.get('approved')}
        credits=[a['rights'] for a in timeline['assets'] if a['id'] in used and a.get('rights')]
        attribution=credits_text(credits)
        for e in timeline['sound_effects']:
            if e.get('approved'):attribution+='\n\nالمؤثر: '+e['type']+'\nالمصدر: '+e['source']+'\nالرخصة: '+e['license']+'\nالتعديل: قص وتحجيم الصوت وخفضه تحت التعليق.'
        (work/'delivery_credits.txt').write_text(attribution,encoding='utf-8')
        def prepare_delivery(data):
            if not data['title'].strip() or len(data['title'])>100 or len(data['description'])>10_000:raise ValueError('عنوان حتى 100 حرف ووصف حتى 10 آلاف حرف.')
            return data,[{'label':'شاهد الملف قبل تنزيله','path':r['path']} for r in rendered]
        metadata=gate('delivery',{'title':title,'description':long_description(title),'credits':attribution},prepare_delivery)
        check();deliver.mkdir()
        files=[]
        for i,item in enumerate(rendered):
            name='long_video.mp4' if i==0 else f'short_{i:02}.mp4';dest=deliver/name;shutil.copy2(item['path'],dest)
            files.append({**item,'path':str(dest),'fingerprint':fingerprint(dest),'kind':'long' if i==0 else 'short'})
            if i:shutil.copy2(Path(item['path']).with_suffix('.srt'),deliver/f'short_{i:02}.srt')
        captions.write_srt(timeline['segments'],deliver/'captions_ar.srt')
        (deliver/'description.txt').write_text(metadata['description']+'\n\n'+attribution,encoding='utf-8')
        (deliver/'title.txt').write_text(metadata['title'],encoding='utf-8')
        (deliver/'MEDIA_CREDITS.txt').write_text(attribution,encoding='utf-8')
        shutil.copy2(clean,deliver/'clean_narration.wav')
        save(analysis,deliver/'audio_edits.json');save(timeline,deliver/'timeline.json');save(state['stage_reviews'],deliver/'stage_reviews.json')
        shutil.copytree(work/'reviews',deliver/'reviews')
        if fingerprint(audio)!=identity['fingerprint']:raise ValueError('تغيّر التسجيل أثناء الإنتاج؛ أعد العملية من الأصل الصحيح.')
        cards=sorted({a.get('game','') for a in timeline['assets'] if a['id'] in used and a.get('editorial_card')})
        if cards:state['warnings'].append('بطاقات معلنة بدل لقطات غير متاحة: '+', '.join(cards))
        if not any(m.get('approved') for m in timeline['memes']):state['warnings'].append('لا ميم مفعّل؛ لا يوجد أصل مناسب أو اخترت إبقاء المقطع دون ميمز.')
        if not timeline['shorts']:state['warnings'].append('لا شورت معتمد؛ لم نقطع جملة عشوائيًا لإنتاج ملف شكلي.')
        from pro_project import write_project
        write_project(pro_document,work/'project.rash.json')
        final_quality=assess_quality(timeline)
        state.update(status='ready_for_review' if final_quality['ready'] else 'draft_ready_for_review',quality=final_quality,
                     delivery=str(deliver),files=files,pro_project=str(work/'project.rash.json'),preview_image=str(Path(rendered[0]['path']).parent/'draft_after.png'),
                     original_duration=limit,clean_duration=clean_limit,removed_seconds=round(limit-clean_limit,3),
                     edits_removed=sum(e['action']=='remove' for e in analysis['edits']),script_coverage=analysis['coverage'],
                     reaction_count=sum(bool(m.get('approved')) for m in timeline['memes']),
                     effect_count=sum(bool(e.get('approved')) for e in timeline['sound_effects']),cards_used=cards,
                     review_required=not bool(on_review),original_preserved=True,thumbnail=None)
        state['warnings']=list(dict.fromkeys(state['warnings']));save(state,project/'production.json');save(state,deliver/'delivery_report.json')
        save({'version':'2.3','assets':timeline['assets']},work/'manifest.json');save(timeline['segments'],work/'transcript.json')
        save(timeline,work/'timeline.json')
        save({'audio':clean,'out':str(work),'model':str(model or app_dir()/'models/small'),'script':str(project/'script.txt'),'cues':str(cues)},work/'project.json')
        emit({'type':'complete','result':state,'progress':100});return state
    except Exception as exc:
        if isinstance(exc,MissingFootage):
            state['status']='needs_media';state['quality']=exc.report;state['error']=str(exc)
            state['stages'][stage_key]='needs_media'
            save(state,project/'production.json')
            emit({'type':'needs_media','message':str(exc),'result':state})
            raise
        state['status']='cancelled' if isinstance(exc,Cancelled) else 'failed';state['error']=str(exc)
        state['stages'][stage_key]='cancelled' if isinstance(exc,Cancelled) else 'failed';save(state,project/'production.json')
        emit({'type':'failed','message':str(exc),'stage':stage_key});raise
