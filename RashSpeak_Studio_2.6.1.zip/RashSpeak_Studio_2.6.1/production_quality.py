"""Auto Studio acceptance checks. A decoded placeholder is not a finished montage."""
from collections import defaultdict
from licensed_media import game_key, same_game, visual_suitable
from smart_editor import licensed, normalize
from pathlib import Path
import json


class MissingFootage(ValueError):
    def __init__(self, report):
        self.report = report
        super().__init__('تغطية اللقطات غير كافية؛ حُفظت المسودة ولم يُنتج فيديو نهائي من البطاقات. '
                         + '؛ '.join(report['blockers']))


def _union_length(ranges):
    end = 0.; total = 0.
    for lo, hi in sorted(ranges):
        if hi > max(lo, end):
            total += hi - max(lo, end)
        end = max(end, hi)
    return total


def assess(timeline):
    limit = timeline['duration']; assets = {a['id']: a for a in timeline['assets']}
    videos = []; cards = []; topics = defaultdict(lambda: {'required': [], 'covered': []})
    duplicate = []; longest_card = 0.; card_start = None; previous_end = 0.
    for shot in sorted(timeline['shots'], key=lambda s: s['start']):
        start, end = shot['start'], shot['end']; asset = assets.get(shot.get('asset_id'), {})
        card = bool(asset.get('editorial_card') or asset.get('missing_media') or not asset)
        display_text=asset.get('display_text','')
        if card and not display_text and asset.get('path'):
            metadata=Path(asset['path']).with_suffix('.json')
            if metadata.is_file():
                try:display_text=json.loads(metadata.read_text(encoding='utf-8-sig')).get('headline','')
                except (OSError,ValueError,AttributeError):pass
        if card:
            cards.append((start, end))
            if card_start is None or start > previous_end + .001:
                card_start = start
            longest_card = max(longest_card, end - card_start)
        else:
            card_start = None
        previous_end = end
        usable = (not card and asset.get('kind') in ('video', 'animation') and licensed(asset)
                  and visual_suitable(asset, 'gameplay'))
        if usable:
            offset = shot.get('source_offset', 0)
            usable = offset >= 0 and offset + end - start <= asset.get('duration', 0) + .02
        for segment in timeline['segments']:
            lo, hi = max(start, segment['start']), min(end, segment['end'])
            if hi <= lo:
                continue
            semantic = segment.get('semantic', {})
            game = semantic.get('game') or segment.get('story_topic', '')
            if game:
                topics[game_key(game)]['required'].append((lo, hi))
            matches = usable and (not game or same_game(asset.get('game'), game))
            # Event-specific sentences cannot inherit arbitrary footage of the same game.
            if semantic.get('search_intent') == 'specific_event':
                matches = matches and normalize(asset.get('event', '')) == normalize(semantic.get('event', ''))
            if matches:
                videos.append((lo, hi))
                if game:
                    topics[game_key(game)]['covered'].append((lo, hi))
            label=normalize(display_text)
            # A game name can contain four or more words. A topic label is not
            # a second transcript just because that name is also spoken.
            topic_labels={normalize(value) for value in (
                asset.get('game',''),shot.get('topic',''),game) if value}
            if card and label not in topic_labels and len(label.split())>=4 and label in normalize(segment['text']):
                duplicate.append({'start': lo, 'end': hi})
    coverage = _union_length(videos) / max(.001, limit)
    card_ratio = _union_length(cards) / max(.001, limit)
    missing = [{'game': game, 'required_seconds': round(_union_length(data['required']), 2),
                'covered_seconds': round(_union_length(data['covered']), 2)}
               for game, data in topics.items()
               if _union_length(data['required']) >= 8 and _union_length(data['covered']) < .6 * _union_length(data['required'])]
    blockers = []
    if coverage < .8:
        blockers.append(f'لقطات متحركة مطابقة تغطي {coverage:.1%}؛ المطلوب 80% على الأقل')
    if card_ratio > .1 or longest_card > 4:
        blockers.append(f'البطاقات تغطي {card_ratio:.1%}؛ أطول امتداد {longest_card:.1f} ثانية')
    if missing:
        blockers.append('مواضيع تحتاج لقطات: ' + ', '.join(t['game'] for t in missing))
    if duplicate:
        blockers.append('يوجد نص منطوق مكرر في الخلفية والترجمة')
    return {'ready': not blockers, 'matching_video_ratio': round(coverage, 5),
            'placeholder_ratio': round(card_ratio, 5), 'longest_placeholder_seconds': round(longest_card, 3),
            'missing_topics': missing, 'duplicate_text_ranges': duplicate, 'blockers': blockers,
            'effect_count': sum(bool(e.get('approved')) for e in timeline.get('sound_effects', [])),
            'meme_count': sum(bool(e.get('approved')) for e in timeline.get('memes', [])),
            'thresholds': {'matching_video_ratio': .8, 'max_placeholder_ratio': .1, 'max_placeholder_seconds': 4}}
