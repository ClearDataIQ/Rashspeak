"""One compositor for Pro Editor proxies, frame preview and final exports."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile
import time
import os
import shutil
import zipfile

import captions
from media_tools import Cancelled, probe, run, tool
from pro_project import validate, sequence, length, write_project, media_matches, edit_digest
from smart_editor import fingerprint, licensed, save
from pro_effects import audio_filters,color_filters,volume_filter,mask_filter,curve_expression


def position_expression(clip,prop,fps,dimension):
    expr=curve_expression(clip.get('keyframes',{}).get(prop,[]),fps,clip['transform'][prop],f'(t-{clip["start"]/fps})','value')
    return f'({expr})*{dimension}'


def execute(command, progress_file, total_frames, cancel=None, on_progress=None):
    """FFmpeg progress is measured from output frames, never a synthetic timer."""
    process=subprocess.Popen([tool('ffmpeg'),'-protocol_whitelist','file,pipe',*map(str,command)],cwd=progress_file.parent,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                             creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
    deadline=time.monotonic()+max(600,total_frames*2)
    last=-1
    try:
        while True:
            if cancel and cancel.is_set():raise Cancelled('أُلغي التصدير؛ لم يُستبدل الملف النهائي.')
            if time.monotonic()>deadline:raise TimeoutError('انتهت مهلة التصدير.')
            if progress_file.exists():
                lines=progress_file.read_text(errors='replace').splitlines()
                values=[int(l.split('=',1)[1]) for l in lines if l.startswith('frame=') and l.split('=',1)[1].strip().isdigit()]
                if values:
                    value=min(99,int(values[-1]*100/total_frames))
                    if value!=last:
                        last=value
                        if on_progress:on_progress(value)
            try:
                _,stderr=process.communicate(timeout=.2);break
            except subprocess.TimeoutExpired:pass
    except BaseException:
        process.kill();process.communicate();raise
    if process.returncode:raise RuntimeError(f'فشل تركيب المسارات (exit {process.returncode}):\n'+'\n'.join(stderr.decode(errors='replace').splitlines()[-12:]))


def used_clips(project, seq):
    for track in seq['tracks']:
        if track['kind'] in ('audio','effect') and track['muted']:continue
        if track['kind'] not in ('audio','effect') and track['hidden']:continue
        for clip in sorted(track['clips'],key=lambda c:(c['start'],c['id'])):
            yield track,clip


def render(project,output,sequence_id=None,size=None,codec='h264',crf=21,cancel=None,on_progress=None,encoder='cpu',bitrate=None):
    p=deepcopy(validate(project));s=sequence(p,sequence_id);fps=p['fps'];count=length(s);seconds=count/fps
    size=tuple(size or (s['width'],s['height']))
    if len(size)!=2 or any(type(x)is not int or not 180<=x<=4096 or x%2 for x in size):raise ValueError('أبعاد تصدير غير صالحة.')
    if codec not in ('h264','h265') or type(crf)is not int or not 12<=crf<=35:raise ValueError('إعداد ترميز غير صالح.')
    if encoder not in ('cpu','nvenc') or (bitrate is not None and (type(bitrate)is not int or not 1000000<=bitrate<=100000000)):raise ValueError('المشفّر أو Bitrate غير صالح.')
    media={a['id']:a for a in p['media']};active=list(used_clips(p,s));used={c['media_id'] for _,c in active if c['media_id']}
    for key in used:
        a=media[key]
        if not licensed(a):raise ValueError('أصل ينتظر موافقة الحقوق: '+a['path'])
        if not media_matches(a):raise ValueError('أصل تغير أو مفقود: '+a['path'])
    for t,c in active:
        if t['kind'] not in ('video','image'):continue
        maximum=max([c['transform']['scale'],*[k['value'] for k in c.get('keyframes',{}).get('scale',[])]])
        if max(size)*maximum>8192 or size[0]*size[1]*maximum*maximum>50000000:
            raise ValueError('طبقة كبيرة جدًا للمعالجة الحالية؛ خفّض Scale أو دقة التسلسل قبل التصدير.')
    output=Path(output).resolve();output.parent.mkdir(parents=True,exist_ok=True)
    if output.suffix.lower()!='.mp4':raise ValueError('اختر ملف MP4.')
    if str(output) in {str(Path(a['path']).resolve()) for a in p['media']}:raise ValueError('لا يمكن الكتابة فوق مصدر أصلي.')
    if sum(t['kind']!='text' for t,_ in active)>128:
        from render_partitions import render_partitioned
        return render_partitioned(p,output,s['id'],size,codec,crf,cancel,on_progress,encoder,bitrate)
    w,h=size
    with tempfile.TemporaryDirectory(prefix='rash-pro-',dir=output.parent) as folder:
        tmp=Path(folder);progress_file=tmp/'progress.txt';target=tmp/'render.mp4'
        command=['-v','error','-y','-nostdin','-progress',progress_file,'-f','lavfi','-i',f'color=c=0x101b30:s={w}x{h}:r={fps}:d={seconds}',
                 '-f','lavfi','-i',f'anullsrc=r=48000:cl=stereo:d={seconds}']
        graph=['[0:v]format=rgba[base]','[1:a]aformat=sample_fmts=fltp:channel_layouts=stereo[silence]']
        current='base';audio=[];effects=[];index=2;vnum=0;anum=0
        for track in s['tracks']:
            if track['kind']=='text':
                if track['hidden'] or not track['clips']:continue
                caption=track.get('caption',{'font':'Arial','style':'clean','region':[.1,.78,.8,.15]})
                region=caption.get('portrait_region',[.1,.70,.74,.12]) if h>w else caption['region']
                from pro_subtitles import caption_segments
                segments=caption_segments(track,fps)
                file=tmp/f'text_{vnum}.ass'
                from timeline_render import caption_font
                font,fontsdir=caption_font(caption,tmp)
                captions.write_ass(segments,file,size,font,caption.get('style','clean'),region,
                    font_size=caption['font_size']*min(w/s['width'],h/s['height']) if caption.get('font_size') else None,
                    outline=caption.get('outline'),highlight=caption.get('highlight',False))
                nxt=f'text{vnum}';graph.append(f'[{current}]ass={file.name}:shaping=complex{fontsdir}[{nxt}]');current=nxt;vnum+=1
                continue
            if (track['kind'] in ('audio','effect') and track['muted']) or (track['kind'] not in ('audio','effect') and track['hidden']):continue
            track_audio=[]
            for c in sorted(track['clips'],key=lambda c:(c['start'],c['id'])):
                a=media[c['media_id']];dur=c['duration']/fps;at=c['start']/fps
                rate=c.get('rate',1.);source_duration=dur*rate
                if a['kind']=='image':command+=['-loop','1','-framerate',fps,'-threads','1','-i',a['path']]
                else:
                    if c['loop']:command+=['-stream_loop','-1']
                    command+=['-ss',c['in']/fps,'-t',source_duration,'-threads','1','-i',a['path']]
                if track['kind'] in ('audio','effect'):
                    name=f'a{anum}';parts=[f'[{index}:a]atrim=duration={dur}','asetpts=PTS-STARTPTS','aresample=48000','aformat=sample_fmts=fltp:channel_layouts=stereo',
                        *audio_filters(c.get('processing',{})),volume_filter(c['gain_db'],c.get('volume_automation',[]),fps)]
                    if c['fade_in']:parts.append(f'afade=t=in:st=0:d={c["fade_in"]/fps}')
                    if c['fade_out']:parts.append(f'afade=t=out:st={dur-c["fade_out"]/fps}:d={c["fade_out"]/fps}')
                    parts += [f'adelay={round(at*48000)}S:all=1',f'apad=whole_dur={seconds}']
                    graph.append(','.join(parts)+f'[{name}]');track_audio.append(name);anum+=1
                else:
                    tr=c['transform']
                    crop=c.get('crop',{'left':0,'top':0,'right':0,'bottom':0})
                    cover=c.get('fit','contain')=='cover'
                    fit_filter=f'crop={w}:{h}' if cover else f'pad={w}:{h}:(ow-iw)/2:(oh-ih)/2:color=black@0'
                    name=f'v{vnum}';parts=[f'[{index}:v]trim=duration={source_duration}',*(['reverse'] if c.get('reverse') else []),f'setpts=(PTS-STARTPTS)/{rate}',f'fps={fps}',
                                         f'crop=iw*{1-crop["left"]-crop["right"]}:ih*{1-crop["top"]-crop["bottom"]}:iw*{crop["left"]}:ih*{crop["top"]}',f'scale={w}:{h}:force_original_aspect_ratio={"increase" if cover else "decrease"}',
                                         'format=rgba',fit_filter,'setsar=1']
                    color=color_filters(c.get('color',{}))
                    if color:
                        graph.append(','.join(parts)+f'[pre{vnum}]')
                        graph.extend([f'[pre{vnum}]split[colin{vnum}][alpin{vnum}]',f'[alpin{vnum}]alphaextract[alpha{vnum}]',
                                      f'[colin{vnum}]'+','.join(color)+f',format=rgb24[graded{vnum}]',
                                      f'[graded{vnum}][alpha{vnum}]alphamerge[merged{vnum}]'])
                        parts=[f'[merged{vnum}]format=rgba']
                    if tr.get('rotation'):parts.append(f'rotate={tr["rotation"]}*PI/180:c=none:ow=iw:oh=ih')
                    if c.get('mask'):parts.append(mask_filter(c['mask']))
                    scale=curve_expression(c.get('keyframes',{}).get('scale',[]),fps,tr['scale'],'t','value')
                    opacity=curve_expression(c.get('keyframes',{}).get('opacity',[]),fps,tr['opacity'],'T','value')
                    if c.get('keyframes',{}).get('opacity'):parts.append(f"geq=r='r(X,Y)':g='g(X,Y)':b='b(X,Y)':a='alpha(X,Y)*({opacity})'")
                    else:parts.append(f'colorchannelmixer=aa={tr["opacity"]}')
                    if c['fade_in']:parts.append(f'fade=t=in:st=0:d={c["fade_in"]/fps}:alpha=1')
                    if c['fade_out']:parts.append(f'fade=t=out:st={dur-c["fade_out"]/fps}:d={c["fade_out"]/fps}:alpha=1')
                    # Alpha/mask kernels keep a fixed canvas; scaling afterward avoids
                    # FFmpeg geq reinitialization crashes on changing frame dimensions.
                    parts.append(f"scale=w='max(2,trunc(iw*({scale})/2)*2)':h='max(2,trunc(ih*({scale})/2)*2)':eval=frame")
                    parts.append(f'setpts=PTS+{at}/TB');graph.append(','.join(parts)+f'[{name}]')
                    xpos=position_expression(c,'x',fps,w);ypos=position_expression(c,'y',fps,h)
                    nxt=f'ov{vnum}';graph.append(f'[{current}][{name}]overlay=x=\'{xpos}\':y=\'{ypos}\':enable=\'gte(t,{at})*lt(t,{at+dur})\':eof_action=pass:repeatlast=0[{nxt}]')
                    current=nxt;vnum+=1
                index+=1
            if track_audio:
                name=f'tracka{anum}';bus=f'bus{anum}'
                graph.append(''.join(f'[{a}]' for a in track_audio)+f'amix=inputs={len(track_audio)}:normalize=0:dropout_transition=0[{bus}]')
                filters=[*audio_filters(track.get('processing',{})),volume_filter(track['gain_db'],track.get('volume_automation',[]),fps)]
                graph.append(f'[{bus}]'+','.join(filters)+f'[{name}]');(effects if track['kind']=='effect' else audio).append(name);anum+=1
        voice='silence'
        if audio:
            graph.append(''.join(f'[{a}]' for a in ['silence',*audio])+f'amix=inputs={len(audio)+1}:normalize=0:dropout_transition=0[voice]');voice='voice'
        if effects:
            graph.append(''.join(f'[{a}]' for a in effects)+f'amix=inputs={len(effects)}:normalize=0:dropout_transition=0[fx]')
            graph += [f'[{voice}]asplit[mainvoice][control]','[fx][control]sidechaincompress=threshold=0.015:ratio=8:attack=5:release=120[ducked]',
                      '[mainvoice][ducked]amix=inputs=2:normalize=0:dropout_transition=0[mixed]'];voice='mixed'
        graph += [f'[{voice}]atrim=duration={seconds},alimiter=limit=0.95:level=false:latency=true[outa]',f'[{current}]format=yuv420p[outv]']
        video_codec=('h264_nvenc' if codec=='h264' else 'hevc_nvenc') if encoder=='nvenc' else 'libx264' if codec=='h264' else 'libx265'
        quality=['-b:v',bitrate,'-maxrate',round(bitrate*1.5),'-bufsize',bitrate*2] if bitrate else ['-cq' if encoder=='nvenc' else '-crf',crf]
        available_cpus=len(os.sched_getaffinity(0)) if hasattr(os,'sched_getaffinity') else (os.cpu_count() or 1)
        command+=['-filter_complex_threads',str(min(4,available_cpus)),'-filter_complex',';'.join(graph),'-map','[outv]','-map','[outa]','-t',seconds,'-r',fps,
                  '-c:v',video_codec,'-preset','p4' if encoder=='nvenc' else 'veryfast',*quality,'-threads','2']
        if codec=='h265' and encoder=='cpu':command+=['-x265-params','pools=2:frame-threads=2']
        command+=['-c:a','aac','-b:a','192k','-ar','48000','-movflags','+faststart',target]
        execute(command,progress_file,count,cancel,on_progress)
        info=probe(target);video=next(v for v in info['streams'] if v['codec_type']=='video')
        if (video['width'],video['height'])!=size or abs(float(info['format']['duration'])-seconds)>max(.12,2/fps):raise RuntimeError('الرندر لا يطابق طول الخط الزمني أو أبعاده.')
        if video['codec_name']!=('h264' if codec=='h264' else 'hevc'):raise RuntimeError('ترميز غير مطابق.')
        for key in used:
            if not media_matches(media[key]):raise ValueError('تغير المصدر أثناء الرندر.')
        if cancel and cancel.is_set():raise Cancelled('أُلغي التصدير.')
        target.replace(output)
    if on_progress:on_progress(100)
    return {'path':str(output),'duration':seconds,'size':list(size),'fps':fps,'codec':codec,'encoder':encoder,'bitrate':bitrate,'crf':crf,'revision':p['revision'],'model_digest':edit_digest(p)}


def cache_key(project,sequence_id=None,size=(640,360)):
    # Includes media identity and the complete edit definition, not just timestamps.
    validate(project)
    used={c['media_id'] for _,c in used_clips(project,sequence(project,sequence_id)) if c['media_id']}
    for a in project['media']:
        if a['id'] in used and not media_matches(a):raise ValueError('أصل مفقود أو تغير: '+a['path'])
    return hashlib.sha256(json.dumps({'project':project,'seq':sequence_id,'size':size},sort_keys=True,ensure_ascii=False).encode()).hexdigest()


def proxy(project,cache,sequence_id=None,cancel=None,on_progress=None):
    s=sequence(project,sequence_id);size=(360,640) if s['height']>s['width'] else (640,360)
    folder=Path(cache);folder.mkdir(parents=True,exist_ok=True)
    key=cache_key(project,sequence_id,size);path=folder/(key+'.mp4');meta=path.with_suffix('.json')
    if path.exists() and meta.exists() and json.loads(meta.read_text())['fingerprint']==fingerprint(path):
        save({'fingerprint':fingerprint(path),'last_access':time.time()},meta)
        if on_progress:on_progress(100)
        return str(path)
    render(project,path,sequence_id,size=size,crf=28,cancel=cancel,on_progress=on_progress)
    save({'fingerprint':fingerprint(path),'last_access':time.time()},meta)
    from preview_cache import prune
    prune(folder,protected=[path,*[a['path'] for a in project['media']]])
    return str(path)


def frame_window(project,at,sequence_id=None):
    """Keep complete visible clips at the cursor, preserving temporal effects.

    Frame review must not encode an entire episode or mix its narration. Keep
    each active visual clip's full extent so reverse, fades and keyframes still
    use precisely the export compositor. Long individual clips can still take
    time; this bounds work by those clips rather than the whole timeline.
    """
    from render_partitions import slice_video
    p=deepcopy(validate(project));s=sequence(p,sequence_id)
    at=max(0,min(int(at),length(s)-1))
    visible=[c for t,c in used_clips(p,s)
             if t['kind'] in ('video','image') and c['start']<=at<c['start']+c['duration']]
    start=min((c['start'] for c in visible),default=at)
    end=max((c['start']+c['duration'] for c in visible),default=at+1)
    for track in s['tracks']:
        track['clips']=[c for c in track['clips']
                        if track['kind'] not in ('audio','effect') and not track['hidden']
                        and c['start']<=at<c['start']+c['duration']]
    p=slice_video(p,s['id'],start,end)
    # Stable internal ids allow repeated cursor positions to reuse the proxy.
    boundary=sequence(p,s['id'])['tracks'][-1]
    boundary['id']=hashlib.sha256((s['id']+':frame-boundary').encode()).hexdigest()[:16]
    boundary['clips'][0]['id']=hashlib.sha256((s['id']+':frame-boundary-clip').encode()).hexdigest()[:16]
    return p,at-start


def frame(project,output,at,sequence_id=None,cancel=None):
    # Seeking the bounded composition preserves fades and temporal effects.
    p,local_at=frame_window(project,at,sequence_id);s=sequence(p,sequence_id);fps=p['fps']
    output=Path(output).resolve()
    if str(output) in {str(Path(a['path']).resolve()) for a in p['media']}:raise ValueError('لا يمكن الكتابة فوق الأصل.')
    output.parent.mkdir(parents=True,exist_ok=True)
    video=proxy(p,output.parent/'proxy_cache',s['id'],cancel=cancel)
    with tempfile.TemporaryDirectory(prefix='rash-frame-',dir=output.parent) as folder:
        temporary=Path(folder)/'frame.png'
        run(['ffmpeg','-v','error','-y','-ss',local_at/fps,'-i',video,'-frames:v','1',temporary],cancel=cancel)
        temporary.replace(output)
    return str(output)


def package(project,destination,exports=(),cancel=None):
    """A new self-contained directory and ZIP. Originals are copied, never moved."""
    validate(project,files=True);dest=Path(destination).resolve()
    if dest.exists():raise ValueError('اختر مجلد تسليم جديدًا حتى لا تُستبدل ملفاتك.')
    dest.mkdir(parents=True);p=deepcopy(project)
    try:
        for name in ('Project','Original_Audio','Media','Long_Video','Shorts','Thumbnails','Subtitles','Export'):(dest/name).mkdir()
        credits=[]
        for a in p['media']:
            if cancel and cancel.is_set():raise Cancelled('أُلغي تجهيز المشروع.')
            sub='Original_Audio' if a['kind']=='audio' else 'Media';target=dest/sub/(a['id']+Path(a['path']).suffix.lower())
            shutil.copy2(a['path'],target);a['path']=str(target);a['fingerprint']=fingerprint(target)
            digest=hashlib.sha256()
            with target.open('rb') as stream:
                for block in iter(lambda:stream.read(1024*1024),b''):digest.update(block)
            a['sha256']=digest.hexdigest()
            credits.append({'id':a['id'],'license':a.get('license',''),'source':a.get('source',''),'rights':a.get('rights',{}),'approved':a.get('usage_approved',False)})
        for key in ('script','audio_edit_decisions','legacy_timeline'):
            value=p['provenance'].get(key)
            if value and Path(value).is_file():
                target=dest/'Project'/(key+Path(value).suffix);shutil.copy2(value,target);p['provenance'][key]=str(target)
        for s in p['sequences']:
            for t in s['tracks']:
                font=t.get('caption',{}).get('font_file')
                if font:
                    target=dest/'Project'/'Fonts'/Path(font).name;target.parent.mkdir(exist_ok=True);shutil.copy2(font,target)
                    t['caption']['font_file']=str(target)
        for i,item in enumerate(exports):
            sub='Shorts' if item.get('portrait') or item.get('kind')=='short' else 'Long_Video'
            shutil.copy2(item['path'],dest/sub/f'{i+1:02}_{Path(item["path"]).name}')
        write_project(p,dest/'Project'/'project.rash.json');save(credits,dest/'Media'/'credits.json')
        rows=[]
        for c in credits:
            rights=c['rights']
            rows.extend((c['id'],rights.get('author',''),c['source'],c['license'],rights.get('license_url',''),rights.get('credit',''),''))
        (dest/'Media'/'MEDIA_CREDITS.txt').write_text('\n'.join(rows),encoding='utf-8')
        for s in p['sequences']:
            for t in s['tracks']:
                if t['kind']=='text' and not t['hidden']:
                    segments=[{'start':c['start']/p['fps'],'end':(c['start']+c['duration'])/p['fps'],'text':c['text']} for c in sorted(t['clips'],key=lambda c:c['start'])]
                    captions.write_srt(segments,dest/'Subtitles'/f'{s["id"]}_{t["id"]}.srt')
        save({'schema':'rashspeak.package/1','project':p['id'],'revision':p['revision'],'files':list(exports)},dest/'Export'/'report.json')
        archive=dest.with_suffix('.zip')
        if archive.exists():raise ValueError('ملف ZIP موجود؛ اختر اسمًا آخر.')
        temporary=archive.with_suffix('.zip.tmp')
        try:
            with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED) as z:
                for file in sorted(dest.rglob('*')):
                    if cancel and cancel.is_set():raise Cancelled('أُلغي تجهيز ZIP.')
                    z.write(file,Path(dest.name)/file.relative_to(dest))
            temporary.replace(archive)
        finally:temporary.unlink(missing_ok=True)
        return {'folder':str(dest),'zip':str(archive)}
    except Exception:
        shutil.rmtree(dest);raise
