"""Official metadata APIs. Search results never establish usage rights by themselves."""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
from urllib.parse import urlparse

import requests

from app_paths import app_dir
from licensed_media import game_key


class SourceUnavailable(RuntimeError):
    pass


HANDLES = {
    game_key('Battlefield'): ['@Battlefield'],
    game_key('Elden Ring'): ['@BandaiNamcoAmerica'],
    game_key('Ghost of Tsushima'): ['@PlayStation'],
    game_key('Red Dead Redemption 2'): ['@RockstarGames'],
    game_key('The Witcher 3'): ['@thewitcher'],
    game_key('Cyberpunk 2077'): ['@CyberpunkGame'],
    game_key('Zelda BOTW'): ['@NintendoAmerica'],
    game_key("Assassin's Creed Mirage"): ['@Ubisoft'],
    game_key('Fortnite'):['@Fortnite'],game_key('Minecraft'):['@minecraft'],
    game_key('Call of Duty'):['@CallofDuty'],game_key('Helldivers 2'):['@PlayStation'],
    game_key('Starfield'):['@Bethesda'],game_key('Hogwarts Legacy'):['@HogwartsLegacy'],
    game_key('GTA'):['@RockstarGames'],game_key('GTA 6'):['@RockstarGames'],
    game_key('PlayStation'):['@PlayStation'],game_key('Xbox'):['@Xbox'],
    game_key('Nintendo Switch'):['@NintendoAmerica'],game_key('Electronic Arts'):['@EA'],
}
_SESSION_KEYS = {}
ENV_NAMES = {'youtube': 'RASH_YOUTUBE_API_KEY', 'images': 'RASH_GOOGLE_SEARCH_API_KEY',
             'engine': 'RASH_GOOGLE_SEARCH_ENGINE_ID'}


def credential(kind):
    if kind in _SESSION_KEYS:
        return _SESSION_KEYS[kind]
    value = os.getenv(ENV_NAMES[kind], '')
    if not value and kind in ('youtube','images'):value=os.getenv('RASH_GOOGLE_API_KEY','')
    if not value and kind=='images':value=_SESSION_KEYS.get('youtube') or os.getenv('RASH_YOUTUBE_API_KEY','')
    if value:
        return value
    try:
        import keyring
        value=keyring.get_password('RashSpeakMediaSources', kind) or ''
        if not value and kind=='images':value=keyring.get_password('RashSpeakMediaSources','youtube') or ''
        return value
    except Exception:
        return ''


def configure_credential(kind, value, persist=False):
    if kind not in ENV_NAMES:
        raise ValueError('إعداد مصدر غير معروف.')
    value = value.strip()
    if persist:
        import keyring
        keyring.set_password('RashSpeakMediaSources', kind, value)
    _SESSION_KEYS[kind] = value


def config_path():
    return app_dir() / 'output' / 'media_library' / 'source_settings.json'


def settings():
    path = config_path()
    return json.loads(path.read_text()) if path.is_file() else {'channels': {}, 'permissions': {}}


def apply_permission(candidate, config=None):
    from source_policy import ai_generated
    if ai_generated(candidate):
        candidate['rights_status']='blocked_ai_generated';return candidate
    config = config if config is not None else settings()
    grant = config.get('permissions', {}).get(candidate['id'])
    if grant is None and candidate.get('official_channel_checked'):
        grant = config.get('permissions', {}).get(candidate.get('channel_handle'))
    if grant:
        from media_acquisition import permission
        candidate['permission'] = dict(grant)
        candidate['rights_status'] = 'approved'
        try:
            permission(candidate)
        except SourceUnavailable:
            candidate['rights_status'] = 'pending'
    return candidate


def channel_handles(game, config=None):
    config = settings() if config is None else config
    key = game_key(game)
    handles = config.get('channels', {}).get(key, HANDLES.get(key, []))
    if key.startswith('battlefield') and not handles:
        handles = HANDLES[game_key('Battlefield')]
    return [h for h in handles if re.fullmatch(r'@[A-Za-z0-9_.-]{2,80}', h)]


def _get_json(url, params, http=requests, cancel=None):
    if cancel and cancel.is_set():
        from media_tools import Cancelled
        raise Cancelled('أُلغي البحث في المصادر الرسمية.')
    try:
        response = http.get(url, params=params, timeout=(8, 25), allow_redirects=False)
    except requests.exceptions.ProxyError:
        raise SourceUnavailable('وكيل الشبكة رفض الاتصال قبل المصادقة؛ تعذر التحقق من المفتاح. راجع اتصال البيئة بالمصدر.') from None
    except requests.exceptions.Timeout:
        raise SourceUnavailable('انتهت مهلة اتصال المصدر؛ تحقق من الشبكة ثم أعد المحاولة.') from None
    except requests.RequestException:
        # Request exceptions can include an API key in the query string.
        raise SourceUnavailable('تعذر اتصال المصدر؛ تحقق من الشبكة وإعداد الخدمة.') from None
    try:
        if response.status_code != 200:
            raise SourceUnavailable(f'المصدر أعاد HTTP {response.status_code}؛ لم تُحمّل وسائط.')
        if len(response.content) > 2_000_000:
            raise SourceUnavailable('رد المصدر أكبر من الحد.')
        try:value = response.json()
        except ValueError:raise SourceUnavailable('المصدر أعاد بيانات غير صالحة.') from None
        if not isinstance(value, dict) or 'error' in value:
            raise SourceUnavailable('المصدر لم يُرجع نتيجة صالحة.')
        return value
    finally:
        response.close()


def _seconds(value):
    match = re.fullmatch(r'PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?', value)
    return sum(int(x or 0) * n for x, n in zip(match.groups(), (3600, 60, 1))) if match else 0


class YouTubeOfficial:
    def __init__(self, key=None, config=None, http=requests, cancel=None):
        self.key = credential('youtube') if key is None else key
        self.config = config if config is not None else settings()
        self.http, self.cancel = http, cancel
        self.channels = {}

    def request(self, resource, **params):
        if not self.key:
            raise SourceUnavailable('مفتاح YouTube Data API غير معدّ؛ بحث القنوات الرسمية غير متاح.')
        return _get_json('https://www.googleapis.com/youtube/v3/' + resource,
                         {**params, 'key': self.key}, self.http, self.cancel)

    def search(self, request):
        handles = channel_handles(request['game'], self.config)
        if not handles:
            raise SourceUnavailable('لم تُحدّد قناة رسمية موثوقة لهذه اللعبة: ' + request['game'])
        results = []
        for handle in handles[:2]:
            if handle not in self.channels:
                channels = self.request('channels', part='snippet', forHandle=handle).get('items',[])
                if len(channels) != 1:
                    raise SourceUnavailable('تعذّر التحقق من هوية القناة الرسمية.')
                self.channels[handle] = channels[0]
            channel = self.channels[handle]
            response = self.request('search', part='snippet', channelId=channel['id'], type='video',
                                    q=request['query'], maxResults=5, order='relevance')
            ids = [x.get('id', {}).get('videoId', '') for x in response.get('items', [])]
            ids = [x for x in ids if re.fullmatch(r'[A-Za-z0-9_-]{11}', x)]
            if not ids:
                continue
            details = self.request('videos', part='snippet,contentDetails,status', id=','.join(ids))
            for video in details.get('items', []):
                snippet = video.get('snippet', {})
                if (snippet.get('channelId') != channel['id'] or video['id'] not in ids
                        or video.get('status', {}).get('privacyStatus') != 'public'):
                    continue
                duration = _seconds(video.get('contentDetails', {}).get('duration', ''))
                if not 1 <= duration <= 7200:
                    continue
                video_id = video['id']
                results.append({'id': 'youtube:' + video_id, 'provider': 'youtube', 'video_id': video_id,
                                'url': 'https://www.youtube.com/watch?v=' + video_id,
                                'title': snippet.get('title', ''), 'description': snippet.get('description', '')[:1500],
                                'published_at': snippet.get('publishedAt', ''), 'duration': duration,
                                'channel_id': channel['id'], 'channel_handle': handle,
                                'author': snippet.get('channelTitle', ''), 'official_channel_checked': True,
                                'game': request['game'], 'event': request['event'],
                                'role':request.get('role','clip'),'mood':request.get('mood',''),
                                'entities': request['entities'], 'search_query': request['query'],
                                'license': video.get('status', {}).get('license', 'unknown'),
                                'rights_status': 'pending', 'scene_status': 'needs_timed_scene_review',
                                'retrieved_at': datetime.now(timezone.utc).isoformat()})
        return [apply_permission(r, self.config) for r in results]


class GoogleImages:
    def __init__(self, key=None, engine=None, http=requests, cancel=None):
        self.key = credential('images') if key is None else key
        self.engine = credential('engine') if engine is None else engine
        self.http, self.cancel = http, cancel

    def search(self, request):
        if not self.key or not self.engine:
            raise SourceUnavailable('بحث صور Google يحتاج مفتاح الخدمة ومعرّف محرك البحث.')
        data = _get_json('https://www.googleapis.com/customsearch/v1',
                         {'key': self.key, 'cx': self.engine, 'q': request['query'],
                          'searchType': 'image', 'num': 5, 'safe': 'active'}, self.http, self.cancel)
        results = []
        for item in data.get('items', []):
            original = item.get('link', '')
            page = item.get('image', {}).get('contextLink', '')
            if any(urlparse(u).scheme != 'https' or not urlparse(u).hostname
                   or urlparse(u).username or urlparse(u).password for u in (original, page)):
                continue
            import hashlib
            results.append({'id': 'image:' + hashlib.sha256(original.encode()).hexdigest()[:20],
                            'provider': 'google_images', 'url': original, 'source': page,
                            'title': item.get('title', ''), 'game': request['game'],
                            'role':request.get('role','clip'),'mood':request.get('mood',''),
                            'event': request['event'], 'entities': request['entities'],
                            'license': 'unknown', 'rights_status': 'pending'})
        return [apply_permission(r) for r in results]


class FreeImages:
    """Keyless Commons search. Only source-verified permissive licenses are returned."""
    def __init__(self,cancel=None):self.cancel=cancel

    def search(self,request):
        import hashlib
        from licensed_media import search
        hint=' '.join(request.get('entities',[]))
        try:items=search(request['game'],cancel=self.cancel,images=True,hint=hint)
        except (requests.RequestException,RuntimeError,ValueError):
            from media_tools import Cancelled
            if self.cancel and self.cancel.is_set():raise Cancelled('أُلغي بحث الصور.')
            raise SourceUnavailable('بحث الصور المجاني غير متاح مؤقتًا؛ لم يُختر بديل غير مطابق.') from None
        results=[]
        for item in items:
            results.append({'id':'commons:'+hashlib.sha256(item['source'].encode()).hexdigest()[:20],
                'provider':'commons_images','url':item['url'],'source':item['source'],'title':item['title'],
                'game':request['game'],'event':request['event'],'entities':request['entities'],
                'role':request.get('role','clip'),'mood':request.get('mood',''),
                'author':item['author'],'license':item['license'],'duration':1,
                'rights_status':'approved','scene_status':'needs_image_review',
                'permission':{'usage_approved':True,'download_allowed':True,'license':item['license'],
                              'evidence_url':item['license_url'],'download_hosts':['upload.wikimedia.org']}})
        return results
