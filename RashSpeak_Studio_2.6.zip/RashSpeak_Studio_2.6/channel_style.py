"""One editable, versioned channel profile shared by scripts, edits and metadata."""
import copy
import json
import math
import re
from pathlib import Path
from urllib.parse import urlparse
from app_paths import app_dir
from smart_editor import save

DEFAULT = {
    'version': '2.1-rash-1', 'channel': '@RashSpeak', 'owner': 'راشد',
    'references': [
        {'url': 'https://youtu.be/nDXJLcR-IMM', 'title': 'توب 5 | أقوى 5 ألعاب عالم مفتوح لازم تلعبها', 'type': 'list', 'review_scope': 'Arabic transcript read; thumbnail and selected video frames inspected'},
        {'url': 'https://youtu.be/BNT7qxT84eg', 'title': 'اخر اخبار الالعاب | GTA 6 اقرب مما كنا نتوقع + لعبة جديدة قاعدة تكتسح السوق', 'type': 'news', 'review_scope': 'Arabic transcript read; thumbnail and intro inspected'},
        {'url': 'https://youtu.be/lhboq1E_IGg', 'title': 'سوالف راشد | لا تشتري The Last of Us 2 قبل ما تشوف هذا المقطع! (+16)', 'type': 'review', 'review_scope': 'Description and thumbnail read; English auto-dub transcript sampled'},
        {'url': 'https://youtu.be/eDAeIkw6qvs', 'title': 'وثائقي | تاريخ السيرفرات العربية وليش ما نلعب فيها !', 'type': 'documentary', 'review_scope': 'Description, chapters and thumbnail read; Arabic transcript sampled'},
    ],
    'script': {'intro': 'السلام عليكم ورحمة الله، معكم راشد.', 'dialect': 'saudi',
               'phrases': ['يا جماعة', 'يا رجل', 'ذحين', 'الحين', 'ترى', 'مرة', 'تبغى', 'خلونا', 'بإذن الله'],
               'structure': ['سلام وتعريف قصير', 'خطاف مرتبط بالموضوع', 'الحقائق ومصدرها', 'تعليق راشد الذي يراجعه بنفسه', 'سؤال وخاتمة'],
               'title_prefixes': {'news': 'اخر اخبار الالعاب', 'review': 'سوالف راشد', 'documentary': 'وثائقي', 'list': 'توب 5'}},
    'editing': {'scene_seconds': 6, 'meme_spacing': 45, 'meme_duration': 1.4,
                'reaction_assets_only': True, 'music_enabled': False, 'caption_style': 'gaming',
                'caption_font': 'Arial', 'caption_region': [.10, .78, .80, .15]},
    'thumbnail': {'primary': '#FFD24C', 'accent': '#08BEED', 'outline': '#111827',
                  'border': True, 'region': [.49, .22, .45, .60], 'max_words': 6,
                  'evidence': 'Yellow/cyan large Arabic headline and cyan border observed on nDXJLcR-IMM; a unified template, not a reconstruction of every thumbnail.'},
    'description': {'prayer': 'اللهم صل وسلم على نبينا محمد ﷺ',
                    'subscriber_count': '',
                    'social_heading': 'حساباتي على مواقع التواصل 👇',
                    'instagram': 'https://www.instagram.com/rashspeak/',
                    'instagram_note': 'انزل تسريبات هنا',
                    'tiktok': 'https://www.tiktok.com/@rashspeak',
                    'x_link': 'https://x.com/Rashspeak',
                    'thanks': 'شكراً على المشاهده اذا انبسطت وعجبك الفديو لا تحرمني من دعمك'},
    'evidence_notes': ['Descriptions share prayer, subscriber count, social links and thanks. Counts in old videos are historical and never copied as current.',
                       'News/reference videos use personal Saudi narration and direct viewer address.',
                       'Cut cadence and new burned-in caption settings are proposed common settings; every original cut was not measured.'],
}


def profile_path():
    return app_dir() / 'channel_style.json'


def validate_profile(profile):
    for key in ('version', 'script', 'editing', 'thumbnail', 'description'):
        if key not in profile:
            raise ValueError('ملف الأسلوب يفتقد ' + key)
    if profile['editing'].get('music_enabled'):
        raise ValueError('الموسيقى معطلة حسب اختيار صاحب القناة.')
    if not 3 <= float(profile['editing']['scene_seconds']) <= 8:
        raise ValueError('إيقاع المشاهد بين 3 و8 ثوانٍ.')
    if float(profile['editing']['meme_spacing']) < 45 or not .6 <= float(profile['editing']['meme_duration']) <= 2:
        raise ValueError('إعدادات الريأكشن تتجاوز السياسة المحافظة.')
    for region in (profile['editing']['caption_region'],profile['thumbnail']['region']):
        if len(region)!=4 or not all(math.isfinite(float(x)) for x in region):
            raise ValueError('منطقة النص غير صالحة.')
        x,y,w,h=map(float,region)
        if min(x,y)<0 or min(w,h)<=0 or x+w>1 or y+h>1:
            raise ValueError('منطقة النص خارج الإطار.')
    for key in ('primary','accent','outline'):
        if not re.fullmatch(r'#[0-9a-fA-F]{6}',profile['thumbnail'][key]):raise ValueError('لون الثامنيل غير صالح.')
    if not profile['script']['intro'].strip() or not profile['editing']['caption_font'].strip():raise ValueError('أكمل المقدمة والخط.')
    if profile['editing']['caption_style'] not in ('gaming','cinematic'):raise ValueError('نمط الترجمة غير صالح.')
    return profile


def load_profile():
    path = profile_path()
    if path.is_file():
        return validate_profile(json.loads(path.read_text(encoding='utf-8')))
    return copy.deepcopy(DEFAULT)


def save_profile(profile):
    save(validate_profile(profile), profile_path())


def long_description(title, summary='', chapters=None, sources=None, subscriber_count=None, profile=None):
    profile = profile or load_profile()
    config = profile['description']
    count = config.get('subscriber_count', '') if subscriber_count is None else str(subscriber_count).strip()
    lines = [title.strip()]
    if summary.strip():
        lines.append(summary.strip())
    lines.append(config['prayer'])
    if count:
        lines += ['', f'عددنا الحين ( {count} مشترك )']
    lines += ['', config['social_heading'], '', f'{config["instagram"]} {config["instagram_note"]}',
              '', f'Tiktok: {config["tiktok"]}', '', f'X : {config["x_link"]}']
    if chapters:
        previous = -1
        lines.append('')
        for at, label in chapters:
            at = float(at)
            if not math.isfinite(at) or at < 0 or at <= previous or not str(label).strip():
                raise ValueError('ترتيب توقيتات الوصف غير صالح.')
            previous = at
            m, s = divmod(int(at), 60)
            h, m = divmod(m, 60)
            stamp = f'{h}:{m:02}:{s:02}' if h else f'{m:02}:{s:02}'
            lines.append(f'{stamp} - {str(label).strip()}')
    if sources:
        lines += ['', 'مصادر الحلقة:']
        for url in sources:
            parsed = urlparse(url)
            if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password:
                raise ValueError('مصدر الوصف يجب أن يكون رابط HTTPS صالحًا.')
            lines.append(url)
    lines += ['', config['thanks']]
    result = '\n'.join(lines).strip()
    if len(result) > 4900:
        raise ValueError('الوصف طويل جدًا؛ اختصر ملخص الحلقة والمصادر.')
    return result


def top5_script(entries, topic, mentions=None, profile=None):
    profile = profile or load_profile()
    if not topic.strip():
        raise ValueError('اكتب موضوع القائمة.')
    if len(entries) != 5 or len({entry['name'].strip().lower() for entry in entries}) != 5:
        raise ValueError('توب فايف يحتاج خمس ألعاب مختلفة مرتبة من الخامس إلى الأول.')
    paragraphs = [profile['script']['intro'],
                  f'يا جماعة، إذا تحبون {topic.strip()}، المقطع هذا لكم. اليوم عندنا توب فايف، ونمشي من المركز الخامس لين الأول. الترتيب هذا اختياري؛ عطوني ترتيبكم في النهاية.']
    order = ['الخامس','الرابع','الثالث','الثاني','الأول']
    sources = []
    for i, entry in enumerate(entries):
        if not all(str(entry.get(k,'')).strip() for k in ('name','facts','why','source')):
            raise ValueError('كل لعبة تحتاج اسمًا وفكرتها وسبب اختيارك ومصدرًا أو توضيح أنها تجربتك.')
        if i == 4 and mentions:
            paragraphs.append('وقبل نروح للمركز الأول، عندنا ألعاب تستحق الذكر: ' + '، '.join(mentions) + '.')
        paragraphs.append(f'في المركز {order[i]} معنا {entry["name"].strip()}.\n\n{entry["facts"].strip()}\n\nليش تلعب {entry["name"].strip()}؟ {entry["why"].strip()}')
        if entry.get('opinion','').strip():
            paragraphs.append(entry['opinion'].strip())
        if str(entry['source']).startswith('https://'):
            sources.append(entry['source'])
    paragraphs.append('وفي الختام يا جماعة، هذه كانت قائمتنا. وش رايكم؟ فيه لعبة ما ذكرتها وتستحق تدخل القائمة؟ اكتبوها في التعليقات، وإذا عجبكم المقطع لا تنسون دعمكم. أشوفكم في المقطع الجاي، مع السلامة.')
    return {'text':'\n\n'.join(paragraphs), 'status':'DRAFT', 'genre':'list', 'sources':list(dict.fromkeys(sources)),
            'profile_version':profile['version'], 'warnings':['الترتيب رأي صاحب القناة؛ راجع الحقائق وسبب الاختيار قبل التسجيل.']}
