"""RashSpeak Studio v2 - Windows creator dashboard (YouTube / Instagram / TikTok only)."""
import threading
import queue
import sys
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog
from pathlib import Path
import webbrowser

from studio import build
from editor_ui import Editor
from app_paths import app_dir
from submissions import guarded_submit
from dashboard_ui import Dashboard, ProfilePanel, ScrollPage, hidden_tabs
from news_ui import NewsroomPanel
from top5_ui import Top5Panel
from thumbnail import ThumbnailPanel
from channel_style import long_description
from publisher import (load_settings,save_settings,secret_set,secret_get,yt_connect,yt_upload,
                       ig_oauth_url,ig_finish_oauth,ig_publish_reel,tiktok_connect,tiktok_upload_draft,tiktok_creator_info,tiktok_post_direct,
                       disconnect,publish_log,recent_logs)

BASE=app_dir()
cfg=load_settings()
root=tk.Tk()
root.title('RashSpeak Studio 2.1 | محرر أخبار الألعاب')
root.geometry('1380x840')
root.minsize(1180,780)
root.configure(bg='#0b1220')

style=ttk.Style(root)
style.theme_use('clam')
style.configure('TFrame',background='#101b30')
style.configure('TLabel',background='#101b30',foreground='#e4edff',font=('Segoe UI',10))
style.configure('TButton',font=('Segoe UI',10,'bold'),padding=(14,8),background='#284c91',foreground='white')
style.map('TButton',background=[('active','#3761b5'),('disabled','#26354b')])
style.configure('TEntry',padding=7,fieldbackground='#eff4fd',foreground='#101726')
style.configure('TNotebook',background='#0b1220',borderwidth=0)
style.configure('TNotebook.Tab',font=('Segoe UI',10,'bold'),padding=(18,12),background='#1b2d4c',foreground='#b7c7e1')
style.map('TNotebook.Tab',background=[('selected','#284c91')],foreground=[('selected','white')])
style.configure('TCheckbutton',background='#101b30',foreground='#e4edff')
style.configure('TLabelframe',background='#101b30',foreground='#e4edff')
style.configure('TLabelframe.Label',background='#101b30',foreground='#e4edff',font=('Segoe UI',10,'bold'))
style.configure('Treeview',background='#0d1728',fieldbackground='#0d1728',foreground='#e4edff',rowheight=28,font=('Segoe UI',10),borderwidth=0)
style.configure('Treeview.Heading',background='#1a2d49',foreground='#9cc0e7',font=('Segoe UI',10,'bold'),padding=7)
style.map('Treeview',background=[('selected','#24577a')],foreground=[('selected','white')])
style.configure('Nav.TButton',background='#101b30',foreground='#c9d9ee',font=('Segoe UI',10),padding=(10,6),anchor='e',borderwidth=0)
style.map('Nav.TButton',background=[('active','#203754')])
style.configure('Card.TFrame',background='#132138')
style.configure('Card.TLabel',background='#132138',foreground='#e4edff')
hidden_tabs(style)

banner=tk.Frame(root,bg='#101b30',height=78)
banner.pack(fill='x',padx=16,pady=(14,8))
tk.Label(banner,text='RashSpeak Studio',font=('Segoe UI',21,'bold'),fg='#f8fbff',bg='#101b30').pack(side='left',padx=20,pady=12)
tk.Label(banner,text='2.1  •  YouTube + Instagram + TikTok',font=('Segoe UI',10),fg='#7fa9e6',bg='#101b30').pack(side='right',padx=18)

workspace=ttk.Frame(root)
workspace.pack(fill='both',expand=True,padx=16,pady=(4,8))
sidebar=ttk.Frame(workspace,width=214)
sidebar.pack(side='right',fill='y',padx=(10,0))
sidebar.pack_propagate(False)
notebook=ttk.Notebook(workspace)
notebook.pack(side='left',fill='both',expand=True)
producer=ttk.Frame(notebook,padding=18)
publishing=ttk.Frame(notebook,padding=18)
accounts_page=ScrollPage(notebook)
accounts=accounts_page.body
history=ttk.Frame(notebook,padding=18)
notebook.add(producer,text='إنتاج 2.0 القديم')
notebook.add(publishing,text='🚀  النشر')
notebook.add(accounts_page,text='🔗  الحسابات')
notebook.add(history,text='📋  السجل')

ui_events=queue.Queue()
active_job=False

def log(message):
    ui_events.put(('log',str(message)))

def drain_ui():
    while not ui_events.empty():
        kind,value=ui_events.get()
        if kind=='log':
            console.insert('end',value+'\n');console.see('end')
        else:value()
    root.after(80,drain_ui)

def job(label,fn,done=None):
    global active_job
    if active_job:
        messagebox.showinfo('معالجة جارية','انتظر انتهاء العملية الحالية.');return
    active_job=True
    status.configure(text=label+' ...')
    def finish(result=None,error=None):
        global active_job
        active_job=False
        if error:
            messagebox.showerror('تعذر التنفيذ',error)
            status.configure(text='تعذر التنفيذ')
        else:
            status.configure(text=label+' — انتهى')
            if done:done(result)
    def worker():
        try:
            result=fn()
            ui_events.put(('call',lambda result=result:finish(result)))
        except Exception as exc:
            # Errors may contain platform status but don't include access tokens or secrets
            message=str(exc)
            log('خطأ: '+message)
            ui_events.put(('call',lambda message=message:finish(error=message)))
    threading.Thread(target=worker,daemon=True).start()

def add_entry(parent,label,row,default='',choose=None):
    ttk.Label(parent,text=label).grid(row=row,column=0,sticky='e',padx=(4,12),pady=9)
    widget=ttk.Entry(parent)
    widget.grid(row=row,column=1,sticky='ew',pady=8)
    if default:widget.insert(0,default)
    if choose:ttk.Button(parent,text='اختيار...',command=lambda:choose(widget)).grid(row=row,column=2,padx=10)
    return widget

def file_picker(entry,types):
    p=filedialog.askopenfilename(filetypes=types)
    if p:entry.delete(0,'end');entry.insert(0,p)

def folder_picker(entry):
    p=filedialog.askdirectory()
    if p:entry.delete(0,'end');entry.insert(0,p)

# --- Produce ---
producer.columnconfigure(1,weight=1)
ttk.Label(producer,text='أنشئ الفيديو من صوتك ولقطات الألعاب المرخّصة',font=('Segoe UI',12,'bold')).grid(row=0,column=0,columnspan=3,sticky='w',pady=(0,15))
voice=add_entry(producer,'التعليق الصوتي',1,choose=lambda w:file_picker(w,[('Audio','*.mp3 *.wav *.m4a *.aac *.flac *.ogg *.mp4')]))
clips=add_entry(producer,'مجلد لقطات الألعاب',2,choose=folder_picker)
out=add_entry(producer,'مجلد الإخراج',3,str(BASE/'output'),choose=folder_picker)
cues=add_entry(producer,'ملف توقيت المشاهد (اختياري)',4,choose=lambda w:file_picker(w,[('CSV','*.csv')]))
render_options=ttk.Frame(producer);render_options.grid(row=5,column=0,columnspan=3,sticky='w',pady=12)
sub_var=tk.BooleanVar(value=False);nvenc_var=tk.BooleanVar(value=False);short_var=tk.BooleanVar(value=True)
for label,var in [('ملف ترجمة عربي SRT',sub_var),('نسخة Shorts (35 ثانية)',short_var),('تسريع NVIDIA',nvenc_var)]:
    ttk.Checkbutton(render_options,text=label,variable=var).pack(side='left',padx=10)

def render_video():
    if not voice.get().strip() or not clips.get().strip():messagebox.showwarning('بيانات ناقصة','اختر الصوت ومجلد اللقطات');return
    data=(voice.get(),clips.get(),out.get(),cues.get(),35 if short_var.get() else 0,sub_var.get(),'nvenc' if nvenc_var.get() else 'cpu')
    def fn():return build(data[0],data[1],data[2],data[3],short_secs=data[4],subtitles=data[5],encoder=data[6],logger=log)
    def done(path):
        video_input.delete(0,'end');video_input.insert(0,str(Path(path).parent/'RashSpeak_short_first_section.mp4' if short_var.get() else path))
        notebook.select(publishing)
        messagebox.showinfo('اكتمل الإنتاج','تم إخراج المسودة. راجع تطابق المشاهد ودقة الأخبار قبل النشر.')
    job('توليد الفيديو',fn,done)

ttk.Button(producer,text='▶  إنتاج الفيديو + Short',command=render_video).grid(row=6,column=0,columnspan=3,pady=(14,12))
ttk.Label(producer,text='ملاحظة: النسخة الحالية لا تفهم كل جملة صوتية؛ استخدم cues.csv لتخصيص لقطات كل خبر.',foreground='#95afce').grid(row=7,column=0,columnspan=3,sticky='w')

# --- Publish ---
publishing.columnconfigure(1,weight=1)
ttk.Label(publishing,text='النشر يتم بعد موافقتك الصريحة — ولا يحدث نشر تلقائي بالخلفية',font=('Segoe UI',12,'bold')).grid(row=0,column=0,columnspan=3,sticky='w',pady=(0,15))
video_input=add_entry(publishing,'ملف الفيديو / Short',1,str(BASE/'output'/'RashSpeak_short_first_section.mp4'),choose=lambda w:file_picker(w,[('Videos','*.mp4 *.mov *.webm')]))
title_input=add_entry(publishing,'عنوان YouTube',2,'آخر أخبار الألعاب | RashSpeak')
ttk.Label(publishing,text='وصف YouTube / Instagram (ممكن تعديل الوسوم)').grid(row=3,column=0,columnspan=3,sticky='w',pady=(8,3))
desc=tk.Text(publishing,height=6,wrap='word',font=('Segoe UI',10),background='#eaf0fb',foreground='#111827')
desc.grid(row=4,column=0,columnspan=3,sticky='nsew',pady=6)
desc.insert('1.0',long_description('آخر أخبار الألعاب | RashSpeak'))
publishing.rowconfigure(4,weight=1)
url_input=add_entry(publishing,'رابط MP4 عام مباشر لإنستغرام',5,choose=None)
ttk.Label(publishing,text='إنستغرام يحتاج HTTPS عام يتيح جلب الملف. تيك توك يأخذ الفيديو مباشرة من جهازك.',foreground='#9baecb').grid(row=6,column=0,columnspan=3,sticky='w')
privacy=tk.StringVar(value='private')
privacy_row=ttk.Frame(publishing);privacy_row.grid(row=7,column=0,columnspan=3,sticky='w',pady=12)
ttk.Label(privacy_row,text='خصوصية رفع YouTube:').pack(side='left',padx=(0,10))
for k,name in [('private','خاص'),('unlisted','غير مدرج'),('public','عام')]:
    ttk.Radiobutton(privacy_row,text=name,variable=privacy,value=k).pack(side='left',padx=7)

def confirm_send(platform,explanation):
    return messagebox.askyesno('تأكيد قبل الاتصال بالمنصة',f'المنصة: {platform}\n\n{explanation}\n\nهل توافق على الإرسال الآن؟')

def content():return desc.get('1.0','end').strip()

def do_yt():
    file=video_input.get().strip()
    title,description,visibility=title_input.get().strip() or 'Gaming news',content(),privacy.get()
    if not confirm_send('YouTube',f'سيتم رفع الملف المختار بخصوصية: {privacy.get()}.'):return
    def fn():
        try:
            video_id=guarded_submit('youtube',cfg.get('yt_channel_id'),file,lambda:yt_upload(file,title,description,visibility,consent=True))
            publish_log('YouTube','uploaded',video_id);return video_id
        except Exception as exc:publish_log('YouTube','failed',str(exc));raise
    job('رفع YouTube',fn,lambda video_id:messagebox.showinfo('YouTube','تم الرفع: https://youtube.com/watch?v='+video_id))

def do_tiktok():
    file=video_input.get().strip()
    if not confirm_send('TikTok', 'سيتم رفع الفيديو إلى صندوق وارد تيك توك كمسودة، ولن ينشر علنًا تلقائيًا. ستكمل الوصف والنشر داخل تطبيق TikTok.'):
        return
    def fn():
        try:
            post_id=guarded_submit('tiktok-inbox',cfg.get('tiktok_name'),file,lambda:tiktok_upload_draft(dict(cfg),file,logger=log,consent=True));publish_log('TikTok','sent to inbox',post_id);return post_id
        except Exception as exc:publish_log('TikTok','failed',str(exc));raise
    job('إرسال إلى TikTok',fn,lambda value:messagebox.showinfo('TikTok','أُرسلت المسودة. افتح إشعارات TikTok وراجع الفيديو ثم انشره بنفسك.'))

def direct_tiktok_dialog(info):
    popup=tk.Toplevel(root)
    popup.title('TikTok Direct Post — مراجعة الحساب والمنشور')
    popup.geometry('610x630')
    popup.configure(bg='#101b30')
    popup.transient(root)
    popup.grab_set()
    wrapper=ttk.Frame(popup,padding=18)
    wrapper.pack(fill='both',expand=True)
    ttk.Label(wrapper,text=f"حساب النشر: @{info.get('creator_username','unknown')} — {info.get('creator_nickname','')}",font=('Segoe UI',12,'bold')).pack(anchor='w',pady=(0,12))
    ttk.Label(wrapper,text='الخصوصية (الخيارات المتاحة فعلًا للحساب)').pack(anchor='w')
    privacy_options=info.get('privacy_level_options',[])
    priv=tk.StringVar(value='SELF_ONLY' if 'SELF_ONLY' in privacy_options else privacy_options[0])
    choice=ttk.Combobox(wrapper,textvariable=priv,values=privacy_options,state='readonly')
    choice.pack(fill='x',pady=(2,12))
    ttk.Label(wrapper,text='التعليق الذي سيظهر مع الفيديو').pack(anchor='w')
    caption_box=tk.Text(wrapper,height=4,font=('Segoe UI',10),background='#f1f5fc',foreground='#152238')
    caption_box.pack(fill='x',pady=(2,10));caption_box.insert('1.0',content())
    values={}
    for key,label,restricted in [('disable_comment','إيقاف التعليقات',info.get('comment_disabled',False)),
                                 ('disable_duet','إيقاف الدويتو',info.get('duet_disabled',False)),
                                 ('disable_stitch','إيقاف Stitch',info.get('stitch_disabled',False)),
                                 ('brand_content','يتضمن رعاية أو ترويج طرف آخر',False),
                                 ('brand_organic','ترويج مشروعك أو منتجك الشخصي',False),
                                 ('is_aigc','المحتوى مُولَّد بالذكاء الاصطناعي',False)]:
        v=tk.BooleanVar(value=bool(restricted));values[key]=v
        checkbox=ttk.Checkbutton(wrapper,text=label,variable=v)
        checkbox.pack(anchor='w',pady=2)
        if restricted:checkbox.state(['disabled'])
    ttk.Label(wrapper,text='النشر المباشر قد يُقيَّد إلى الخاص إذا لم تجتز مراجعة TikTok.',foreground='#ffca8e').pack(anchor='w',pady=(14,5))
    def send():
        privacy_level=priv.get();caption=caption_box.get('1.0','end').strip()
        if not messagebox.askyesno('آخر تأكيد',f"تأكيد رفع ونشر الفيديو إلى @{info['creator_username']}\nالخصوصية: {privacy_level}\nمباشرة عبر TikTok API؟",parent=popup):return
        options={k:v.get() for k,v in values.items()}
        file=video_input.get().strip()
        popup.destroy()
        def fn():
            try:
                publish_id=guarded_submit('tiktok-direct',cfg.get('tiktok_name'),file,lambda:tiktok_post_direct(cfg,file,caption,privacy_level,
                  comment_disabled=options['disable_comment'],duet_disabled=options['disable_duet'],
                  stitch_disabled=options['disable_stitch'],brand_content=options['brand_content'],
                  brand_organic=options['brand_organic'],is_aigc=options['is_aigc'],
                  consent=True,creator_info=info,logger=log))
                publish_log('TikTok Direct Post','submitted',publish_id);return publish_id
            except Exception as exc:publish_log('TikTok Direct Post','failed',str(exc));raise
        job('TikTok Direct Post',fn,lambda value:messagebox.showinfo('TikTok','تم إرسال الفيديو للنشر في TikTok. رقم العملية: '+value+'\nقد تستمر المعالجة؛ راجع حسابك للتأكد من ظهوره.'))
    ttk.Button(wrapper,text='موافقة وإرسال للنشر المباشر',command=send).pack(fill='x',pady=(14,5))

def do_tiktok_direct():
    job('فحص أهلية TikTok Direct Post',lambda:tiktok_creator_info(cfg),direct_tiktok_dialog)

def do_instagram():
    url=url_input.get().strip()
    caption=content()
    if not confirm_send('Instagram', 'سيُنشر Reels بشكل عام على حساب إنستغرام مباشرة بعد تجهيز المعالجة. الرابط يجب أن يكون HTTPS عامًا للملف النهائي.'):
        return
    def fn():
        try:
            post_id=guarded_submit('instagram',cfg.get('ig_account_id'),url,lambda:ig_publish_reel(dict(cfg),url,caption,consent=True));publish_log('Instagram','published',post_id);return post_id
        except Exception as exc:publish_log('Instagram','failed',str(exc));raise
    job('نشر Instagram Reels',fn,lambda value:messagebox.showinfo('Instagram','تم نشر Reels. معرف المنشور: '+str(value)))

buttons=ttk.Frame(publishing);buttons.grid(row=8,column=0,columnspan=3,sticky='ew',pady=14)
for name,method in [('رفع YouTube',do_yt),('إرسال مسودة TikTok',do_tiktok),('نشر TikTok مباشرة*',do_tiktok_direct),('نشر Instagram Reels',do_instagram)]:
    ttk.Button(buttons,text=name,command=method).pack(side='left',padx=6)

def apply_channel_description():
    title=title_input.get().strip()
    metadata_path=editor.output()/'episode.json'
    sources=[]
    if metadata_path.is_file():
        import json
        sources=json.loads(metadata_path.read_text(encoding='utf-8')).get('sources',[])
    text=long_description(title,sources=sources)
    desc.delete('1.0','end');desc.insert('1.0',text)
ttk.Button(publishing,text='تطبيق وصف القناة الثابت للفيديو الطويل',command=apply_channel_description).grid(row=9,column=0,columnspan=3,sticky='e')

# --- Accounts ---
accounts.columnconfigure(1,weight=1)
ttk.Label(accounts,text='الربط عبر موافقة الحسابات الرسمية — لا تدخل كلمات مرور منصات التواصل هنا',font=('Segoe UI',11,'bold')).grid(row=0,column=0,columnspan=3,sticky='w',pady=(0,10))

def section(text,row):
    ttk.Separator(accounts).grid(row=row,column=0,columnspan=3,sticky='ew',pady=10)
    ttk.Label(accounts,text=text,font=('Segoe UI',12,'bold')).grid(row=row+1,column=0,columnspan=3,sticky='w',pady=6)

section('YouTube / Google Cloud',1)
yt_json=add_entry(accounts,'OAuth Desktop JSON',3,cfg['yt_client_json'],choose=lambda w:file_picker(w,[('JSON','*.json')]))
section('TikTok Developers / Login Kit',4)
tt_key=add_entry(accounts,'TikTok Client Key',6,cfg['tiktok_client_key'])
tt_redirect=add_entry(accounts,'TikTok Local Redirect',7,cfg['tiktok_redirect'])
tt_secret=add_entry(accounts,'TikTok Client Secret (محلي)',8)
tt_secret.configure(show='•')
section('Instagram / Meta Developers',9)
ig_id=add_entry(accounts,'Instagram App ID',11,cfg['ig_client_id'])
ig_redirect=add_entry(accounts,'Instagram HTTPS Redirect',12,cfg['ig_redirect'])
ig_secret=add_entry(accounts,'Instagram App Secret (محلي)',13)
ig_secret.configure(show='•')

def snapshot():
    cfg.update({'yt_client_json':yt_json.get().strip(),'tiktok_client_key':tt_key.get().strip(),
                'tiktok_redirect':tt_redirect.get().strip(),'ig_client_id':ig_id.get().strip(),
                'ig_redirect':ig_redirect.get().strip()})
    save_settings(cfg)
    if tt_secret.get().strip():secret_set('tiktok_client_secret',tt_secret.get().strip());tt_secret.delete(0,'end')
    if ig_secret.get().strip():secret_set('instagram_client_secret',ig_secret.get().strip());ig_secret.delete(0,'end')

def connect_youtube():
    snapshot()
    job('ربط YouTube',lambda:yt_connect(cfg),lambda value:messagebox.showinfo('YouTube','تم ربط قناة: '+value))

def connect_tiktok():
    snapshot()
    job('ربط TikTok',lambda:tiktok_connect(cfg,log),lambda value:messagebox.showinfo('TikTok','تم ربط TikTok بشكل ناجح.'))

def connect_tiktok_direct():
    snapshot()
    if not messagebox.askyesno('Direct Post','هل تمت الموافقة على video.publish في تطبيقك على TikTok for Developers؟\nإذا لم تحصل على الموافقة، استعمل زر ربط TikTok العادي.'):
        return
    job('ربط TikTok للنشر المباشر',lambda:tiktok_connect(cfg,log,direct=True),lambda value:messagebox.showinfo('TikTok','تم ربط TikTok بطلب صلاحية video.publish.'))

def start_ig():
    snapshot()
    try:
        url=ig_oauth_url(cfg)
        webbrowser.open(url)
        messagebox.showinfo('Instagram','سيفتح تسجيل الدخول الرسمي. بعد الموافقة، انسخ رابط التحويل الكامل من المتصفح ثم اضغط «إكمال Instagram».\n\nهذه الخطوة تتطلب Redirect HTTPS مسجلًا في Meta Developers.')
    except Exception as exc:messagebox.showerror('Instagram',str(exc))

def finish_ig():
    value=simpledialog.askstring('Instagram OAuth','الصق رابط التحويل الكامل الذي يحتوي على code و state:',parent=root)
    if not value:return
    job('إكمال ربط Instagram',lambda:ig_finish_oauth(cfg,value),lambda name:messagebox.showinfo('Instagram','تم الربط: '+str(name)))

account_buttons=ttk.Frame(accounts);account_buttons.grid(row=14,column=0,columnspan=3,sticky='w',pady=15)
for txt,fn in [('حفظ الإعدادات',lambda:(snapshot(),messagebox.showinfo('تم','حُفظت الإعدادات غير السرية في ملف محلي، والأسرار في مخزن النظام.'))),('ربط YouTube',connect_youtube),('ربط TikTok',connect_tiktok),('ربط TikTok Direct*',connect_tiktok_direct),('بدء Instagram',start_ig),('إكمال Instagram',finish_ig)]:
    ttk.Button(account_buttons,text=txt,command=fn).pack(side='left',padx=4)

def remove_account():
    platform=simpledialog.askstring('فصل الحساب','اكتب: youtube أو instagram أو tiktok')
    if platform not in ('youtube','instagram','tiktok'):return
    if messagebox.askyesno('فصل الحساب','حذف رموز اتصال '+platform+' المحلية؟'):
        disconnect(platform,cfg);messagebox.showinfo('تم','تم مسح الربط المحلي.')
ttk.Button(accounts,text='فصل حساب ومسح رموزه من الجهاز',command=remove_account).grid(row=15,column=0,columnspan=3,pady=(0,8))

# --- logs ---
history.columnconfigure(0,weight=1);history.rowconfigure(1,weight=1)
ttk.Label(history,text='سجل الإرسالات (لا يخزن رموز وصول أو كلمات مرور)',font=('Segoe UI',12,'bold')).grid(row=0,column=0,sticky='w',pady=(0,10))
logs=tk.Text(history,wrap='word',font=('Consolas',10),background='#eaf0fb',foreground='#111827')
logs.grid(row=1,column=0,sticky='nsew')

def refresh_history():
    logs.delete('1.0','end')
    for item in recent_logs():logs.insert('end',f"{item['date']}  |  {item['platform']}  |  {item['status']}\n{item['detail']}\n\n")
ttk.Button(history,text='تحديث السجل',command=refresh_history).grid(row=2,column=0,pady=10)

# --- global console ---
log_frame=tk.Frame(root,bg='#101b30')
log_frame.pack(fill='x',padx=16,pady=(0,7))
status=tk.Label(log_frame,text='جاهز — لم يتم ربط أي حساب في هذه الجلسة',bg='#101b30',fg='#80c5ff',font=('Segoe UI',9))
status.pack(anchor='w',padx=9,pady=(7,0))
console=tk.Text(log_frame,height=3,wrap='word',font=('Consolas',9),bg='#0c172a',fg='#a8c5ec',relief='flat')
console.pack(fill='x',padx=8,pady=(4,9))
log('جاهز. جهّز المحتوى، ثم اربط حساباتك من تبويب «الحسابات» بعد إنشاء تطبيقات المطورين.')
editor=Editor(notebook,log)
notebook.insert(0,editor,text='🎬  المحرر الذكي 2.1')
def script_ready(metadata):
    title_input.delete(0,'end');title_input.insert(0,metadata['title'])
    desc.delete('1.0','end');desc.insert('1.0',metadata['description'])
    dashboard.edit(0)
news_page=NewsroomPanel(notebook,editor,script_ready)
top5_page=Top5Panel(notebook,editor,script_ready)
thumbnail_page=ThumbnailPanel(notebook,editor)
profile_page=ProfilePanel(notebook)
for page,text in [(news_page,'الأخبار'),(top5_page,'توب فايف'),(thumbnail_page,'الثامنيل'),(profile_page,'أسلوب القناة')]:notebook.add(page,text=text)
dashboard=Dashboard(sidebar,notebook,editor,{'news':news_page,'top5':top5_page,'thumbnail':thumbnail_page,'profile':profile_page,'publish':publishing,'accounts':accounts_page,'history':history})
if '--project' in sys.argv:
    index=sys.argv.index('--project')
    if index+1<len(sys.argv):editor.load_project(sys.argv[index+1]);dashboard.edit(0)
root.after(80,drain_ui)
def close_app():
    if editor.busy or active_job:
        if not messagebox.askyesno('عملية جارية','إلغاء المعالجة وإغلاق البرنامج؟'):return
        editor.cancel.set()
    root.destroy()
root.protocol('WM_DELETE_WINDOW',close_app)
root.mainloop()
