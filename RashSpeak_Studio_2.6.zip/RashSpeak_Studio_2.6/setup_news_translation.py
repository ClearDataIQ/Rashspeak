"""Explicit preparation of a licensed local Helsinki Marian translation model."""
import os
from pathlib import Path
import json
from app_paths import app_dir


def main():
    output=app_dir()/'models/news-helsinki-en-ar'
    if (output/'model.bin').is_file():
        print('Existing model retained:',output);return
    os.environ['HF_HOME']=str(app_dir()/'models/download-cache')
    from ctranslate2.converters import TransformersConverter
    converter=TransformersConverter('Helsinki-NLP/opus-mt-en-ar',copy_files=['source.spm','target.spm'],trust_remote_code=False)
    converter.convert(str(output),quantization='int8',force=False)
    (output/'origin.json').write_text(json.dumps({'repo':'Helsinki-NLP/opus-mt-en-ar','license':'Apache-2.0','runtime':'CTranslate2 int8','offline_after_setup':True},indent=2),encoding='utf-8')
    print('Local news translation ready:',output)


if __name__=='__main__':main()
