"""Real encoded moving test video with three editable overlays; no human ASR."""
import argparse
from pathlib import Path
from PIL import Image,ImageDraw
import captions
from media_tools import run
from pro_project import Session,new_project,new_clip,import_media,sequence
from pro_render import render,package
from sound_effects import library


def demo(output):
    root=Path(output).resolve()
    if root.exists():raise ValueError('Use a new directory for this demo.')
    root.mkdir(parents=True);media=root/'sources';media.mkdir()
    video=media/'generated_motion.mp4';voice=media/'generated_signal.wav'
    run(['ffmpeg','-v','error','-y','-f','lavfi','-i','testsrc2=size=1280x720:rate=30:duration=6','-c:v','libx264','-preset','veryfast','-threads','2',video])
    run(['ffmpeg','-v','error','-y','-f','lavfi','-i','sine=frequency=330:sample_rate=48000:duration=6',voice])
    gif=media/'original_transparent.gif';frames=[]
    for i in range(6):
        im=Image.new('RGBA',(240,240),(0,0,0,0));draw=ImageDraw.Draw(im)
        draw.rounded_rectangle((35+i*4,40,190+i*4,195),radius=25,fill='#ffce39');draw.text((70,102),'TEST',fill='black',font_size=26)
        frames.append(im)
    frames[0].save(gif,save_all=True,append_images=frames[1:],duration=150,loop=0,disposal=2,transparency=0)
    card=media/'original_badge.png';im=Image.new('RGBA',(600,200),(0,0,0,0));draw=ImageDraw.Draw(im)
    draw.rounded_rectangle((10,10,590,190),radius=30,fill='#087bb0');draw.text((45,65),'RASH / EDIT TEST',fill='white',font_size=43);im.save(card)
    s=Session(new_project('اختبار Pro Editor'));base=s.add_track('video','الفيديو الأساسي')
    overlays=[s.add_overlay(f'Overlay {i} — ميم / GIF') for i in range(1,4)]
    text=s.add_track('text','الترجمة');audio=s.add_track('audio','التعليق الاختباري');fx=s.add_track('effect','المؤثرات')
    a=import_media(video,rights='Original generated test',source='Generated locally');b=import_media(voice,rights='Original test signal',source='Generated locally')
    first=s.add(base,new_clip(a['id'],0,90,0),a);second=s.add(base,new_clip(a['id'],90,90,90,fade_in=6))
    s.add(audio,new_clip(b['id'],0,180),b)
    g=import_media(gif,rights='Original generated transparent animation',source='Generated locally')
    clip=s.add(overlays[0],new_clip(g['id'],20,100,loop=True,transform={'x':.62,'y':.08,'scale':.30,'opacity':1.},
                                   crop={'left':.05,'top':.05,'right':.05,'bottom':.05},fade_in=5,fade_out=5),g)
    s.properties(clip,keyframes={'x':[{'frame':0,'value':.62,'easing':'linear'},{'frame':60,'value':.50,'easing':'ease_out'},{'frame':99,'value':.62,'easing':'ease_in'}]})
    badge=import_media(card,rights='Original generated image',source='Generated locally')
    s.add(overlays[1],new_clip(badge['id'],90,90,transform={'x':.03,'y':.06,'scale':.35,'opacity':.95}),badge)
    s.add(text,new_clip(start=5,duration=80,text='عرض اختبار — الصورة متحركة والصوت إشارة اصطناعية'))
    s.add(text,new_clip(start=90,duration=85,text='ثلاث طبقات للميمز وGIF فوق الفيديو، كلها قابلة للتحرير'))
    effect=library(media/'effects')['whoosh'];e=import_media(effect['path'],rights=effect['license'],source=effect['source'])
    s.add(fx,new_clip(e['id'],90,13,gain_db=-20),e)
    original=s.project['active_sequence'];s.make_short(30,150,'شورت الاختبار');s.project['active_sequence']=original
    s.save(root/'project.rash.json');results=[]
    for i,seq in enumerate(s.project['sequences']):
        path=root/('long_video.mp4' if i==0 else 'short_01.mp4');r=render(s.project,path,seq['id'],on_progress=lambda n:print(f'{seq["name"]}: {n}%',flush=True))
        r.update(sequence=seq['id'],portrait=i>0);results.append(r)
    result=package(s.project,root/'RashSpeak_Project',results)
    (root/'READ_ME_AR.txt').write_text('هذا مثال اختبار مولّد محليًا، وليس صوتًا بشريًا أو Gameplay حقيقيًا أو نتيجة تفريغ. افتح Project/project.rash.json من ZIP في Pro Editor. ثلاثة Overlay: GIF شفاف متحرك، بطاقة، وطبقة فارغة لتضيف عليها. المصدر محفوظ.\n',encoding='utf-8')
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--out',default='output/pro_editor_demo');print(demo(parser.parse_args().out))
