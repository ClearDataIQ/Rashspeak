"""Explicit synthetic timed fixture, not an ASR accuracy demonstration.

Creates original generated test signals and graphics; no third-party assets.
"""
import argparse
import array
import math
from pathlib import Path
import wave
from PIL import Image, ImageDraw
from production import produce
from smart_editor import import_asset


def demo(output,size=(1920,1080),portrait_size=(1080,1920),on_event=None,on_review=None):
    root=Path(output).resolve();root.mkdir(parents=True,exist_ok=True)
    script='فورتنايت خبر جديد وممتع. التحديث مجاني وفيه تحديات جديدة. هههه ضحكت مرة. ماينكرافت فيها عالم جديد للاستكشاف.'
    spoken='فورتنايت خبر فورتنايت خبر جديد وممتع. التحديث مجاني وفيه تحديات جديدة. هههه ضحكت مرة. ماينكرافت فيها عالم جديد للاستكشاف.'
    units=[];at=.8
    for text in spoken.split():
        units.append({'start':at,'end':at+.33,'text':text,'probability':1})
        at+=1.1 if text.endswith('.') else .53
    rate=48000;limit=at+.7;samples=array.array('h',[0])*round(limit*rate)
    for index,word in enumerate(units):
        for i in range(round(word['start']*rate),round(word['end']*rate)):
            samples[i]=round(6000*math.sin(2*math.pi*(200+index*12)*i/rate))
    audio=root/'synthetic_test_signal.wav'
    with wave.open(str(audio),'wb') as file:
        file.setnchannels(1);file.setsampwidth(2);file.setframerate(rate);file.writeframes(samples.tobytes())
    assets=[]
    for topic,color in [('Fortnite','#225976'),('Minecraft','#285e40')]:
        image=Image.new('RGB',(1280,720),color);draw=ImageDraw.Draw(image)
        for i in range(0,1200,120):draw.rectangle((i,360-i//8,i+85,660),fill='#152a3c',outline='#08beed',width=3)
        draw.text((45,45),'SYNTHETIC TEST GRAPHIC / '+topic,fill='white',font_size=28)
        path=root/(topic+'.png');image.save(path)
        assets.append(import_asset(path,game=topic,license='Original generated test graphic',source='Generated locally',approved=True))
    result=produce(audio,script,root/'project',online=False,quality_mode='draft',
                   asr_override={'words':units,'segments':[]},assets_override=assets,
                   sizes={'size':size,'portrait_size':portrait_size},
                   on_event=on_event or (lambda e:print(e.get('detail') or e.get('message','')) if e['type'] in ('stage','log') else None),on_review=on_review)
    (root/'READ_ME.txt').write_text('اختبار اصطناعي: الصوت نغمات وليس تسجيل كلام، والتوقيتات مكتوبة للاختبار. لا يمثل صوتك أو دقة Whisper. الرسومات مولدة وليست لقطات ألعاب.\n'+result['delivery'],encoding='utf-8')
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--out',default='output/production_demo')
    print(demo(parser.parse_args().out)['delivery'])
