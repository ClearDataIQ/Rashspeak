# RashSpeak 2.5 architecture

This extends the existing Python/Tk/FFmpeg app. There is no React rewrite or alternate mock renderer. The old tools and publishing adapters remain in `advanced_gui.py`; the main app never publishes.

## Shared production document

`reviewed_production.py` retains six owner-review gates. Audio alignment (`audio_edit.py`), optional official Gemini context (`gemini_context.py`), legal asset collection (`licensed_media.py`/`media_library.py`), locally guarded planning (`smart_editor.py`) and original procedural SFX (`sound_effects.py`) feed the existing legacy timeline. At the montage gate, `pro_project.from_legacy` converts it to `rashspeak.multitrack/1`. **The actual montage/Short files reviewed by the owner are rendered from this document, and this same document opens in Pro Editor.** Early stage previews retain the legacy renderer; the final montage gate is where the common multitrack definition applies.

The importer references original assets, processed narration and original raw narration separately. It does not use the flattened MP4 as its source. Legacy timeline and audio decisions stay available. Each production run gets a new `project.rash.json`; opening Pro Editor preserves its edits and never reconstructs it over existing manual work. Rerunning Auto Studio produces a new run rather than merging manual edits.

`pro_project.py` contains schema/validation, media import, legacy migration, atomic save/load, sequences, track/clip operations, a transactional `Session`, bounded Undo/Redo and autosave recovery. FPS is an integer supported timebase; timeline start/duration/source-in/fades are **integer frames**, while source durations remain measured seconds. Paths resolve to local files. Sources have identity metadata; portable ZIP uses SHA256 so ZIP timestamp loss does not invalidate unchanged media.

```json
{
  "schema": "rashspeak.multitrack/1",
  "fps": 30,
  "media": [{"id": "source", "path": "../Media/source.mp4", "kind": "video", "duration": 10}],
  "sequences": [{
    "id": "long", "width": 1920, "height": 1080,
    "tracks": [{
      "id": "v1", "kind": "video", "locked": false, "hidden": false, "muted": false,
      "clips": [{"id": "clip", "media_id": "source", "start": 60, "in": 30, "duration": 90}]
    }]
  }]
}
```

This is an abbreviated schema example, not a complete loadable fixture; constructors provide the required properties. `start=60` means timeline second 2; `in=30` means source second 1; `duration=90` means 3 seconds. Track order is compositing order, from background to foreground. Audio/effect tracks mix independently; text is rendered through ASS at its own layer order. Three overlay tracks are provided by the importer/new UI and may remain empty.

Edits validate the whole candidate, write the autosave atomically, then enter history. Validation/write failure rolls the document back. Locks are enforced by edit operations, including group members and ripple destinations. Undo/Redo preserve sources. Split/Trim/Slip/Slide/Roll respect source bounds; explicit loop permits repeating a visual source. Ripple rejects intersecting unselected clips rather than silently breaking synchronization. Copy duplicates clip IDs and remaps groups; property changes are undoable. Up to 100 in-session snapshot operations are retained, not a disk-persistent history.

Shorts are independent sequences with a contiguous parent range and the same media references. They do not assemble disjoint narration and do not dynamically synchronize after edits to the parent. Portrait framing is manual via transforms/Crop/contain/cover; no saliency tracking exists yet.

## Compositor and files

`pro_render.py` consumes only the validated document. Each visible clip supplies an independently trimmed source with a timeline offset. FFmpeg builds compositing layers with crop, aspect fit, position, scale, opacity, X/Y/Scale/Opacity keyframes with exact partial easing, rotation, color adjustment, rectangle/ellipse masks with feather, alpha fades/Crossfade and visual-only rate/reverse. Reverse is bounded to 10 source seconds. Voice order/rate remains unchanged. Text retains logical Arabic Unicode for libass shaping. Audio uses trim/resample/clip DSP/volume automation/fades/delay, then a real per-track mix bus and optional track DSP, plus a latency-compensated limiter. DSP includes EQ/compression/de-esser/denoise/high-pass/optional loudness. Processed Auto narration is marked to avoid silent double normalization. SFX duck against the combined narration. Embedded video audio can be referenced as a separate audio clip.

Final export, low-resolution proxy and frame preview use this same compositor. Frame preview seeks the completed proxy so transitions and motion are not reinterpreted at a single isolated frame. Proxy cache is keyed by the complete document and source identities, and requires matching output metadata. Preview is not a GPU real-time editing player. `preview_player.py` decodes the actual cached MP4 internally with PyAV. Optional sounddevice uses decoded PCM and the DAC sample clock as master; without a device playback declares video-only and uses monotonic timing. Pause/seek and stale-worker token guards are implemented. Tk image creation stays on its thread. External ffplay/OS playback remains available. This is cached proxy playback, not a live GPU compositor.

FFmpeg is invoked with argument arrays, never a shell. Only local `file,pipe` protocols are permitted by media tool calls and the compositor. Input extensions and measured duration/size are bounded at import; source identity/rights are rechecked before and after render. No arbitrary filter expression comes from a user or command assistant: keyframe expressions are constructed only from validated numeric properties. Processing has timeouts and cancellation. Sources cannot be an export destination. FFmpeg frame progress drives the UI; temporary output is promoted atomically after metadata checks. This is bounded local processing, not an OS/container sandbox for hostile media decoders.

H.264/H.265 AAC, CRF/Bitrate and CPU/NVENC options are shared UI/CLI settings and stored in job snapshots. Codec/device failures remain explicit without a fake successful GPU fallback. Document dimensions allow up to 4096 per side; 1080p/portrait are exercised. FPS allows 24/25/30/50/60. The current compositor permits 128 active **media inputs** per export; ASS subtitle events do not count toward this limit. It uses bounded encoder/decoder threads and filter threads, but is not yet tuned for large 4K projects. H.265 was rendered/decoded. Short CPU 1440p/4K smoke used a generated lower-resolution image upscaled; native 4K long-project performance and NVENC hardware remain unverified.

`ProEditor.task` runs one background task per editor, queues results/progress to the Tk thread, records terminal state/error under `jobs/`, and supports cancellation. `job_queue.py` additionally handles exports as persistent SQLite snapshots with progress/cancel/retry, atomic job claims and dead-worker recovery, preserving current edits independently. Recovery restarts a whole render, not from a frame. At most 3 attempts; an alive worker is not reset by another process. Other task types remain local workers. Closing a window cancels and waits for its worker before destroying Tk. Auto Studio resumes source-aware review drafts and reuses valid assets/cache, with no delivery before owner approval.

`pro_render.package` creates a new directory and a self-contained ZIP; originals are copied, never moved. It carries relative paths, SHA256 media identities, media rights, referenced scripts/audio decisions/fonts when available, all sequences and SRT files. It includes supplied matching exports; the UI excludes stale exports. It does not publish or upload. Thumbnails remain optional creator/legacy outputs and their directory can be empty.

## UI and optional services

`pro_editor_ui.py` is a Canvas timeline mapped to real frame data, properties, layer controls, media drag/drop, shortcuts, Undo/Redo, save/recovery, actual preview/export, crop/keyframes dialogs and linked shorts. `production_ui.py` launches it on the accepted shared project. `gui.py --pro` also allows independent editing without ASR/API credentials.

`rtl_ui.py` shapes display text only; editable strings and exported captions remain logical Unicode. Main review UI can edit transcript words and timing; Pro Editor edits caption blocks and individual source-derived word text/frame timing via `pro_subtitles.py`/`pro_tools_ui.py`. Strict non-overlap/clip bounds and retiming apply; libass emits verified word highlighting and per-track size/outline. No guessed word times.

Whisper is local and optional to Pro Editor. Small weights have been downloaded and loaded with successful local inference on a generated non-speech signal; human accuracy remains unverified. Commons403 and YouTube source ProxyError remain actual external blocks. `verify_video.py` accepts an authorized local original, extracts independent PCM, calls real Whisper without fixtures, runs the six-stage engine and fully decodes exports. If a true script is absent it marks the derived ASR script as a non-independent reference.

## Gemini decisions and reviewable editing

`gemini_client.py` uses the official REST API with header-only credentials, bounded request sizes/retries/timeouts and JSON schemas. Keys are session-only, secure keyring or environment, never serialized. Default `gemini-3-flash-preview` was live tested; actual model listing/settings can change it. Response exceptions do not dump remote bodies/keys. No raw narration/video is uploaded automatically; only text/timing and limited logical project information.

`gemini_context.py` batches up to240 sentences in groups of12, caches by prompt/model/schema/input hash for a day, validates exact sentence IDs/quotes/finite values and downgrades unsupported game assertions. The cleaned owner's transcript stays authoritative. Local ASR confidence, sensitive-content, timing and rights checks dominate SFX/meme/media/Short recommendations. Shots route to matching approved video/image or an explicit source-word title card, never unrelated Gameplay. Commons adds semantic queries; a specific update query does not blindly reuse generic catalog assets.

`ai_editing.py` converts Gemini's bounded actions into a forked Session. Supported operations are numerical transforms/colors/DSP/gain/keyframes, caption style, hiding overlays, approved local media replacement, full-caption-range Shorts, visual split and verified silence ripple removal. No arbitrary shell/FFmpeg filters/download/publication/source writes. Locks and project validation apply. The assistant renders a candidate proxy; owner approval requires the unchanged base document/sequence, candidate digest, preview identity and unchanged used source identities. Commit is one atomic Undo transaction. An unsupported or failed request does not mutate the original.

`gemini_ui.py` connects actual settings and Assistant UI to these operations. Auto Studio exposes semantic decisions in the footage review, with editable transcript words and source-aware draft dependencies. It reports Gemini success, failure or local fallback honestly.

## Local library, resource limits and cache

`media_library.py` stores SHA256/metadata/tags/game/rights in SQLite, checks current file identity and leaves conflicting licenses pending. It does not grant permission from the internet or silently treat all imports as owned. `preview_cache.py` evicts only recognized generated files with a512MB budget and protects the current proxy and every source. Layer dimensions≤8192 and layer area≤50Mpx, input dimensions≤8192, and128 active media clips bound the compositor; these are not a complete hostile-decoder OS sandbox.

Workspace upper/lower panes resize; properties scroll and the progress/cancel footer remains visible. Track waveform, graphical keyframe curves, automatic portrait subject/HUD tracking, motion blur, speed ramping, expanded Thumbnail Studio and broad publisher Gameplay/reaction coverage remain future work. Full feature status and real test boundaries are in docs/FEATURE_STATUS_AR.md.


## Full real recording fixes

See docs/FULL_REAL_PRODUCTION_AR.md. render_partitions.py renders bounded temporal video slices through the same compositor, mixes audio once without encoder seams, then concatenates exact-frame video and muxes continuous audio. It preserves partial caption text/highlight and avoids cuts inside visual fades. Batch runs omit unused intermediate previews; owner-reviewed UI still renders them. Entity aliases resolve metadata only. Gemini references sentence IDs; the application attaches original verbatim evidence, retains raw response, validates all IDs/rows and never repairs source words with model guesses. CPU filters use up to4threads according to affinity.
