# RashSpeak cloud continuation — 2.4 shared Pro Editor

Current source `/workspace/Rashspeak` is newer than the uploaded `RashSpeak_Cloud_Continuation_WIP.zip`; do NOT replace it. The Git remote was empty; this is an unborn `work` checkout with untracked source, no commits/pushes. A recoverable pre-Pro source ZIP exists outside the repo at `/workspace/restore-points/RashSpeak_pre_Pro_Editor_2.3.zip` (SHA256 `994a1b63b555531acfabb25b26f24089f0fe459696c233440469a8c7e87a39ef`). Final source delivery is another backup; do not assume an empty upstream can restore this work.

Latest owner scope: implement the largest tested part of phase 1 inside the existing app, then expand. Main flow remains audio → footage → SFX → optional memes → montage/Shorts → local manual-upload delivery, reviewed after every phase. No automatic music/publication/thumbnail. Latest follow-up: **three separate overlay tracks for cropped memes and animated GIFs above the video**. Extended Thumbnail Studio is a later optional phase, not a new compulsory main step. Style is general/context-adaptive, not copying supplied videos.

## Current implementation

2.3 introduced reviewed_production.py, sound_effects.py, ReviewBridge and stage_review_ui.py. Every owner gate displays actual valid previews, permits manual correction/import and explicit approval, persists unsent drafts, rejects stale/changed/unpreviewed approvals and checks original identity. SFX are original noise transients with ducking, protected-context/confidence/spacing guards. Reactions are sparse and optional. All 110 tests passed before Pro changes. Original adapters/editor retained in advanced_gui.py.

2.4 adds pro_project.py (schema `rashspeak.multitrack/1`), pro_render.py, pro_editor_ui.py, pro_cli.py and demo_pro_editor.py. Integer frames, independent flexible tracks/clip references, source bounds, transactional Move/Trim/Split/Delete/Ripple/Slip/Slide/Roll, group/copy/paste, locks/state/layer order, Undo/Redo, atomic save/autosave recovery, multiple linked sequences. Render composes actual layers/audio/subtitles, crop/fit/transform/opacity, X/Y keyframes/easing, fades, SFX ducking; preview uses the same compositor. Cache, actual FFmpeg frame progress, cancellation/atomic output, job result/error records and portable ZIP with relative paths/SHA256/rights are implemented. Three Overlay tracks exist by default; native PNG/GIF alpha is preserved.

**Auto Studio montage gate now renders the multitrack document it saves.** `production_ui.py` opens that same `project.rash.json` in Pro Editor without flattening/rebuilding. Rerunning Auto Studio creates a new run; it does not merge arbitrary manual edits. Old early-stage preview renderer remains, and legacy JSON import creates a new Pro file. `gui.py --pro [path]` supports offline independent use. No React rewrite was necessary.

Full verification: 132 tests passed without skips (54.951s), plus standalone Pro GUI shutdown smoke and the delivered demo ZIP re-render/decode. See README_AR.md, docs/PRO_EDITOR_AR.md, docs/ARCHITECTURE.md, docs/FEATURE_STATUS_AR.md, docs/VERIFICATION_2.4_AR.md and TEST_RESULTS.txt for implementation and evidence. Do not overclaim semantic AI, real-time internal playback, complete pro effects, word-level Pro UI, persistent queue or Windows readiness. X/Y curves after trim/split sample boundaries and reconnect them; partial Ease may change and needs review. H.265/4K performance is unverified; H.265/CRF are CLI options. Current compositor cap: 128 active media inputs (ASS text events excluded). Histories contain 100 session snapshots and are not reopened as Undo history.

## Environment/checks

Use `/workspace/cloud-tools/python-env/bin/python` (Debian 3.13/Tk 8.6, true Arabic fonts). Default `.venv` can check engines but its bundled Tk lacks fonts. FFmpeg/ffprobe/ffplay are installed. Xvfb `:99` may need restarting after environment restoration: `/workspace/cloud-tools/root/usr/bin/Xvfb :99 -screen 0 1440x1000x24 -nolisten tcp` in a retained tool session. Do not expose a localhost link for this desktop app.

```
DISPLAY=:99 /workspace/cloud-tools/python-env/bin/python -m unittest discover -s tests -v
DISPLAY=:99 /workspace/cloud-tools/python-env/bin/python gui.py
DISPLAY=:99 /workspace/cloud-tools/python-env/bin/python gui.py --pro output/pro_editor_release/project.rash.json
/workspace/cloud-tools/python-env/bin/python demo_pro_editor.py --out output/new_pro_demo
```

Synthetic demos generate moving encoded video, original graphics/GIF and signals; they are not real human speech/Gameplay or Whisper results. API publisher tests are mocks. Full 1080p/portrait Pro demo lives under ignored `output/pro_editor_release/`; final ZIP and source are under `/workspace/deliverables`.

Whisper `small` isn't downloaded; HF and Commons returned proxy 403. Network custom domains were saved to the draft (`huggingface.co`, `commons.wikimedia.org`, `upload.wikimedia.org`), not applied. Retry only after a real settings change through the supported proxy; diagnose actual CDN destinations rather than bypassing policy/TLS. Do not claim ASR/live sourcing ready before successful inference/download. No credentials are needed for local Pro editing. No real-account tests/publishing were performed.

Cloud draft now declares the actual mount `Rashspeak` with verified unborn HEAD and current start instructions; it requires review/save/publish in environment settings. Setup is installed in the current instance; saving a draft does not activate or prove fresh-task restoration. The empty read-only `/workspace/.git` is a managed metadata mount, not a checkout. No upstream history/source exists to rely on.

## Next work

1. Perform Windows + real Saudi narration acceptance and live permitted-source check; preserve originals and return last take with no suffix backfill. Don't label ASR mismatch as narrator error.
2. Polish per-word caption editing, embedded player/proxy scrubbing, track waveform, motion/keyframe curve editing preserving exact Ease through trims; functional tests first.
3. Extend audio EQ/compressor/de-esser/automation, visual color/crop/rotation/masks/advanced keyframes/transitions incrementally on the shared project; both preview and export must consume the same definitions.
4. Add an optional semantic analysis provider and real reviewable natural-language command transactions; deterministic planning remains the offline fallback. Never add fake assistant/model results.
5. Improve portrait reframing/meaning boundaries and legal provider coverage; unknown rights remain pending. Then optional Thumbnail Studio, performance/cache eviction and persistent task queue. Do not reinstate automated publishing.
