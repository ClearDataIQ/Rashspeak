#!/usr/bin/env bash
set -euo pipefail
cd /workspace/Rashspeak
python -m venv .venv
.venv/bin/python -m pip install -r requirements.txt -r requirements-asr.txt -r requirements-media.txt
/usr/bin/python3 -m venv --without-pip /workspace/cloud-tools/python-env
.venv/bin/python -m pip --python /workspace/cloud-tools/python-env/bin/python install -r requirements.txt -r requirements-asr.txt -r requirements-media.txt
mkdir -p /workspace/cloud-tools/lists/partial /workspace/cloud-tools/cache/archives/partial /workspace/cloud-tools/debs /workspace/cloud-tools/hf-cache
printf '%s\n' 'deb [signed-by=/usr/share/keyrings/debian-archive-keyring.gpg] https://deb.debian.org/debian trixie main' > /workspace/cloud-tools/sources.list
apt_options=(-o Dir::Etc::parts=- -o Dir::Etc::sourcelist=/workspace/cloud-tools/sources.list -o Dir::Etc::sourceparts=- -o Dir::State::lists=/workspace/cloud-tools/lists -o Dir::Cache=/workspace/cloud-tools/cache -o APT::Sandbox::User=agent)
apt-get "${apt_options[@]}" update
(cd /workspace/cloud-tools/debs && apt-get "${apt_options[@]}" download xvfb libportaudio2)
python - <<'EXTRACT'
from pathlib import Path
import subprocess
for pattern in ('xvfb_*.deb', 'libportaudio2_*.deb'):
    for package in Path('/workspace/cloud-tools/debs').glob(pattern):
        subprocess.run(['dpkg-deb', '-x', str(package), '/workspace/cloud-tools/root'], check=True)
EXTRACT
# Model download is optional to manual editing. Keep caches under writable roots.
HF_HOME=/workspace/cloud-tools/hf-cache HF_HUB_DISABLE_XET=1 HF_HUB_DOWNLOAD_TIMEOUT=60 HF_HUB_ETAG_TIMEOUT=15 /workspace/cloud-tools/python-env/bin/python - <<'MODEL'
from pathlib import Path
model = Path('/workspace/Rashspeak/models/small')
if not all((model/name).is_file() for name in ('model.bin','config.json','tokenizer.json')):
    try:
        from faster_whisper.utils import download_model
        download_model('small', output_dir=str(model))
    except Exception as exc:
        print('Optional Whisper download unavailable:', type(exc).__name__)
MODEL
/workspace/cloud-tools/python-env/bin/python diagnose_environment.py
