# RashSpeak Studio 2.5 — current handoff, 2026-10-14

The existing Python/Tk/FFmpeg source was continued from the uploaded WIP, not replaced with an older copy. This checkout is unborn `work`, no commits/pushes; upstream was empty. The recoverable copies are this filesystem and `/workspace/deliverables/RashSpeak_Studio_2.5.zip`. Do not reset or replace it. Restore points live outside the source in `/workspace/restore-points/` (pre Pro2.3, Gemini2.4 and full real export2.5).

## Owner scope and current work

The owner supplied an actual MP3 and explicitly said finish without asking opinions. All six stages were run in batch mode with no fake owner approvals. Publishing remains manual, thumbnail optional, no music added. Normal app projects retain six review gates: audio → footage → SFX → optional memes → long/Short montage → file delivery. Auto Studio and Pro Editor share the exact non-destructive rendered document. Three independent cropped/transparent GIF/meme overlays exist.

Read docs/FULL_REAL_PRODUCTION_AR.md and output/real_voice_test_20261014/production_result.json + full_verification.json for actual latest completion. The old session64632/audio revision3 wait was closed; never resume that review or restart ASR unnecessarily. Final corrected native renders are under Project/runs/run_007/delivery and project.rash.json. The final audit replaced known backstage/previous-game visuals; one matching Witcher trailer remains, most coverage is clearly labelled original topic cards. No broad professional Gameplay coverage claim.

## Implemented modules

- pro_project.py/timeline_ops.py: frame-based non-destructive multitrack model, move/trim/split/ripple/slip/slide/roll/group/copy/paste, locks, Undo/Redo/autosave/save/reopen; relative portable references and source fingerprints/SHA256.
- pro_render.py/render_partitions.py: same compositor for preview and final; real H.264/H.265, portrait, transitions/color/transform/masks/keyframes. Long sequences partition temporally, preserve full text/word highlight/keyframes, render one continuous audio mix, validate actual frame/duration/codec and source identity, atomic output. Practical limits:128 simultaneous video inputs,128 audio clips in the continuous mix.
- gemini_client.py/gemini_context.py/gemini_ui.py: official Gemini REST, session-memory/keyring/env key, chosen model/settings, strict structured context in12-row batches, source-id grounding and verbatim evidence, raw/normalized cache and explicit failure state. Actual test used gemini-3.1-flash-lite for160 real narration rows. Default remains3FlashPreview; select available model in settings. No raw audio/video sent.
- ai_editing.py/pro_tools_ui.py: bounded natural-language edit proposals, real candidate proxy, review/freshness checks, single transaction Undo; DSP, volume automation, colors/rotation/masks, scale/opacity/easing, crossfade, visual rate/reverse.
- captions.py/pro_subtitles.py: editable source-derived words/timing, Arabic shaping/RTL, styles/highlight/outline/SRT. No invented timings or words. Real ASR draft has errors and lacks a reviewed reference script.
- preview_player.py: actual PyAV internal proxy/pause/seek, optional PCM/DAC audio clock and explicit no-device state. No GPU live compositor.
- licensed_media.py/media_library.py: approved provider/domain and license validation, attribution evidence, local SHA256 SQLite catalog. Explicit backstage/interview/cosplay metadata is excluded from automatic visual selection; low-confidence semantic rows cannot keep previous-game footage. This is a metadata guard, not a full visual classifier. Local manual media editing remains available.
- sound_effects.py: original procedural effects, conservative speech-gap timing, ducking. Actual test one whoosh, no suitable approved meme so zero memes; no automatic music.
- job_queue.py/preview_cache.py: persistent export snapshots/progress/cancel/retry/dead-worker recovery and bounded derivative cache. Recovery restarts a whole export, not halfway.
- verify_video.py: authorized local video → immutable source hash → PCM extraction → actual local Whisper → production → full decode → portable ZIP. Without script, ASR is a draft, not independent accuracy/retake evidence. YouTube downloader is not built.

## Real audio evidence

Actual uploaded source673.410612s,44.1kHz stereo, about127kbps; filename48KBPS is misleading. Whisper small/int8 transcribed1655words locally in227.2s;160 grouped segments went to Gemini. Original hash02faede7626d041188ed01ee32ee5741b591a6f9afadc57453ace6448e8a1801 stayed unchanged. Only1.8206s quiet tail removed; all1655ASR texts/order preserved. Processed671.59s WAV: –17.06LUFS and –1.46dBTP; exact–16 target was not reached. No denoise on the already mixed original, no guessed retake deletion, no speech synthesis. English trailer speech stayed intact.

Long output671.62s1920×1080/30fpsH.264AAC; three1080×1920Shorts36.03,24.43,34.07s. Complete decoding checks are in full_verification.json. Gemini-proposed Short ranges were refined against actual word timings to end complete thoughts (Zelda534.90–570.92, Ghost35.97–60.39, Elden188.01–222.05; outward frame rounding). The long sequence was byte-for-byte unchanged in the document; its output was reused. Short ranges are contiguous original speech, but portrait layout is contain/manual, no subject/HUD tracking. Original cards dominate due limited fitting footage. The user's quality acceptance remains unapproved; do not call this entire Premiere/Resolve scope finished.

Final source suite:166unit/integration/Tk/API mock and real FFmpeg tests. See TEST_RESULTS.txt. The synthetic demos/resolution smoke are labelled separately; they do not prove human transcription accuracy or RTX4060 throughput. Some Gemini models returned404/503/timeouts/invalid grounding; rejected results are not marked successful.

## Run and recover

Use `/workspace/cloud-tools/python-env/bin/python` (DebianPython3.13/Tk8.6 with Arabic TrueType). Bundled.venvTk lacks suitable fonts. FFmpeg/ffprobe/ffplay7.1.5 and PyAV15.1 are installed. Whisper small weights exist at models/small; HF_HOME=/workspace/cloud-tools/hf-cache.

```
DISPLAY=:99 XDG_CACHE_HOME=/workspace/cloud-tools/cache /workspace/cloud-tools/python-env/bin/python -m unittest discover -s tests -v
DISPLAY=:99 XDG_CACHE_HOME=/workspace/cloud-tools/cache /workspace/cloud-tools/python-env/bin/python gui.py
DISPLAY=:99 XDG_CACHE_HOME=/workspace/cloud-tools/cache /workspace/cloud-tools/python-env/bin/python gui.py --pro output/real_voice_test_20261014/Project/runs/run_007/project.rash.json
/workspace/cloud-tools/python-env/bin/python diagnose_environment.py
```

Start Xvfb :99 if absent, `/workspace/cloud-tools/root/usr/bin/Xvfb :99 -screen 0 1440x1000x24 -nolisten tcp`, in a retained terminal. Desktop app has no user-facing localhost site. Cloud setup/start scripts: docs/CLOUD_SETUP.sh and docs/CLOUD_START.md. Managed cloud draft saved, requires save/publish in environment settings, not applied or restoration-tested from empty upstream. No persistent Gemini key; secure UI/keyring or optional RASH_GEMINI_API_KEY. Never reproduce/save the chat key to source, projects, artifacts, logs or shell files.

## Delivery

`/workspace/deliverables/RashSpeak_Real_Long.mp4`, three RashSpeak_Real_Short_01..03.mp4, portable RashSpeak_Real_Full_Project.zip, source RashSpeak_Studio_2.5.zip and RashSpeak_Real_Full_Verification.json. Portable project has Project,Original_Audio,Media,Long_Video,Shorts,Thumbnails(empty),Subtitles,Export. Original user media and model weights are excluded from the source ZIP; included only where needed in the private portable production project. Source includes dependencies/run instructions/tests/architecture/full prompt/limits/handoff.

## Remaining priorities

1. Better licensed publisher Gameplay coverage, actual update/scene relevance; Commons access was intermittent/403, sparse assets were insufficient. Never use behind-the-scenes recording as gameplay or assume unknown internet rights.
2. Actual owner review of ASR words and style/pacing/Short boundaries. No original script was supplied; no accuracy metric or guaranteed last-correct-take detection can be inferred from this recording.
3. Windows/audio device/RTX4060/EXE acceptance. Cloud lacks physical audio output and GPU; signed installer not supplied.
4. Portrait subject/HUD tracking, graphical keyframe curves/waveform, speed ramping/motion blur/LUT/color wheels, broader background job kinds and performance/cache tuning. Current first proxy needs rendering.
5. Optional expanded Thumbnail Studio outside the owner workflow. Legacy tools remain accessible with--advanced, no automatic publishing.

Historical 2.4 handoff is docs/HANDOFF_2.4_ARCHIVE.md. Update this current handoff rather than reviving older pending steps.

Final completion confirmed: all4native outputs decoded, original hash matched, portable ZIP157.46MB extracted and validated in a new directory, actual move/Undo/Redo/save/reopen plus portrait sample rendered, Short source links point to the original long sequence. Metadata-only verification is docs/verification/real_audio_full_production.json. No active review/export workers need resuming.
