# RashSpeak Studio 2.x → 3.0 : implementation backlog

## Product goal
Create a **reliable, attractive Windows desktop creator workflow** for @RashSpeak (Arabic gaming news). User records **his own voice** and provides or approves legally reusable media. App should transform narration into video drafts and vertical cutdowns and facilitate YouTube + Instagram + TikTok publishing. Minimize manual editing; never promise literally fully unattended posting across disallowed accounts.

### P0 — stabilization and security (do first)
- [ ] Establish baseline run on Windows 11 Python 3.11+ and document current tests, optional features and FFmpeg setup; compile + test. Audit assumptions in source and README.
- [ ] Enforce input validation, file limits, robust progress reporting, cancellation for long render/upload tasks; keep Tk main thread responsive. Avoid command injection, unsafe file handling, accidental secret logging, duplicate uploads.
- [ ] Harden the three OAuth flows: CSRF/state, TikTok PKCE according to latest official docs, token refresh/expiration, HTTP timeouts/backoff, account identity verification, disconnect/revoke, failure messaging. Never expose tokens in logs.
- [ ] Reconcile README and UI with implemented capabilities; platform features must clearly say connected/authorized, permissions pending, draft-only, ready to publish, published/failed.
- [ ] Add tests that simulate errors, failures, partial uploads, retries, duplicate prevention and token expiry.

### P1 — creator/editor (highest value)
- [ ] User selects commentary audio and licensed gameplay clips. Auto-transcribe Arabic voice locally (faster-whisper optional), with a timeline and editable corrected captions.
- [ ] Produce suggested scene boundaries from transcript/time segments, use local media filename/tags to suggest shots, show editable mapping before rendering. **No unlicensed online gameplay fetching**.
- [ ] Support per-story clips and multiple vertical Shorts/Reels, selectable in/out points instead of always first 35 seconds; preview thumbnail/frame and export valid 1080x1920 H.264/AAC.
- [ ] Branded overlays: persistent RashSpeak title/logo, lower-thirds for game names, subtitles safe-zone, intro/outro templates, adjustable music ducking only with creator-provided licensed music, consistent export profiles.
- [ ] Deliver one-click workflow for a 4–7 min news video plus 2–3 proposed short clips; allow batch render locally with progress and render validation via ffprobe.

### P2 — official publishing and review
- [ ] Account panel for YouTube @RashSpeak, Instagram Professional account, TikTok. Show verified account ID/display name, scope status and provider constraints, with secure disconnect.
- [ ] YouTube: OAuth via Desktop app; upload long/Short with unique title/description/thumbnail where permitted, private default, user-triggered scheduling with UTC conversion and status polling; honor API audit restrictions and quotas.
- [ ] TikTok: draft/inbox upload first; Direct Post ONLY if official `video.publish` scope + platform audit permit. Before submitting, show verified account, privacy/interaction settings, copyright/brand disclosures, video preview, and explicit publish confirmation.
- [ ] Instagram: OAuth Professional API; implement a safe creator-selected compatible hosted-media flow (explain when public HTTPS is needed), upload status, Reel container status and public publish only after consent. Avoid leaking private media via silent uploads. Verify the actual current Meta API endpoints and capabilities before coding.
- [ ] Separate per-platform captions, hashtags, cover, privacy and visibility; do not copy a YouTube description blindly to TikTok.
- [ ] Local persistent queue for staged uploads, idempotency and resilient status: draft / waiting_for_approval / uploading / processing / posted / failed; re-check statuses without duplicated posts. NO unattended scheduled public publishing without prior per-item approval and official support.
- [ ] If API credentials or permissions aren't available: export the final media, captions and thumbnails locally with clear upload instructions; never fake successful publication.

### P3 — polish, tests and delivery
- [ ] Update Arabic UI with RTL presentation, clear onboarding, dark appearance, navigation, responsive resizing, polished timeline/media browser and video player if dependencies allow.
- [ ] Produce unit tests, API mock tests, FFmpeg render smoke tests, and Windows manual acceptance test checklist, including no-network render.
- [ ] Package an EXE using PyInstaller or comparable (possibly FFmpeg external), clarify unsigned status, Windows Defender caveats; prove it runs from a clean path on Windows if test machine available.
- [ ] User docs: quick start in Arabic, developer-app setup for each platform, security/privacy/permissions, troubleshooting and cost breakdown, known limitations.

## Acceptance scenarios
1. From a WAV voice file and local gameplay folder, make a playable narrated long MP4 and at least two 1080x1920 short candidates after user selects time ranges. Captions can be corrected. Do not use internet for basic rendering.
2. Account not connected: app says so and leaves exported files intact. Zero fake success messages.
3. Valid mocked OAuth: account identity/scopes displayed; token material stored in local OS credential store. Invalid state and expired token cases tested.
4. After review of YouTube metadata, upload is `private` by default. Show video link only when actual API returns a video id.
5. TikTok restricted account produces a clearly labeled draft/inbox flow; no unsanctioned Direct Post.
6. Instagram with missing Professional access or HTTPS-hosted media blocks before submission with actionable error.
7. User explicitly opts into each public publication; app prevents duplicate postings during retry after ambiguous failure.
8. Run complete unit tests, media smoke tests; report real vs mocked integration coverage. EXE packaging documented and verified as far as environment allows.

## Developer dependencies/constraints
- No owner API secrets or channel permissions are included. Missing approvals are **real external blockers**; implement mocked tests and instructions, not bypasses.
- Publish only to YouTube, Instagram, TikTok. Ignore X, Facebook.
- Built-in localization should prioritize Saudi Arabic; subtitle content comes from user narration.
- Production app may need external FFmpeg and per-user API app registration; keep user aware of recurring hosting/platform costs.

## Suggested checkpoints and evidence
- Checkpoint A: audited baseline, security fixes, tests green.
- Checkpoint B: robust narration-to-multishort renderer + preview + captions.
- Checkpoint C: platform account and publishing wizard with safe OAuth + mock tests.
- Checkpoint D: Windows distributable, quickstart docs, limitations matrix.
