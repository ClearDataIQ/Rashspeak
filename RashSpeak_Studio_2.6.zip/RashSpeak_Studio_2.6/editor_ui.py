"""Incremental Arabic editor panel, all Tk access confined to the UI thread."""
import copy
import json
import os
from pathlib import Path
import queue
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk

import captions
from app_paths import app_dir
from smart_editor import approve, digest, fingerprint, import_asset, plan, save, validate_timeline
from timeline_render import caption_preview, render


class Editor(ttk.Frame):
    def __init__(self, parent, logger=print):
        super().__init__(parent, padding=10)
        self.logger = logger
        self.assets, self.segments, self.timeline = [], [], None
        self.draft_digest = None
        self.busy = False
        self.cancel = threading.Event()
        self.events = queue.Queue()
        self.images = []
        self.paths = {}
        self.tabs = ttk.Notebook(self)
        self.tabs.pack(fill='both', expand=True)
        inputs, transcript, timeline = [ttk.Frame(self.tabs, padding=10) for _ in range(3)]
        for frame, label in [(inputs, '١. الصوت والأصول'), (transcript, '٢. مراجعة الترجمة'), (timeline, '٣. المونتاج والمراجعة')]:
            self.tabs.add(frame, text=label)
        inputs.columnconfigure(1, weight=1)
        for row, (key, label, directory) in enumerate([('audio', 'تسجيلك الصوتي', False),
                ('out', 'مجلد المشروع', True), ('model', 'نموذج Whisper محلي (اختياري)', True),
                ('cues', 'cues.csv يدوي (اختياري)', False), ('script', 'نص الخبر TXT (اختياري)', False)]):
            ttk.Label(inputs, text=label, anchor='e').grid(row=row, column=2, sticky='e', padx=6, pady=3)
            default = str(app_dir() / 'output') if key == 'out' else ''
            local_model = app_dir() / 'models/small'
            if key == 'model' and local_model.is_dir():
                default = str(local_model)
            variable = tk.StringVar(value=default)
            self.paths[key] = variable
            ttk.Entry(inputs, textvariable=variable, justify='right').grid(row=row, column=1, sticky='ew', padx=5)
            ttk.Button(inputs, text='اختيار', command=lambda k=key, d=directory: self.pick(k, d)).grid(row=row, column=0)
        self.asset_tree = self.tree(inputs, ('ملف', 'النوع', 'اللعبة / الوسوم', 'الرخصة', 'اعتماد'), height=5)
        self.asset_tree.grid(row=5, column=0, columnspan=3, sticky='nsew', pady=8)
        inputs.rowconfigure(5, weight=1)
        self.asset_tree.bind('<Double-1>', lambda e: self.edit_asset())
        bar = ttk.Frame(inputs)
        bar.grid(row=6, column=0, columnspan=3)
        for label, fn in [('إضافة لقطة / صورة', lambda: self.add_assets('clip')), ('إضافة ريأكشن مرخص', lambda: self.add_assets('meme')),
                          ('وسوم وحقوق الأصل', self.edit_asset), ('معاينة الأصل', self.preview_asset), ('حذف الأصل', self.remove_asset), ('حفظ المشروع', self.save_project), ('فتح مشروع', self.open_project)]:
            ttk.Button(bar, text=label, command=fn).pack(side='right', padx=3)
        ttk.Label(inputs, text='كل أصل يحتاج مصدرًا ورخصة واعتماد استخدام. انقر مرتين لتعديل الوسوم. لا يُنزّل البرنامج لقطات من الإنترنت.', wraplength=800, anchor='e').grid(row=7, column=0, columnspan=3, sticky='e', pady=6)
        self.segment_tree = self.tree(transcript, ('بداية', 'نهاية', 'النص', 'نوع الجملة', 'أهمية'), height=9)
        self.segment_tree.pack(fill='both', expand=True)
        self.segment_tree.bind('<Double-1>', lambda e: self.edit_segment())
        bar = ttk.Frame(transcript)
        bar.pack(pady=6)
        for label, fn in [('تفريغ عربي محلي', self.transcribe), ('استيراد SRT / JSON', self.import_transcript),
                          ('إضافة جملة', lambda: self.edit_segment(True)), ('تعديل جملة', self.edit_segment),
                          ('حذف جملة', self.remove_segment), ('حفظ SRT', self.export_srt)]:
            ttk.Button(bar, text=label, command=fn).pack(side='right', padx=3)
        ttk.Label(transcript, text='راجع الكلمات والتوقيت. النص المكتوب وحده لا يُعامل كترجمة موقّتة. التعرّف الصوتي يحتاج نموذجًا محليًا ولا ينزّله تلقائيًا.', wraplength=800, anchor='e').pack(anchor='e')
        options = ttk.Frame(timeline)
        options.pack(fill='x')
        self.memes_enabled = tk.BooleanVar(value=False)
        self.nvenc = tk.BooleanVar(value=False)
        ttk.Checkbutton(options, text='اقتراح ريأكشنات قليلة من مكتبتك (اعتماد كل واحد)', variable=self.memes_enabled).pack(side='right')
        ttk.Checkbutton(options, text='NVIDIA', variable=self.nvenc).pack(side='right')
        ttk.Button(options, text='تحليل وبناء المونتاج', command=self.analyze).pack(side='left')
        self.shot_tree = self.tree(timeline, ('بداية', 'نهاية', 'اللقطة', 'ثقة', 'سبب الاختيار'), height=4)
        self.shot_tree.pack(fill='both', expand=True, pady=5)
        controls = ttk.Frame(timeline)
        controls.pack(fill='x')
        for label, fn in [('تبديل الأصل', self.replace_shot), ('تحريك للأعلى', lambda: self.move_shot(-1)),
                          ('تحريك للأسفل', lambda: self.move_shot(1)), ('حذف ودمج', self.remove_shot), ('تعديل التوقيت والمناطق JSON', self.edit_json)]:
            ttk.Button(controls, text=label, command=fn).pack(side='right', padx=2)
        lower = ttk.Frame(timeline)
        lower.pack(fill='x')
        self.meme_tree = self.tree(lower, ('التوقيت', 'المدة', 'الميم', 'سبب الاقتراح', 'الحالة'), height=3)
        self.meme_tree.pack(side='right', fill='both', expand=True)
        self.short_tree = self.tree(lower, ('من', 'إلى', 'Short', 'الحالة'), height=3)
        self.short_tree.pack(side='left', fill='both', expand=True)
        self.meme_tree.bind('<Double-1>', lambda e: self.toggle_meme())
        self.short_tree.bind('<Double-1>', lambda e: self.edit_short())
        controls = ttk.Frame(timeline)
        controls.pack(fill='x', pady=3)
        for label, fn in [('اعتماد / رفض الميم', self.toggle_meme), ('إضافة / تعديل Short', self.edit_short),
                          ('حذف Short', self.remove_short), ('معاينة الترجمة', self.preview_caption), ('الخط ونمط الترجمة', self.caption_settings)]:
            ttk.Button(controls, text=label, command=fn).pack(side='right', padx=2)
        self.warnings = tk.Text(timeline, height=3, wrap='word', font=('Segoe UI', 9), bg='#17243b', fg='#ffdcaa')
        self.warnings.pack(fill='x')
        self.warnings.tag_configure('rtl', justify='right')
        export = ttk.Frame(timeline)
        export.pack(fill='x', pady=6)
        for label, fn in [('إخراج مسودة للمراجعة', lambda: self.render_video(False)), ('فتح المسودة', self.open_draft), ('قبل / بعد', self.preview_comparison),
                          ('اعتماد بعد المشاهدة', self.approve), ('تصدير نهائي 1080p', lambda: self.render_video(True))]:
            ttk.Button(export, text=label, command=fn).pack(side='right', padx=3)
        self.progress = ttk.Progressbar(self, mode='indeterminate')
        self.progress.pack(fill='x', pady=(6, 0))
        footer = ttk.Frame(self)
        footer.pack(fill='x')
        self.status = tk.StringVar(value='جاهز — التحرير محلي والنشر منفصل ويتطلب موافقتك')
        ttk.Label(footer, textvariable=self.status, anchor='e').pack(side='right', fill='x', expand=True)
        ttk.Button(footer, text='إلغاء المعالجة', command=self.cancel.set).pack(side='left')
        self.drain_id = self.after(80, self.drain)
        self.bind('<Destroy>', self.shutdown, add='+')

    def tree(self, parent, columns, height):
        tree = ttk.Treeview(parent, columns=columns, show='headings', height=height, selectmode='browse')
        for column in columns:
            tree.heading(column, text=column, anchor='e')
            tree.column(column, width=120 if column not in ('النص', 'سبب الاختيار') else 300, anchor='e')
        return tree

    def drain(self):
        while not self.events.empty():
            kind, value = self.events.get()
            if kind == 'log':
                self.status.set(value)
                self.logger(value)
            else:
                self.busy = False
                self.progress.stop()
                if kind == 'error':
                    self.status.set('تعذر التنفيذ / أُلغي')
                    messagebox.showerror('RashSpeak', value, parent=self)
                else:
                    result, done = value
                    self.status.set('انتهت المعالجة')
                    if done:
                        try:
                            done(result)
                        except Exception as exc:
                            messagebox.showerror('RashSpeak', str(exc), parent=self)
        self.drain_id = self.after(80, self.drain)

    def shutdown(self, event=None):
        if event is not None and event.widget is not self:
            return
        self.cancel.set()
        if self.drain_id:
            self.after_cancel(self.drain_id)
            self.drain_id = None

    def job(self, label, fn, done=None):
        if self.busy:
            messagebox.showinfo('معالجة جارية', 'انتظر أو ألغِ العملية الحالية.', parent=self)
            return
        self.busy = True
        self.cancel.clear()
        self.status.set(label)
        self.progress.start()
        def worker():
            try:
                self.events.put(('done', (fn(), done)))
            except Exception as exc:
                self.events.put(('error', str(exc)))
        threading.Thread(target=worker, daemon=True).start()

    def log(self, value):
        self.events.put(('log', value))

    def pick(self, key, directory):
        value = filedialog.askdirectory(parent=self) if directory else filedialog.askopenfilename(parent=self)
        if value:
            self.paths[key].set(value)

    def output(self):
        return Path(self.paths['out'].get()).resolve()

    def changed(self):
        if self.timeline:
            self.timeline['review'] = None
        self.draft_digest = None

    def selected(self, tree):
        return int(tree.selection()[0]) if tree.selection() else None

    def dialog(self, title, values, done):
        popup = tk.Toplevel(self)
        popup.title(title)
        popup.transient(self.winfo_toplevel())
        popup.grab_set()
        entries = {}
        for row, (key, label, value) in enumerate(values):
            ttk.Label(popup, text=label, anchor='e').grid(row=row, column=1, padx=12, pady=6, sticky='e')
            entry = ttk.Entry(popup, width=65, justify='right')
            entry.insert(0, str(value))
            entry.grid(row=row, column=0, padx=12, pady=6)
            entries[key] = entry
        def apply():
            try:
                done({k: e.get() for k, e in entries.items()})
                popup.destroy()
            except Exception as exc:
                messagebox.showerror('تحقق من القيم', str(exc), parent=popup)
        ttk.Button(popup, text='حفظ', command=apply).grid(row=len(values), column=0, pady=10)

    def refresh(self):
        for tree in (self.asset_tree, self.segment_tree, self.shot_tree, self.meme_tree, self.short_tree):
            tree.delete(*tree.get_children())
        for i, a in enumerate(self.assets):
            self.asset_tree.insert('', 'end', iid=str(i), values=(Path(a['path']).name, a['role'], a['game'] + ' / ' + ', '.join(a['tags']), a['license'], 'نعم' if a['usage_approved'] else 'لم يُعتمد'))
        for i, s in enumerate(self.segments):
            self.segment_tree.insert('', 'end', iid=str(i), values=(s['start'], s['end'], s['text'], s.get('mode', 'auto'), s.get('importance', 0)))
        if not self.timeline:
            return
        names = {a['id']: Path(a['path']).name for a in self.assets}
        for i, s in enumerate(self.timeline['shots']):
            self.shot_tree.insert('', 'end', iid=str(i), values=(s['start'], s['end'], names.get(s['asset_id'], 'خلفية محايدة'), s['confidence'], s['reason']))
        for i, m in enumerate(self.timeline['memes']):
            self.meme_tree.insert('', 'end', iid=str(i), values=(m['timestamp'], m['duration'], names.get(m['asset_id'], '?'), m['reason'], 'معتمد' if m['approved'] else 'اقتراح'))
        for i, s in enumerate(self.timeline['shorts']):
            self.short_tree.insert('', 'end', iid=str(i), values=(s['start'], s['end'], s['reason'], 'معتمد' if s['approved'] else 'اقتراح'))
        self.warnings.delete('1.0', 'end')
        self.warnings.insert('end', '\n'.join(self.timeline['warnings']) or 'راجع الترجمة والحقوق والمحتوى قبل الاعتماد.', 'rtl')

    def add_assets(self, role):
        paths = filedialog.askopenfilenames(parent=self, filetypes=[('صور وفيديو', '*.mp4 *.mov *.mkv *.webm *.avi *.m4v *.png *.jpg *.jpeg *.gif *.webp')])
        if not paths:
            return
        previews = self.output() / 'previews'
        def done(assets):
            known = {a['id'] for a in self.assets}
            self.assets.extend(a for a in assets if a['id'] not in known)
            self.changed()
            self.refresh()
        self.job('فحص الأصول وتوليد الصور', lambda: [import_asset(p, role, previews=previews, cancel=self.cancel) for p in paths], done)

    def edit_asset(self):
        i = self.selected(self.asset_tree)
        if i is None:
            return
        a = self.assets[i]
        def done(v):
            updated = {**a, 'game': v['game'].strip(), 'tags': [x.strip() for x in v['tags'].split(',') if x.strip()],
                       'mood': v['mood'].strip(), 'license': v['license'].strip(), 'source': v['source'].strip(),
                       'usage_approved': v['approved'].strip() == 'نعم'}
            if updated['usage_approved'] and (not updated['license'] or not updated['source']):
                raise ValueError('أدخل الرخصة والمصدر أولًا.')
            self.assets[i] = updated
            self.timeline = None
            self.changed()
            self.refresh()
        self.dialog('وسوم الأصل وحقوقه', [('game', 'اللعبة (اتركها فارغة للأصل العام)', a['game']),
             ('tags', 'وسوم مفصولة بفاصلة إنجليزية', ', '.join(a['tags'])), ('mood', 'الميم: humor / frustration / surprise', a['mood']),
             ('license', 'الرخصة / ملكية شخصية', a['license']), ('source', 'المصدر / وصف تصويرك', a['source']),
             ('approved', 'توافق على استخدام الأصل؟ اكتب نعم', 'نعم' if a['usage_approved'] else 'لا')], done)

    def remove_asset(self):
        i = self.selected(self.asset_tree)
        if i is not None:
            self.assets.pop(i)
            self.timeline = None
            self.changed()
            self.refresh()

    def transcribe(self):
        audio, model = self.paths['audio'].get(), self.paths['model'].get()
        vocabulary = [a.get('game','') for a in self.assets if a.get('game')]
        def done(value):
            self.segments = value
            self.timeline = None
            self.changed()
            self.refresh()
        self.job('تفريغ لهجتك السعودية محليًا — راجع الكلمات قبل الحرق', lambda: captions.transcribe(audio, model, self.log, self.cancel, dialect='saudi', vocabulary=vocabulary or None), done)

    def import_transcript(self):
        path = filedialog.askopenfilename(parent=self, filetypes=[('ترجمة', '*.srt *.json')])
        if path:
            try:
                self.segments = captions.load(path)
                self.timeline = None
                self.changed()
                self.refresh()
            except Exception as exc:
                messagebox.showerror('الترجمة', str(exc), parent=self)

    def edit_segment(self, new=False):
        i = None if new else self.selected(self.segment_tree)
        if i is None and not new:
            return
        s = {'start': 0, 'end': 3, 'text': '', 'mode': 'auto', 'importance': 0} if new else self.segments[i]
        def done(v):
            item = {'start': float(v['start']), 'end': float(v['end']), 'text': v['text'].strip(), 'mode': v['mode'].strip(), 'importance': float(v['importance'])}
            trial = copy.deepcopy(self.segments)
            if new:
                trial.append(item)
            else:
                trial[i] = item
            trial.sort(key=lambda x: x['start'])
            from media_tools import duration
            captions.validate(trial, duration(self.paths['audio'].get(), 'audio'))
            self.segments = trial
            self.timeline = None
            self.changed()
            self.refresh()
        self.dialog('مراجعة الجملة', [('start', 'البداية بالثواني', s['start']), ('end', 'النهاية', s['end']), ('text', 'النص', s['text']),
             ('mode', 'auto / factual / sensitive / crucial / cta / humor / surprise / frustration', s.get('mode', 'auto')),
             ('importance', 'أهمية الخبر من 0 إلى 10', s.get('importance', 0))], done)

    def remove_segment(self):
        i = self.selected(self.segment_tree)
        if i is not None:
            self.segments.pop(i)
            self.timeline = None
            self.changed()
            self.refresh()

    def export_srt(self):
        path = filedialog.asksaveasfilename(parent=self, defaultextension='.srt')
        if path:
            captions.write_srt(self.segments, path)

    def analyze(self):
        audio, cues, script_path = (self.paths[x].get() for x in ('audio', 'cues', 'script'))
        assets, segments, enabled = copy.deepcopy(self.assets), copy.deepcopy(self.segments), self.memes_enabled.get()
        def work():
            script = Path(script_path).read_text(encoding='utf-8-sig') if script_path else ''
            return plan(audio, {'assets': assets}, segments, script, cues, enabled)
        def done(timeline):
            self.timeline = timeline
            self.changed()
            save(timeline, self.output() / 'timeline.json')
            self.refresh()
        self.job('مطابقة الوسوم وبناء الاقتراحات', work, done)

    def ensure(self):
        if not self.timeline:
            messagebox.showinfo('المونتاج', 'حلل المشروع أولًا.', parent=self)
            return False
        return True

    def replace_shot(self):
        if not self.ensure():
            return
        i = self.selected(self.shot_tree)
        if i is None:
            return
        choices = [a for a in self.assets if a['role'] == 'clip' and a['usage_approved']]
        text = '\n'.join(f'{j+1}: {Path(a["path"]).name}' for j, a in enumerate(choices))
        selection = simpledialog.askinteger('تبديل الأصل', text + '\n0: خلفية محايدة', parent=self, minvalue=0, maxvalue=len(choices))
        if selection is not None:
            shot = self.timeline['shots'][i]
            shot.update(asset_id=choices[selection-1]['id'] if selection else None, reason='اختيار يدوي؛ راجعه', confidence=1, source_offset=0, manual=True)
            self.changed()
            self.refresh()

    def move_shot(self, delta):
        if not self.ensure():
            return
        i = self.selected(self.shot_tree)
        shots = self.timeline['shots']
        if i is None or not 0 <= i + delta < len(shots):
            return
        # Swap assignments while preserving complete narration coverage.
        a, b = shots[i], shots[i + delta]
        for key in ('asset_id', 'source_offset', 'topic', 'reason', 'confidence', 'manual', 'transition'):
            a[key], b[key] = b[key], a[key]
        a['reason'] = b['reason'] = 'تحريك يدوي؛ راجع تطابق الخبر'
        self.changed()
        self.refresh()

    def remove_shot(self):
        if not self.ensure():
            return
        i = self.selected(self.shot_tree)
        shots = self.timeline['shots']
        if i is None or len(shots) == 1:
            return
        shot = shots.pop(i)
        if i:
            shots[i - 1]['end'] = shot['end']
        else:
            shots[0]['start'] = shot['start']
        self.changed()
        self.refresh()

    def edit_json(self):
        if not self.ensure():
            return
        popup = tk.Toplevel(self)
        popup.title('الخط الزمني — التوقيت والمناطق المحجوزة')
        popup.geometry('850x580')
        popup.grab_set()
        text = tk.Text(popup, wrap='none')
        text.pack(fill='both', expand=True)
        text.insert('1.0', json.dumps(self.timeline, ensure_ascii=False, indent=2))
        def apply():
            try:
                timeline = json.loads(text.get('1.0', 'end'))
                validate_timeline(timeline)
                self.timeline = timeline
                self.assets, self.segments = timeline['assets'], timeline['segments']
                self.changed()
                self.refresh()
                popup.destroy()
            except Exception as exc:
                messagebox.showerror('الخط الزمني', str(exc), parent=popup)
        ttk.Button(popup, text='تحقق وحفظ', command=apply).pack(pady=6)

    def toggle_meme(self):
        if not self.ensure():
            return
        i = self.selected(self.meme_tree)
        if i is None:
            return
        trial = copy.deepcopy(self.timeline)
        trial['memes'][i]['approved'] = not trial['memes'][i]['approved']
        try:
            validate_timeline(trial)
            self.timeline = trial
            self.changed()
            self.refresh()
        except Exception as exc:
            messagebox.showerror('الميم', str(exc), parent=self)

    def edit_short(self):
        if not self.ensure():
            return
        i = self.selected(self.short_tree)
        s = self.timeline['shorts'][i] if i is not None else {'start': 0, 'end': min(35, self.timeline['duration']), 'approved': False}
        def done(v):
            trial = copy.deepcopy(self.timeline)
            item = {'start': float(v['start']), 'end': float(v['end']), 'approved': v['approved'] == 'نعم', 'reason': 'اختيار يدوي'}
            if i is None:
                trial['shorts'].append(item)
            else:
                trial['shorts'][i] = item
            validate_timeline(trial)
            self.timeline = trial
            self.changed()
            self.refresh()
        self.dialog('نطاق Short ومعاينته', [('start', 'البداية', s['start']), ('end', 'النهاية', s['end']), ('approved', 'اعتماد للتصدير النهائي؟ نعم / لا', 'نعم' if s['approved'] else 'لا')], done)

    def remove_short(self):
        if self.ensure():
            i = self.selected(self.short_tree)
            if i is not None:
                self.timeline['shorts'].pop(i)
                self.changed()
                self.refresh()

    def caption_settings(self):
        if not self.ensure():
            return
        c = self.timeline['caption']
        def done(v):
            if v['style'] not in ('gaming', 'cinematic'):
                raise ValueError('النمط gaming أو cinematic')
            region = [float(x) for x in v['region'].split(',')]
            trial = copy.deepcopy(self.timeline)
            trial['caption'] = {'font': v['font'], 'style': v['style'], 'region': region, 'font_file': v['file'].strip()}
            if v['file'].strip():
                from PIL import ImageFont
                trial['caption']['font'] = ImageFont.truetype(v['file'].strip(), 24).getname()[0]
            validate_timeline(trial)
            self.timeline = trial
            self.changed()
        self.dialog('الترجمة العربية', [('font', 'اسم خط مثبت يدعم العربية', c['font']), ('file', 'ملف خط مثبت TTF / OTF (اختياري)', c.get('font_file', '')),
             ('style', 'gaming / cinematic', c['style']), ('region', 'منطقة الترجمة: x,y,width,height بين 0 و1', ','.join(map(str, c['region'])))], done)

    def music_settings(self):
        if not self.ensure():
            return
        file = filedialog.askopenfilename(parent=self, filetypes=[('موسيقى', '*.wav *.mp3 *.m4a *.flac *.ogg')])
        if not file:
            return
        def done(v):
            trial = copy.deepcopy(self.timeline)
            trial['music'] = {'path': file, 'license': v['license'], 'source': v['source'],
                              'usage_approved': v['approved'] == 'نعم', 'volume': float(v['volume']),
                              'fingerprint': fingerprint(file)}
            validate_timeline(trial)
            self.timeline = trial
            self.changed()
        self.dialog('موسيقى تحت صوتك — مرخصة فقط', [('license', 'الرخصة', ''), ('source', 'المصدر', ''),
             ('volume', 'المستوى من 0 إلى 0.12', .06), ('approved', 'اعتماد استخدام الموسيقى؟ اكتب نعم', 'لا')], done)

    def show_image(self, path):
        popup = tk.Toplevel(self)
        popup.title('معاينة الترجمة العربية')
        image = tk.PhotoImage(file=path)
        popup.image = image
        ttk.Label(popup, image=image).pack()

    def preview_asset(self):
        i = self.selected(self.asset_tree)
        if i is not None and Path(self.assets[i].get('thumbnail', '')).is_file():
            self.show_image(self.assets[i]['thumbnail'])

    def preview_comparison(self):
        paths = [self.output() / f'draft_{name}.png' for name in ('before', 'after')]
        if not all(p.is_file() for p in paths):
            messagebox.showinfo('المعاينة', 'أخرج مسودة أولًا.', parent=self)
            return
        popup = tk.Toplevel(self)
        popup.title('اللقطة قبل الإضافات وبعدها — شاهد الفيديو للمراجعة الكاملة')
        popup.images = []
        for path, label in zip(paths, ('قبل الإضافات', 'بعد الترجمة والميم المعتمد')):
            frame = ttk.Frame(popup, padding=6)
            frame.pack(side='right')
            ttk.Label(frame, text=label).pack()
            image = tk.PhotoImage(file=str(path))
            popup.images.append(image)
            ttk.Label(frame, image=image).pack()

    def preview_caption(self):
        if not self.ensure():
            return
        at = self.timeline['segments'][0]['start'] if self.timeline['segments'] else 0
        i = self.selected(self.segment_tree)
        if i is not None:
            at = self.segments[i]['start']
        data, output = copy.deepcopy(self.timeline), self.output() / 'caption_preview.png'
        self.job('معاينة الترجمة', lambda: caption_preview(data, output, at, cancel=self.cancel), self.show_image)

    def render_video(self, final):
        if not self.ensure():
            return
        timeline, output, encoder = copy.deepcopy(self.timeline), self.output(), 'nvenc' if self.nvenc.get() else 'cpu'
        def done(results):
            if not final and self.timeline and digest(self.timeline) == digest(timeline):
                self.draft_digest = digest(timeline)
            messagebox.showinfo('تم الإخراج', '\n'.join(r['path'] for r in results), parent=self)
        self.job('إخراج الفيديو — يمكنك الإلغاء', lambda: render(timeline, output, final=final, encoder=encoder, cancel=self.cancel, logger=self.log), done)

    def open_draft(self):
        path = self.output() / 'draft_video.mp4'
        if path.is_file():
            os.startfile(path)

    def approve(self):
        if not self.ensure():
            return
        if self.draft_digest != digest(self.timeline):
            messagebox.showinfo('المراجعة', 'أخرج مسودة حديثة وشاهدها أولًا.', parent=self)
            return
        if not messagebox.askyesno('اعتماد النسخة', 'هل شاهدت المسودة وراجعت التوقيت والحقوق والميمز ونطاقات Shorts؟\n\n' + '\n'.join(self.timeline['warnings']), parent=self):
            return
        try:
            approve(self.timeline, accept_warnings=True)
            save(self.timeline, self.output() / 'timeline.json')
            self.status.set('معتمد للتصدير المحلي — النشر يتطلب موافقة منفصلة')
        except Exception as exc:
            messagebox.showerror('المراجعة', str(exc), parent=self)

    def save_project(self):
        output = self.output()
        save({'version': '2.1', 'assets': self.assets}, output / 'manifest.json')
        save(self.segments, output / 'transcript.json')
        save({key: var.get() for key, var in self.paths.items()}, output / 'project.json')
        if self.timeline:
            save(self.timeline, output / 'timeline.json')
        self.status.set('حُفظ المشروع محليًا')

    def open_project(self):
        path = filedialog.askopenfilename(parent=self, filetypes=[('مشروع', 'project.json')])
        if not path:
            return
        self.load_project(path)

    def load_project(self, path):
        try:
            folder = Path(path).parent
            values = json.loads(Path(path).read_text(encoding='utf-8'))
            for key, var in self.paths.items():
                var.set(str(folder) if key == 'out' else values.get(key, ''))
            self.assets = json.loads((folder / 'manifest.json').read_text(encoding='utf-8'))['assets']
            self.segments = json.loads((folder / 'transcript.json').read_text(encoding='utf-8'))
            self.timeline = json.loads((folder / 'timeline.json').read_text(encoding='utf-8')) if (folder / 'timeline.json').exists() else None
            if self.timeline:self.timeline['music']=None
            self.memes_enabled.set(bool(self.timeline and self.timeline.get('memes_enabled')))
            self.changed()
            self.refresh()
        except Exception as exc:
            messagebox.showerror('فتح المشروع', str(exc), parent=self)
