"""Logical Arabic word editing and ASS timing without model-invented transcript."""
from copy import deepcopy


def validate_words(words,duration):
    if not isinstance(words,list) or len(words)>500:raise ValueError('عدد كلمات الترجمة غير صالح.')
    previous=0
    for w in words:
        if set(w)!= {'start','end','text'} or type(w['start'])is not int or type(w['end'])is not int or not previous<=w['start']<w['end']<=duration:
            raise ValueError('توقيت كلمة متداخل أو خارج مقطع الترجمة.')
        if not isinstance(w['text'],str) or not w['text'].strip() or len(w['text'])>200:raise ValueError('كلمة فارغة أو أكبر من الحد.')
        previous=w['end']


def canonical_words(clip,fps):
    if 'word_timing' in clip:return deepcopy(clip['word_timing'])
    original=clip.get('words',[])
    if ' '.join(w['text'].strip() for w in original)!=' '.join(clip['text'].split()):return []
    result=[]
    for word in original:
        a=max(0,round(word['start']*fps)-clip['start']);b=min(clip['duration'],round(word['end']*fps)-clip['start'])
        if b>a:result.append({'start':a,'end':b,'text':word['text']})
    validate_words(result,clip['duration']);return result


def caption_segments(track,fps):
    segments=[]
    for c in sorted(track['clips'],key=lambda c:c['start']):
        words=canonical_words(c,fps)
        if words and ' '.join(w['text'] for w in words)!=' '.join(c['text'].split()):words=[]
        segments.append({'start':c['start']/fps,'end':(c['start']+c['duration'])/fps,'text':c['text'],
                         'words':[{'start':(c['start']+w['start'])/fps,'end':(c['start']+w['end'])/fps,'text':w['text']} for w in words]})
    return segments


def update_word(session,key,index,text,start,end):
    track,clip=session.clip(key);session.editable(track)
    if track['kind']!='text':raise ValueError('اختر مقطع ترجمة.')
    words=canonical_words(clip,session.project['fps'])
    if not 0<=index<len(words):raise ValueError('لا توجد كلمة موقّتة بهذا المعرف؛ أضف توقيتًا يدويًا أولًا.')
    words[index]={'text':str(text).strip(),'start':int(start),'end':int(end)};validate_words(words,clip['duration'])
    session.properties(key,word_timing=words,text=' '.join(w['text'] for w in words))


def trim_words(clip,offset,duration):
    if 'word_timing' not in clip:return
    words=[]
    for w in clip['word_timing']:
        start=w['start']-offset;end=w['end']-offset
        if 0<=start<end<=duration:words.append({**w,'start':start,'end':end})
    clip['word_timing']=words
    if words:clip['text']=' '.join(w['text'] for w in words)
