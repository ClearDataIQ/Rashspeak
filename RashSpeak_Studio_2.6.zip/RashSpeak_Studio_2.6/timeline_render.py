"""Real FFmpeg timeline rendering. Final exports require a current review."""
import json
from pathlib import Path
import shutil
import tempfile
import hashlib

import captions
from media_tools import Cancelled, probe, run, thumbnail
from smart_editor import require_approval, save, validate_timeline


def codec(encoder):
    if encoder == 'nvenc':
        return ['-c:v', 'h264_nvenc', '-preset', 'p4', '-cq', '23']
    return ['-c:v', 'libx264', '-preset', 'veryfast', '-crf', '21', '-threads', '2']


def animation_source(asset, tmp):
    source = Path(asset['path'])
    if source.suffix.lower() == '.webp' and asset['kind'] == 'animation':
        from PIL import Image
        dest = tmp / f'animation_{asset["id"]}.gif'
        if dest.exists():
            return dest
        with Image.open(source) as image:
            frames, durations = [], []
            for i in range(image.n_frames):
                image.seek(i)
                image.load()
                frames.append(image.convert('RGBA').copy())
                durations.append(image.info.get('duration', 100))
            frames[0].save(dest, save_all=True, append_images=frames[1:], duration=durations, loop=0, disposal=2)
        return dest
    return source


def base_shot(shot, asset, output, size, frames, cancel, encoder):
    w, h = size
    command = ['ffmpeg', '-v', 'error', '-y']
    if asset is None:
        command += ['-f', 'lavfi', '-i', f'color=c=0x101b30:s={w}x{h}:r=30']
    elif asset['kind'] == 'image':
        command += ['-loop', '1', '-framerate', '30', '-i', asset['path']]
    else:
        source = animation_source(asset, Path(output).parent)
        command += ['-stream_loop', '-1', '-ss', str(shot.get('source_offset', 0)), '-i', source]
    vf = f'scale={w}:{h}:force_original_aspect_ratio=decrease,pad={w}:{h}:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=30'
    if asset and asset['kind'] == 'image':
        vf += f",zoompan=z='min(1.025,1+on*0.00015)':x='iw/2-iw/zoom/2':y='ih/2-ih/zoom/2':d=1:s={w}x{h}:fps=30"
    if shot.get('transition') == 'fade':
        vf += ',fade=t=in:st=0:d=0.15'
    run(command + ['-frames:v', str(frames), '-vf', vf, '-an', *codec(encoder), '-pix_fmt', 'yuv420p',
                   '-r', '30', '-video_track_timescale', '30000', output], cancel=cancel)


def slice_segments(segments, start, end):
    return [{**s, 'start': max(start, s['start']) - start, 'end': min(end, s['end']) - start}
            for s in segments if s['end'] > start and s['start'] < end]


def caption_font(caption, tmp):
    font = caption['font']
    if caption.get('font_file'):
        from PIL import ImageFont
        font_file = Path(caption['font_file'])
        font = ImageFont.truetype(str(font_file), 24).getname()[0]
        font_folder = tmp / 'fonts'
        font_folder.mkdir(exist_ok=True)
        shutil.copy2(font_file, font_folder / font_file.name)
        return font, ':fontsdir=fonts'
    return font, ''


def compose(clean, audio, timeline, output, tmp, start, end, size, portrait, encoder, cancel, logger):
    w, h = size
    seconds = end - start
    command = ['ffmpeg', '-v', 'error', '-y', '-ss', str(start), '-i', clean,
               '-ss', str(start), '-i', audio]
    filters = []
    if portrait:
        # Keep the full gameplay/HUD visible. Captions are reapplied at portrait size.
        filters += [f'[0:v]split[bg][fg]',
                    f'[bg]scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h},boxblur=20:3[back]',
                    f'[fg]scale={w}:{h}:force_original_aspect_ratio=decrease[front]',
                    '[back][front]overlay=(W-w)/2:(H-h)/2,setsar=1[v0]']
    else:
        filters.append('[0:v]setsar=1[v0]')
    current = 'v0'
    index = 2
    asset_map = {a['id']: a for a in timeline['assets']}
    for number, meme in enumerate(timeline['memes']):
        if not meme.get('approved') or meme['timestamp'] + meme['duration'] <= start or meme['timestamp'] >= end:
            continue
        asset = asset_map[meme['asset_id']]
        source = animation_source(asset, tmp)
        if asset['kind'] == 'image':
            command += ['-loop', '1', '-framerate', '30', '-i', source]
        else:
            elapsed = max(0, start - meme['timestamp'])
            command += ['-stream_loop', '-1', '-ss', str(elapsed), '-i', source]
        x, y, rw, rh = meme['region']
        mw, mh = max(2, int(rw * w) // 2 * 2), max(2, int(rh * h) // 2 * 2)
        at = max(0, meme['timestamp'] - start)
        stop = min(seconds, meme['timestamp'] + meme['duration'] - start)
        filters.append(f'[{index}:v]fps=30,scale={mw}:{mh}:force_original_aspect_ratio=decrease,format=rgba,setpts=PTS-STARTPTS+{at}/TB[m{number}]')
        next_label = f'ov{number}'
        filters.append(f'[{current}][m{number}]overlay=x={round(x*w)}:y={round(y*h)}:enable=\'gte(t,{at})*lt(t,{stop})\':eof_action=pass:repeatlast=0[{next_label}]')
        current = next_label
        index += 1
    caption = timeline['caption']
    if timeline['segments']:
        ass = tmp / 'captions.ass'
        font, fontsdir = caption_font(caption, tmp)
        region=caption.get('portrait_region',(.10,.70,.74,.12)) if portrait else caption['region']
        captions.write_ass(slice_segments(timeline['segments'], start, end), ass, size, font,
                           caption['style'], region)
        filters.append(f'[{current}]ass=captions.ass:shaping=complex{fontsdir},format=yuv420p[v]')
    else:
        filters.append(f'[{current}]format=yuv420p[v]')
    normal='' if timeline.get('audio_processed') else 'loudnorm=I=-16:TP=-1.5:LRA=11,'
    filters.append('[1:a]aformat=channel_layouts=stereo,'+normal+'aresample=48000,aformat=sample_fmts=fltp:channel_layouts=stereo[voice]')
    from sound_effects import filters as effect_filters
    effect_inputs,effect_graph=effect_filters(timeline.get('sound_effects',[]),start,end,first_index=index)
    command+=effect_inputs
    filters+=effect_graph
    command += ['-filter_complex_threads', '1', '-filter_complex', ';'.join(filters),
                '-map', '[v]', '-map', '[a]', '-t', str(seconds), *codec(encoder), '-pix_fmt', 'yuv420p',
                '-r', '30', '-c:a', 'aac', '-b:a', '192k', '-ar', '48000', '-movflags', '+faststart', output]
    logger('حرق الترجمة والميمز المعتمدة' + (' / عمودي' if portrait else ' / أفقي'))
    run(command, cwd=tmp, cancel=cancel, timeout=max(600, seconds * 40))


def check_video(path, size, expected):
    info = probe(path)
    video = next(s for s in info['streams'] if s['codec_type'] == 'video')
    if (video['width'], video['height']) != size or video['codec_name'] != 'h264':
        raise RuntimeError('أبعاد الفيديو أو الترميز لا تطابق الملف المطلوب.')
    if not any(s['codec_type'] == 'audio' and s['codec_name'] == 'aac' for s in info['streams']):
        raise RuntimeError('الفيديو لا يحتوي على الصوت AAC المطلوب.')
    if abs(float(info['format']['duration']) - expected) > .12:
        raise RuntimeError('مدة الفيديو لا تطابق الخط الزمني.')
    return {'path': str(path), 'size': list(size), 'duration': float(info['format']['duration']),
            'video': 'h264', 'audio': 'aac'}


def render(timeline, output, final=False, size=(1920, 1080), portrait_size=(1080, 1920),
           encoder='cpu', cancel=None, logger=print,cache_dir=None):
    validate_timeline(timeline)
    if final:
        require_approval(timeline)
    if any(len(s) != 2 or min(s) < 180 or any(x % 2 for x in s) for s in (size, portrait_size)):
        raise ValueError('الأبعاد يجب أن تكون زوجية وصالحة.')
    output = Path(output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    asset_map = {a['id']: a for a in timeline['assets']}
    results = []
    prefix = 'RashSpeak' if final else 'draft'
    cache=None
    if cache_dir:
        from smart_editor import fingerprint
        folder=Path(cache_dir);folder.mkdir(parents=True,exist_ok=True)
        signature=hashlib.sha256(json.dumps({'shots':timeline['shots'],'size':size,'encoder':encoder,
                    'assets':[{k:a.get(k) for k in ('id','path','fingerprint','kind')} for a in timeline['assets'] if a['role']=='clip']},sort_keys=True).encode()).hexdigest()
        cache=folder/(signature+'.mp4');meta=cache.with_suffix('.json')
        if cache.exists():
            try:
                expected=json.loads(meta.read_text())
                if expected['fingerprint']!=fingerprint(cache):cache=None
            except (OSError,ValueError,KeyError):cache=None
    with tempfile.TemporaryDirectory(prefix='rash_render_') as folder:
        tmp = Path(folder)
        pieces = []
        cached=cache is not None and cache.exists()
        for i, shot in enumerate([] if cached else timeline['shots']):
            logger(f'مشهد {i+1}/{len(timeline["shots"])} — {shot["reason"]}')
            dest = tmp / f'shot_{i:04}.mp4'
            frames = round(shot['end'] * 30) - round(shot['start'] * 30)
            if frames <= 0:
                continue
            base_shot(shot, asset_map.get(shot['asset_id']), dest, size, frames, cancel, encoder)
            pieces.append(dest)
        clean = tmp / 'clean.mp4'
        if cached:
            logger('إعادة استخدام تركيب اللقطات المعتمد؛ يُعاد تركيب الترجمة والمؤثرات فقط')
            shutil.copyfile(cache,clean)
        else:
            playlist = tmp / 'concat.txt'
            playlist.write_text(''.join(f"file '{p.name}'\n" for p in pieces), encoding='utf-8')
            run(['ffmpeg', '-v', 'error', '-y', '-f', 'concat', '-safe', '1', '-i', playlist,
                 '-c', 'copy', clean], cwd=tmp, cancel=cancel)
            if cache is not None:
                pending=cache.with_suffix('.pending.mp4');shutil.copyfile(clean,pending);pending.replace(cache)
                save({'fingerprint':fingerprint(cache)},meta)
        staged = tmp / 'main.mp4'
        compose(clean, timeline['audio'], timeline, staged, tmp, 0, timeline['duration'], size, False,
                encoder, cancel, logger)
        results.append(check_video(staged, size, timeline['duration']))
        main = output / f'{prefix}_video.mp4'
        # Atomic promotion: a failed/cancelled encode leaves any previous deliverable intact.
        pending = main.with_suffix('.pending.mp4')
        shutil.copyfile(staged, pending)
        pending.replace(main)
        results[-1]['path'] = str(main)
        for i, short in enumerate(timeline['shorts'], 1):
            if final and not short.get('approved'):
                continue
            staged = tmp / 'short.mp4'
            compose(clean, timeline['audio'], timeline, staged, tmp, short['start'], short['end'],
                    portrait_size, True, encoder, cancel, logger)
            results.append(check_video(staged, portrait_size, short['end'] - short['start']))
            dest = output / f'{prefix}_short_{i:02}.mp4'
            pending = dest.with_suffix('.pending.mp4')
            shutil.copyfile(staged, pending)
            pending.replace(dest)
            results[-1]['path'] = str(dest)
            captions.write_srt(slice_segments(timeline['segments'], short['start'], short['end']), output / f'{prefix}_short_{i:02}.srt')
        captions.write_srt(timeline['segments'], output / f'{prefix}_ar.srt')
        captions.write_ass(timeline['segments'], output / f'{prefix}_ar.ass', size,
                           timeline['caption']['font'], timeline['caption']['style'], timeline['caption']['region'])
        preview_at = next((m['timestamp'] + .3 for m in timeline['memes'] if m.get('approved')), min(1, timeline['duration'] / 2))
        thumbnail(clean, output / f'{prefix}_before.png', preview_at, cancel)
        thumbnail(main, output / f'{prefix}_after.png', preview_at, cancel)
    save(timeline, output / 'timeline.json')
    save({'version': '2.1', 'final': final, 'files': results}, output / 'render_report.json')
    return results


def caption_preview(timeline, output, at=0, size=(960, 540), cancel=None):
    """Preview corrected captions using the same libass renderer as export."""
    output = Path(output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='rash_caption_') as folder:
        tmp = Path(folder)
        end = min(timeline['duration'], at + .5)
        font, fontsdir = caption_font(timeline['caption'], tmp)
        captions.write_ass(slice_segments(timeline['segments'], at, end), tmp / 'captions.ass', size,
                           font, timeline['caption']['style'], timeline['caption']['region'])
        run(['ffmpeg', '-v', 'error', '-y', '-f', 'lavfi', '-i', f'color=c=0x101b30:s={size[0]}x{size[1]}:r=30',
             '-vf', 'ass=captions.ass:shaping=complex'+fontsdir, '-frames:v', '1', output], cwd=tmp, cancel=cancel)
    return str(output)
