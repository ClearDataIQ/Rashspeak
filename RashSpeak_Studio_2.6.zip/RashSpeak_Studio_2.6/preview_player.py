"""Decoded proxy video with optional sample-clocked PortAudio output. No Tk in workers."""
from pathlib import Path
import queue
import threading
import time
import wave

from media_tools import run


class AudioClock:
    def __init__(self,path,at):
        import sounddevice as sd
        self.sd=sd;self.source=wave.open(str(path),'rb');self.rate=self.source.getframerate();self.channels=self.source.getnchannels()
        self.source.setpos(min(self.source.getnframes(),round(at*self.rate)));self.played=0;self.latency=0.;self.lock=threading.Lock()
        self.dac_end=0.;self.wall=time.monotonic()
        def callback(outdata,frames,timing,status):
            data=self.source.readframes(frames);expected=frames*self.channels*2
            outdata[:]=data+b'\0'*(expected-len(data))
            with self.lock:
                self.played+=len(data)//(self.channels*2);self.dac_end=timing.outputBufferDacTime+len(data)/(self.channels*2*self.rate)
            if len(data)<expected:raise sd.CallbackStop
        self.stream=sd.RawOutputStream(samplerate=self.rate,channels=self.channels,dtype='int16',callback=callback,blocksize=1024)
        self.stream.start();self.latency=float(self.stream.latency)
    def elapsed(self):
        with self.lock:
            if not self.stream.active:return max(self.played/self.rate,time.monotonic()-self.wall)
            return max(0,self.played/self.rate-max(0,self.dac_end-self.stream.time))
    def close(self):
        self.stream.stop();self.stream.close();self.source.close()


class PreviewPlayer:
    def __init__(self,events,audio_factory=AudioClock):
        self.events=events;self.audio_factory=audio_factory;self.cancel=threading.Event();self.thread=None;self.running=False;self.token=0
        self.path=None;self.position=0.;self.audio_reason=''

    def start(self,path,at=0):
        self.stop();self.path=Path(path).resolve();self.position=max(0,float(at));self.cancel=threading.Event();self.token+=1
        token=self.token;cancel=self.cancel;events=self.events;audio_factory=self.audio_factory;file=self.path;start=self.position
        if not file.is_file() or file.suffix.lower()!='.mp4':raise ValueError('اختر Proxy MP4 محليًا.')
        self.running=True
        def work():
            audio=None;container=None
            try:
                import av
                wav=file.with_suffix('.preview.wav')
                if not wav.exists():
                    tmp=wav.with_suffix('.pending.wav')
                    run(['ffmpeg','-v','error','-y','-i',file,'-map','0:a:0','-ac','2','-ar','48000','-c:a','pcm_s16le',tmp],cancel=cancel)
                    tmp.replace(wav)
                container=av.open(str(file));stream=container.streams.video[0]
                container.seek(round(start/float(stream.time_base)),stream=stream,backward=True)
                try:audio=audio_factory(wav,start)
                except Exception:audio=None
                events.put(('player_status',{'token':token,'audio':audio is not None},None));wall=time.monotonic()
                for frame in container.decode(stream):
                    if cancel.is_set():break
                    seconds=float(frame.pts*frame.time_base) if frame.pts is not None else start
                    if seconds<start-.01:continue
                    while not cancel.is_set():
                        elapsed=audio.elapsed() if audio else time.monotonic()-wall
                        delay=seconds-start-elapsed
                        if delay<=0:break
                        cancel.wait(min(delay,.025))
                    if cancel.is_set():break
                    if elapsed-(seconds-start)>.15:continue
                    image=frame.to_image();image.thumbnail((700,380))
                    events.put(('player_frame',{'token':token,'seconds':seconds,'image':image},None))
                    self.position=seconds
                events.put(('player_end',{'token':token},None))
            except Exception as exc:
                if not cancel.is_set():events.put(('player_error',{'token':token,'message':'تعذرت المعاينة الداخلية؛ استخدم المشغل الخارجي.'},None))
            finally:
                if audio:
                    try:audio.close()
                    except Exception:pass
                if container:container.close()
                if self.token==token:self.running=False
        self.thread=threading.Thread(target=work,daemon=True);self.thread.start()

    def stop(self):
        self.cancel.set()
        if self.thread and self.thread.is_alive():self.thread.join(timeout=2)
        self.running=False;self.token+=1
