"""Persistent duplicate guard. Ambiguous failures stay blocked for manual review."""
import hashlib
import json
from pathlib import Path
import sqlite3
import time
from contextlib import closing


def guarded_submit(platform, account, media, operation, metadata=None, state_dir=None):
    if platform not in ('youtube', 'instagram', 'tiktok-inbox', 'tiktok-direct'):
        raise ValueError('Unsupported destination')
    if not account:
        raise RuntimeError('اربط الحساب وتحقق من هويته قبل الإرسال.')
    from publisher import STATE_DIR
    directory = Path(state_dir or STATE_DIR)
    directory.mkdir(parents=True, exist_ok=True)
    hasher = hashlib.sha256()
    path = Path(media) if not str(media).startswith('https://') else None
    if path is not None:
        with path.open('rb') as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b''):
                hasher.update(block)
    else:
        hasher.update(str(media).encode())
    # Content/account guard also blocks retries with changed captions after ambiguous failure.
    key = hashlib.sha256(f'{platform}:{account}:{hasher.hexdigest()}'.encode()).hexdigest()
    with closing(sqlite3.connect(directory / 'submissions.sqlite3', timeout=10)) as database, database:
        database.execute('CREATE TABLE IF NOT EXISTS submissions (key TEXT PRIMARY KEY, platform TEXT, status TEXT, updated REAL, result TEXT)')
        try:
            database.execute('INSERT INTO submissions VALUES (?,?,?,?,?)', (key, platform, 'uploading', time.time(), ''))
            database.commit()
        except sqlite3.IntegrityError:
            raise RuntimeError('هذا المحتوى أُرسل أو توجد محاولة غير محسومة. راجع المنصة وسجل الإرسال قبل أي إعادة رفع.')
        try:
            result = operation()
        except Exception:
            database.execute('UPDATE submissions SET status=?, updated=? WHERE key=?', ('unknown', time.time(), key))
            database.commit()
            raise
        database.execute('UPDATE submissions SET status=?, updated=?, result=? WHERE key=?', ('submitted', time.time(), str(result)[:160], key))
        database.commit()
    return result
