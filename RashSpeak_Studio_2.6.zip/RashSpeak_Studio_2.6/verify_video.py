"""Acceptance runner for an authorized local video; no network downloader or ASR fixtures."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

import captions
from app_paths import app_dir
from media_tools import duration, run
from production import produce
from pro_project import load_project
from pro_render import package
from smart_editor import fingerprint, save


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as file:
        for chunk in iter(lambda: file.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def extract_audio(video, output):
    video, output = Path(video).resolve(), Path(output).resolve()
    if not video.is_file() or video.suffix.lower() not in ('.mp4', '.mov', '.mkv', '.webm', '.m4v', '.avi'):
        raise ValueError('اختر ملف فيديو محليًا مسموحًا لك باستخدامه.')
    if video.stat().st_size > 2 * 1024**3 or duration(video, 'audio') > 7200:
        raise ValueError('حد اختبار الفيديو ساعتان و2GB.')
    if output.exists() or output.suffix.lower() != '.wav' or output == video:
        raise ValueError('استخدم ملف WAV جديدًا؛ لا نستبدل الأصل أو اختبارًا سابقًا.')
    before = sha256(video)
    output.parent.mkdir(parents=True, exist_ok=True)
    try:
        run(['ffmpeg', '-v', 'error', '-nostdin', '-n', '-i', video,
             '-map', '0:a:0', '-vn', '-ac', '1', '-ar', '48000', '-c:a', 'pcm_s24le', output], timeout=1800)
        if sha256(video) != before:
            raise ValueError('تغيّر مصدر الفيديو أثناء الاستخراج.')
        return {'source_sha256': before, 'audio_sha256': sha256(output),
                'duration': duration(output, 'audio'), 'source_preserved': True}
    except BaseException:
        output.unlink(missing_ok=True)
        raise


def verify(video, output, script=None, model=None, online=False, on_review=None, on_event=None):
    root = Path(output).resolve()
    if root.exists():
        raise ValueError('اختر مجلد اختبار جديدًا حتى تبقى النتائج السابقة محفوظة.')
    root.mkdir(parents=True)
    report = {'status': 'extracting', 'asr': 'not_run', 'synthetic_asr': False,
              'owner_review': bool(on_review), 'warnings': []}
    save(report, root / 'verification.json')
    try:
        audio = root / 'Original_Audio' / 'extracted_original.wav'
        report.update(extract_audio(video, audio), status='audio_extracted')
        save(report, root / 'verification.json')
        model = Path(model or app_dir() / 'models' / 'small').resolve()
        if not all((model / name).is_file() for name in ('model.bin', 'config.json', 'tokenizer.json')):
            raise ValueError('أوزان Whisper المحلية غير متاحة؛ لم يُجرَ التفريغ أو المونتاج.')
        project = root / 'Project'
        if script is None:
            detailed = captions.transcribe(audio, model, return_words=True)
            report['asr'] = 'local_whisper'
            script = '\n'.join(row['text'] for row in detailed['segments'])
            project.mkdir()
            # Cache only the result actually inferred above, using the engine's input identity.
            identity = {'audio': str(audio), 'fingerprint': fingerprint(audio),
                        'script_sha256': hashlib.sha256(script.encode()).hexdigest()}
            save({'input': identity, 'result': detailed, 'source': 'local_whisper'}, project / 'asr_cache.json')
            report['script_source'] = 'actual_asr_transcript'
            report['warnings'].append('السكربت مشتق من التفريغ؛ ليس مرجعًا مستقلاً لقياس دقة الكلمات أو اكتشاف الإعادات. راجعه قبل اعتماد القص.')
        else:
            report['script_source'] = 'owner_supplied'
        report['status'] = 'producing'
        save(report, root / 'verification.json')
        result = produce(audio, script, project, online=online, model=model,
                         on_review=on_review, on_event=on_event)
        report['asr'] = result['asr_source']
        verified = []
        for item in result['files']:
            # Decode every frame/sample, not just the container header.
            run(['ffmpeg', '-v', 'error', '-xerror', '-i', item['path'], '-f', 'null', '-'], timeout=3600)
            verified.append({'kind': item['kind'], 'duration': duration(item['path']),
                             'sha256': sha256(item['path']), 'decoded': True})
        if sha256(video) != report['source_sha256'] or sha256(audio) != report['audio_sha256']:
            raise ValueError('تغيّر أصل خلال الاختبار؛ لا تُقبل النتيجة.')
        document = load_project(result['pro_project'])
        bundle = package(document, root / 'RashSpeak_Project', result['files'])
        report.update(status='completed', outputs=verified, project=result['pro_project'],
                      zip=bundle['zip'], original_preserved=True,
                      warnings=report['warnings'] + result['warnings'])
        if not on_review:
            report['warnings'].append('اختبار Batch دون اعتماد المالك؛ يجب مراجعة النتائج قبل النشر.')
        save(report, root / 'verification.json')
        return report
    except Exception as exc:
        report.update(status='blocked_or_failed', error_type=type(exc).__name__)
        state_path = root / 'Project' / 'production.json'
        if state_path.is_file():
            state = json.loads(state_path.read_text(encoding='utf-8'))
            if state.get('asr_source') in ('local_whisper', 'local_whisper_cache'):
                report['asr'] = state['asr_source']
        # Store actionable local validation errors only; never dump a remote response or credentials.
        if isinstance(exc, ValueError):
            report['reason'] = str(exc)
        save(report, root / 'verification.json')
        raise


def terminal_review(request):
    print('\n' + request['label'])
    for item in request['previews']:
        print(item['label'] + ': ' + item['path'])
    pending = Path(request['work']) / 'reviews' / f"{request['key']}_pending.json"
    print('بيانات المراجعة:', pending)
    if request['error']:
        print(request['error'])
    while True:
        answer = input('[a] اعتماد / [e] تطبيق تعديلات JSON وإعادة المعاينة / [q] توقف: ').strip().lower()
        if answer == 'a' and not request['error']:
            return {'action': 'approve'}
        if answer == 'e':
            return {'action': 'revise', 'data': json.loads(pending.read_text(encoding='utf-8'))['data']}
        if answer == 'q':
            return {'action': 'cancel'}


def main():
    parser = argparse.ArgumentParser(description='اختبار فعلي من فيديو محلي مع حفظ الأصل والتفريغ والمونتاج وفك ترميز الصادرات.')
    parser.add_argument('--video', required=True, help='ملف محلي مصرح به؛ لا رابط إنترنت')
    parser.add_argument('--out', required=True, help='مجلد جديد للنتائج')
    parser.add_argument('--script', help='سكربت UTF-8 اختياري؛ بدونه تستخدم الكلمات المتعرف عليها مع تحذير')
    parser.add_argument('--model', help='مجلد نموذج Whisper محلي')
    parser.add_argument('--online', action='store_true', help='البحث عن وسائط مرخصة بدل بطاقات موضوع معلنة')
    parser.add_argument('--batch-test', action='store_true', help='تجاوز مراجعات المالك للاختبار فقط؛ يبقى التقرير دون اعتماد')
    args = parser.parse_args()
    if not args.batch_test and not sys.stdin.isatty():
        parser.error('استخدم طرفية تفاعلية للمراجعات أو --batch-test صراحةً للاختبار.')
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    script = Path(args.script).read_text(encoding='utf-8-sig') if args.script else None
    def event(item):
        if item['type'] == 'stage':
            print(item['detail'], flush=True)
    try:
        report = verify(args.video, args.out, script, args.model, args.online,
                        None if args.batch_test else terminal_review, event)
    except Exception:
        print('تعذر إكمال الاختبار؛ انظر verification.json. لم نختلق تفريغًا أو نتيجة.', file=sys.stderr)
        return 1
    print('النتائج:', report['zip'])
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
