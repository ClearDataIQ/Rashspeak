"""Headless export of exactly the same document used by the desktop editor."""
import argparse
from pathlib import Path
from pro_project import Session,load_project,sequence
from pro_render import render,package


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--project',required=True)
    parser.add_argument('--out',required=True,help='New export directory')
    parser.add_argument('--all',action='store_true',help='Export all linked sequences')
    parser.add_argument('--codec',choices=('h264','h265'),default='h264')
    parser.add_argument('--crf',type=int,default=21)
    parser.add_argument('--encoder',choices=('cpu','nvenc'),default='cpu')
    parser.add_argument('--bitrate',type=int,help='Video bitrate in bits/sec, 1000000..100000000')
    parser.add_argument('--size',help='Override resolution, e.g. 1920x1080 (active sequence only)')
    parser.add_argument('--package',action='store_true')
    args=parser.parse_args();p=load_project(args.project);output=Path(args.out).resolve();output.mkdir(parents=True,exist_ok=True)
    size=tuple(map(int,args.size.lower().split('x'))) if args.size else None
    if args.all and size:parser.error('--size is only for an active sequence; each Short has its own resolution.')
    sequences=p['sequences'] if args.all else [sequence(p)];results=[]
    for i,s in enumerate(sequences):
        portrait=s['height']>s['width'];name=f'{i+1:02}_'+('short.mp4' if portrait else 'long.mp4')
        result=render(p,output/name,s['id'],size=size,codec=args.codec,crf=args.crf,encoder=args.encoder,bitrate=args.bitrate,on_progress=lambda n:print(f'{n}%',flush=True))
        result.update(sequence=s['id'],portrait=portrait);results.append(result)
    if args.package:print(package(p,output/'RashSpeak_Project',results)['zip'])
    else:
        for r in results:print(r['path'])


if __name__=='__main__':main()
