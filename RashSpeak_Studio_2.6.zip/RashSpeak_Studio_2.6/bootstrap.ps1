param([switch]$Install, [switch]$Launch, [switch]$Subtitles, [switch]$Check, [switch]$Model, [switch]$Demo, [switch]$NewsModel, [switch]$MediaSources)
$ErrorActionPreference = 'Stop'
$env:PYTHONUTF8 = '1'
Set-Location -LiteralPath $PSScriptRoot
$pythonCandidates = @()
foreach ($name in @('python', 'python3')) {
    $command = Get-Command $name -ErrorAction SilentlyContinue
    if ($command) { $pythonCandidates += $command.Source }
}
$pythonCandidates += @(Get-ChildItem -Path "$env:LOCALAPPDATA/Programs/Python/Python*/python.exe" -File -ErrorAction SilentlyContinue | Sort-Object FullName -Descending | ForEach-Object FullName)
$pythonExe = $null
foreach ($candidate in ($pythonCandidates | Select-Object -Unique)) {
    if ($candidate -like '*WindowsApps*') { continue }
    & $candidate -c "import sys, tkinter; sys.exit(0 if sys.version_info >= (3,11) else 1)" 2>$null
    if ($LASTEXITCODE -eq 0) { $pythonExe = $candidate; break }
}
if (-not $pythonExe) { throw 'Python 3.11+ with tkinter was not found. Install Python from python.org, then retry.' }
$venvPython = Join-Path $PSScriptRoot '.venv/Scripts/python.exe'
if ($Check) {
    Write-Host "Python found: $pythonExe"
    & $pythonExe -c "import sys, tkinter; print(sys.version)"
    exit $LASTEXITCODE
}
if (-not (Test-Path -LiteralPath $venvPython)) {
    & $pythonExe -m venv .venv
    if ($LASTEXITCODE -ne 0) { throw 'Could not create the private Python environment.' }
    $Install = $true
}
$rashHashAlgorithm = [System.Security.Cryptography.SHA256]::Create()
try {
    $rashDependencyBytes = [System.IO.File]::ReadAllBytes((Join-Path $PSScriptRoot 'requirements.txt'))
    $dependencyHash = [System.BitConverter]::ToString($rashHashAlgorithm.ComputeHash($rashDependencyBytes)).Replace('-', '')
} finally { $rashHashAlgorithm.Dispose() }
$readyPath = Join-Path $PSScriptRoot '.venv/rash-ready.txt'
$readyHash = if (Test-Path -LiteralPath $readyPath) { (Get-Content -LiteralPath $readyPath -Raw).Trim() } else { '' }
if ($dependencyHash -ne $readyHash) { $Install = $true }
if ($Install) {
    & $venvPython -m pip install -r requirements.txt
    if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed. Check Internet access and retry INSTALL_WINDOWS.bat.' }
    Set-Content -LiteralPath $readyPath -Value $dependencyHash -Encoding ascii
}
$asrReadyPath = Join-Path $PSScriptRoot '.venv/rash-asr-ready.txt'
$asrHash = (Get-FileHash -LiteralPath (Join-Path $PSScriptRoot 'requirements-asr.txt') -Algorithm SHA256).Hash
$asrReadyHash = if (Test-Path -LiteralPath $asrReadyPath) { (Get-Content -LiteralPath $asrReadyPath -Raw).Trim() } else { '' }
if ($Subtitles -or ($Launch -and $asrHash -ne $asrReadyHash)) {
    & $venvPython -m pip install -r requirements-asr.txt
    if ($LASTEXITCODE -ne 0) { throw 'Optional speech recognition installation failed.' }
    Set-Content -LiteralPath $asrReadyPath -Value $asrHash -Encoding ascii
}
if ($Model) {
    & $venvPython download_model.py --model small
    if ($LASTEXITCODE -ne 0) { throw 'Model download failed. You can still import SRT and edit offline.' }
}
if ($NewsModel) {
    & $venvPython -m pip install -r requirements-news-build.txt
    if ($LASTEXITCODE -ne 0) { throw 'News libraries installation failed.' }
    & $venvPython setup_news_translation.py
    if ($LASTEXITCODE -ne 0) { throw 'News translation model download failed.' }
}
if ($MediaSources) {
    & $venvPython -m pip install -r requirements-media.txt
    if ($LASTEXITCODE -ne 0) { throw 'Optional media source libraries installation failed.' }
}
if ($Demo) {
    $demoProject = Join-Path $PSScriptRoot 'output/demo/project.json'
    if (-not (Test-Path -LiteralPath $demoProject)) {
        & $venvPython demo.py --out output/demo
        if ($LASTEXITCODE -ne 0) { throw 'Demo generation failed. Check FFmpeg/ffprobe.' }
    }
    & $venvPython gui.py --project $demoProject
    if ($LASTEXITCODE -ne 0) { throw 'Application failed.' }
}
if ($Launch) {
    & $venvPython gui.py
    if ($LASTEXITCODE -ne 0) { throw 'Application failed. See the error above.' }
}
