@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0bootstrap.ps1" -NewsModel
if errorlevel 1 echo Setup failed. Check the error above.
pause
