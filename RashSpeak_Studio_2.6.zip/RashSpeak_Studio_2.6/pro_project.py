"""Frame-based non-destructive project model. No command writes source media."""
from copy import deepcopy
import hashlib
import json
import math
import os
from pathlib import Path
import uuid

from media_tools import probe
from smart_editor import fingerprint, save

SCHEMA = 'rashspeak.multitrack/1'
KINDS = {'video', 'image', 'audio', 'text', 'effect'}


def uid():
    return uuid.uuid4().hex[:16]


def frames(seconds, fps):
    return round(float(seconds) * fps)


def media_matches(asset):
    path = Path(asset['path'])
    if not path.is_file(): return False
    if asset.get('sha256'):
        digest = hashlib.sha256()
        with path.open('rb') as stream:
            for block in iter(lambda: stream.read(1024*1024), b''): digest.update(block)
        return digest.hexdigest() == asset['sha256']
    return fingerprint(path) == asset['fingerprint']


def new_project(name='RashSpeak', fps=30, size=(1920, 1080)):
    sequence = {'id': uid(), 'name': 'المقطع الطويل', 'width': size[0], 'height': size[1], 'tracks': [], 'source_range': None}
    return {'schema': SCHEMA, 'id': uid(), 'name': name, 'fps': fps, 'media': [], 'sequences': [sequence],
            'active_sequence': sequence['id'], 'provenance': {}, 'revision': 0}


def sequence(project, key=None):
    return next(s for s in project['sequences'] if s['id'] == (key or project['active_sequence']))


def length(seq):
    return max((c['start'] + c['duration'] for t in seq['tracks'] for c in t['clips']), default=1)


def edit_digest(project):
    data=deepcopy(project)
    data.pop('active_sequence',None);data.pop('revision',None)
    return hashlib.sha256(json.dumps(data,sort_keys=True,ensure_ascii=False).encode()).hexdigest()


def new_track(kind, name=None):
    if kind not in KINDS: raise ValueError('نوع المسار غير صالح.')
    return {'id': uid(), 'name': name or kind, 'kind': kind, 'locked': False, 'hidden': False,
            'muted': False, 'gain_db': 0., 'clips': []}


def new_clip(media_id=None, start=0, duration=30, source_in=0, text='', **extra):
    return {'id': uid(), 'media_id': media_id, 'start': start, 'duration': duration, 'in': source_in,
            'text': text, 'group': None, 'loop': False, 'gain_db': 0., 'fade_in': 0, 'fade_out': 0,
            'transform': {'x': 0., 'y': 0., 'scale': 1., 'opacity': 1.}, **extra}


def curve_value(clip, prop, frame):
    keys=clip.get('keyframes',{}).get(prop,[])
    if not keys:return clip['transform'][prop]
    points=keys if keys[0]['frame']==0 else [{'frame':0,'value':clip['transform'][prop],'easing':'linear'},*keys]
    for left,right in zip(points,points[1:]):
        if frame<=right['frame']:
            u=max(0,min(1,(frame-left['frame'])/(right['frame']-left['frame'])))
            if 'u_start' in right:
                u=right['u_start']+(right['u_end']-right['u_start'])*u
                easing=right['source_easing'];a=right['source_left'];b=right['source_right']
            else:easing=right['easing'];a=left['value'];b=right['value']
            if easing=='ease_in':u=u*u
            elif easing=='ease_out':u=1-(1-u)*(1-u)
            return a+(b-a)*u
    return points[-1]['value']


def retime_animation(clip, offset, duration):
    from pro_subtitles import trim_words
    trim_words(clip,offset,duration)
    if duration>0 and clip.get('volume_automation'):
        keys=clip['volume_automation'];points=keys if keys[0]['frame']==0 else [{'frame':0,'gain_db':0},*keys]
        def sample(at):
            for a,b in zip(points,points[1:]):
                if at<=b['frame']:
                    u=max(0,min(1,(at-a['frame'])/(b['frame']-a['frame'])));return a['gain_db']+(b['gain_db']-a['gain_db'])*u
            return points[-1]['gain_db']
        times=sorted({0,duration-1,*[k['frame']-offset for k in keys if 0<k['frame']-offset<duration-1]})
        clip['volume_automation']=[{'frame':at,'gain_db':sample(at+offset)} for at in times]
    for prop,keys in list(clip.get('keyframes',{}).items()):
        if not keys:continue
        if duration<=0:continue
        points=deepcopy(keys if keys[0]['frame']==0 else [{'frame':0,'value':clip['transform'][prop],'easing':'linear'},*keys])
        times=sorted({0,duration-1,*[k['frame']-offset for k in keys if 0<k['frame']-offset<duration-1]})
        result=[]
        for i,at in enumerate(times):
            item={'frame':at,'value':curve_value(clip,prop,at+offset),'easing':'linear'}
            if i:
                begin=times[i-1]+offset;end=at+offset;mid=(begin+end)/2
                for left,right in zip(points,points[1:]):
                    if left['frame']<=mid<=right['frame']:
                        a=(begin-left['frame'])/(right['frame']-left['frame']);b=(end-left['frame'])/(right['frame']-left['frame'])
                        u0=right.get('u_start',0);u1=right.get('u_end',1)
                        item.update(u_start=u0+(u1-u0)*a,u_end=u0+(u1-u0)*b,source_left=right.get('source_left',left['value']),
                                    source_right=right.get('source_right',right['value']),source_easing=right.get('source_easing',right['easing']))
                        break
            result.append(item)
        clip['keyframes'][prop]=result;clip['transform'][prop]=result[0]['value']


def import_media(path, rights='owned', source='local owner', approved=True):
    path = Path(path).resolve()
    if not path.is_file() or path.stat().st_size > 20 * 1024**3: raise ValueError('ملف غير موجود أو أكبر من 20GB.')
    if path.suffix.lower() not in {'.mp4','.mov','.mkv','.webm','.avi','.m4v','.wav','.mp3','.m4a','.aac','.flac','.ogg','.png','.jpg','.jpeg','.gif','.webp'}:
        raise ValueError('صيغة وسائط غير مدعومة.')
    info = probe(path); streams = info.get('streams', [])
    video = next((s for s in streams if s['codec_type'] == 'video'), None)
    if video and (min(int(video.get('width',0)),int(video.get('height',0)))<=0 or max(int(video.get('width',0)),int(video.get('height',0)))>8192):
        raise ValueError('أبعاد المصدر غير صالحة أو تتجاوز 8192؛ جهّز نسخة مناسبة قبل الاستيراد.')
    audio = any(s['codec_type'] == 'audio' for s in streams)
    still = path.suffix.lower() in {'.png','.jpg','.jpeg'}
    if path.suffix.lower() in {'.gif','.webp'}:
        from PIL import Image
        with Image.open(path) as image: still = getattr(image, 'n_frames', 1) == 1
    kind = 'image' if still else 'video' if video else 'audio' if audio else None
    seconds = float(info.get('format', {}).get('duration') or 0)
    if kind is None or (kind != 'image' and not 0 < seconds <= 86400): raise ValueError('لا توجد وسائط صالحة في الملف.')
    return {'id': uid(), 'path': str(path), 'kind': kind, 'duration': seconds, 'has_audio': audio,
            'width':int(video.get('width',0)) if video else 0,'height':int(video.get('height',0)) if video else 0,
            'fingerprint': fingerprint(path), 'license': rights, 'source': source, 'usage_approved': bool(approved)}


def validate(project, files=False):
    if project.get('schema') != SCHEMA: raise ValueError('صيغة مشروع غير مدعومة؛ افتح timeline.json القديم للاستيراد.')
    fps = project.get('fps')
    if type(fps) is not int or fps not in (24,25,30,50,60): raise ValueError('معدل الإطارات غير صالح.')
    assets = {a['id']: a for a in project['media']}
    if len(assets) != len(project['media']): raise ValueError('معرف وسيط مكرر.')
    ids = set(assets)
    def register(key):
        if not isinstance(key,str) or not key or key in ids: raise ValueError('معرف عنصر مكرر أو فارغ.')
        ids.add(key)
    def number(value, lower, upper):
        if isinstance(value, bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or not lower <= value <= upper:
            raise ValueError('قيمة رقمية خارج النطاق.')
    for a in assets.values():
        if a['kind'] not in ('audio','video','image'): raise ValueError('نوع وسيط غير صالح.')
        number(a['duration'],0,86400)
        if files:
            p = Path(a['path'])
            if not media_matches(a): raise ValueError('أصل مفقود أو تغير: '+str(p))
    for s in project['sequences']:
        register(s['id'])
        for k in ('width','height'):
            v = s[k]
            if type(v) is not int or not 180 <= v <= 4096 or v % 2: raise ValueError('الأبعاد يجب أن تكون زوجية بين 180 و4096.')
        for t in s['tracks']:
            register(t['id'])
            if t['kind'] not in KINDS: raise ValueError('نوع مسار غير صالح.')
            for k in ('locked','hidden','muted'):
                if type(t[k]) is not bool: raise ValueError('حالة المسار غير صالحة.')
            number(t['gain_db'],-60,12)
            from pro_effects import validate_audio,validate_color,validate_mask,validate_automation
            validate_audio(t.get('processing',{}));validate_automation(t.get('volume_automation',[]),length(s))
            caption=t.get('caption',{})
            if 'font_size' in caption:number(caption['font_size'],16,160)
            if 'outline' in caption:number(caption['outline'],0,10)
            if 'highlight' in caption and type(caption['highlight'])is not bool:raise ValueError('حالة Highlight غير صالحة.')
            for c in t['clips']:
                register(c['id'])
                for k in ('start','duration','in','fade_in','fade_out'):
                    if type(c[k]) is not int or c[k] < (1 if k == 'duration' else 0): raise ValueError('القص والتوقيت يجب أن يكونا بالإطارات الصحيحة.')
                if c['start'] + c['duration'] > fps*7200: raise ValueError('مدة المشروع القصوى ساعتان.')
                if c['fade_in'] > c['duration'] or c['fade_out'] > c['duration']: raise ValueError('مدة التلاشي أطول من المقطع.')
                number(c['gain_db'],-60,12)
                rate=c.get('rate',1.);number(rate,.25,4)
                if type(c.get('reverse',False))is not bool:raise ValueError('حالة Reverse غير صالحة.')
                tr = c['transform']
                for k in ('x','y'): number(tr[k],-2,2)
                number(tr['scale'],.05,4); number(tr['opacity'],0,1)
                number(tr.get('rotation',0),-180,180)
                validate_audio(c.get('processing',{}));validate_color(c.get('color',{}));validate_automation(c.get('volume_automation',[]),c['duration'])
                if c.get('mask') is not None:validate_mask(c['mask'])
                if c.get('fit','contain') not in ('contain','cover'):raise ValueError('طريقة ملاءمة الإطار غير صالحة.')
                crop=c.get('crop',{'left':0.,'top':0.,'right':0.,'bottom':0.})
                for k in ('left','top','right','bottom'):number(crop[k],0,.95)
                if crop['left']+crop['right']>=.95 or crop['top']+crop['bottom']>=.95:raise ValueError('يجب إبقاء جزء ظاهر من الصورة بعد Crop.')
                for prop,keys in c.get('keyframes',{}).items():
                    bounds={'x':(-2,2),'y':(-2,2),'scale':(.05,4),'opacity':(0,1)}
                    if prop not in bounds:raise ValueError('خاصية Keyframe غير مدعومة.')
                    previous=-1
                    for key in keys:
                        if type(key['frame'])is not int or not previous<key['frame']<c['duration']:raise ValueError('توقيت Keyframe متكرر أو خارج المقطع.')
                        number(key['value'],*bounds[prop]);previous=key['frame']
                        if key['easing'] not in ('linear','ease_in','ease_out'):raise ValueError('منحنى حركة غير صالح.')
                        if 'u_start' in key:
                            number(key['u_start'],0,1);number(key['u_end'],0,1)
                            if key['u_end']<=key['u_start'] or key['source_easing'] not in ('linear','ease_in','ease_out'):raise ValueError('جزء منحنى غير صالح.')
                            number(key['source_left'],*bounds[prop]);number(key['source_right'],*bounds[prop])
                if t['kind'] == 'text':
                    if c['media_id'] is not None or not str(c['text']).strip(): raise ValueError('نص فارغ أو مرجع غير صالح.')
                    from pro_subtitles import validate_words
                    validate_words(c.get('word_timing',[]),c['duration'])
                else:
                    a = assets.get(c['media_id'])
                    if a is None: raise ValueError('مرجع وسيط غير موجود.')
                    expected = ('audio','video') if t['kind'] in ('audio','effect') else ('image',) if t['kind']=='image' else ('video','image')
                    if a['kind'] not in expected: raise ValueError('الوسيط لا يطابق نوع المسار.')
                    if (rate!=1 or c.get('reverse')) and (t['kind'] not in ('video','image') or a['kind']!='video'):
                        raise ValueError('تغيير السرعة والاتجاه هنا للقطات الفيديو فقط؛ التعليق محفوظ بترتيبه.')
                    if c.get('reverse') and c['duration']*rate>fps*10:raise ValueError('Reverse محدود بعشر ثوانٍ من المصدر لضبط الذاكرة.')
                    if t['kind'] in ('audio','effect') and a['kind']=='video' and not a.get('has_audio'):raise ValueError('الفيديو لا يحتوي على صوت.')
                    if a['kind'] != 'image':
                        if c['in'] >= math.ceil(a['duration']*fps): raise ValueError('بداية المصدر خارج مدته.')
                        if not c['loop'] and c['in'] + math.ceil(c['duration']*rate) > math.ceil(a['duration']*fps): raise ValueError('القص يتجاوز المصدر؛ عدّل المدة.')
    if project['active_sequence'] not in [s['id'] for s in project['sequences']]: raise ValueError('التسلسل النشط مفقود.')
    return project


def write_project(project, path):
    validate(project)
    path = Path(path).resolve(); data = deepcopy(project)
    # Relative paths preserve portability; external originals stay absolute.
    for a in data['media']:
        try: a['path'] = os.path.relpath(Path(a['path']).resolve(), path.parent)
        except ValueError: pass
    for key in ('script','audio_edit_decisions','legacy_timeline'):
        value=data['provenance'].get(key)
        if value:
            try:data['provenance'][key]=os.path.relpath(Path(value).resolve(),path.parent)
            except ValueError:pass
    for s in data['sequences']:
        for t in s['tracks']:
            font=t.get('caption',{}).get('font_file')
            if font:
                try:t['caption']['font_file']=os.path.relpath(Path(font).resolve(),path.parent)
                except ValueError:pass
    save(data, path)
    return str(path)


def load_project(path):
    path = Path(path).resolve()
    data = json.loads(path.read_text(encoding='utf-8-sig'))
    if data.get('schema') != SCHEMA:
        if 'shots' in data: return from_legacy(data, origin=str(path))
        legacy = path.parent/'timeline.json'
        if legacy.is_file() and legacy != path: return load_project(legacy)
        raise ValueError('هذا ليس مشروع Pro Editor أو Timeline قابلاً للاستيراد.')
    for a in data['media']:
        p = Path(a['path'])
        if not p.is_absolute(): a['path'] = str((path.parent/p).resolve())
    for key in ('script','audio_edit_decisions','legacy_timeline'):
        value=data['provenance'].get(key)
        if value and not Path(value).is_absolute():data['provenance'][key]=str((path.parent/value).resolve())
    for s in data['sequences']:
        for t in s['tracks']:
            font=t.get('caption',{}).get('font_file')
            if font and not Path(font).is_absolute():t['caption']['font_file']=str((path.parent/font).resolve())
    return validate(data)


class Session:
    """Validated transactions; failed edits leave both document and history intact."""
    def __init__(self, project, path=None):
        self.project = deepcopy(validate(project)); self.path = Path(path).resolve() if path else None
        self.undo_stack = []; self.redo_stack = []; self.clipboard = []; self.dirty = False
        self.revision_clock=self.project['revision']

    @property
    def seq(self): return sequence(self.project)

    def track(self, key): return next(t for t in self.seq['tracks'] if t['id'] == key)

    def clip(self, key):
        for t in self.seq['tracks']:
            for c in t['clips']:
                if c['id'] == key: return t,c
        raise ValueError('المقطع غير موجود.')

    def editable(self, track):
        if track['locked']: raise ValueError('المسار مقفل.')

    def edit(self, label, change):
        before = deepcopy(self.project)
        try:
            result = change(); validate(self.project)
            if before == self.project: return result
            self.revision_clock=max(self.revision_clock,self.project['revision'])+1
            self.project['revision']=self.revision_clock
            self.autosave()
        except Exception:
            self.project = before; raise
        self.undo_stack.append((label,before)); self.undo_stack = self.undo_stack[-100:]
        self.redo_stack.clear(); self.dirty = True
        return result

    def autosave(self):
        if self.path: write_project(self.project,self.path.with_suffix('.autosave.json'))

    def save(self, path=None):
        target = Path(path).resolve() if path else self.path
        if target is None: raise ValueError('اختر اسم ملف للمشروع.')
        write_project(self.project,target); self.path=target; self.dirty=False
        self.autosave(); return str(target)

    def undo(self):
        if not self.undo_stack: return False
        label, target = self.undo_stack[-1]; old=self.project
        self.project=deepcopy(target)
        try: self.autosave()
        except Exception: self.project=old;raise
        self.undo_stack.pop();self.redo_stack.append((label,old));self.dirty=True;return True

    def redo(self):
        if not self.redo_stack:return False
        label,target=self.redo_stack[-1];old=self.project
        self.project=deepcopy(target)
        try:self.autosave()
        except Exception:self.project=old;raise
        self.redo_stack.pop();self.undo_stack.append((label,old));self.dirty=True;return True

    def add_track(self,kind,name=None):
        t=new_track(kind,name)
        self.edit('إضافة مسار',lambda:self.seq['tracks'].append(t));return t['id']

    def track_state(self,key,**changes):
        if set(changes)-{'locked','hidden','muted','gain_db','name','processing','volume_automation'}:raise ValueError('خاصية مسار غير معروفة.')
        self.edit('خصائص المسار',lambda:self.track(key).update(changes))

    def reorder_track(self,key,direction):
        def change():
            t=self.track(key);self.editable(t);tracks=self.seq['tracks'];index=tracks.index(t)
            target=max(0,min(len(tracks)-1,index+direction));tracks.pop(index);tracks.insert(target,t)
        self.edit('ترتيب طبقات الفيديو',change)

    def add(self,track_id,clip,media=None):
        def change():
            t=self.track(track_id);self.editable(t)
            if media and not any(a['id']==media['id'] for a in self.project['media']):self.project['media'].append(deepcopy(media))
            t['clips'].append(deepcopy(clip))
        self.edit('إضافة مقطع',change);return clip['id']

    def selection(self,keys,grouped=False):
        pairs=[self.clip(key) for key in keys]
        if grouped:
            groups={c['group'] for _,c in pairs if c['group']}
            pairs=[(t,c) for t in self.seq['tracks'] for c in t['clips'] if c['id'] in keys or c['group'] in groups]
        return pairs

    def move(self,key,start,track_id=None,snap=False,other_keys=()):
        def change():
            track,clip=self.clip(key);target=self.track(track_id) if track_id else track
            self.editable(target)
            pairs=self.selection([key,*other_keys],True)
            for t,_ in pairs:self.editable(t)
            at=int(start)
            if snap:
                edges={0}
                moving={c['id'] for _,c in pairs}
                for t in self.seq['tracks']:
                    for c in t['clips']:
                        if c['id'] not in moving:edges.update((c['start'],c['start']+c['duration'],c['start']-clip['duration'],c['start']+c['duration']-clip['duration']))
                nearest=min(edges,key=lambda x:abs(x-at))
                if abs(nearest-at)<=max(1,self.project['fps']//5):at=nearest
            delta=at-clip['start']
            for _,c in pairs:c['start']+=delta
            if target is not track:track['clips'].remove(clip);target['clips'].append(clip)
        self.edit('نقل المقاطع',change)

    def trim(self,key,start,end):
        def change():
            t,c=self.clip(key);self.editable(t)
            delta=int(start)-c['start'];source_delta=c['duration']-(int(end)-c['start']) if c.get('reverse') else delta
            retime_animation(c,delta,int(end)-int(start));c['in']+=round(source_delta*c.get('rate',1.));c['start']=int(start);c['duration']=int(end)-int(start)
            if t['kind']=='text':c['in']=0
            c['fade_in']=min(c['fade_in'],c['duration']);c['fade_out']=min(c['fade_out'],c['duration'])
        self.edit('قص حدود المقطع',change)

    def split(self,key,at):
        created=uid()
        def change():
            t,c=self.clip(key);self.editable(t);offset=int(at)-c['start']
            if not 0<offset<c['duration']:raise ValueError('اختر إطارًا داخل المقطع.')
            right=deepcopy(c);right.update(id=created,start=int(at),duration=c['duration']-offset,group=None)
            retime_animation(right,offset,right['duration']);retime_animation(c,0,offset)
            right['in']=0 if t['kind']=='text' else c['in'] if c.get('reverse') else c['in']+round(offset*c.get('rate',1.))
            if c.get('reverse'):c['in']+=round((c['duration']-offset)*c.get('rate',1.))
            if c['loop'] and c['media_id']:
                a=next(a for a in self.project['media'] if a['id']==c['media_id'])
                if a['kind']!='image':right['in']%=max(1,frames(a['duration'],self.project['fps']))
            c['duration']=offset;c['fade_in']=min(c['fade_in'],offset);c['fade_out']=0
            right['fade_in']=0;right['fade_out']=min(right['fade_out'],right['duration']);t['clips'].append(right)
        self.edit('تقسيم المقطع',change);return created

    def delete(self,keys,ripple=False):
        def change():
            pairs=self.selection(keys,True)
            if not pairs:return
            removed={c['id'] for _,c in pairs};begin=min(c['start'] for _,c in pairs);end=max(c['start']+c['duration'] for _,c in pairs)
            for t,_ in pairs:self.editable(t)
            if ripple:
                for t in self.seq['tracks']:
                    for c in t['clips']:
                        if c['id'] in removed:continue
                        if c['start']<end and c['start']+c['duration']>begin:raise ValueError('القص المتتابع يتقاطع مع مقطع آخر؛ قسّم المسارات المرتبطة أولًا.')
                        if c['start']>=end:self.editable(t);c['start']-=end-begin
            for t in self.seq['tracks']:t['clips'][:]=[c for c in t['clips'] if c['id'] not in removed]
        self.edit('حذف متتابع' if ripple else 'حذف',change)

    def properties(self,key,**changes):
        allowed={'text','gain_db','fade_in','fade_out','loop','transform','crop','keyframes','fit','processing','color','mask','volume_automation','word_timing','rate','reverse'}
        if set(changes)-allowed:raise ValueError('خاصية غير معروفة.')
        def change():
            t,c=self.clip(key);self.editable(t);c.update(deepcopy(changes))
        self.edit('خصائص المقطع',change)

    def add_overlay(self,name='Overlay — ميم / GIF'):
        t=new_track('video',name);t['role']='overlay'
        self.edit('إضافة طبقة فوق الفيديو',lambda:self.seq['tracks'].append(t));return t['id']

    def set_fps(self,value):
        def change():
            old=self.project['fps'];self.project['fps']=value
            for s in self.project['sequences']:
                if s.get('source_range'):
                    for k in ('start','end'):s['source_range'][k]=round(s['source_range'][k]*value/old)
                for t in s['tracks']:
                    for c in t['clips']:
                        end=round((c['start']+c['duration'])*value/old)
                        c['start']=round(c['start']*value/old);c['duration']=max(1,end-c['start'])
                        for k in ('in','fade_in','fade_out'):c[k]=round(c[k]*value/old)
                        for prop,keys in c.get('keyframes',{}).items():
                            converted={min(c['duration']-1,round(k['frame']*value/old)):{**k,'frame':min(c['duration']-1,round(k['frame']*value/old))} for k in keys}
                            c['keyframes'][prop]=[converted[f] for f in sorted(converted)]
                        c['fade_in']=min(c['fade_in'],c['duration']);c['fade_out']=min(c['fade_out'],c['duration'])
        self.edit('معدل الإطارات',change)

    def group(self,keys,ungroup=False):
        def change():
            value=None if ungroup else uid()
            for t,c in self.selection(keys):self.editable(t);c['group']=value
        self.edit('فك المجموعة' if ungroup else 'تجميع',change)

    def copy(self,keys):
        self.clipboard=[(t['id'],deepcopy(c)) for t,c in self.selection(keys,True)]

    def paste(self,at):
        result=[]
        def change():
            if not self.clipboard:return
            first=min(c['start'] for _,c in self.clipboard);groups={}
            for key,old in self.clipboard:
                t=self.track(key);self.editable(t);c=deepcopy(old);c['id']=uid();c['start']+=int(at)-first
                if c['group']:c['group']=groups.setdefault(c['group'],uid())
                t['clips'].append(c);result.append(c['id'])
        self.edit('لصق المقاطع',change);return result

    def slip(self,key,delta):
        def change():
            t,c=self.clip(key);self.editable(t)
            if t['kind']=='text':raise ValueError('Slip غير صالح للنص.')
            c['in']+=int(delta)
        self.edit('Slip',change)

    def roll(self,left_id,right_id,delta):
        def change():
            t,l=self.clip(left_id);u,r=self.clip(right_id);self.editable(t);self.editable(u)
            if t is not u or l['start']+l['duration']!=r['start']:raise ValueError('Roll يحتاج مقطعين متجاورين على المسار نفسه.')
            d=int(delta);l['duration']+=d;r['start']+=d;r['duration']-=d
            if l.get('reverse'):l['in']-=round(d*l.get('rate',1.))
            retime_animation(l,0,l['duration']);retime_animation(r,d,r['duration'])
            if t['kind']!='text' and not r.get('reverse'):r['in']+=round(d*r.get('rate',1.))
            l['fade_in']=min(l['fade_in'],l['duration']);l['fade_out']=min(l['fade_out'],l['duration'])
            r['fade_in']=min(r['fade_in'],r['duration']);r['fade_out']=min(r['fade_out'],r['duration'])
        self.edit('Roll',change)

    def slide(self,key,left_id,right_id,delta):
        def change():
            t,c=self.clip(key);u,l=self.clip(left_id);v,r=self.clip(right_id)
            if not t is u is v or l['start']+l['duration']!=c['start'] or c['start']+c['duration']!=r['start']:raise ValueError('Slide يحتاج ثلاثة مقاطع متجاورة.')
            self.editable(t);d=int(delta);l['duration']+=d;c['start']+=d;r['start']+=d;r['duration']-=d
            if l.get('reverse'):l['in']-=round(d*l.get('rate',1.))
            retime_animation(l,0,l['duration']);retime_animation(r,d,r['duration'])
            if t['kind']!='text' and not r.get('reverse'):r['in']+=round(d*r.get('rate',1.))
            for item in (l,r):
                item['fade_in']=min(item['fade_in'],item['duration']);item['fade_out']=min(item['fade_out'],item['duration'])
        self.edit('Slide',change)

    def crossfade(self,left_id,right_id,duration):
        def change():
            t,l=self.clip(left_id);u,r=self.clip(right_id);self.editable(t);self.editable(u)
            if t is not u or t['kind'] not in ('video','image') or l['start']+l['duration']!=r['start']:raise ValueError('Crossfade يحتاج لقطتين متجاورتين على مسار مرئي.')
            if type(duration)is not int or not 2<=duration<=min(l['duration'],r['duration'],self.project['fps']*2):raise ValueError('مدة انتقال غير صالحة، حتى ثانيتين.')
            before=duration//2;after=duration-before
            l['duration']+=after;l['fade_out']=0;r['start']-=before;r['duration']+=before;r['fade_in']=duration
            if l.get('reverse'):l['in']-=round(after*l.get('rate',1.))
        self.edit('Crossfade حقيقي بين اللقطات',change)

    def make_short(self,start,end,name='شورت'):
        result=uid()
        def change():
            start_frame,end_frame=int(start),int(end)
            if not 0<=start_frame<end_frame<=length(self.seq):raise ValueError('نطاق الشورت غير صالح.')
            s=deepcopy(self.seq);s.update(id=result,name=name,width=1080,height=1920,source_range={'sequence':self.seq['id'],'start':start_frame,'end':end_frame})
            groups={}
            for t in s['tracks']:
                t['id']=uid();items=[]
                for c in t['clips']:
                    begin=max(start_frame,c['start']);finish=min(end_frame,c['start']+c['duration'])
                    if begin>=finish:continue
                    delta=begin-c['start'];source_delta=c['duration']-(finish-c['start']) if c.get('reverse') else delta
                    retime_animation(c,delta,finish-begin);c.update(id=uid(),start=begin-start_frame,duration=finish-begin)
                    if t['kind']!='text':
                        c['in']+=round(source_delta*c.get('rate',1.))
                        a=next(a for a in self.project['media'] if a['id']==c['media_id'])
                        if c['loop'] and a['kind']!='image':c['in']%=max(1,frames(a['duration'],self.project['fps']))
                    c['fade_in']=min(c['fade_in'],c['duration']);c['fade_out']=min(c['fade_out'],c['duration'])
                    if c['group']:c['group']=groups.setdefault(c['group'],uid())
                    items.append(c)
                t['clips']=items
            self.project['sequences'].append(s);self.project['active_sequence']=result
        self.edit('استخراج شورت متصل',change);return result


def from_legacy(timeline, origin=''):
    """Import editable originals, not the flattened exported video."""
    timeline=deepcopy(timeline)
    if origin:
        folder=Path(origin).resolve().parent
        for a in timeline['assets']:
            if not Path(a['path']).is_absolute():a['path']=str((folder/a['path']).resolve())
        if not Path(timeline['audio']).is_absolute():timeline['audio']=str((folder/timeline['audio']).resolve())
    p=new_project();fps=p['fps'];s=sequence(p)
    base=new_track('video','اللقطات');text_track=new_track('text','الترجمة');voice_track=new_track('audio','التعليق');fx_track=new_track('effect','المؤثرات')
    overlays=[new_track('video',f'Overlay {i} — ميم / GIF') for i in range(1,4)]
    for track in overlays:track['role']='overlay'
    tracks=[base,*overlays,text_track,voice_track,fx_track]
    s['tracks']=tracks
    p['media']=deepcopy(timeline['assets'])
    for a in p['media']:
        a['kind']='video' if a['kind']=='animation' else a['kind'];a['has_audio']=False
    audio=import_media(timeline['audio']);p['media'].append(audio)
    audio['processed']=bool(timeline.get('audio_processed',False))
    audio_frames=max(1,math.ceil(timeline['duration']*fps))
    voice_track['clips'].append(new_clip(audio['id'],duration=audio_frames))
    for shot in timeline['shots']:
        start=frames(shot['start'],fps);stop=audio_frames if abs(shot['end']-timeline['duration'])<.001 else frames(shot['end'],fps)
        if stop<=start:continue
        if shot['asset_id']:
            c=new_clip(shot['asset_id'],start,stop-start,frames(shot.get('source_offset',0),fps),loop=True)
            asset=next(a for a in p['media'] if a['id']==shot['asset_id'])
            if asset['kind']=='image' and stop-start>=15:
                c['keyframes']={'scale':[{'frame':0,'value':1.,'easing':'linear'},
                                         {'frame':stop-start-1,'value':1.025,'easing':'linear'}]}
            if shot.get('transition')=='fade':c['fade_in']=min(stop-start,frames(.15,fps))
            base['clips'].append(c)
    for m in timeline.get('memes',[]):
        if not m.get('approved'):continue
        x,y,w,h=m['region']
        overlays[0]['clips'].append(new_clip(m['asset_id'],frames(m['timestamp'],fps),max(1,frames(m['duration'],fps)),loop=True,
                                         transform={'x':x,'y':y,'scale':min(w,h),'opacity':1.}))
    for segment in timeline.get('segments',[]):
        start=frames(segment['start'],fps);end=frames(segment['end'],fps)
        if end>start:text_track['clips'].append(new_clip(start=start,duration=end-start,text=segment['text'],words=deepcopy(segment.get('words',[]))))
    from pro_subtitles import canonical_words
    for c in text_track['clips']:c['word_timing']=canonical_words(c,fps)
    audio['words']=[deepcopy(w) for segment in timeline.get('segments',[]) for w in segment.get('words',[])]
    text_track['caption']=deepcopy(timeline.get('caption',{'font':'Arial','style':'clean','region':[.1,.78,.8,.15]}))
    for e in timeline.get('sound_effects',[]):
        if not e.get('approved'):continue
        a=import_media(e['path'],e['license'],e['source'],e['usage_approved']);p['media'].append(a)
        fx_track['clips'].append(new_clip(a['id'],frames(e['timestamp'],fps),max(1,frames(e['duration'],fps)),gain_db=e['gain_db']))
    p['provenance']={'legacy_timeline':origin,'audio_edit_decisions':str(Path(origin).parent/'delivery'/'audio_edits.json') if origin else '',
                     'note':'Sources preserved; Auto Studio processed narration remains referenced independently.'}
    validate(p);session=Session(p)
    main=p['active_sequence']
    for i,short in enumerate(timeline.get('shorts',[]),1):
        if short.get('approved'):
            session.project['active_sequence']=main
            session.make_short(frames(short['start'],fps),frames(short['end'],fps),f'شورت {i}')
    session.project['active_sequence']=main
    return validate(session.project)
