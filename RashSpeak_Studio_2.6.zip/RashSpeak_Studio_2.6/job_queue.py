"""Persistent local export queue. Resumes whole jobs, never claims mid-frame resume."""
from copy import deepcopy
from contextlib import contextmanager
import json
import os
from pathlib import Path
import sqlite3
import threading
import time

from media_tools import Cancelled
from pro_project import uid,write_project,load_project
from pro_render import render


def alive(pid):
    if not pid:return False
    if os.name=='nt':
        import ctypes
        handle=ctypes.windll.kernel32.OpenProcess(0x1000,False,pid)
        if not handle:return ctypes.get_last_error()==5
        try:
            code=ctypes.c_ulong();ctypes.windll.kernel32.GetExitCodeProcess(handle,ctypes.byref(code));return code.value==259
        finally:ctypes.windll.kernel32.CloseHandle(handle)
    try:os.kill(pid,0);return True
    except ProcessLookupError:return False
    except PermissionError:return True


class ExportQueue:
    def __init__(self,folder,events=None,processor=render):
        self.folder=Path(folder).resolve();self.folder.mkdir(parents=True,exist_ok=True)
        self.path=self.folder/'exports.sqlite3';self.events=events;self.processor=processor;self.stopping=threading.Event();self.cancel=threading.Event();self.worker=None
        with self.db() as db:
            db.execute('CREATE TABLE IF NOT EXISTS jobs (id TEXT PRIMARY KEY,status TEXT,payload TEXT,result TEXT,error TEXT,progress INTEGER,attempts INTEGER,owner INTEGER)')
            for key,pid in db.execute("SELECT id,owner FROM jobs WHERE status='running'").fetchall():
                if not alive(pid):db.execute("UPDATE jobs SET status='queued',error='استعادة مهمة انقطعت؛ يعاد الرندر من البداية',owner=NULL WHERE id=?",(key,))

    @contextmanager
    def db(self):
        connection=sqlite3.connect(self.path,timeout=10)
        try:yield connection;connection.commit()
        except Exception:connection.rollback();raise
        finally:connection.close()

    def enqueue(self,project,output,options=None):
        key=uid();snapshot=self.folder/'snapshots'/(key+'.rash.json');write_project(deepcopy(project),snapshot)
        payload={'snapshot':str(snapshot),'output':str(Path(output).resolve()),'options':options or {}}
        if set(payload['options'])-{'sequence_id','codec','crf','size','encoder','bitrate'}:raise ValueError('إعداد مهمة غير مدعوم.')
        with self.db() as db:
            busy=db.execute("SELECT COUNT(*) FROM jobs WHERE status IN ('running','queued') AND json_extract(payload,'$.output')=?",(payload['output'],)).fetchone()[0]
            if busy:raise ValueError('مهمة أخرى تكتب إلى الملف نفسه؛ اختر اسمًا آخر.')
            db.execute('INSERT INTO jobs VALUES (?,?,?,?,?,?,?,?)',(key,'queued',json.dumps(payload),None,'',0,0,None))
        self.start();return key

    def rows(self):
        with self.db() as db:
            rows=db.execute('SELECT id,status,payload,result,error,progress,attempts FROM jobs ORDER BY rowid DESC').fetchall()
        return [{'id':r[0],'status':r[1],'payload':json.loads(r[2]),'result':json.loads(r[3]) if r[3] else None,'error':r[4],'progress':r[5],'attempts':r[6]} for r in rows]

    def retry(self,key):
        with self.db() as db:
            row=db.execute('SELECT status,attempts FROM jobs WHERE id=?',(key,)).fetchone()
            if not row or row[0] not in ('failed','cancelled') or row[1]>=3:raise ValueError('المهمة لا تقبل إعادة المحاولة أو بلغت ثلاث محاولات.')
            db.execute("UPDATE jobs SET status='queued',error='',progress=0 WHERE id=?",(key,))
        self.start()

    def cancel_job(self,key):
        with self.db() as db:
            row=db.execute('SELECT status FROM jobs WHERE id=?',(key,)).fetchone()
            if row and row[0]=='running':self.cancel.set()
            else:db.execute("UPDATE jobs SET status='cancelled' WHERE id=? AND status='queued'",(key,))

    def start(self):
        if self.worker and self.worker.is_alive():return
        self.stopping.clear();self.worker=threading.Thread(target=self.work,daemon=True);self.worker.start()

    def emit(self,kind,value):
        if self.events:self.events.put((kind,value,None))

    def work(self):
        while not self.stopping.is_set():
            with self.db() as db:
                db.execute('BEGIN IMMEDIATE')
                row=db.execute("SELECT id,payload FROM jobs WHERE status='queued' ORDER BY rowid LIMIT 1").fetchone()
                if not row:return
                key,payload=row[0],json.loads(row[1]);db.execute("UPDATE jobs SET status='running',attempts=attempts+1,owner=? WHERE id=?",(os.getpid(),key))
            self.cancel.clear();self.emit('queue_status',{'id':key,'status':'running'})
            def progress(value):
                with self.db() as db:db.execute('UPDATE jobs SET progress=? WHERE id=?',(value,key))
                self.emit('queue_progress',{'id':key,'progress':value})
            try:
                p=load_project(payload['snapshot']);result=self.processor(p,payload['output'],cancel=self.cancel,on_progress=progress,**payload['options'])
                with self.db() as db:db.execute("UPDATE jobs SET status='completed',result=?,error='',progress=100 WHERE id=?",(json.dumps(result),key))
                self.emit('queue_done',{'id':key,'result':result,'sequence':payload['options'].get('sequence_id',p['active_sequence'])})
            except Exception as exc:
                status='cancelled' if isinstance(exc,Cancelled) else 'failed'
                with self.db() as db:db.execute('UPDATE jobs SET status=?,error=? WHERE id=?',(status,str(exc),key))
                self.emit('queue_status',{'id':key,'status':status,'error':str(exc)})

    def close(self):
        self.stopping.set();self.cancel.set()
        if self.worker and self.worker.is_alive():self.worker.join(timeout=3)
