"""Validated numeric DSP/color controls shared by preview and export."""
import math


def number(value,lo,hi):
    if type(value) not in (int,float) or not math.isfinite(value) or not lo<=value<=hi:raise ValueError('قيمة تأثير خارج النطاق.')


def validate_audio(data):
    bounds={'highpass':(0,150),'eq_low':(-12,12),'eq_mid':(-12,12),'eq_high':(-12,12),
            'threshold_db':(-40,-3),'ratio':(1,12),'attack':(1,100),'release':(20,1000)}
    if not isinstance(data,dict) or set(data)-set(bounds)-{'denoise','compressor','deesser','loudness'}:raise ValueError('خاصية معالجة صوت غير مدعومة.')
    for k,v in data.items():
        if k in ('denoise','compressor','deesser'):
            if type(v)is not bool:raise ValueError('تفعيل التأثير يجب أن يكون منطقيًا.')
        elif k=='loudness':
            if v is not None:number(v,-24,-9)
        else:number(v,*bounds[k])


def validate_color(data):
    bounds={'exposure':(-2,2),'contrast':(.5,2),'saturation':(0,2),'temperature':(-1,1)}
    if not isinstance(data,dict) or set(data)-set(bounds):raise ValueError('خاصية لون غير مدعومة.')
    for k,v in data.items():number(v,*bounds[k])


def validate_automation(keys,duration):
    if not isinstance(keys,list) or len(keys)>1000:raise ValueError('Volume Automation أكبر من الحد.')
    previous=-1
    for k in keys:
        if set(k)!= {'frame','gain_db'} or type(k['frame'])is not int or not previous<k['frame']<duration:raise ValueError('توقيت Volume Automation غير صالح.')
        number(k['gain_db'],-60,12);previous=k['frame']


def validate_mask(mask):
    if not isinstance(mask,dict) or set(mask)!= {'shape','x','y','width','height','feather'} or mask['shape'] not in ('rectangle','ellipse'):raise ValueError('قناع غير صالح.')
    for k in ('x','y'):number(mask[k],0,1)
    for k in ('width','height'):number(mask[k],.01,1)
    number(mask['feather'],0,.25)
    if mask['x']+mask['width']>1 or mask['y']+mask['height']>1:raise ValueError('القناع خارج الصورة.')


def audio_filters(data):
    validate_audio(data);parts=[]
    if data.get('highpass'):parts.append(f'highpass=f={data["highpass"]}')
    if data.get('denoise'):parts.append('afftdn=nf=-25')
    for key,freq in [('eq_low',120),('eq_mid',1000),('eq_high',6500)]:
        if data.get(key):parts.append(f'equalizer=f={freq}:t=q:w=1:g={data[key]}')
    if data.get('compressor'):
        parts.append(f'acompressor=threshold={10**(data.get("threshold_db",-18)/20)}:ratio={data.get("ratio",3)}:attack={data.get("attack",10)}:release={data.get("release",120)}:makeup=1')
    if data.get('deesser'):parts.append('deesser=i=0.3:m=0.5:f=0.5:s=o')
    if data.get('loudness') is not None:parts.append(f'loudnorm=I={data["loudness"]}:TP=-1.5:LRA=11')
    return parts


def color_filters(data):
    validate_color(data);parts=[]
    if data.get('exposure'):parts.append(f'exposure=exposure={data["exposure"]}')
    if 'contrast' in data or 'saturation' in data:parts.append(f'eq=contrast={data.get("contrast",1)}:saturation={data.get("saturation",1)}')
    if data.get('temperature'):
        v=data['temperature'];parts.append(f'colorbalance=rs={v*.18}:bs={-v*.18}:rh={v*.1}:bh={-v*.1}')
    return parts


def curve_expression(keys,fps,default=0,timevar='t',value_key='gain_db'):
    if not keys:return str(default)
    points=keys if keys[0]['frame']==0 else [{'frame':0,value_key:default},*keys]
    expr=str(points[-1][value_key])
    for left,right in reversed(list(zip(points,points[1:]))):
        start=left['frame']/fps;end=right['frame']/fps;u=f'clip(({timevar}-{start})/{end-start},0,1)'
        if right.get('easing')=='ease_in':u=f'pow({u},2)'
        elif right.get('easing')=='ease_out':u=f'(1-pow(1-{u},2))'
        if 'u_start' in right:
            # Exact sub-curve from an original eased interval, including split/trim.
            a=right['u_start'];b=right['u_end'];v=f'({a}+({b-a})*clip(({timevar}-{start})/{end-start},0,1))'
            easing=right.get('source_easing','linear')
            if easing=='ease_in':v=f'pow({v},2)'
            elif easing=='ease_out':v=f'(1-pow(1-{v},2))'
            else:v=v
            value=f'({right["source_left"]}+({right["source_right"]-right["source_left"]})*{v})'
        else:value=f'({left[value_key]}+({right[value_key]-left[value_key]})*{u})'
        expr=f'if(lte({timevar},{end}),{value},{expr})'
    return expr


def volume_filter(base,keys,fps):
    if not keys:return f'volume={base}dB'
    expr=curve_expression(keys,fps,timevar='if(isnan(t),0,t)')
    return f"volume='pow(10,({base}+({expr}))/20)':eval=frame"


def mask_filter(mask):
    validate_mask(mask);x,y,w,h,f=(mask[k] for k in ('x','y','width','height','feather'))
    if mask['shape']=='rectangle':
        if f:
            alpha=f'clip((X-W*{x})/(W*{f}),0,1)*clip((W*{x+w}-X)/(W*{f}),0,1)*clip((Y-H*{y})/(H*{f}),0,1)*clip((H*{y+h}-Y)/(H*{f}),0,1)'
        else:alpha=f'gte(X,W*{x})*lte(X,W*{x+w})*gte(Y,H*{y})*lte(Y,H*{y+h})'
    else:
        radius=f'sqrt(pow((X-W*{x+w/2})/(W*{w/2}),2)+pow((Y-H*{y+h/2})/(H*{h/2}),2))'
        alpha=f'clip((1-({radius}))/{max(f,.00001)},0,1)' if f else f'lte({radius},1)'
    return f"geq=r='r(X,Y)':g='g(X,Y)':b='b(X,Y)':a='alpha(X,Y)*({alpha})'"
