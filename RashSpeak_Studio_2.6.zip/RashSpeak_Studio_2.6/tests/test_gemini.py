from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from gemini_client import GeminiClient,GeminiError,GeminiUnavailable
from gemini_context import validate_context,analyse
from ai_editing import compile_plan,commit,project_context
from pro_project import Session,new_project,new_clip,import_media,edit_digest
from smart_editor import fingerprint
from pro_render import render
from PIL import Image


class Response:
    def __init__(self,data,status=200):self.data=data;self.status_code=status;self.closed=False
    def iter_content(self,size):yield json.dumps(self.data).encode()
    def close(self):self.closed=True


class HTTP:
    def __init__(self,response):self.response=response;self.calls=[]
    def request(self,*args,**kwargs):self.calls.append((args,kwargs));return self.response


def action(op,target='',prop='',value='',start=0,end=0):return {'op':op,'target':target,'property':prop,'value':value,'start':start,'end':end,'reason':'اقتراح للاختبار'}


class ClientTests(unittest.TestCase):
    def test_official_request_schema_header_and_no_paths_or_secret_diagnostics(self):
        http=HTTP(Response({'candidates':[{'finishReason':'STOP','content':{'parts':[{'text':'{"ok":true}'}]}}],'usageMetadata':{'totalTokenCount':5}}))
        c=GeminiClient(key='TEST_SECRET',model='gemini-flash-latest',http=http)
        self.assertEqual(c.generate('system',{'script':'نص سعودي'}, {'type':'OBJECT'}),{'ok':True})
        args,kw=http.calls[0];self.assertEqual(kw['headers']['x-goog-api-key'],'TEST_SECRET');self.assertNotIn('TEST_SECRET',args[1])
        self.assertFalse(kw['allow_redirects']);self.assertEqual(kw['json']['generationConfig']['responseMimeType'],'application/json')
        self.assertEqual(c.last_usage['totalTokenCount'],5)
        bad=GeminiClient(key='TEST_SECRET',http=HTTP(Response({'error':{'message':'TEST_SECRET'}},403)))
        with self.assertRaises(GeminiUnavailable) as error:bad.models()
        self.assertNotIn('TEST_SECRET',str(error.exception))

    def test_missing_key_bad_model_blocked_truncated_and_invalid_json_are_not_success(self):
        with self.assertRaises(GeminiUnavailable):GeminiClient(key='')
        with self.assertRaises(ValueError):GeminiClient(key='x',model='../secret')
        for data in ({'candidates':[]},{'candidates':[{'finishReason':'MAX_TOKENS'}]}, {'candidates':[{'content':{'parts':[{'text':'not JSON'}]}}]}):
            client=GeminiClient(key='x',http=HTTP(Response(data)))
            with self.assertRaises(GeminiError):client.generate('system',{}, {'type':'OBJECT'})


class ContextTests(unittest.TestCase):
    def data(self):
        text='فورتنايت موعد التحديث 20 أكتوبر.'
        segment={'start':0.,'end':4.,'text':text,'asr_confidence':.95}
        row={'id':'s0000','game':'Fortnite','event':'تحديث','idea':'موعد التحديث','evidence':text,'tone':'humor','importance':8,'confidence':.95,
             'visual':'gameplay','meme':True,'effect':'impact','reason':'اختبار','queries':['Fortnite update']}
        return text,[segment],{'segments':[row],'shorts':[]}

    def test_model_cannot_override_sensitive_number_guards_or_invent_evidence_ids(self):
        text,segments,response=self.data();validated=validate_context(response,text,segments)
        self.assertFalse(validated['segments'][0]['meme']);self.assertEqual(validated['segments'][0]['effect'],'none')
        for field,value in [('id','invented'),('evidence','كلام لم يقله أحد'),('confidence',float('nan'))]:
            bad=deepcopy(response);bad['segments'][0][field]=value
            with self.assertRaises(GeminiError):validate_context(bad,text,segments)

    def test_valid_cache_reuses_timing_grounded_context(self):
        text,segments,response=self.data()
        class Fake:
            model='gemini-flash-latest';last_usage={};calls=0
            def generate(self,*args):self.calls+=1;return response
        client=Fake()
        with tempfile.TemporaryDirectory() as folder:
            one=analyse(text,segments,folder,client);two=analyse(text,segments,folder,client)
        self.assertFalse(one['cached']);self.assertTrue(two['cached']);self.assertEqual(client.calls,1)


class EditingTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);file=self.root/'original.png';Image.new('RGB',(320,180),'red').save(file)
        self.s=Session(new_project(size=(320,180)));self.t=self.s.add_track('image');a=import_media(file);self.c=self.s.add(self.t,new_clip(a['id'],duration=60),a)
    def tearDown(self):self.tmp.cleanup()

    def test_reviewed_real_candidate_commits_one_undo_and_rejects_stale_unpreviewed(self):
        before=deepcopy(self.s.project)
        p=compile_plan(self.s.project,{'summary':'تكبير وتخفيف اللون','actions':[action('set_transform',self.c,'scale','0.5'),action('set_color',self.c,'saturation','0.2')]})
        self.assertEqual(self.s.project,before)
        with self.assertRaises(GeminiError):commit(self.s,p)
        path=self.root/'preview.mp4';render(p['project'],path)
        p.update(preview=str(path),preview_fingerprint=fingerprint(path),preview_model_digest=edit_digest(p['project']))
        count=len(self.s.undo_stack);self.assertTrue(commit(self.s,p));self.assertEqual(len(self.s.undo_stack),count+1)
        self.s.undo();self.assertEqual(self.s.project,before);self.s.redo()
        with self.assertRaises(GeminiError):commit(self.s,p)

    def test_unknown_shell_changes_locked_assets_and_guessed_silence_rejected(self):
        for a in [action('shell',value='rm -rf'),action('remove_silence',start=0,end=30),action('replace_media',self.c,value='invented')]:
            with self.assertRaises((GeminiError,ValueError)):compile_plan(self.s.project,{'summary':'test','actions':[a]})
        self.s.track_state(self.t,locked=True)
        with self.assertRaises(ValueError):compile_plan(self.s.project,{'summary':'test','actions':[action('set_transform',self.c,'scale','.5')]})

    def test_prompt_context_never_contains_local_path(self):
        text=json.dumps(project_context(self.s.project));self.assertNotIn(str(self.root),text);self.assertNotIn('original.png',text)

    def test_candidate_changed_after_preview_and_audio_processing_leave_visual_unchanged(self):
        p=compile_plan(self.s.project,{'summary':'test','actions':[action('set_transform',self.c,'opacity','.5')]})
        path=self.root/'review.mp4';render(p['project'],path);p.update(preview=str(path),preview_fingerprint=fingerprint(path),preview_model_digest=edit_digest(p['project']))
        p['project']['sequences'][0]['tracks'][0]['clips'][0]['transform']['opacity']=.2
        with self.assertRaises(GeminiError):commit(self.s,p)
        wav=self.root/'audio.wav'
        from media_tools import run
        run(['ffmpeg','-v','error','-y','-f','lavfi','-i','sine=duration=2',wav]);a=import_media(wav);t=self.s.add_track('audio');c=self.s.add(t,new_clip(a['id'],duration=60),a)
        before=deepcopy(self.s.project['sequences'][0]['tracks'][0])
        p=compile_plan(self.s.project,{'summary':'صوت فقط','actions':[action('set_audio',c,'compressor','true'),action('set_audio',c,'eq_mid','1.5')]})
        self.assertEqual(p['project']['sequences'][0]['tracks'][0],before)
        render(p['project'],self.root/'processed.mp4')

    def test_semantic_visual_type_changes_real_shot_and_does_not_substitute_game(self):
        from gemini_context import apply_visual_plan
        a=self.s.project['media'][0];a.update(role='clip',game='Fortnite',kind='image')
        timeline={'assets':[a],'segments':[{'start':0,'end':2,'text':'فورتنايت تحديات جديدة','semantic':{'confidence':.95,'visual':'gameplay','game':'Fortnite','reason':'تحديات'}}],
                  'shots':[{'start':0,'end':2,'asset_id':a['id'],'source_offset':0}]}
        def card(title,i):return {**a,'id':'card','editorial_card':True}
        apply_visual_plan(timeline,card)
        self.assertEqual(timeline['shots'][0]['asset_id'],'card');self.assertIn('بطاقة',timeline['shots'][0]['reason'])
        timeline['segments'][0]['semantic']['visual']='image';apply_visual_plan(timeline,card)
        self.assertEqual(timeline['shots'][0]['asset_id'],a['id'])
