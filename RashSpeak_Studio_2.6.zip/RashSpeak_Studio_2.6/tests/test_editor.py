import copy
import json
from pathlib import Path
import tempfile
import threading
import types
import unittest
from unittest.mock import patch

import captions
from media_tools import Cancelled, run
import smart_editor as e
from submissions import guarded_submit


def asset(id='f', role='clip', game='fortnite', mood='humor'):
    return {'id': id, 'role': role, 'game': game, 'tags': ['قتال'], 'mood': mood,
            'license': 'own', 'source': 'synthetic', 'usage_approved': True,
            'path': 'missing.mp4', 'kind': 'video', 'duration': 9, 'fingerprint': {}}


class EditorTests(unittest.TestCase):
    def test_arabic_game_synonyms(self):
        self.assertEqual(e.normalize('إِكس بُوكس'), 'xbox')
        self.assertEqual(e.normalize('فورتنايت'), 'fortnite')
        self.assertTrue(e.contains('خبر PS5 اليوم', 'بلايستيشن'))

    def test_game_guard_even_when_generic_tag_matches(self):
        self.assertEqual(e.match('قتال في ماينكرافت', [asset()]), [])
        self.assertTrue(e.match('قتال في فورتنايت', [asset()]))

    def test_license_unknown_never_matches(self):
        a = asset()
        a['usage_approved'] = False
        self.assertEqual(e.match('fortnite', [a]), [])
        a['usage_approved'] = True
        a['license'] = 'unknown'
        self.assertEqual(e.match('fortnite', [a]), [])

    def test_match_word_boundary(self):
        self.assertFalse(e.contains('ماتيوس', 'مات'))

    def test_cues_override_and_unmatched_neutral(self):
        with tempfile.TemporaryDirectory() as folder:
            cue = Path(folder) / 'cues.csv'
            cue.write_text('start,end,tag\n0,3,minecraft\n', encoding='utf-8')
            with patch.object(e, 'duration', return_value=6), patch.object(e, 'fingerprint', return_value={}):
                timeline = e.plan('voice.wav', {'assets': [asset(), asset('m', game='minecraft')]},
                                  [{'start': 0, 'end': 3, 'text': 'fortnite'}, {'start': 3, 'end': 6, 'text': 'خبر مختلف'}], cues=cue)
            self.assertEqual(timeline['shots'][0]['asset_id'], 'm')
            self.assertIsNone(timeline['shots'][-1]['asset_id'])
            self.assertTrue(timeline['warnings'])

    def test_overlapping_or_nonfinite_cues_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            cue = Path(folder) / 'c.csv'
            for rows in ('0,5,a\n3,6,b', 'nan,5,a'):
                cue.write_text('start,end,tag\n' + rows, encoding='utf-8')
                with self.assertRaises(ValueError):
                    e.read_cues(cue, 8)

    def test_clip_only_explicit_sequence_no_subtitles(self):
        with patch.object(e, 'duration', return_value=13), patch.object(e, 'fingerprint', return_value={}):
            t = e.plan('voice.wav', {'assets': [asset()]})
        self.assertTrue(all(s['asset_id'] == 'f' and s['confidence'] == 0 for s in t['shots']))
        self.assertEqual(t['segments'], [])
        self.assertEqual(t['shorts'], [])

    def test_meme_opt_in_spacing_cap_and_serious_rejection(self):
        segments = [{'start': i, 'end': i + 2, 'text': 'هههه فورتنايت'} for i in range(0, 350, 20)]
        assets = [asset('j', 'meme', game='')]
        self.assertEqual(e.suggest_memes(segments, assets, 360, False), [])
        result = e.suggest_memes(segments, assets, 360, True)
        self.assertLessEqual(len(result), 4)
        self.assertTrue(all(not m['approved'] for m in result))
        self.assertTrue(all(b['timestamp'] - a['timestamp'] >= 45 for a, b in zip(result, result[1:])))
        self.assertIsNone(e.reaction('هههه تسريح الموظفين', 'humor'))
        self.assertIsNone(e.reaction('هههه السعر 70 دولار', 'humor'))
        self.assertIsNone(e.reaction('اشترك في القناة', 'humor'))
        self.assertIsNone(e.reaction('ضحكت', 'factual'))

    def timeline(self):
        with patch.object(e, 'duration', return_value=12), patch.object(e, 'fingerprint', return_value={}):
            return e.plan('voice.wav', {'assets': [asset(), asset('j', 'meme', game='')]},
                          [{'start': 0, 'end': 6, 'text': 'هههه fortnite'},
                           {'start': 6, 'end': 12, 'text': 'موعد اصدار fortnite', 'importance': 9}], memes_enabled=True)

    def test_revalidate_meme_cannot_cross_into_crucial_news(self):
        t = self.timeline()
        t['memes'][0].update(approved=True, timestamp=5.8, duration=1.4)
        with self.assertRaisesRegex(ValueError, 'خبر حساس'):
            e.validate_timeline(t, files=False)

    def test_meme_and_caption_collision(self):
        t = self.timeline()
        t['memes'][0].update(approved=True, region=[.1, .8, .2, .1])
        with self.assertRaisesRegex(ValueError, 'يتقاطع'):
            e.validate_timeline(t, files=False)

    def test_meme_and_subject_collision(self):
        t = self.timeline()
        t['memes'][0].update(approved=True, region=[.3, .3, .2, .2])
        with self.assertRaisesRegex(ValueError, 'يتقاطع'):
            e.validate_timeline(t, files=False)

    def test_revalidate_meme_duration_and_rate(self):
        t = self.timeline()
        t['memes'][0].update(approved=True, duration=2.1)
        with self.assertRaises(ValueError):
            e.validate_timeline(t, files=False)
        t['memes'][0]['duration'] = 1
        t['memes'].append(copy.deepcopy(t['memes'][0]))
        with self.assertRaises(ValueError):
            e.validate_timeline(t, files=False)

    def test_highlight_is_ranked_not_first_seconds(self):
        t = self.timeline()
        self.assertEqual(t['shorts'][0]['start'], 6)

    def test_gaps_in_shots_rejected(self):
        t = self.timeline()
        t['shots'][0]['end'] = 5
        with self.assertRaisesRegex(ValueError, 'فجوات'):
            e.validate_timeline(t, files=False)

    def test_review_required_and_edits_invalidate(self):
        t = self.timeline()
        with patch.object(e, 'validate_timeline', return_value=t):
            with self.assertRaises(ValueError):
                e.require_approval(t)
            e.approve(t, accept_warnings=True)
            e.require_approval(t)
            t['caption']['style'] = 'cinematic'
            with self.assertRaises(ValueError):
                e.require_approval(t)

    def test_changed_audio_rejected(self):
        t = self.timeline()
        with patch.object(e, 'fingerprint', return_value={'size': 1}):
            with self.assertRaisesRegex(ValueError, 'تغير الصوت'):
                e.validate_timeline(t)

    def test_srt_roundtrip_and_two_lines(self):
        with tempfile.TemporaryDirectory() as folder:
            p = Path(folder) / 'ar.srt'
            data = [{'start': 1.1, 'end': 9.5, 'text': ('إصدار Minecraft 2026 رائع جدًا ' * 8).strip()}]
            captions.write_srt(data, p)
            result = captions.read_srt(p)
            captions.validate(result, 10)
            self.assertAlmostEqual(result[0]['start'], 1.1)
            self.assertAlmostEqual(result[-1]['end'], 9.5)
            blocks = p.read_text(encoding='utf-8-sig').strip().split('\n\n')
            self.assertTrue(all(len(b.splitlines()[2:]) <= 2 for b in blocks))

    def test_ass_injection_is_escaped_logical_arabic_preserved(self):
        with tempfile.TemporaryDirectory() as folder:
            p = Path(folder) / 'ar.ass'
            captions.write_ass([{'start': 0, 'end': 3, 'text': r'لعبة Xbox 2026 {\pos(1,1)} رائعة'}], p)
            content = p.read_text(encoding='utf-8-sig')
            self.assertIn('لعبة Xbox 2026', content)
            self.assertNotIn(r'{\pos(1,1)}', content)

    def test_invalid_caption_timestamps(self):
        for start, end in [(float('nan'), 2), (0, float('inf')), (0, 11), (3, 2)]:
            with self.assertRaises(ValueError):
                captions.validate([{'start': start, 'end': end, 'text': 'نص'}], 10)

    def test_microsecond_audio_tail_does_not_make_zero_frame_shot(self):
        with patch.object(e, 'duration', return_value=10.000005), patch.object(e, 'fingerprint', return_value={}):
            timeline = e.plan('voice.wav', {'assets': [asset()]}, [{'start': 0, 'end': 10, 'text': 'fortnite'}])
        self.assertEqual(timeline['shots'][-1]['end'], 10.000005)
        self.assertFalse(any(s['end'] - s['start'] < .001 for s in timeline['shots']))

    def test_asr_real_word_times_and_overlap_cleanup(self):
        words = [types.SimpleNamespace(start=0.1, end=1.2, word='مرحبا.'),
                 types.SimpleNamespace(start=1.1, end=2.2, word=' ألعاب.')]
        segment = types.SimpleNamespace(words=words, start=0, end=2.2, text='مرحبا ألعاب')
        from unittest.mock import Mock
        call = Mock(return_value=(iter([segment]), None))
        model = types.SimpleNamespace(transcribe=call)
        fake = types.SimpleNamespace(WhisperModel=lambda *a, **k: model)
        with tempfile.TemporaryDirectory() as folder, patch.dict('sys.modules', {'faster_whisper': fake}), patch('media_tools.duration', return_value=3):
            result = captions.transcribe('fake.wav', folder, logger=lambda x: None)
        self.assertEqual(result[0]['start'], .1)
        self.assertEqual(result[1]['start'], 1.2)
        self.assertEqual(result[-1]['end'], 2.2)
        self.assertEqual(call.call_args.kwargs['language'], 'ar')
        self.assertIn('اللهجة السعودية',call.call_args.kwargs['initial_prompt'])
        self.assertIn('ذحين',call.call_args.kwargs['initial_prompt'])
        with tempfile.TemporaryDirectory() as folder, patch.dict('sys.modules', {'faster_whisper': fake}), patch('media_tools.duration', return_value=3):
            call.return_value=(iter([segment]),None)
            detailed=captions.transcribe('fake.wav',folder,logger=lambda x:None,return_words=True)
        self.assertEqual(detailed['segments'],result)
        self.assertEqual(detailed['words'][1]['start'],1.2)
        self.assertEqual(detailed['words'][1]['end'],2.2)

    def test_cancellation_prevents_subprocess(self):
        cancel = threading.Event()
        cancel.set()
        with patch('media_tools.subprocess.Popen') as process:
            with self.assertRaises(Cancelled):
                run(['unused'], cancel=cancel)
            process.assert_not_called()

    def test_duplicate_guard_and_ambiguous_failure(self):
        with tempfile.TemporaryDirectory() as folder:
            p = Path(folder) / 'video.mp4'
            p.write_bytes(b'test content')
            result = guarded_submit('youtube', 'test-channel', p, lambda: 'id', state_dir=folder)
            self.assertEqual(result, 'id')
            with self.assertRaises(RuntimeError):
                guarded_submit('youtube', 'test-channel', p, lambda: self.fail('duplicate'), state_dir=folder)
            with self.assertRaises(TimeoutError):
                guarded_submit('tiktok-inbox', 'test', p, lambda: (_ for _ in ()).throw(TimeoutError()), state_dir=folder)
            with self.assertRaises(RuntimeError):
                guarded_submit('tiktok-inbox', 'test', p, lambda: self.fail('ambiguous retry'), state_dir=folder)


if __name__ == '__main__':
    unittest.main()
