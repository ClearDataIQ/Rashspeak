from pathlib import Path
from copy import deepcopy
import array, math, wave
import tempfile
import unittest
from PIL import Image

from pro_project import Session,new_project,new_clip,import_media
from pro_render import render,package
from render_partitions import slice_video,partitions
from media_tools import run,probe


class PartitionTests(unittest.TestCase):
    def test_auto_short_export_kind_goes_into_shorts_folder(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);image=root/'card.png';Image.new('RGB',(320,180),'#275d80').save(image)
            s=Session(new_project(size=(320,180)));t=s.add_track('image');a=import_media(image)
            s.add(t,new_clip(a['id'],duration=30),a)
            item=render(s.project,root/'legacy_short.mp4');item['kind']='short'
            result=package(s.project,root/'bundle',[item])
            self.assertTrue((Path(result['folder'])/'Shorts/01_legacy_short.mp4').is_file())
            self.assertFalse(any((Path(result['folder'])/'Long_Video').iterdir()))
            import zipfile
            with zipfile.ZipFile(result['zip']) as archive:
                self.assertIn('bundle/Thumbnails/',archive.namelist())
                self.assertIn('bundle/Shorts/01_legacy_short.mp4',archive.namelist())

    def test_many_sequential_clips_export_with_exact_frames_and_continuous_audio(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);file=root/'image.png';Image.new('RGB',(320,180),'#275d80').save(file)
            s=Session(new_project(size=(320,180)));t=s.add_track('image');a=import_media(file)
            for i in range(130):s.add(t,new_clip(a['id'],start=i*2,duration=2),a if i==0 else None)
            voice=root/'signal.wav';run(['ffmpeg','-v','error','-y','-f','lavfi','-i','sine=frequency=440:duration=9',voice])
            track=s.add_track('audio');m=import_media(voice);s.add(track,new_clip(m['id'],duration=260),m)
            before=deepcopy(s.project);out=root/'full.mp4';result=render(s.project,out)
            self.assertGreater(result['render_parts'],1);self.assertEqual(s.project,before)
            metadata=__import__('json').loads(run(['ffprobe','-v','error','-count_frames','-show_streams','-of','json',out]))
            self.assertEqual(int(next(v for v in metadata['streams'] if v['codec_type']=='video')['nb_read_frames']),260)
            run(['ffmpeg','-v','error','-xerror','-i',out,'-f','null','-'])
            wav=root/'decoded.wav';run(['ffmpeg','-v','error','-y','-i',out,'-ac','1','-ar','48000','-c:a','pcm_s16le',wav])
            with wave.open(str(wav)) as stream:samples=array.array('h',stream.readframes(stream.getnframes()))
            boundary=partitions(s.project,s.seq['id'])[0][1]/30
            for a,b in ((boundary-.03,boundary-.01),(boundary-.01,boundary+.01),(boundary+.01,boundary+.03)):
                window=samples[round(a*48000):round(b*48000)]
                self.assertGreater(math.sqrt(sum(v*v for v in window)/len(window)),1000)

    def test_slicing_keeps_caption_text_and_partial_word_highlight(self):
        s=Session(new_project(size=(320,180)));t=s.add_track('text')
        s.add(t,new_clip(text='كلمة كاملة',duration=90,word_timing=[{'text':'كلمة','start':0,'end':50},{'text':'كاملة','start':50,'end':90}]))
        part=slice_video(s.project,s.seq['id'],30,70);c=part['sequences'][0]['tracks'][0]['clips'][0]
        self.assertEqual(c['text'],'كلمة كاملة')
        self.assertEqual(c['word_timing'],[{'text':'كلمة','start':0,'end':20},{'text':'كاملة','start':20,'end':40}])
