import copy
from pathlib import Path
import tempfile
import time
import tkinter as tk
from tkinter import messagebox
import unittest
from unittest.mock import patch

from editor_ui import Editor
from smart_editor import save
from demo import make_demo


class GuiTests(unittest.TestCase):
    def setUp(self):
        try:
            self.root = tk.Tk()
        except tk.TclError as exc:
            self.skipTest(str(exc))
        self.root.withdraw()
        self.editor = Editor(self.root, logger=lambda x: None)
        self.editor.pack(fill='both', expand=True)

    def tearDown(self):
        if hasattr(self, 'root'):
            self.root.destroy()

    def pump(self, timeout=10):
        end = time.monotonic() + timeout
        while self.editor.busy and time.monotonic() < end:
            self.root.update()
            time.sleep(.01)
        self.root.update()
        self.assertFalse(self.editor.busy)

    def test_worker_error_is_delivered_without_tk_thread_calls(self):
        with patch.object(messagebox, 'showerror') as error:
            self.editor.job('test', lambda: (_ for _ in ()).throw(ValueError('expected test error')))
            self.pump()
            self.assertEqual(error.call_args.args[1], 'expected test error')

    def test_project_load_analysis_and_edit_invalidates_review(self):
        with tempfile.TemporaryDirectory() as folder:
            data = make_demo(folder, test_fixtures=True)
            self.editor.load_project(Path(folder) / 'project.json')
            self.assertEqual(len(self.editor.assets), 5)
            self.assertEqual(len(self.editor.segments), 4)
            self.editor.analyze()
            self.pump()
            self.assertEqual(self.editor.timeline['shorts'][0]['start'], 10)
            self.editor.shot_tree.selection_set('1')
            self.editor.move_shot(1)
            self.assertIsNone(self.editor.timeline['review'])
            self.editor.shot_tree.selection_set('1')
            self.editor.remove_shot()
            from smart_editor import validate_timeline
            validate_timeline(self.editor.timeline)
            self.editor.save_project()
            self.assertTrue((Path(folder) / 'manifest.json').is_file())
