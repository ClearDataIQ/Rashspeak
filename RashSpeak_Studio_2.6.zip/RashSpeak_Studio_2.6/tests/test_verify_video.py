"""Extraction/blocked-state integration only. Generated signal is not human ASR evidence."""
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from media_tools import run
from verify_video import extract_audio, sha256, verify


class VideoVerificationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.video = self.root / 'local.mp4'
        run(['ffmpeg', '-v', 'error', '-y', '-f', 'lavfi', '-i', 'color=size=320x180:rate=30:duration=1',
             '-f', 'lavfi', '-i', 'sine=frequency=440:sample_rate=48000:duration=1',
             '-c:v', 'libx264', '-threads', '1', '-c:a', 'aac', '-shortest', self.video])

    def tearDown(self):
        self.tmp.cleanup()

    def test_extract_audio_preserves_source_and_rejects_overwrite(self):
        before = sha256(self.video)
        wav = self.root / 'original.wav'
        result = extract_audio(self.video, wav)
        self.assertEqual(before, sha256(self.video))
        self.assertTrue(result['source_preserved'])
        self.assertAlmostEqual(result['duration'], 1, delta=.05)
        wav_hash = sha256(wav)
        with self.assertRaises(ValueError):
            extract_audio(self.video, wav)
        self.assertEqual(wav_hash, sha256(wav))

    def test_missing_weights_produce_blocked_report_never_a_fake_success(self):
        destination = self.root / 'acceptance'
        with patch('verify_video.produce') as engine:
            with self.assertRaises(ValueError):
                verify(self.video, destination, script='تحديث لعبة', model=self.root / 'missing-model')
            engine.assert_not_called()
        report = json.loads((destination / 'verification.json').read_text(encoding='utf-8'))
        self.assertEqual(report['status'], 'blocked_or_failed')
        self.assertEqual(report['asr'], 'not_run')
        self.assertNotIn('outputs', report)
        self.assertTrue((destination / 'Original_Audio' / 'extracted_original.wav').is_file())
        with self.assertRaises(ValueError):
            verify(self.video, destination, script='تحديث لعبة')
