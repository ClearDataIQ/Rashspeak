import tkinter as tk
import unittest
from rtl_ui import Label, visual


class RtlTests(unittest.TestCase):
    def test_logical_text_is_not_changed_and_visual_is_repeatable(self):
        text='تحديث Fortnite 2026 مجاني'
        shown=visual(text)
        self.assertIn('Fortnite 2026',shown)
        self.assertNotEqual(shown,text)
        self.assertEqual(visual(shown),shown)
        self.assertEqual(visual('RASH 2.2'),'RASH 2.2')

    def test_stringvar_keeps_original_and_display_tracks_updates(self):
        try:root=tk.Tk()
        except tk.TclError as exc:self.skipTest(str(exc))
        try:
            source=tk.StringVar(root,value='جاهز للإنتاج')
            label=Label(root,textvariable=source)
            self.assertEqual(source.get(),'جاهز للإنتاج')
            self.assertEqual(label.display_variable.get(),visual(source.get()))
            source.set('اكتمل الإنتاج');root.update()
            self.assertEqual(label.display_variable.get(),visual('اكتمل الإنتاج'))
            label.destroy();source.set('تم')
        finally:root.destroy()
