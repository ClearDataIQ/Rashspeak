import copy
import os
from pathlib import Path
import tempfile
import unittest

from demo import make_demo
from media_tools import probe, run, tool
from smart_editor import approve, fingerprint, import_asset, validate_timeline
from timeline_render import render


class RenderTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        try:
            tool('ffmpeg')
            tool('ffprobe')
        except RuntimeError as exc:
            raise unittest.SkipTest(str(exc))

    def test_real_ffmpeg_arabic_gif_and_ranked_portrait(self):
        with tempfile.TemporaryDirectory(prefix='rash_عربي_') as folder:
            timeline = make_demo(folder, test_fixtures=True)
            self.assertEqual(timeline['shorts'][0]['start'], 10)
            self.assertEqual(len(timeline['memes']), 1)
            blocked = copy.deepcopy(timeline)
            blocked['memes'][0]['timestamp'] = 6.1
            with self.assertRaises(ValueError):
                validate_timeline(blocked)
            with self.assertRaises(ValueError):
                render(timeline, folder, final=True, size=(640, 360), portrait_size=(360, 640))
            approve(timeline, accept_warnings=True)
            results = render(timeline, folder, final=True, size=(640, 360), portrait_size=(360, 640), logger=lambda x: None)
            self.assertEqual(len(results), 2)
            self.assertEqual(results[0]['size'], [640, 360])
            self.assertEqual(results[1]['size'], [360, 640])
            self.assertAlmostEqual(results[0]['duration'], 14, delta=.12)
            self.assertAlmostEqual(results[1]['duration'], 4, delta=.12)
            # Decode every frame and audio packet; ffprobe alone does not prove playability.
            for item in results:
                run(['ffmpeg', '-v', 'error', '-i', item['path'], '-f', 'null', '-'])
            from PIL import Image, ImageChops
            before = Image.open(Path(folder) / 'RashSpeak_before.png').convert('RGB')
            after = Image.open(Path(folder) / 'RashSpeak_after.png').convert('RGB')
            self.assertIsNotNone(ImageChops.difference(before, after).getbbox())

    def test_still_motion_webp_transparency_font_and_music_disabled(self):
        from PIL import Image
        with tempfile.TemporaryDirectory() as folder:
            timeline = make_demo(folder, test_fixtures=True)
            frames = [Image.new('RGBA', (120, 120), (255, 20, 20, 180)), Image.new('RGBA', (120, 120), (20, 255, 20, 180))]
            webp = Path(folder) / 'meme.webp'
            frames[0].save(webp, save_all=True, append_images=frames[1:], duration=[120, 240], loop=0, lossless=True)
            meme = import_asset(webp, role='meme', mood='humor', license='own', source='synthetic', approved=True, previews=Path(folder) / 'previews')
            self.assertEqual(meme['kind'], 'animation')
            self.assertAlmostEqual(meme['duration'], .36, delta=.02)
            timeline['assets'].append(meme)
            timeline['memes'][0]['asset_id'] = meme['id']
            still = import_asset(timeline['assets'][-3]['path'], role='clip', game='fortnite', license='own', source='synthetic', approved=True)
            self.assertEqual(still['kind'], 'image')
            timeline['assets'].append(still)
            timeline['shots'][0]['asset_id'] = still['id']
            timeline['music'] = {'path': timeline['audio'], 'license': 'own', 'source': 'synthetic', 'usage_approved': True, 'volume': .04, 'fingerprint': fingerprint(timeline['audio'])}
            with self.assertRaisesRegex(ValueError,'الموسيقى معطلة'):
                validate_timeline(timeline)
            timeline['music'] = None
            timeline['caption']['style'] = 'cinematic'
            if Path('C:/Windows/Fonts/arial.ttf').is_file():
                timeline['caption']['font_file'] = 'C:/Windows/Fonts/arial.ttf'
            validate_timeline(timeline)
            results = render(timeline, folder, size=(640, 360), portrait_size=(360, 640), logger=lambda x: None)
            self.assertEqual(len(results), 2)
            run(['ffmpeg', '-v', 'error', '-i', results[0]['path'], '-f', 'null', '-'])
