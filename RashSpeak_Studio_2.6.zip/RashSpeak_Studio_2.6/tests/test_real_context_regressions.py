"""Entity and fallback regressions exposed by real narration; no original media in tests."""
from copy import deepcopy
import unittest

from licensed_media import topics, visual_suitable
from gemini_context import apply_visual_plan,validate_context,analyse
from gemini_client import GeminiError
import sound_effects


class ContextRegressionTests(unittest.TestCase):
    def test_low_confidence_cannot_reuse_previous_games_video(self):
        timeline={'assets':[{'id':'old','kind':'video','role':'clip','game':'The Witcher 3'}],
                  'segments':[{'start':0,'end':4,'text':'The tarnished will soon return',
                               'semantic':{'game':'Elden Ring','visual':'gameplay','confidence':.7,'reason':'مدخل اللعبة'}}],
                  'shots':[{'start':0,'end':4,'asset_id':'old','source_offset':0}]}
        apply_visual_plan(timeline,lambda text,index:{'id':'safe','editorial_card':True})
        self.assertEqual(timeline['shots'][0]['asset_id'],'safe')

    def test_known_backstage_and_cosplay_are_not_gameplay(self):
        for source in ('ELDEN_RING_OST_Behind_the_Scenes_with_Orchestra',
                       'The_Witcher_3_In_the_studio_with_Charles_Dance',
                       'Cyberpunk_2077_cosplayer'):
            for value in (source,source.replace('_','%20')):
                self.assertFalse(visual_suitable({'source':value},'gameplay'))
        self.assertTrue(visual_suitable({'title':'Elden Ring gameplay exploration'},'gameplay'))

    def test_backstage_video_is_replaced_by_card_even_for_same_game(self):
        asset={'id':'old','role':'clip','kind':'video','game':'Elden Ring','license':'CC BY 3.0',
               'source':'https://commons.wikimedia.org/wiki/File:Elden_Ring_Behind_the_Scenes.webm',
               'usage_approved':True}
        timeline={'assets':[asset],'segments':[{'start':0,'end':4,'text':'Elden Ring عالم مفتوح',
                  'semantic':{'game':'Elden Ring','visual':'gameplay','confidence':.95,'reason':'استكشاف'}}],
                  'shots':[{'start':0,'end':4,'asset_id':'old','source_offset':0}]}
        apply_visual_plan(timeline,lambda text,index:{'id':'safe','editorial_card':True})
        self.assertEqual(timeline['shots'][0]['asset_id'],'safe')

    def test_model_references_source_without_rewriting_dialect_evidence(self):
        text='المكتع هذا عدتها مليون مرة'
        row={'id':'s0000','game':'','event':'','idea':'افتتاحية','tone':'humor','importance':5,'confidence':.8,
             'visual':'title','meme':False,'effect':'none','reason':'افتتاحية','queries':[]}
        class Client:
            model='gemini-3.1-flash-lite';last_usage={}
            def generate(self,system,data,schema):
                self_schema=schema['properties']['segments']['items']
                assert 'evidence' not in self_schema['properties']
                return {'segments':[dict(row)],'shorts':[]}
        result=analyse(text,[{'start':0.,'end':4.,'text':text}],client=Client())
        self.assertEqual(result['segments'][0]['evidence'],text)
        row['id']='s9999'
        with self.assertRaises(GeminiError):analyse(text,[{'start':0.,'end':4.,'text':text}],client=Client())

    def test_transition_sound_stays_between_factual_speech(self):
        def segment(start,end,topic):
            return {'start':start,'end':end,'text':'معلومة عن اللعبة','story_topic':topic,'mode':'factual',
                    'asr_confidence':.95,'semantic':{'effect':'none'}}
        base={'type':'whoosh','duration':.42,'license':'Original procedural audio','source':'local creator','usage_approved':True}
        segments=[segment(0.,4.,'Minecraft'),segment(5.5,9.,'Fortnite')]
        effects=sound_effects.suggest({'segments':segments,'duration':10.},{'whoosh':base})
        self.assertEqual(len(effects),1);self.assertGreater(effects[0]['timestamp'],4)
        self.assertLess(effects[0]['timestamp']+effects[0]['duration'],5.5)
        sound_effects.validate(effects,10.,segments=segments,files=False)
        segments[1]['start']=4.1
        self.assertEqual(sound_effects.suggest({'segments':segments,'duration':10.},{'whoosh':base}),[])

    def test_quote_from_another_sentence_does_not_ground_this_row(self):
        segments=[{'start':0.,'end':4.,'text':'Minecraft عالم البناء'},
                  {'start':4.,'end':8.,'text':'Fortnite تحديث جديد'}]
        def row(i):
            return {'id':f's{i:04}','game':'','event':'','idea':'خبر','evidence':segments[0]['text'],
                    'tone':'neutral','importance':5,'confidence':.8,'visual':'title','meme':False,
                    'effect':'none','reason':'اختبار','queries':[]}
        with self.assertRaises(GeminiError):
            validate_context({'segments':[row(0),row(1)],'shorts':[]},'نص',segments)

    def test_spoken_game_aliases_resolve_metadata_without_rewriting_transcript(self):
        text = 'ردد ردمشن تو. سيبر بنك 2077. أساسن كريد ميراج.'
        original = text
        self.assertEqual(topics(text), ['Red Dead Redemption 2', 'Cyberpunk 2077', "Assassin's Creed Mirage"])
        self.assertEqual(text, original)
        self.assertNotIn('Cyberpunk 2077', topics('الأجواء السيبر بانكية جميلة'))

    def test_previous_game_card_cannot_cover_another_semantic_game(self):
        current = {'id':'old','editorial_card':True,'game':'Fortnite'}
        row = {'game':'Minecraft','visual':'gameplay','confidence':.95,'reason':'الحديث عن ماينكرافت'}
        timeline = {'assets':[current], 'segments':[{'start':0,'end':4,'text':'ماينكرافت عالم البناء','semantic':row}],
                    'shots':[{'start':0,'end':4,'asset_id':'old','source_offset':0}]}
        def card(text, index):
            return {'id':'new','editorial_card':True,'game':text}
        created=apply_visual_plan(timeline,card)
        self.assertEqual(timeline['shots'][0]['asset_id'],'new')
        self.assertEqual(created[0]['game'],'Minecraft')
