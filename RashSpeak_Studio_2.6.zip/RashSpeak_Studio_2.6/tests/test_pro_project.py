import copy
import json
from pathlib import Path
import tempfile
import unittest

from pro_project import Session,new_project,new_clip,sequence,validate,write_project,load_project


def fixture():
    p=new_project(fps=30,size=(320,180));s=Session(p);track=s.add_track('video')
    a={'id':'source','kind':'video','duration':20,'path':'/original.mp4','has_audio':False,
       'fingerprint':{'size':1,'mtime_ns':1},'license':'owned','source':'local','usage_approved':True}
    first=s.add(track,new_clip('source',0,90,0),a);second=s.add(track,new_clip('source',90,90,90));third=s.add(track,new_clip('source',180,90,180))
    return s,track,first,second,third


class ProjectTests(unittest.TestCase):
    def test_split_trim_move_undo_redo_are_frame_exact_and_non_destructive(self):
        s,t,a,b,c=fixture();source=copy.deepcopy(s.project['media']);right=s.split(a,31)
        self.assertEqual(s.clip(right)[1]['in'],31);self.assertEqual(s.clip(a)[1]['duration'],31)
        s.trim(right,35,89);self.assertEqual(s.clip(right)[1]['in'],35)
        s.move(right,40);self.assertEqual(s.clip(right)[1]['in'],35)
        state=copy.deepcopy(s.project);s.undo();s.redo();self.assertEqual(state,s.project);self.assertEqual(source,s.project['media'])

    def test_invalid_edit_is_atomic_and_does_not_enter_history(self):
        s,t,a,b,c=fixture();before=copy.deepcopy(s.project);count=len(s.undo_stack)
        with self.assertRaises(ValueError):s.trim(a,-1,900)
        self.assertEqual(before,s.project);self.assertEqual(count,len(s.undo_stack))
        s.track_state(t,locked=True)
        with self.assertRaises(ValueError):s.split(a,20)
        with self.assertRaises(ValueError):s.move(a,2)

    def test_ripple_checks_all_tracks_and_locked_tracks_before_change(self):
        s,t,a,b,c=fixture();s.delete([b],ripple=True);self.assertEqual(s.clip(c)[1]['start'],90)
        s.undo();audio=s.add_track('audio');asset={'id':'voice','kind':'audio','duration':20,'path':'/voice.wav','has_audio':True,'fingerprint':{},'license':'owned','source':'local','usage_approved':True}
        voice=s.add(audio,new_clip('voice',0,270),asset);before=copy.deepcopy(s.project)
        with self.assertRaises(ValueError):s.delete([b],ripple=True)
        self.assertEqual(before,s.project)
        s.delete([voice]);s.track_state(t,locked=True)
        with self.assertRaises(ValueError):s.delete([b],ripple=True)

    def test_group_copy_snap_and_locked_member(self):
        s,t,a,b,c=fixture();s.group([a,b]);s.move(a,10);self.assertEqual(s.clip(b)[1]['start'],100)
        s.copy([a]);ids=s.paste(300);self.assertEqual(len(ids),2);self.assertNotEqual(s.clip(ids[0])[1]['group'],s.clip(a)[1]['group'])
        s.group([a,b],True);s.move(a,175,snap=True);self.assertEqual(s.clip(a)[1]['start'],180)

    def test_slip_roll_slide_source_continuity(self):
        s,t,a,b,c=fixture();s.slip(b,10);self.assertEqual(s.clip(b)[1]['in'],100)
        s.roll(a,b,10);self.assertEqual(s.clip(a)[1]['duration'],100);self.assertEqual(s.clip(b)[1]['start'],100);self.assertEqual(s.clip(b)[1]['in'],110)
        s.slide(b,a,c,5);self.assertEqual(s.clip(b)[1]['start'],105);self.assertEqual(s.clip(c)[1]['start'],185)
        self.assertEqual(s.clip(c)[1]['in'],185)

    def test_save_reload_recovery_and_short_keep_same_sources(self):
        s,t,a,b,c=fixture()
        with tempfile.TemporaryDirectory() as folder:
            file=Path(folder)/'project.rash.json';s.save(file);s.move(a,2)
            self.assertEqual(load_project(file)['sequences'][0]['tracks'][0]['clips'][0]['start'],0)
            recovered=load_project(file.with_suffix('.autosave.json'));self.assertEqual(recovered,s.project)
            s.save();self.assertEqual(load_project(file),s.project)
            main=s.project['active_sequence'];key=s.make_short(20,200)
            short=sequence(s.project,key);self.assertEqual((short['width'],short['height']),(1080,1920))
            self.assertEqual(short['source_range']['sequence'],main);self.assertEqual(short['tracks'][0]['clips'][0]['in'],18)
            self.assertEqual(short['tracks'][0]['clips'][0]['start'],0);validate(s.project)

    def test_rejects_invalid_schema_frames_source_and_nonfinite_properties(self):
        s,t,a,b,c=fixture()
        for changes in ({'start':.1},{'duration':0},{'in':900},{'gain_db':float('nan')}):
            p=copy.deepcopy(s.project);p['sequences'][0]['tracks'][0]['clips'][0].update(changes)
            with self.assertRaises(ValueError):validate(p)

    def test_new_edit_after_undo_has_unique_revision_and_failed_autosave_rolls_back(self):
        from unittest.mock import patch
        s,t,a,b,c=fixture();s.move(a,5);revision=s.project['revision'];s.undo();s.move(a,8)
        self.assertGreater(s.project['revision'],revision)
        before=copy.deepcopy(s.project);count=len(s.undo_stack)
        with tempfile.TemporaryDirectory() as folder:
            s.path=Path(folder)/'project.rash.json'
            with patch('pro_project.write_project',side_effect=OSError('disk full')):
                with self.assertRaises(OSError):s.move(a,10)
        self.assertEqual(before,s.project);self.assertEqual(count,len(s.undo_stack))
