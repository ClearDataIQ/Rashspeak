"""Offline tests; no real account linking or publish calls."""
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import publisher as p

class Resp:
    def __init__(self,data,status_code=200):self.data=data;self.status_code=status_code
    def json(self):return self.data

class PublisherTests(unittest.TestCase):
    def test_tiktok_chunk_calculation(self):
        self.assertEqual(p.chunk_plan(4_194_304),(4_194_304,[(0,4_194_304)]))
        chunk,spans=p.chunk_plan(50_000_123)
        self.assertEqual(chunk,50_000_123);self.assertEqual(spans,[(0,50_000_123)])
        chunk,spans=p.chunk_plan(100_000_123)
        self.assertEqual(chunk,20_000_000);self.assertEqual(len(spans),5)
        self.assertEqual(spans[-1],(80_000_000,100_000_123))
        self.assertEqual(sum(b-a for a,b in spans),100_000_123)

    def test_tiktok_authorize_pkce_and_state(self):
        url,state,verifier=p.tiktok_authorize_url({'tiktok_client_key':'example','tiktok_redirect':'http://127.0.0.1:8585/callback'})
        self.assertIn('www.tiktok.com/v2/auth/authorize',url)
        self.assertNotIn('client_secret',url)
        self.assertIn('code_challenge=',url)
        self.assertGreater(len(state),20);self.assertGreater(len(verifier),43)

    def test_instagram_prohibits_non_https_or_non_media_url(self):
        with patch.object(p,'secret_get',return_value='fake'):
            opts={'ig_account_id':'1234','ig_api_version':'v24.0'}
            for url in ['file:///home/video.mp4','http://x.test/file.mp4','https://x.test/file.txt']:
                with self.assertRaises(ValueError):p.ig_publish_reel(opts,url,'caption',consent=True)

    def test_tiktok_draft_upload_one_chunk(self):
        with tempfile.TemporaryDirectory() as folder:
            media=Path(folder)/'short.mp4';media.write_bytes(b'0'*65536)
            init=Resp({'data':{'publish_id':'draft123','upload_url':'https://upload.tiktokapis.com/video/?id=example'},'error':{'code':'ok'}})
            done=Resp({},201)
            with patch.object(p,'tiktok_access',return_value='fake'),patch.object(p.requests,'post',return_value=init) as post,patch.object(p.requests,'put',return_value=done) as put:
                result=p.tiktok_upload_draft({},media,lambda x:None,consent=True)
            self.assertEqual(result,'draft123')
            args=post.call_args.kwargs['json']['source_info']
            self.assertEqual(args['total_chunk_count'],1)
            self.assertEqual(put.call_args.kwargs['headers']['Content-Range'],'bytes 0-65535/65536')
            self.assertEqual(len(put.call_args.kwargs['data']),65536)

    def test_instagram_oauth_state_checked(self):
        with patch.object(p,'secret_get',side_effect=lambda k: {'instagram_client_secret':'x','ig_pending_state':'xyz'}.get(k)):
            cfg={'ig_redirect':'https://example.org/oauth/callback'}
            with self.assertRaisesRegex(RuntimeError,'state mismatch'):
                p.ig_finish_oauth(cfg,'https://example.org/oauth/callback?code=fake&state=invalid')

if __name__=='__main__':unittest.main()
