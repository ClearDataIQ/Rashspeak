from pathlib import Path
import tempfile
import unittest
import queue,time,json
from copy import deepcopy
from PIL import Image

from job_queue import ExportQueue
from pro_project import Session,new_project,new_clip,import_media
from media_tools import run,probe,Cancelled
from media_library import remember,search
from preview_cache import prune
from preview_player import PreviewPlayer


class SystemTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);image=self.root/'media.png';Image.new('RGB',(320,180),'blue').save(image)
        s=Session(new_project(size=(320,180)));t=s.add_track('image');a=import_media(image);s.add(t,new_clip(a['id'],duration=60),a);self.project=s.project;self.asset=a
    def tearDown(self):self.tmp.cleanup()

    def wait(self,q):
        end=time.monotonic()+15
        while q.worker and q.worker.is_alive() and time.monotonic()<end:time.sleep(.03)
        self.assertFalse(q.worker.is_alive())

    def test_persistent_queue_real_export_snapshot_and_failure_retry(self):
        q=ExportQueue(self.root/'jobs');output=self.root/'export.mp4';key=q.enqueue(self.project,output);self.wait(q)
        row=q.rows()[0];self.assertEqual(row['status'],'completed');self.assertEqual(row['progress'],100);self.assertEqual(float(probe(output)['format']['duration']),2.)
        q.close();opened=ExportQueue(self.root/'jobs');self.assertEqual(opened.rows()[0]['id'],key)
        calls=[]
        def processor(*args,**kwargs):
            calls.append(1)
            if len(calls)==1:raise RuntimeError('test failure')
            return {'path':str(self.root/'retied.mp4')}
        q=ExportQueue(self.root/'retry',processor=processor);key=q.enqueue(self.project,self.root/'retry.mp4');self.wait(q)
        self.assertEqual(q.rows()[0]['status'],'failed');q.retry(key);self.wait(q);self.assertEqual(q.rows()[0]['status'],'completed');self.assertEqual(q.rows()[0]['attempts'],2);q.close()

    def test_dead_worker_recovery_and_cancellation(self):
        q=ExportQueue(self.root/'recover');q.start=lambda:None;key=q.enqueue(self.project,self.root/'recover.mp4')
        with q.db() as db:db.execute("UPDATE jobs SET status='running',owner=99999999 WHERE id=?",(key,))
        recovered=ExportQueue(self.root/'recover');self.assertEqual(recovered.rows()[0]['status'],'queued');recovered.start();self.wait(recovered);recovered.close()
        def slow(p,out,cancel,on_progress,**kwargs):
            while not cancel.wait(.02):pass
            raise Cancelled('test cancelled')
        q=ExportQueue(self.root/'cancel',processor=slow);key=q.enqueue(self.project,self.root/'cancel.mp4')
        end=time.monotonic()+2
        while q.rows()[0]['status']!='running' and time.monotonic()<end:time.sleep(.01)
        q.cancel_job(key);self.wait(q);self.assertEqual(q.rows()[0]['status'],'cancelled');q.close()

    def test_library_deduplicates_content_and_conflicting_rights_remain_pending(self):
        db=self.root/'library.sqlite3';a=remember(self.asset,db);b=remember({**self.asset,'id':'new'},db)
        self.assertEqual(a['id'],b['id']);self.assertEqual(len(search(path=db)),1)
        remember({**self.asset,'license':'different'},db)
        self.assertEqual(search(path=db,approved_only=True),[]);self.assertFalse(search(path=db)[0]['usage_approved'])
        Path(self.asset['path']).write_bytes(b'changed');self.assertEqual(search(path=db),[])

    def test_cache_cleanup_protects_original_and_only_owned_names(self):
        cache=self.root/'cache';cache.mkdir();old=cache/('a'*64+'.mp4');old.write_bytes(b'0'*100)
        source=cache/('b'*64+'.mp4');source.write_bytes(b'1'*100);other=cache/'private_user_file.mp4';other.write_bytes(b'2'*100)
        removed=prune(cache,max_bytes=100,protected=[source]);self.assertIn(str(old),removed);self.assertTrue(source.exists());self.assertTrue(other.exists())

    def test_internal_player_decodes_real_frames_pause_seek_and_audio_unavailable_status(self):
        file=self.root/'proxy.mp4';run(['ffmpeg','-v','error','-y','-f','lavfi','-i','testsrc2=size=320x180:rate=30:duration=1',
            '-f','lavfi','-i','sine=frequency=440:duration=1','-c:v','libx264','-threads','1','-c:a','aac','-shortest',file])
        events=queue.Queue()
        def unavailable(*args):raise OSError('no device')
        player=PreviewPlayer(events,audio_factory=unavailable);player.start(file,.3);deadline=time.monotonic()+4;frames=[];status=None
        while time.monotonic()<deadline:
            try:
                kind,value,_=events.get(timeout=.2)
                if kind=='player_frame':frames.append(value['seconds'])
                if kind=='player_status':status=value
                if kind=='player_end':break
            except queue.Empty:pass
        self.assertFalse(status['audio']);self.assertGreater(len(frames),5);self.assertGreaterEqual(min(frames),.29)
        player.stop();token=player.token;player.start(file,.6);self.assertGreater(player.token,token);player.stop();self.assertFalse(player.running)
