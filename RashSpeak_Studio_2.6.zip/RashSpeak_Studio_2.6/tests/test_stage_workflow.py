import array
import copy
import json
import math
from pathlib import Path
import queue
import tempfile
import threading
import unittest
import wave
from unittest.mock import patch
from PIL import Image

from production import produce, STAGES
from stage_review import ReviewBridge
from media_tools import Cancelled, run
from smart_editor import import_asset, reaction, save, plan
from sound_effects import library, suggest, validate, preview, filters
from test_production import words, signal


def fixture(root):
    script='فورتنايت خبر جديد. هههه ضحكت مرة.'
    units=words('فورتنايت خبر فورتنايت خبر جديد. هههه ضحكت مرة.',spacing=.65)
    file=root/'original.wav';signal(file,units,units[-1]['end']+.5)
    image=root/'clip.png';Image.new('RGB',(640,360),'#245970').save(image)
    assets=[import_asset(image,game='Fortnite',license='Original test',source='Generated test',approved=True),
            import_asset(image,role='meme',mood='humor',license='Original test',source='Generated test',approved=True)]
    return file,script,{'words':units,'segments':[]},assets


class SoundTests(unittest.TestCase):
    def test_original_library_is_repeatable_and_does_not_change_fingerprints(self):
        with tempfile.TemporaryDirectory() as folder:
            first=library(folder);second=library(folder)
            self.assertEqual(first,second)
            for e in first.values():
                self.assertLessEqual(e['duration'],.45);self.assertIn('procedural',e['license'])
                with wave.open(e['path']) as f:self.assertEqual(f.getframerate(),48000)

    def test_protected_uncertain_and_negated_contexts_do_not_get_sfx_or_memes(self):
        with tempfile.TemporaryDirectory() as folder:
            available=library(folder)
            for text in ['هههه السعر 70 دولار','هههه تسريح موظفين','مو مضحك ولا مزحه','مو مفاجأة']:
                self.assertIsNone(reaction(text))
                timeline={'duration':10,'memes':[],'segments':[{'start':0,'end':4,'text':text}]}
                self.assertEqual(suggest(timeline,available),[])
            timeline={'duration':10,'memes':[],'segments':[{'start':0,'end':4,'text':'هههه ضحكت','asr_confidence':.2}]}
            self.assertEqual(suggest(timeline,available),[])

    def test_effect_timing_level_rights_and_rate_limits_revalidated(self):
        with tempfile.TemporaryDirectory() as folder:
            base=library(folder)['pop']
            effect={**base,'id':'a','timestamp':1,'gain_db':-20,'approved':True}
            validate([effect],40)
            for changes in [{'timestamp':-1},{'gain_db':0},{'duration':2},{'usage_approved':False}]:
                with self.assertRaises(ValueError):validate([{**effect,**changes}],40)
            with self.assertRaises(ValueError):validate([effect,{**effect,'id':'b','timestamp':2}],40)
            with self.assertRaises(ValueError):validate([effect],40,[{'start':0,'end':3,'text':'تحذير مهم.'}])

    def test_short_start_inside_effect_seeks_and_trims_remaining_part(self):
        effect={'approved':True,'timestamp':1.8,'duration':.45,'path':'effect.wav','gain_db':-20}
        inputs,graph=filters([effect],2,3,first_index=5)
        self.assertAlmostEqual(float(inputs[1]),.2)
        self.assertIn('[5:a]',graph[1]);self.assertIn('duration=0.25',graph[1])
        self.assertIn('sidechaincompress',graph[2])
        self.assertEqual(filters([effect],3,4)[0],[])

    def test_real_mix_ducks_effect_under_voice_and_leaves_voice_present(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);rate=48000;file=root/'original_voice.wav'
            samples=array.array('h',(round(9000*math.sin(i*2*math.pi*300/rate)) if i<rate*1.5 else 0 for i in range(rate*4)))
            with wave.open(str(file),'wb') as f:
                f.setnchannels(1);f.setsampwidth(2);f.setframerate(rate);f.writeframes(samples.tobytes())
            base=library(root/'effects')['whoosh'];data=[]
            for name,at in [('plain',None),('voice',.2),('silence',2.2)]:
                effects=[] if at is None else [{**base,'id':'test','timestamp':at,'gain_db':-12,'approved':True}]
                output=root/(name+'.wav');preview(file,effects,output,4,already_processed=True)
                with wave.open(str(output)) as f:data.append(array.array('h',f.readframes(f.getnframes())))
            def delta(index,start):
                begin=round(start*rate)*2;stop=round((start+.45)*rate)*2
                return math.sqrt(sum((data[index][i]-data[0][i])**2 for i in range(begin,stop))/(stop-begin))
            self.assertGreater(delta(1,.2),1)
            self.assertLess(delta(1,.2),delta(2,2.2)*.7)
            self.assertGreater(max(abs(x) for x in data[1][:rate*2]),5000)


class BridgeTests(unittest.TestCase):
    def test_waits_for_explicit_matching_response_and_ignores_stale_tokens(self):
        events=queue.Queue();cancel=threading.Event();bridge=ReviewBridge(events,cancel);result=[]
        worker=threading.Thread(target=lambda:result.append(bridge({'key':'audio'})));worker.start()
        request=events.get(timeout=2)
        self.assertTrue(worker.is_alive());self.assertEqual(result,[])
        self.assertFalse(bridge.submit(request['token']+1,{'action':'approve'}))
        self.assertTrue(bridge.submit(request['token'],{'action':'approve'}))
        self.assertFalse(bridge.submit(request['token'],{'action':'approve'}))
        worker.join(2);self.assertEqual(result,[{'action':'approve'}])

    def test_cancel_unblocks_wait_without_user_approval(self):
        events=queue.Queue();cancel=threading.Event();bridge=ReviewBridge(events,cancel);errors=[]
        def work():
            try:bridge({'key':'audio'})
            except Cancelled:errors.append(True)
        worker=threading.Thread(target=work);worker.start();events.get(timeout=2);cancel.set();worker.join(2)
        self.assertFalse(worker.is_alive());self.assertEqual(errors,[True])


class WorkflowTests(unittest.TestCase):
    def test_review_every_phase_revise_preview_and_optional_memes_then_deliver(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);audio,script,detailed,assets=fixture(root);seen=[];visits={}
            def review(request):
                key=request['key'];seen.append(key);visits[key]=visits.get(key,0)+1
                self.assertFalse((root/'project/runs/run_001/delivery').exists())
                self.assertTrue(all(Path(p['path']).exists() for p in request['previews']))
                data=copy.deepcopy(request['data'])
                if key=='audio' and visits[key]==1:
                    for e in data['edits']:e['action']='keep'
                    data['processing']['denoise']=False
                    return {'action':'revise','data':data}
                if key=='reactions' and visits[key]==1:
                    data['memes']=[];return {'action':'revise','data':data}
                if key=='delivery' and visits[key]==1:
                    data['title']='عنوان يختاره صاحب القناة';return {'action':'revise','data':data}
                return {'action':'approve'}
            result=produce(audio,script,root/'project',online=False,asr_override=detailed,assets_override=assets,
                           sizes={'size':(640,360),'portrait_size':(360,640)},on_review=review,quality_mode='draft')
            self.assertEqual(list(dict.fromkeys(seen)),[k for k,label in STAGES])
            self.assertEqual([label for key,label in STAGES],['تعديل الصوت','تركيب اللقطات','إضافة المؤثرات','الميمز عند الحاجة','المونتاج والشورتات','تجهيز الملفات للرفع'])
            self.assertTrue(all(r['approved_by_owner'] for r in result['stage_reviews'].values()))
            self.assertEqual(result['stage_reviews']['audio']['revision'],2)
            self.assertEqual(result['reaction_count'],0);self.assertFalse(result['published'])
            delivery=Path(result['delivery']);self.assertFalse((delivery/'thumbnail.jpg').exists())
            self.assertEqual((delivery/'title.txt').read_text(),'عنوان يختاره صاحب القناة')
            self.assertFalse(result['review_required'])
            for f in result['files']:run(['ffmpeg','-v','error','-i',f['path'],'-f','null','-'])

    def test_audio_review_cancellation_does_not_start_media_or_deliver(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);audio,script,detailed,assets=fixture(root);seen=[]
            def review(request):seen.append(request['key']);return {'action':'cancel'}
            with self.assertRaises(Cancelled):produce(audio,script,root/'project',asr_override=detailed,on_review=review)
            self.assertEqual(seen,['audio'])
            state=json.loads((root/'project/production.json').read_text())
            self.assertEqual(state['status'],'cancelled');self.assertNotIn('media',state['stages'])
            self.assertFalse((root/'project/runs/run_001/delivery').exists())

    def test_cannot_approve_changed_data_without_new_preview(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);audio,script,detailed,assets=fixture(root)
            def review(request):
                data=copy.deepcopy(request['data']);data['processing']['highpass']=0
                return {'action':'approve','data':data}
            with self.assertRaisesRegex(ValueError,'المعاينة'):produce(audio,script,root/'project',asr_override=detailed,on_review=review)

    def test_low_confidence_asr_cut_is_kept_for_owner_review(self):
        import audio_edit
        units=words('خبر جديد خبر جديد.');units[0]['probability']=.2
        analysis=audio_edit.analyse('خبر جديد.',units,[],2)
        self.assertTrue(any(e.get('review_needed') and e['action']=='keep' for e in analysis['edits']))

    def test_generic_pacing_ignores_reference_video_urls_and_sequences(self):
        from channel_style import DEFAULT
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);audio,script,detailed,assets=fixture(root)
            segments=[{'start':0,'end':3,'text':'فورتنايت خبر.'},{'start':3,'end':5,'text':'فورتنايت تحديث جديد.'}]
            a=copy.deepcopy(DEFAULT);b=copy.deepcopy(DEFAULT);b['references']=[{'url':'https://example.test/unrelated','title':'different reference'}]
            with patch('channel_style.load_profile',return_value=a):first=plan(audio,{'assets':assets},segments,adaptive=True)
            with patch('channel_style.load_profile',return_value=b):second=plan(audio,{'assets':assets},segments,adaptive=True)
            self.assertEqual(first['shots'],second['shots'])
