from copy import deepcopy
from pathlib import Path
import tempfile
import unittest
from PIL import Image,ImageDraw
from media_tools import run
from pro_project import Session,new_project,new_clip,import_media,validate,curve_value
from pro_render import render


class OverlayTests(unittest.TestCase):
    def test_three_cropped_layers_and_transparent_animated_gif_really_render(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);base=root/'base.png';Image.new('RGB',(320,180),'#101020').save(base)
            gif=root/'cutout.gif';images=[]
            for x in (2,6):
                image=Image.new('RGBA',(80,80),(0,0,0,0));ImageDraw.Draw(image).rectangle((x,20,x+25,60),fill='red');images.append(image)
            images[0].save(gif,save_all=True,append_images=images[1:],duration=200,loop=0,disposal=2,transparency=0)
            side=root/'crop.png';image=Image.new('RGB',(80,80),'blue');ImageDraw.Draw(image).rectangle((40,0,79,79),fill='lime');image.save(side)
            s=Session(new_project(size=(320,180)));video=s.add_track('video');a=import_media(base);s.add(video,new_clip(a['id'],duration=60),a)
            tracks=[s.add_overlay(f'Overlay {i}') for i in range(3)];g=import_media(gif);b=import_media(side)
            s.add(tracks[0],new_clip(g['id'],duration=60,loop=True,transform={'x':0.,'y':0.,'scale':.5,'opacity':1.}),g)
            crop={'left':.5,'top':0.,'right':0.,'bottom':0.}
            key=s.add(tracks[1],new_clip(b['id'],duration=60,crop=crop,transform={'x':.5,'y':0.,'scale':.5,'opacity':1.}),b)
            out=root/'overlay.mp4';render(s.project,out)
            image=root/'frame.png';run(['ffmpeg','-v','error','-y','-ss','0.1','-i',out,'-frames:v','1',image])
            with Image.open(image) as im:
                green=im.getpixel((235,40));empty=im.getpixel((20,10));red=im.getpixel((55,40))
                self.assertGreater(green[1],180);self.assertLess(green[2],50)
                self.assertLess(max(empty),60);self.assertGreater(red[0],170)
            s.track_state(tracks[1],locked=True)
            with self.assertRaises(ValueError):s.properties(key,crop={'left':.96,'top':0.,'right':0.,'bottom':0.})

    def test_keyframe_position_and_fade_show_in_export_and_survive_undo(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);image=root/'red.png';Image.new('RGB',(320,180),'red').save(image)
            s=Session(new_project(size=(320,180)));t=s.add_overlay();a=import_media(image)
            k=s.add(t,new_clip(a['id'],duration=90,transform={'x':0.,'y':0.,'scale':.25,'opacity':1.},fade_in=15),a)
            keys={'x':[{'frame':0,'value':0.,'easing':'linear'},{'frame':60,'value':.65,'easing':'ease_in'}]}
            s.properties(k,keyframes=keys);state=deepcopy(s.project);s.undo();s.redo();self.assertEqual(s.project,state)
            out=root/'animated.mp4';render(s.project,out)
            def pixel(at,x,y):
                file=root/'sample.png';run(['ffmpeg','-v','error','-y','-ss',at,'-i',out,'-frames:v','1',file])
                with Image.open(file) as im:return im.getpixel((x,y))
            early=pixel(0.,10,10);middle=pixel(1.,60,10);late=pixel(2.2,240,10)
            self.assertLess(early[0],100);self.assertGreater(middle[0],180);self.assertGreater(late[0],180)
            self.assertLess(pixel(2.2,20,10)[0],100)
            s.trim(k,10,80);validate(s.project);self.assertAlmostEqual(curve_value(s.clip(k)[1],'x',0),.65*(10/60)**2)
            s.set_fps(60);validate(s.project)

    def test_invalid_crop_and_keyframes_leave_document_unchanged(self):
        p=new_project(size=(320,180));s=Session(p);t=s.add_track('text');k=s.add(t,new_clip(text='كلام صحيح',duration=60))
        before=deepcopy(s.project)
        for change in ({'crop':{'left':.6,'right':.6,'top':0,'bottom':0}}, {'keyframes':{'x':[{'frame':60,'value':.3,'easing':'linear'}]}}):
            with self.assertRaises(ValueError):s.properties(k,**change)
            self.assertEqual(s.project,before)
