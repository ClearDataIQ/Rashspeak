from copy import deepcopy
import gc
import json
from pathlib import Path
import tempfile
import time
import tkinter as tk
import unittest
from unittest.mock import patch
from PIL import Image

from pro_project import Session,new_project,new_clip,import_media,load_project
from pro_editor_ui import ProEditor


class UITests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.folder=Path(self.temp.name)
        self.root=tk.Tk();self.root.geometry('1440x1000')
        image=self.folder/'original.png';Image.new('RGB',(320,180),'#23708a').save(image)
        s=Session(new_project(size=(320,180)));t=s.add_track('image');a=import_media(image)
        self.key=s.add(t,new_clip(a['id'],0,90),a);self.track=t
        self.path=self.folder/'project.rash.json';s.save(self.path)
        self.editor=ProEditor(self.root,self.path);self.editor.pack(fill='both',expand=True);self.root.update()
        self.editor.selected=[self.key];self.editor.refresh()

    def tearDown(self):
        self.root.destroy();self.editor=None;self.root=None;gc.collect();self.temp.cleanup()

    def pump(self):
        deadline=time.monotonic()+15
        while self.editor.busy and time.monotonic()<deadline:self.root.update();time.sleep(.02)
        self.root.update();self.assertFalse(self.editor.busy)

    def test_canvas_drag_trim_properties_undo_save_reopen(self):
        # Drag body one second, not a fabricated visual position.
        self.editor.canvas.event_generate('<Button-1>',x=35,y=50)
        self.editor.canvas.event_generate('<B1-Motion>',x=115,y=50)
        self.editor.canvas.event_generate('<ButtonRelease-1>',x=115,y=50);self.root.update()
        self.assertEqual(self.editor.session.clip(self.key)[1]['start'],30)
        self.editor.props['end'].set('110');self.editor.props['x'].set('.1');self.editor.apply_properties()
        self.assertEqual(self.editor.session.clip(self.key)[1]['duration'],80)
        changed=deepcopy(self.editor.session.project);self.editor.command(self.editor.session.undo);self.editor.command(self.editor.session.redo)
        self.assertEqual(changed,self.editor.session.project);self.editor.save()
        self.assertEqual(load_project(self.path),changed)

    def test_real_background_frame_preview_and_lock_rejects_edit(self):
        self.editor.preview_frame();self.pump();self.assertIsNotNone(self.editor.image)
        self.assertEqual(self.editor.preview_revision,self.editor.session.project['revision'])
        self.editor.session.track_state(self.track,locked=True)
        with patch('pro_editor_ui.messagebox.showerror') as error:
            self.editor.command(lambda:self.editor.session.move(self.key,10));error.assert_called_once()
        self.assertEqual(self.editor.session.clip(self.key)[1]['start'],0)

    def test_recovers_unsaved_document_and_does_not_overwrite_legacy(self):
        self.editor.command(lambda:self.editor.session.move(self.key,10));self.editor.destroy();self.root.update()
        reopened=ProEditor(self.root,self.path);reopened.pack();self.editor=reopened;self.root.update()
        self.assertEqual(reopened.session.clip(self.key)[1]['start'],10)
        reopened.session.undo();self.assertEqual(reopened.session.clip(self.key)[1]['start'],0)

    def test_shortcuts_leave_text_input_to_native_editor(self):
        self.editor.caption.focus_set();self.root.update()
        event=type('Event',(),{'widget':self.editor.caption})()
        before=deepcopy(self.editor.session.project);self.assertIsNone(self.editor.key_action(event,'delete'))
        self.assertEqual(before,self.editor.session.project)

    def test_auto_exports_seed_zip_and_edit_excludes_stale_export(self):
        from pro_render import render
        from smart_editor import fingerprint
        output=self.folder/'accepted.mp4';record=render(self.editor.session.project,output)
        record.update(fingerprint=fingerprint(output),kind='long')
        self.editor.destroy();self.root.update()
        self.editor=ProEditor(self.root,self.path,exports=[record]);self.editor.pack();self.root.update()
        self.assertEqual(len(self.editor.exported),1)
        self.editor.session.properties(self.key,transform={'x':0.,'y':0.,'scale':1.,'opacity':.5})
        with patch('pro_editor_ui.filedialog.askdirectory',return_value=str(self.folder)):
            self.editor.bundle();self.pump()
        packaged=next(self.folder.glob('RashSpeak_Project_*'))
        if packaged.is_file():packaged=next(p for p in self.folder.glob('RashSpeak_Project_*') if p.is_dir())
        self.assertEqual(list((packaged/'Long_Video').iterdir()),[])
