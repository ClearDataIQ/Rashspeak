import copy
from datetime import datetime, timezone
from pathlib import Path
import tempfile
import tkinter as tk
from tkinter import messagebox
import unittest
from unittest.mock import patch

from channel_style import DEFAULT, long_description, top5_script, validate_profile
from newsroom import SOURCES, article_excerpt, enrich_item, parse_feed, script
from top5_ui import REFERENCE_LIST, Top5Panel
from news_ui import NewsroomPanel
from editor_ui import Editor
from thumbnail import make_thumbnail
from smart_editor import import_asset


class ChannelTests(unittest.TestCase):
    def test_feed_freshness_hosts_and_html(self):
        payload=b'''<rss><channel><item><title>New update</title><link>https://blog.playstation.com/new</link><pubDate>Tue, 13 Oct 2026 12:00:00 GMT</pubDate><description>&lt;p&gt;Available now.&lt;/p&gt;</description></item><item><title>Old</title><link>https://blog.playstation.com/old</link><pubDate>Tue, 01 Sep 2026 12:00:00 GMT</pubDate></item><item><title>Wrong host</title><link>https://example.com/x</link><pubDate>Tue, 13 Oct 2026 12:00:00 GMT</pubDate></item></channel></rss>'''
        result=parse_feed(payload,SOURCES[0],datetime(2026,10,14,tzinfo=timezone.utc))
        self.assertEqual(len(result),1)
        self.assertEqual(result[0]['summary'],'Available now.')
        self.assertFalse(result[0]['translation_reviewed'])

    def test_xml_entities_are_rejected(self):
        with self.assertRaises(ValueError):parse_feed(b'<!DOCTYPE rss [<!ENTITY x SYSTEM "file:///secret">]><rss/>',SOURCES[0])

    def test_article_excludes_navigation_and_marketing(self):
        text=article_excerpt(b'<nav>Buy now</nav><article><p>Picture a magical forest.</p><p>The update launches October 20.</p><p>It includes new weapons.</p><p>Requires the base game.</p></article>')
        self.assertIn('October 20',text)
        self.assertNotIn('magical',text)
        self.assertNotIn('Buy',text)

    def test_article_wrong_host_blocks_network(self):
        with patch('newsroom.requests.get') as get:
            with self.assertRaises(ValueError):enrich_item({'source_id':'playstation','url':'https://example.com/x'})
            get.assert_not_called()

    def test_description_preserves_channel_template_without_historic_count(self):
        text=long_description('حلقة الاختبار',chapters=[(0,'المقدمة'),(65,'الخبر')],profile=DEFAULT)
        for phrase in ('اللهم صل وسلم','instagram.com/rashspeak/','tiktok.com/@rashspeak','x.com/Rashspeak','شكراً على المشاهده','01:05 - الخبر'):self.assertIn(phrase,text)
        self.assertNotIn('مشترك',text)
        with self.assertRaises(ValueError):long_description('x',chapters=[(float('nan'),'bad')],profile=DEFAULT)

    def test_top5_structure_and_duplicate_guard(self):
        result=top5_script(REFERENCE_LIST,'العالم المفتوح',['Hogwarts Legacy'],profile=DEFAULT)
        text=result['text']
        self.assertLess(text.index('المركز الخامس'),text.index('المركز الأول معنا'))
        self.assertLess(text.index('Hogwarts Legacy'),text.index('المركز الأول معنا'))
        self.assertEqual(text.count('ليش تلعب'),5)
        duplicate=copy.deepcopy(REFERENCE_LIST);duplicate[1]=duplicate[0]
        with self.assertRaises(ValueError):top5_script(duplicate,'x',profile=DEFAULT)

    def test_profile_rejects_music_and_invalid_text_regions(self):
        for field,value in [('music_enabled',True),('caption_region',[0,.9,1,.5])]:
            p=copy.deepcopy(DEFAULT);p['editing'][field]=value
            with self.assertRaises(ValueError):validate_profile(p)

    def test_news_script_attributes_source_and_does_not_fake_experience(self):
        item={'title_ar':'تحديث جديد','facts_ar':'يصدر في 20 أكتوبر.','source':'PlayStation Blog','url':'https://blog.playstation.com/x','published':'2026-10-13'}
        result=script(item,profile=DEFAULT)
        self.assertIn('بحسب PlayStation Blog',result['text'])
        self.assertEqual(result['status'],'DRAFT')
        self.assertTrue(result['warnings'])
        self.assertNotIn('جربت',result['text'])

    def test_real_thumbnail_dimensions_metadata_and_unlicensed_guard(self):
        from PIL import Image
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'owner.png';Image.new('RGB',(900,600),'#245071').save(path)
            asset=import_asset(path,role='clip',license='own',source='synthetic test',approved=True)
            dest=Path(folder)/'thumb.jpg'
            make_thumbnail(asset,'مغامرات\nعالم مفتوح',dest,genre='list',profile=DEFAULT)
            with Image.open(dest) as image:self.assertEqual(image.size,(1280,720))
            self.assertTrue(dest.with_suffix('.json').is_file())
            asset['usage_approved']=False
            with self.assertRaises(ValueError):make_thumbnail(asset,'عنوان',dest,profile=DEFAULT)


class PanelTests(unittest.TestCase):
    def setUp(self):
        self.root=tk.Tk();self.root.withdraw()
        self.editor=Editor(self.root,logger=lambda text:None)
        self.temp=tempfile.TemporaryDirectory()
        self.editor.paths['out'].set(self.temp.name)
    def tearDown(self):
        self.editor.shutdown();self.root.destroy();self.temp.cleanup()

    def test_top5_transfers_script_description_to_project(self):
        received=[]
        panel=Top5Panel(self.root,self.editor,received.append)
        panel.load_reference();panel.generate();panel.use_script()
        self.assertTrue((Path(self.temp.name)/'top5_script.txt').is_file())
        self.assertEqual(received[0]['genre'],'list')
        self.assertIn('x.com/Rashspeak',received[0]['description'])

    def test_changed_news_facts_require_new_review(self):
        panel=NewsroomPanel(self.root,self.editor)
        panel.cache=Path(self.temp.name)/'news.json'
        panel.items=[{'id':'x','source':'PlayStation Blog','published':'2026-10-13','title':'Update','summary':'Update','url':'https://blog.playstation.com/x','title_ar':'تحديث','facts_ar':'موعد الإصدار','translation_reviewed':True}]
        panel.populate();panel.news_tree.selection_set('0');panel.show_item()
        panel.set_text(panel.script_box,'مسودة')
        panel.set_text(panel.facts,'حقائق تغيرت بعد الاعتماد')
        with patch.object(messagebox,'showinfo') as info:panel.use_script();info.assert_called_once()
        self.assertFalse((Path(self.temp.name)/'news_script.txt').exists())


if __name__=='__main__':unittest.main()
