from copy import deepcopy
from pathlib import Path
import tempfile
import unittest
import array,math,wave
from PIL import Image,ImageChops

from pro_project import Session,new_project,new_clip,import_media,curve_value,validate
from pro_render import render
from media_tools import run
from pro_subtitles import update_word


class EffectsTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        image=self.root/'rgb.png';im=Image.new('RGBA',(320,180),(160,60,30,255));im.save(image)
        self.s=Session(new_project(size=(320,180)));self.t=self.s.add_track('image');a=import_media(image);self.c=self.s.add(self.t,new_clip(a['id'],duration=90),a)
    def tearDown(self):self.tmp.cleanup()
    def frame(self,file,at):
        output=self.root/'frame.png';run(['ffmpeg','-v','error','-y','-ss',at,'-i',file,'-frames:v','1',output])
        with Image.open(output) as im:return im.convert('RGB').copy()

    def test_color_mask_rotation_and_scale_opacity_animation_reach_pixels(self):
        base=self.root/'base.mp4';render(self.s.project,base);normal=self.frame(base,1).getpixel((160,90))
        self.s.properties(self.c,color={'exposure':.5,'contrast':1.1,'saturation':0.,'temperature':.1},mask={'shape':'ellipse','x':.1,'y':.1,'width':.8,'height':.8,'feather':.05})
        keys={'scale':[{'frame':0,'value':.4,'easing':'linear'},{'frame':60,'value':1.,'easing':'ease_out'}],
              'opacity':[{'frame':0,'value':.2,'easing':'linear'},{'frame':60,'value':1.,'easing':'ease_in'}]}
        self.s.properties(self.c,keyframes=keys,transform={'x':0.,'y':0.,'scale':.4,'opacity':.2,'rotation':15})
        out=self.root/'effects.mp4';render(self.s.project,out)
        early=self.frame(out,.1);late=self.frame(out,2.1)
        self.assertLess(max(late.getpixel((5,5))),70);self.assertNotEqual(normal,late.getpixel((160,90)))
        self.assertGreater(sum(late.getpixel((160,90))),sum(early.getpixel((160,90)))+80)

    def test_exact_ease_after_multiple_trims_and_split(self):
        self.s.properties(self.c,keyframes={'x':[{'frame':0,'value':0.,'easing':'linear'},{'frame':80,'value':1.,'easing':'ease_in'}]})
        original=deepcopy(self.s.clip(self.c)[1]);self.s.trim(self.c,10,85);self.s.trim(self.c,20,80)
        clip=self.s.clip(self.c)[1]
        for f in range(clip['duration']):self.assertAlmostEqual(curve_value(clip,'x',f),curve_value(original,'x',f+20),places=10)
        right=self.s.split(self.c,50)
        for f in range(self.s.clip(right)[1]['duration']):self.assertAlmostEqual(curve_value(self.s.clip(right)[1],'x',f),curve_value(original,'x',f+50),places=10)

    def test_dsp_and_volume_automation_produce_measured_audio(self):
        file=self.root/'voice.wav';run(['ffmpeg','-v','error','-y','-f','lavfi','-i','sine=frequency=1000:sample_rate=48000:duration=3',file])
        a=import_media(file);t=self.s.add_track('audio');c=self.s.add(t,new_clip(a['id'],duration=90),a)
        self.s.properties(c,processing={'eq_mid':3,'highpass':65,'compressor':True,'deesser':True,'denoise':True},
                          volume_automation=[{'frame':0,'gain_db':-25},{'frame':60,'gain_db':0}])
        self.s.track_state(t,processing={'eq_high':-2})
        out=self.root/'dsp.mp4';render(self.s.project,out)
        decoded=self.root/'decoded.wav';run(['ffmpeg','-v','error','-y','-i',out,'-map','0:a','-c:a','pcm_s16le',decoded])
        with wave.open(str(decoded)) as f:samples=array.array('h',f.readframes(f.getnframes()));rate=f.getframerate()*f.getnchannels()
        def rms(a,b):values=samples[round(a*rate):round(b*rate)];return math.sqrt(sum(v*v for v in values)/len(values))
        self.assertGreater(rms(2.2,2.8),rms(.1,.5)*5)

    def test_word_edit_timing_and_invalid_effect_are_atomic(self):
        t=self.s.add_track('text');clip=self.s.add(t,new_clip(text='الحين خبر',duration=90,word_timing=[{'start':0,'end':20,'text':'الحين'},{'start':25,'end':50,'text':'خبر'}]))
        update_word(self.s,clip,1,'تحديث',30,60);self.assertEqual(self.s.clip(clip)[1]['text'],'الحين تحديث')
        before=deepcopy(self.s.project)
        with self.assertRaises(ValueError):update_word(self.s,clip,1,'تحديث',10,60)
        self.assertEqual(before,self.s.project)
        for data in ({'color':{'contrast':999}},{'processing':{'ratio':float('nan')}},{'mask':{'shape':'shell'}}):
            with self.assertRaises(ValueError):self.s.properties(self.c,**data)
            self.assertEqual(before,self.s.project)

    def test_true_crossfade_has_both_sources_and_visual_speed_reverse_preserve_voice(self):
        blue=self.root/'blue.png';Image.new('RGB',(320,180),'blue').save(blue);a=import_media(blue)
        self.s.trim(self.c,0,30);right=self.s.add(self.t,new_clip(a['id'],start=30,duration=30),a)
        self.s.crossfade(self.c,right,12);out=self.root/'crossfade.mp4';render(self.s.project,out)
        pixel=self.frame(out,1.).getpixel((160,90));self.assertGreater(pixel[0],30);self.assertGreater(pixel[2],60)
        video=self.root/'two_colors.mp4'
        run(['ffmpeg','-v','error','-y','-f','lavfi','-i','color=red:size=320x180:rate=30:duration=1','-f','lavfi','-i','color=blue:size=320x180:rate=30:duration=1',
             '-filter_complex','[0:v][1:v]concat=n=2:v=1:a=0[v]','-map','[v]','-c:v','libx264','-threads','1',video])
        s=Session(new_project(size=(320,180)));t=s.add_track('video');a=import_media(video);c=s.add(t,new_clip(a['id'],duration=30,rate=2.),a)
        fast=self.root/'fast.mp4';render(s.project,fast)
        self.assertGreater(self.frame(fast,.2).getpixel((160,90))[0],180);self.assertGreater(self.frame(fast,.8).getpixel((160,90))[2],180)
        s.properties(c,reverse=True);reversed_file=self.root/'reverse.mp4';render(s.project,reversed_file)
        self.assertGreater(self.frame(reversed_file,.2).getpixel((160,90))[2],180)
        s.trim(c,5,25);validate(s.project);right=s.split(c,15);validate(s.project)
        self.assertEqual(s.clip(c)[1]['in'],30);self.assertEqual(s.clip(right)[1]['in'],10)

    def test_h265_and_explicit_bitrate_are_real_exports(self):
        from media_tools import probe
        file=self.root/'hevc.mp4';result=render(self.s.project,file,codec='h265',bitrate=1500000)
        self.assertEqual(result['bitrate'],1500000);self.assertEqual(next(s for s in probe(file)['streams'] if s['codec_type']=='video')['codec_name'],'hevc')
        run(['ffmpeg','-v','error','-i',file,'-f','null','-'])
