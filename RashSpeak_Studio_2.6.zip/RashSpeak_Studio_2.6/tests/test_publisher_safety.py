import tempfile
from pathlib import Path
import unittest
from unittest.mock import patch

import publisher as p


class SafetyTests(unittest.TestCase):
    def test_all_destinations_require_approval_before_network(self):
        calls = [lambda: p.yt_upload('missing', 'title', 'body'),
                 lambda: p.ig_publish_reel({}, 'https://example.test/v.mp4', ''),
                 lambda: p.tiktok_upload_draft({}, 'missing'),
                 lambda: p.tiktok_post_direct({}, 'missing', '', 'SELF_ONLY')]
        with patch.object(p.requests, 'post') as post:
            for fn in calls:
                with self.assertRaisesRegex(RuntimeError, 'approval'):
                    fn()
            post.assert_not_called()

    def test_instagram_missing_pending_state_cannot_pass_missing_received_state(self):
        with patch.object(p, 'secret_get', side_effect=lambda k: 'secret' if k == 'instagram_client_secret' else None), patch.object(p.requests, 'post') as post:
            with self.assertRaisesRegex(RuntimeError, 'state mismatch'):
                p.ig_finish_oauth({'ig_redirect': 'https://test.example/callback'}, 'https://test.example/callback?code=fake')
            post.assert_not_called()

    def test_direct_tiktok_cannot_bypass_scope_with_creator_info(self):
        with patch.object(p, 'secret_get', return_value='video.upload'), patch.object(p.requests, 'post') as post:
            with self.assertRaisesRegex(RuntimeError, 'scope'):
                p.tiktok_post_direct({}, 'missing.mp4', '', 'SELF_ONLY', consent=True, creator_info={'privacy_level_options': ['SELF_ONLY']})
            post.assert_not_called()

    def test_direct_tiktok_bad_probe_never_posts(self):
        with tempfile.TemporaryDirectory() as folder:
            file = Path(folder) / 'bad.mp4'
            file.write_bytes(b'x' * 1000)
            with patch.object(p, 'secret_get', return_value='video.publish'), patch.object(p, 'tiktok_access', return_value='fake'), patch('media_tools.duration', side_effect=RuntimeError('invalid media')), patch.object(p.requests, 'post') as post:
                with self.assertRaisesRegex(RuntimeError, 'validate'):
                    p.tiktok_post_direct({}, file, '', 'SELF_ONLY', consent=True, creator_info={'privacy_level_options': ['SELF_ONLY']})
                post.assert_not_called()
