import gc
from pathlib import Path
import tempfile
import tkinter as tk
import time
import unittest
from unittest.mock import patch
from PIL import Image
from pro_project import Session,new_project,new_clip,import_media
from pro_editor_ui import ProEditor
from gemini_ui import AssistantPanel
from ai_editing import compile_plan
from test_gemini import action


class GeminiUITests(unittest.TestCase):
    def test_candidate_requires_real_preview_and_watch_before_one_undo_commit(self):
        with tempfile.TemporaryDirectory() as folder:
            root=tk.Tk();root.geometry('1440x1000');file=Path(folder)/'clip.png';Image.new('RGB',(320,180),'blue').save(file)
            s=Session(new_project(size=(320,180)));t=s.add_track('image');a=import_media(file);c=s.add(t,new_clip(a['id'],duration=60),a);s.save(Path(folder)/'project.rash.json')
            editor=ProEditor(root,s.path);editor.pack();window=tk.Toplevel(root);panel=AssistantPanel(window,editor);panel.pack();root.update()
            proposal=compile_plan(editor.session.project,{'summary':'تصحيح لون','actions':[action('set_color',c,'saturation','0.3')]})
            panel.received(proposal);self.assertEqual(panel.approve_button['state'],'disabled');panel.preview()
            end=time.monotonic()+15
            while editor.busy and time.monotonic()<end:root.update();time.sleep(.02)
            root.update();self.assertFalse(editor.busy);self.assertEqual(panel.approve_button['state'],'disabled')
            with patch.object(editor,'open_file') as opened:panel.watch();opened.assert_called_once()
            self.assertEqual(panel.approve_button['state'],'normal');count=len(editor.session.undo_stack);panel.approve()
            self.assertEqual(len(editor.session.undo_stack),count+1);self.assertEqual(editor.session.clip(c)[1]['color']['saturation'],.3)
            editor.session.undo();self.assertNotIn('color',editor.session.clip(c)[1])
            root.destroy();root=None;editor=None;window=None;panel=None;gc.collect()
