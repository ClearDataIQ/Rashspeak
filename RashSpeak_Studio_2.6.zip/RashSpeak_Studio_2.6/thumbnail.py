"""Consistent thumbnails from owner-approved local assets; Arabic via libass."""
from pathlib import Path
import tempfile
from PIL import Image, ImageDraw
from channel_style import load_profile
import captions
from media_tools import run
from smart_editor import fingerprint, licensed, save
from timeline_render import animation_source


def ass_color(hex_color):
    value=hex_color.lstrip('#')
    if len(value)!=6 or any(c not in '0123456789abcdefABCDEF' for c in value):raise ValueError('لون غير صالح.')
    return '&H00'+value[4:6]+value[2:4]+value[0:2]


def make_thumbnail(asset, headline, output, genre='news', secondary=None, profile=None,cancel=None):
    profile=profile or load_profile()
    for a in (asset,secondary):
        if a and (not licensed(a) or fingerprint(a['path'])!=a['fingerprint']):raise ValueError('اختر أصلًا معتمدًا لم يتغير.')
    if not asset:raise ValueError('اختر خلفية مرخصة من مشروعك.')
    config=profile['thumbnail']
    lines=[line.strip() for line in headline.strip().splitlines() if line.strip()]
    if len(lines)>2 or not lines or len(' '.join(lines).split())>int(config['max_words']):raise ValueError('عنوان الثامنيل سطر أو سطران، بحد أقصى ست كلمات.')
    output=Path(output).resolve();output.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='rash_thumb_') as folder:
        temp=Path(folder)
        def frame(a,dest,width):
            source=animation_source(a,temp)
            run(['ffmpeg','-v','error','-y','-i',source,'-vf',f'scale={width}:720:force_original_aspect_ratio=increase,crop={width}:720,setsar=1','-frames:v','1',dest],cancel=cancel)
        if secondary:
            frame(asset,temp/'left.png',640);frame(secondary,temp/'right.png',640)
            image=Image.new('RGB',(1280,720));image.paste(Image.open(temp/'left.png'),(0,0));image.paste(Image.open(temp/'right.png'),(640,0))
            draw=ImageDraw.Draw(image);draw.line((640,0,640,720),fill='white',width=12)
        else:
            frame(asset,temp/'frame.png',1280);image=Image.open(temp/'frame.png').convert('RGB')
        # Contrast matte protects the heading; imagery stays genuine owner media.
        overlay=Image.new('RGBA',image.size,(0,0,0,0));draw=ImageDraw.Draw(overlay)
        for x in range(1280):draw.line((x,0,x,720),fill=(0,0,0,int(25+110*x/1280)))
        image=Image.alpha_composite(image.convert('RGBA'),overlay)
        draw=ImageDraw.Draw(image)
        if config['border']:draw.rectangle((5,5,1274,714),outline=config['accent'],width=10)
        draw.rounded_rectangle((1010,28,1235,98),radius=12,fill='#111827')
        image.convert('RGB').save(temp/'base.png')
        captions.write_ass([{'start':0,'end':2,'text':' '.join(lines)}],temp/'thumbnail.ass',(1280,720),profile['editing']['caption_font'],'gaming',config['region'])
        ass=(temp/'thumbnail.ass').read_text(encoding='utf-8-sig').split('[Events]')[0]
        # Large word groups, dark outline and two-tone typography shared by the references.
        ass=ass.replace('Style: Default,Arial,35,','Style: Default,Arial,88,')
        style_line=next(line for line in ass.splitlines() if line.startswith('Style:'))
        fields=style_line.split(',');fields[2]=str(min(88,max(36,int(config['region'][2]*1280/max(1,max(len(line) for line in lines)*.68)))));fields[3]=ass_color(config['primary']);fields[5]=ass_color(config['outline']);fields[16]='8';fields[17]='5'
        ass=ass.replace(style_line,','.join(fields))
        ass+='[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n'
        text=r'\N'.join(' '.join(captions.wrapped(line,80)) for line in lines)
        if len(lines)==2:
            text=' '.join(captions.wrapped(lines[0],80))+r'\N{\c'+ass_color(config['accent'])+'}'+ ' '.join(captions.wrapped(lines[1],80))
        x,y,w,h=config['region']
        position=(int((x+w/2)*1280),int((y+h/2)*720))
        ass+=f'Dialogue: 0,0:00:00.00,0:00:02.00,Default,,0,0,0,,{{\\an5\\pos({position[0]},{position[1]})}}{text}\n'
        ass+='Dialogue: 1,0:00:00.00,0:00:02.00,Default,,0,0,0,,{\\an5\\pos(1120,63)\\fs34\\bord0\\shad0\\c&H00FFFFFF&}RASH\n'
        badge=profile['script']['title_prefixes'].get(genre,'RashSpeak')
        ass+=f'Dialogue: 1,0:00:00.00,0:00:02.00,Default,,0,0,0,,{{\\an7\\pos(32,30)\\fs30\\bord3\\shad1\\c&H00FFFFFF&}}{badge}\n'
        (temp/'thumbnail.ass').write_text(ass,encoding='utf-8-sig')
        staged=temp/'thumbnail.jpg'
        run(['ffmpeg','-v','error','-y','-i','base.png','-vf','ass=thumbnail.ass:shaping=complex','-frames:v','1','-q:v','2',staged],cwd=temp,cancel=cancel)
        with Image.open(staged) as image:
            if image.size!=(1280,720):raise RuntimeError('أبعاد الثامنيل غير صحيحة.')
        pending=output.with_suffix('.pending.jpg');pending.write_bytes(staged.read_bytes());pending.replace(output)
    save({'profile_version':profile['version'],'headline':headline,'genre':genre,'asset_ids':[a['id'] for a in (asset,secondary) if a], 'status':'DRAFT','size':[1280,720]},output.with_suffix('.json'))
    return str(output)


class ThumbnailPanel:
    def __new__(cls,parent,editor):
        import tkinter as tk
        from tkinter import ttk,messagebox
        panel=ttk.Frame(parent,padding=20)
        ttk.Label(panel,text='ثامنيل بهوية ثابتة',font=('Segoe UI',20,'bold')).pack(anchor='e')
        ttk.Label(panel,text='صورة أو صورتان من أصولك المعتمدة + عنوان عربي كبير + حدود وهوية ثابتة. لا تُجلب صور محمية تلقائيًا.',foreground='#8299ba',wraplength=1000).pack(anchor='e',pady=8)
        choices=[]
        selected=tk.StringVar();secondary=tk.StringVar(value='بدون صورة ثانية')
        row=ttk.Frame(panel);row.pack(fill='x')
        first_box=ttk.Combobox(row,textvariable=selected,state='readonly');first_box.pack(side='right',fill='x',expand=True,padx=5)
        second_box=ttk.Combobox(row,textvariable=secondary,state='readonly');second_box.pack(side='left',fill='x',expand=True,padx=5)
        def refresh():
            choices[:]=[a for a in editor.assets if licensed(a) and a['role']=='clip']
            labels=[f'{i+1}. {Path(a["path"]).name}' for i,a in enumerate(choices)]
            first_box.configure(values=labels);second_box.configure(values=['بدون صورة ثانية',*labels])
            if labels:selected.set(labels[0])
        ttk.Button(panel,text='تحديث أصول المشروع',command=refresh).pack(anchor='e',pady=8)
        ttk.Label(panel,text='عنوان قصير في سطرين — ست كلمات بحد أقصى').pack(anchor='e')
        headline=tk.Text(panel,height=2,font=('Segoe UI',19,'bold'),bg='#0d1728',fg='#FFD24C',insertbackground='white',wrap='word',relief='flat');headline.pack(fill='x',pady=7)
        headline.insert('1.0','وش الجديد؟\nخلونا نشوف')
        preview=ttk.Label(panel);preview.pack(fill='both',expand=True,pady=10)
        note=tk.StringVar(value='أضف أصلًا مرخصًا للمشروع ثم حدّث القائمة. الثامنيل مسودة تحتاج مراجعتك.')
        def create():
            try:
                if first_box.current()<0:raise ValueError('اختر أصلًا.')
                a=choices[first_box.current()]
                second=choices[second_box.current()-1] if second_box.current()>0 else None
                text=headline.get('1.0','end').strip();dest=editor.output()/'thumbnail.jpg'
                def done(path):
                    from PIL import Image,ImageTk
                    image=Image.open(path);image.thumbnail((850,478))
                    panel.image=ImageTk.PhotoImage(image);preview.configure(image=panel.image)
                    note.set('حُفظ thumbnail.jpg بدقة 1280×720. راجع العنوان والخلفية قبل رفعه.')
                genre='news'
                metadata=editor.output()/'episode.json'
                if metadata.is_file():
                    import json
                    genre=json.loads(metadata.read_text(encoding='utf-8')).get('genre','news')
                editor.job('توليد الثامنيل',lambda:make_thumbnail(a,text,dest,genre=genre,secondary=second),done)
            except (IndexError,ValueError):messagebox.showinfo('الثامنيل','اختر أصلًا معتمدًا أولًا.',parent=panel)
        ttk.Button(panel,text='توليد ومعاينة الثامنيل',command=create).pack(anchor='e',pady=8)
        ttk.Label(panel,textvariable=note,foreground='#ffce88',wraplength=1000).pack(anchor='e')
        panel.refresh=refresh
        return panel
