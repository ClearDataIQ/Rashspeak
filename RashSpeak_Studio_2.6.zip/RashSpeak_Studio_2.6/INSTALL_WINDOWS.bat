@echo off
chcp 65001 >nul
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0bootstrap.ps1" -Install
if errorlevel 1 (
 echo ERROR installing dependencies. Verify your Python/Internet and try again.
 pause
 exit /b 1
)
echo Packages installed. Open START_WINDOWS.bat. FFmpeg is also required for rendering.
pause
