"""Arabic desktop dashboard shell around the preserved editor and adapters."""
from pathlib import Path
import json
import tkinter as tk
from tkinter import ttk, messagebox
from app_paths import app_dir
from channel_style import load_profile, save_profile
from smart_editor import licensed


def hidden_tabs(style):
    style.layout('Workspace.TNotebook.Tab', [])
    style.configure('Workspace.TNotebook', background='#0b1220', borderwidth=0, tabmargins=0)


class Dashboard:
    def __init__(self, sidebar, notebook, editor, pages):
        self.notebook,self.editor=notebook,editor
        self.home=ttk.Frame(notebook,padding=24)
        notebook.insert(0,self.home,text='الرئيسية')
        self.buttons=[]
        ttk.Label(sidebar,text='RASH',font=('Segoe UI',27,'bold'),foreground='#08BEED',anchor='e').pack(fill='x',padx=18,pady=(22,0))
        ttk.Label(sidebar,text='STUDIO  /  2.1',foreground='#8299ba',anchor='e').pack(fill='x',padx=20,pady=(0,26))
        actions=[('الرئيسية',lambda:self.show(self.home)),('الأخبار والسكربتات',lambda:self.show(pages['news'])),
                 ('توب فايف',lambda:self.show(pages['top5'])),('ملفات المشروع',lambda:self.edit(0)),
                 ('الصوت والترجمة السعودية',lambda:self.edit(1)),('المونتاج والريأكشن',lambda:self.edit(2)),
                 ('الثامنيل',lambda:self.show(pages['thumbnail'])),('وصف الحلقة والنشر',lambda:self.show(pages['publish'])),
                 ('أسلوب القناة',lambda:self.show(pages['profile'])),('الحسابات',lambda:self.show(pages['accounts'])),
                 ('سجل الإرسال',lambda:self.show(pages['history']))]
        for text,fn in actions:
            button=ttk.Button(sidebar,text=text,command=fn,style='Nav.TButton')
            button.pack(fill='x',padx=12,pady=3)
            self.buttons.append(button)
        ttk.Label(sidebar,text='صوتك • رأيك • هويتك\nتحرير محلي، مراجعة واعتماد',foreground='#8299ba',anchor='e',justify='right').pack(side='bottom',fill='x',padx=18,pady=18)
        ttk.Label(self.home,text='أهلًا راشد، خلّنا نجهّز حلقتك',font=('Segoe UI',25,'bold'),anchor='e').pack(fill='x')
        ttk.Label(self.home,text='مسار واحد للقناة: فكرة موثقة ← سكربت بأسلوبك ← صوتك ← مونتاج وريأكشن ← مراجعة وتصدير',foreground='#8299ba',anchor='e',wraplength=1000).pack(fill='x',pady=(5,24))
        cards=ttk.Frame(self.home);cards.pack(fill='x')
        self.metrics=[]
        for title in ['أصول معتمدة','جمل مراجعة','ريأكشنات معتمدة','Shorts مختارة']:
            card=tk.Frame(cards,bg='#132138',highlightbackground='#243851',highlightthickness=1)
            card.pack(side='right',fill='both',expand=True,padx=5)
            value=tk.StringVar(value='0')
            tk.Label(card,textvariable=value,bg='#132138',fg='#08BEED',font=('Segoe UI',28,'bold')).pack(anchor='e',padx=18,pady=(16,0))
            tk.Label(card,text=title,bg='#132138',fg='#b2c4dc',font=('Segoe UI',11)).pack(anchor='e',padx=18,pady=(0,16))
            self.metrics.append(value)
        next_card=ttk.Frame(self.home,padding=20,style='Card.TFrame');next_card.pack(fill='x',pady=24)
        ttk.Label(next_card,text='ابدأ من هنا',font=('Segoe UI',17,'bold'),style='Card.TLabel').pack(anchor='e')
        self.next_step=tk.StringVar(value='اختر فكرة من الأخبار، أو جهّز قائمة توب فايف، ثم سجّل بصوتك.')
        ttk.Label(next_card,textvariable=self.next_step,style='Card.TLabel',wraplength=900,anchor='e').pack(fill='x',pady=8)
        buttons=ttk.Frame(next_card,style='Card.TFrame');buttons.pack(fill='x')
        ttk.Button(buttons,text='غرفة الأخبار',command=lambda:self.show(pages['news'])).pack(side='right',padx=5)
        ttk.Button(buttons,text='جهّز توب فايف',command=lambda:self.show(pages['top5'])).pack(side='right',padx=5)
        ttk.Button(buttons,text='افتح مشروعًا محفوظًا',command=lambda:(editor.open_project(),self.edit(0))).pack(side='right',padx=5)
        ttk.Label(self.home,text='هوية واحدة، أربع سلاسل',font=('Segoe UI',17,'bold')).pack(anchor='e')
        ttk.Label(self.home,text='اخر أخبار الألعاب   /   توب فايف   /   سوالف راشد   /   وثائقي',foreground='#FFD24C',font=('Segoe UI',13,'bold')).pack(anchor='e',pady=7)
        ttk.Label(self.home,text='الأسلوب محفوظ في ملف القناة ويُستخدم للسكربت، الترجمة، إيقاع المشاهد، الثامنيل والوصف.\nالريأكشن من مكتبتك المعتمدة؛ لا فيسات تلقائية ولا موسيقى.',anchor='e',justify='right',wraplength=980).pack(fill='x',pady=(0,15))
        self.readiness=tk.StringVar()
        ttk.Label(self.home,textvariable=self.readiness,anchor='e',justify='right',foreground='#8299ba',wraplength=980).pack(fill='x')
        notebook.configure(style='Workspace.TNotebook')
        editor.tabs.configure(style='Workspace.TNotebook')
        self.show(self.home)
        self.tick_id=self.home.after(300,self.tick)
        self.home.bind('<Destroy>',self.shutdown,add='+')

    def show(self,page):
        self.notebook.select(page)

    def edit(self,page):
        self.notebook.select(self.editor)
        self.editor.tabs.select(page)

    def tick(self):
        t=self.editor.timeline or {}
        counts=[sum(licensed(a) for a in self.editor.assets),len(self.editor.segments),sum(m.get('approved',False) for m in t.get('memes',[])),sum(s.get('approved',False) for s in t.get('shorts',[]))]
        for value,count in zip(self.metrics,counts):value.set(str(count))
        if self.editor.busy:self.next_step.set(self.editor.status.get())
        elif t.get('review'):self.next_step.set('المراجعة معتمدة. صدّر الفيديو النهائي والثامنيل، ثم راجع وصف الحلقة قبل النشر.')
        elif t:self.next_step.set('الخط الزمني جاهز. راجع المشاهد والريأكشن ونطاقات Shorts، ثم أخرج المسودة.')
        elif self.editor.paths['audio'].get():self.next_step.set('صوتك مختار. راجع الترجمة والوسوم ثم حلل المونتاج.')
        model=app_dir()/'models/small'
        news_model=app_dir()/'models/news-helsinki-en-ar'
        self.readiness.set('التفريغ المحلي: '+('جاهز' if model.is_dir() else 'يحتاج SETUP_ARABIC_MODEL.bat')+'   |   ترجمة الأخبار: '+('جاهزة' if news_model.is_dir() else 'تحتاج SETUP_NEWS_MODEL.bat')+'\nالحسابات والنشر تحتاج ربطًا وموافقة مستقلة؛ لا يحدث نشر من غرفة الأخبار.')
        self.tick_id=self.home.after(800,self.tick)

    def shutdown(self,event):
        if event.widget is self.home and self.tick_id:
            self.home.after_cancel(self.tick_id);self.tick_id=None


class ProfilePanel(ttk.Frame):
    def __init__(self,parent):
        super().__init__(parent,padding=20)
        ttk.Label(self,text='ملف أسلوب القناة — المرجع الواحد',font=('Segoe UI',20,'bold')).pack(anchor='e')
        ttk.Label(self,text='السكريبتات والقص والترجمة والثامنيل والوصف تعتمد هذا الملف. غيّر الإعدادات مرة ليستخدمها كل مشروع جديد.',foreground='#8299ba',wraplength=1000).pack(anchor='e',pady=8)
        self.profile=load_profile()
        self.values={}
        form=ttk.Frame(self);form.pack(fill='x',pady=20)
        fields=[('intro','مقدمة راشد',self.profile['script']['intro']),('subscriber_count','عدد المشتركين الحالي (اختياري)',self.profile['description'].get('subscriber_count','')),('scene_seconds','مدة المشهد بالثواني (3 إلى 8)',self.profile['editing']['scene_seconds']),('caption_font','خط الترجمة',self.profile['editing']['caption_font']),('primary','لون عنوان الثامنيل',self.profile['thumbnail']['primary']),('accent','لون الهوية والحدود',self.profile['thumbnail']['accent'])]
        for i,(key,label,value) in enumerate(fields):
            ttk.Label(form,text=label,anchor='e').grid(row=i,column=1,sticky='e',padx=12,pady=8)
            variable=tk.StringVar(value=str(value));self.values[key]=variable
            ttk.Entry(form,textvariable=variable,justify='right').grid(row=i,column=0,sticky='ew',pady=8)
        form.columnconfigure(0,weight=1)
        ttk.Label(self,text='قالب الوصف الثابت: الصلاة على النبي، روابط حساباتك، والشكر للمشاهد.\nأخبار الألعاب • توب فايف • سوالف راشد • وثائقي\nبدون موسيقى. الريأكشن قصير ومتباعد وتراجعه بنفسك.',justify='right',anchor='e',wraplength=950).pack(fill='x',pady=18)
        ttk.Button(self,text='حفظ هوية القناة',command=self.save).pack(anchor='e',pady=6)
        ttk.Label(self,text='أرقام المشتركين في مقاطعك القديمة تاريخية؛ اترك العدد فارغًا لإخفاء السطر.\nX رابط في الوصف كما في قناتك. النشر إلى YouTube وInstagram وTikTok فقط.',foreground='#ffce88',wraplength=1000,justify='right').pack(anchor='e',pady=12)

    def save(self):
        import copy
        try:
            profile=copy.deepcopy(self.profile)
            profile['script']['intro']=self.values['intro'].get().strip()
            profile['description']['subscriber_count']=self.values['subscriber_count'].get().strip()
            profile['editing']['scene_seconds']=float(self.values['scene_seconds'].get())
            profile['editing']['caption_font']=self.values['caption_font'].get().strip()
            for key in ('primary','accent'):profile['thumbnail'][key]=self.values[key].get().strip()
            save_profile(profile);self.profile=profile
            messagebox.showinfo('أسلوب القناة','حُفظ الأسلوب للمشاريع الجديدة. راجع المشاريع القديمة قبل تغييرها.',parent=self)
        except Exception as exc:messagebox.showerror('هوية القناة',str(exc),parent=self)


class ScrollPage(ttk.Frame):
    def __init__(self,parent):
        super().__init__(parent)
        canvas=tk.Canvas(self,bg='#101b30',highlightthickness=0)
        bar=ttk.Scrollbar(self,orient='vertical',command=canvas.yview)
        bar.pack(side='left',fill='y');canvas.pack(side='right',fill='both',expand=True)
        canvas.configure(yscrollcommand=bar.set)
        self.body=ttk.Frame(canvas,padding=18)
        window=canvas.create_window((0,0),window=self.body,anchor='nw')
        self.body.bind('<Configure>',lambda event:canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>',lambda event:canvas.itemconfigure(window,width=event.width))
