@echo off
chcp 65001 >nul
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0bootstrap.ps1" -MediaSources
if errorlevel 1 (
 echo Media source installation failed. Read the error above.
 pause
 exit /b 1
)
echo Optional excerpt support installed. Configure sources from the app menu.
pause
