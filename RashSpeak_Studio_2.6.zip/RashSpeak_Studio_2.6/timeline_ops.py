"""Verified silence ripple preserves source order across all unlocked tracks."""
from copy import deepcopy
import math

from pro_project import uid,retime_animation,validate,length
from media_tools import Cancelled


def ripple_range(session,start,end):
    if type(start)is not int or type(end)is not int or not 0<=start<end<=length(session.seq):raise ValueError('نطاق سكوت غير صالح.')
    delta=end-start
    for t in session.seq['tracks']:
        if any(c['start']+c['duration']>start for c in t['clips']):session.editable(t)
    for t in session.seq['tracks']:
        result=[]
        for c in t['clips']:
            a,b=c['start'],c['start']+c['duration']
            if b<=start:result.append(c);continue
            if a>=end:c['start']-=delta;result.append(c);continue
            if a<start:
                left=deepcopy(c);retime_animation(left,0,start-a);left['duration']=start-a
                if c.get('reverse'):left['in']+=round((b-start)*c.get('rate',1.))
                left['fade_in']=min(left['fade_in'],left['duration']);left['fade_out']=min(left['fade_out'],left['duration']);result.append(left)
            if b>end:
                right=deepcopy(c);offset=end-a;retime_animation(right,offset,b-end)
                right.update(id=uid(),start=start,duration=b-end,group=None)
                if t['kind']!='text':
                    if not c.get('reverse'):right['in']+=round(offset*c.get('rate',1.))
                    asset=next(m for m in session.project['media'] if m['id']==right['media_id'])
                    if c['loop'] and asset['kind']!='image':right['in']%=max(1,round(asset['duration']*session.project['fps']))
                right['fade_in']=min(right['fade_in'],right['duration']);right['fade_out']=min(right['fade_out'],right['duration']);result.append(right)
        t['clips']=result
        keys=t.get('volume_automation',[])
        t['volume_automation']=[{**k,'frame':k['frame']-delta if k['frame']>=end else k['frame']} for k in keys if k['frame']<start or k['frame']>=end]
    validate(session.project)


def verified_silences(project,cancel=None):
    """A range must be silent in every active audio source and outside known words."""
    from audio_edit import detect_silences
    from pro_project import sequence
    from media_tools import duration
    s=sequence(project);fps=project['fps'];assets={m['id']:m for m in project['media']};candidates=None
    for t in s['tracks']:
        if t['kind'] not in ('audio','effect') or t['muted']:continue
        for c in t['clips']:
            if cancel and cancel.is_set():raise Cancelled('أُلغي قياس السكوت.')
            if c['loop']:return []
            asset=assets[c['media_id']];silences=detect_silences(asset['path'],asset['duration'],cancel,threshold=-42)
            if t['kind']=='audio' and not asset.get('words'):return []
            here=[]
            for item in silences:
                a,b=(item['start'],item['end']) if isinstance(item,dict) else item
                a=max(a,c['in']/fps);b=min(b,(c['in']+c['duration'])/fps)
                begin=c['start']+math.ceil((a-c['in']/fps+.08)*fps);finish=c['start']+math.floor((b-c['in']/fps-.08)*fps)
                if finish-begin<fps:continue
                if any(w['start']<b and w['end']>a for w in asset.get('words',[])):continue
                here.append((begin,finish))
            # Silent outside a clip's own range, but never delete an unproven voiced span.
            here=[(0,c['start']),*here,(c['start']+c['duration'],length(s))]
            if candidates is None:candidates=here
            else:candidates=[(max(a,x),min(b,y)) for a,b in candidates for x,y in here if min(b,y)-max(a,x)>=fps]
    return sorted(set((a,b) for a,b in (candidates or []) if b-a>=fps))[:20]
