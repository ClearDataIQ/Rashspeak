"""Official Gemini REST integration. Secrets never enter projects or diagnostics."""
from dataclasses import dataclass
import json
import os
from pathlib import Path
import re
import time

import requests
from app_paths import app_dir
from media_tools import Cancelled
from smart_editor import save

HOST='https://generativelanguage.googleapis.com/v1beta'
SERVICE='RashSpeakStudio.Gemini'
DEFAULT_MODEL='gemini-3-flash-preview'
_session_key=''


class GeminiError(RuntimeError):pass
class GeminiUnavailable(GeminiError):pass


def settings_path():return app_dir()/'output'/'settings'/'gemini.json'


def settings():
    value={'enabled':True,'model':os.getenv('RASH_GEMINI_MODEL') or DEFAULT_MODEL}
    if settings_path().is_file():
        try:
            data=json.loads(settings_path().read_text(encoding='utf-8'))
            value.update({k:data[k] for k in value if k in data})
        except (ValueError,OSError):pass
    validate_settings(value);return value


def validate_settings(value):
    if type(value['enabled'])is not bool or not re.fullmatch(r'gemini-[A-Za-z0-9._-]{1,80}',value['model']):
        raise ValueError('اختر معرف نموذج Gemini صالحًا وحالة تشغيل صحيحة.')
    if re.search(r'(?:^|[-_.])(image|imagen|veo|tts)(?:$|[-_.])',value['model'].lower()):
        raise ValueError('نماذج توليد الصور والفيديو والصوت غير مسموحة؛ Gemini للتحليل والمونتاج فقط.')


def save_settings(value):
    validate_settings(value);save({k:value[k] for k in ('enabled','model')},settings_path())


def api_key():
    if _session_key:return _session_key
    for name in ('RASH_GEMINI_API_KEY','GEMINI_API_KEY','GOOGLE_API_KEY','RASH_GOOGLE_API_KEY'):
        if os.getenv(name):return os.environ[name]
    try:
        import keyring
        return keyring.get_password(SERVICE,'api_key') or ''
    except Exception:return ''


def use_session_key(value):
    global _session_key
    _session_key=value.strip()


def save_key(value):
    try:
        import keyring
        if value:keyring.set_password(SERVICE,'api_key',value.strip())
        else:
            try:keyring.delete_password(SERVICE,'api_key')
            except keyring.errors.PasswordDeleteError:pass
    except Exception as exc:
        raise GeminiUnavailable('تعذر الوصول لخزنة مفاتيح النظام. استخدم RASH_GEMINI_API_KEY في إعدادات البيئة الآمنة.') from None


class GeminiClient:
    def __init__(self,key=None,model=None,http=None,cancel=None):
        cfg=settings();self._key=api_key() if key is None else key;self.model=model or cfg['model']
        validate_settings({'enabled':True,'model':self.model})
        self.http=http or requests.Session();self.cancel=cancel;self.last_usage={}
        if not self._key:raise GeminiUnavailable('Gemini غير متاح: جهّز مفتاح API من إعداداته. الأدوات المحلية تبقى متاحة.')

    def check(self):
        if self.cancel and self.cancel.is_set():raise Cancelled('أُلغي طلب Gemini.')

    def request(self,method,path,body=None):
        self.check()
        # Path is generated exclusively from validated model identifiers.
        for attempt in range(3):
            try:
                response=self.http.request(method,HOST+path,headers={'x-goog-api-key':self._key,'Content-Type':'application/json'},
                    json=body,timeout=(10,90),allow_redirects=False,stream=True)
            except requests.RequestException:
                self.check()
                raise GeminiUnavailable('تعذر الاتصال بـGemini؛ تحقق من الشبكة وإتاحة API. لم تُطبق تعديلات.') from None
            status=response.status_code
            if status in (429,500,502,503,504) and attempt<2:
                response.close();deadline=time.monotonic()+min(2**attempt,4)
                while time.monotonic()<deadline:self.check();time.sleep(.05)
                continue
            if status!=200:
                response.close()
                if status in (401,403):raise GeminiUnavailable(f'Gemini HTTP {status}: تحقق من المفتاح وصلاحية النموذج وسياسة الوصول.')
                if status==429:raise GeminiUnavailable('Gemini تجاوز حد الاستخدام؛ جرّب لاحقًا أو راجع الحصة والفوترة.')
                if status>=500:raise GeminiUnavailable(f'Gemini HTTP {status}: الخدمة غير متاحة مؤقتًا؛ لم تُطبق تعديلات.')
                raise GeminiError(f'Gemini HTTP {status}: لم ينجح الطلب؛ تحقق من النموذج وإعداداته.')
            try:
                chunks=[];count=0
                for block in response.iter_content(65536):
                    self.check();count+=len(block)
                    if count>2*1024*1024:raise GeminiError('رد Gemini أكبر من الحد المسموح.')
                    chunks.append(block)
                value=json.loads(b''.join(chunks).decode('utf-8'))
                if not isinstance(value,dict):raise ValueError()
                return value
            except (ValueError,UnicodeError):raise GeminiError('رد Gemini ليس JSON صالحًا.') from None
            finally:response.close()
        raise GeminiError('تعذر إكمال طلب Gemini.')

    def models(self):
        values=[];page=''
        for _ in range(10):
            from urllib.parse import urlencode
            body=self.request('GET','/models'+('?' + urlencode({'pageToken':page}) if page else ''))
            for m in body.get('models',[]):
                name=m.get('name','').removeprefix('models/')
                if 'generateContent' in m.get('supportedGenerationMethods',[]) and re.fullmatch(r'gemini-[A-Za-z0-9._-]{1,80}',name):values.append(name)
            page=body.get('nextPageToken','')
            if not page:break
        return sorted(set(values))

    def generate(self,system,data,schema,video_url=None,image_path=None):
        payload=json.dumps(data,ensure_ascii=False,allow_nan=False)
        if len(payload)>160000:raise GeminiError('المشروع أكبر من سياق الطلب الحالي؛ اختر نطاقًا أصغر.')
        config={'temperature':.15,'maxOutputTokens':8192,'responseMimeType':'application/json','responseSchema':schema}
        if self.model=='gemini-3-flash-preview':config['thinkingConfig']={'thinkingLevel':'LOW'}
        parts=[{'text':payload}]
        if image_path is not None:
            from PIL import Image
            import base64,io
            path=Path(image_path)
            if path.stat().st_size>20_000_000:raise GeminiError('صورة المصدر أكبر من حد التحليل.')
            with Image.open(path) as image:
                if image.width*image.height>40_000_000:raise GeminiError('أبعاد الصورة أكبر من حد التحليل.')
                image.thumbnail((1280,1280));buffer=io.BytesIO();image.convert('RGB').save(buffer,format='JPEG',quality=85)
            parts.insert(0,{'inlineData':{'mimeType':'image/jpeg','data':base64.b64encode(buffer.getvalue()).decode('ascii')}})
        if video_url is not None:
            from urllib.parse import urlparse,parse_qs
            parsed=urlparse(video_url)
            ids=parse_qs(parsed.query).get('v',[])
            if (parsed.scheme!='https' or parsed.hostname!='www.youtube.com' or parsed.path!='/watch'
                    or parsed.username or parsed.password or parsed.port not in (None,443)
                    or len(ids)!=1 or not re.fullmatch(r'[A-Za-z0-9_-]{11}',ids[0])):
                raise ValueError('اختر رابط فيديو YouTube عام صالحًا لتحليل المشاهد.')
            parts.insert(0,{'fileData':{'fileUri':video_url}})
        body=self.request('POST',f'/models/{self.model}:generateContent',{
            'systemInstruction':{'parts':[{'text':system}]},
            'contents':[{'role':'user','parts':parts}],
            'generationConfig':config})
        self.check();self.last_usage={k:int(v) for k,v in body.get('usageMetadata',{}).items() if k.endswith('TokenCount') and type(v)is int}
        candidates=body.get('candidates',[])
        if not candidates:raise GeminiError('Gemini لم يُرجع اقتراحًا؛ قد يكون الطلب مرفوضًا أو غير قابل للإجابة.')
        candidate=candidates[0]
        if candidate.get('finishReason') not in (None,'STOP'):raise GeminiError('اقتراح Gemini غير مكتمل أو مرفوض؛ لم تُطبق تعديلات.')
        text=''.join(p.get('text','') for p in candidate.get('content',{}).get('parts',[]) if not p.get('thought'))
        try:
            result=json.loads(text)
            if not isinstance(result,dict):raise ValueError()
            return result
        except (ValueError,TypeError):raise GeminiError('Gemini أرجع اقتراحًا ببنية غير صالحة؛ لم تُطبق تعديلات.') from None
