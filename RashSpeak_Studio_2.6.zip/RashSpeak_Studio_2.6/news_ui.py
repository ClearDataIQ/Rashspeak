import copy
from datetime import datetime
import json
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox
import webbrowser

from app_paths import app_dir
from channel_style import load_profile, long_description
from newsroom import collect, LocalNewsTranslator, script, translate_item, enrich_item
from smart_editor import save


class NewsroomPanel(ttk.Frame):
    def __init__(self, parent, editor, on_script=None):
        super().__init__(parent, padding=16)
        self.editor, self.on_script = editor, on_script
        self.items, self.translator, self.current_script = [], None, None
        self.cache = app_dir() / 'output/news_cache.json'
        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)
        ttk.Label(self, text='غرفة أخبار RashSpeak', font=('Segoe UI', 20, 'bold'), anchor='e').grid(row=0, column=0, sticky='e')
        ttk.Label(self, text='مصادر رسمية • ترجمة محلية • سكربت بلهجتك • مراجعة قبل التسجيل', foreground='#75bdd9', anchor='e').grid(row=1, column=0, sticky='e', pady=(2,12))
        body = ttk.Panedwindow(self, orient='horizontal')
        body.grid(row=2, column=0, sticky='nsew')
        left, right = ttk.Frame(body), ttk.Frame(body)
        body.add(left, weight=3)
        body.add(right, weight=2)
        self.news_tree = ttk.Treeview(right, columns=('source','date','title'), show='headings', selectmode='browse', height=8)
        for key, label, width in [('source','المصدر',110),('date','التاريخ',95),('title','الخبر',310)]:
            self.news_tree.heading(key, text=label, anchor='e')
            self.news_tree.column(key, width=width, anchor='e')
        self.news_tree.pack(fill='both', expand=True)
        self.news_tree.bind('<<TreeviewSelect>>', lambda event:self.show_item())
        controls = ttk.Frame(right)
        controls.pack(fill='x', pady=6)
        self.source_vars = {key:tk.BooleanVar(value=True) for key in ('playstation','xbox','steam')}
        for key, var in self.source_vars.items():
            ttk.Checkbutton(controls, text=key, variable=var).pack(side='right')
        self.days = tk.StringVar(value='7')
        ttk.Combobox(controls, values=['3','7','14'], textvariable=self.days, state='readonly', width=4).pack(side='left')
        ttk.Button(right, text='تحديث الأخبار الرسمية الآن', command=self.refresh_news).pack(fill='x', pady=4)
        ttk.Button(right, text='افتح المصدر للتحقق', command=self.open_source).pack(fill='x')
        ttk.Button(right, text='استخرج تفاصيل الخبر من المقال', command=self.enrich).pack(fill='x', pady=4)
        ttk.Label(left, text='العنوان العربي — قابل للمراجعة', anchor='e').pack(anchor='e')
        self.title_ar = tk.StringVar()
        ttk.Entry(left, textvariable=self.title_ar, justify='right').pack(fill='x', pady=4)
        ttk.Label(left, text='تفاصيل المصدر الأصلية', anchor='e').pack(anchor='e')
        self.original = self.text(left, height=5)
        ttk.Label(left, text='الخلاصة العربية — راجع الأرقام وأسماء الألعاب', anchor='e').pack(anchor='e', pady=(8,0))
        self.facts = self.text(left, height=5)
        bar = ttk.Frame(left)
        bar.pack(fill='x', pady=6)
        ttk.Button(bar, text='ترجم الخبر محليًا', command=self.translate).pack(side='right', padx=3)
        ttk.Button(bar, text='راجعت الترجمة مع المصدر', command=self.review_translation).pack(side='right', padx=3)
        self.variant = tk.StringVar(value='أخبار')
        ttk.Combobox(bar, values=['أخبار','Short','تحليل'], textvariable=self.variant, state='readonly', width=8).pack(side='left')
        ttk.Button(left, text='اقترح سكربت بأسلوب راشد', command=self.generate).pack(fill='x', pady=3)
        ttk.Label(left, text='مسودة التسجيل — عدّل رأيك وصياغتك هنا', anchor='e').pack(anchor='e')
        self.script_box = self.text(left, height=9, expand=True)
        bar = ttk.Frame(left)
        bar.pack(fill='x', pady=5)
        ttk.Button(bar, text='اعتماد للتسجيل ونقل إلى المشروع', command=self.use_script).pack(side='right')
        ttk.Button(bar, text='نسخ السكربت', command=self.copy_script).pack(side='left')
        self.note = tk.StringVar(value='اضغط تحديث. آخر جلب محفوظ يُعرض كأرشيف، وليس خبرًا جديدًا مؤكدًا.')
        ttk.Label(self, textvariable=self.note, wraplength=1000, anchor='e', foreground='#ffce88').grid(row=3,column=0,sticky='ew',pady=(10,0))
        if self.cache.exists():
            try:
                self.items = json.loads(self.cache.read_text(encoding='utf-8')).get('items', [])
                self.populate()
            except (OSError,ValueError):
                pass

    def text(self, parent, height, expand=False):
        box = tk.Text(parent, height=height, wrap='word', font=('Segoe UI',11), background='#0d1728', foreground='#e4edff', insertbackground='#ffffff', relief='flat', padx=10, pady=8)
        box.tag_configure('rtl',justify='right')
        box.pack(fill='both' if expand else 'x', expand=expand, padx=(0,12))
        return box

    def set_text(self, box, value):
        box.delete('1.0','end')
        box.insert('1.0',value,'rtl')

    def selected(self):
        selected = self.news_tree.selection()
        return self.items[int(selected[0])] if selected else None

    def populate(self):
        self.news_tree.delete(*self.news_tree.get_children())
        for i,item in enumerate(self.items):
            self.news_tree.insert('','end',iid=str(i),values=(item['source'],item['published'][:10],item.get('title_ar') or item['title']))

    def show_item(self):
        item = self.selected()
        if not item:return
        self.title_ar.set(item.get('title_ar',''))
        self.set_text(self.original, item['title']+'\n\n'+item['summary']+'\n\n'+item['url'])
        self.set_text(self.facts,item.get('facts_ar',''))
        self.set_text(self.script_box,'')
        self.current_script=None
        self.note.set('المصدر: '+item['source']+' | النشر: '+item['published']+' | '+('ترجمة مراجعة' if item.get('translation_reviewed') else 'تحتاج مراجعة'))

    def refresh_news(self):
        ids = [key for key,var in self.source_vars.items() if var.get()]
        days = int(self.days.get())
        if not ids:return
        previous={item['id']:item for item in self.items}
        def done(result):
            self.items=result['items']
            for item in self.items:
                old=previous.get(item['id'])
                if old and old['title']==item['title'] and old['summary']==item['summary']:
                    for key in ('title_ar','facts_ar','translation_reviewed'):item[key]=old.get(key,'')
            save({**result,'items':self.items},self.cache)
            self.populate()
            self.note.set(f'جُلب {len(self.items)} خبرًا خلال {days} أيام. '+(' | '.join(e['source']+': '+e['error'] for e in result['errors']) or 'لا تُجمع لقطات أو صور أخبار تلقائيًا.'))
        self.editor.job('تحديث غرفة الأخبار',lambda:collect(ids,days,self.editor.log,self.editor.cancel),done)

    def open_source(self):
        item=self.selected()
        if item:webbrowser.open(item['url'])

    def translate(self):
        item=self.selected()
        if not item:return
        data=copy.deepcopy(item)
        def work():
            if self.translator is None:self.translator=LocalNewsTranslator()
            return translate_item(data,self.translator)
        def done(result):
            index=next(i for i,x in enumerate(self.items) if x['id']==result['id'])
            self.items[index]=result
            self.populate()
            self.news_tree.selection_set(str(index))
            self.show_item()
            save({'items':self.items},self.cache)
            self.note.set('ترجمة محلية مقترحة. راجع الأرقام والأسماء والنص الأصلي قبل اعتمادها.')
        self.editor.job('ترجمة الخبر دون إرسال النص لخدمة خارجية',work,done)

    def enrich(self):
        item=self.selected()
        if not item:return
        data=copy.deepcopy(item)
        def done(result):
            index=next(i for i,x in enumerate(self.items) if x['id']==result['id'])
            self.items[index]=result
            self.populate();self.news_tree.selection_set(str(index));self.show_item()
            save({'items':self.items},self.cache)
            self.note.set('مقتطف قصير من المقال الرسمي. راجعه؛ استخراج الجمل لا يضمن اكتمال الخبر.')
        self.editor.job('قراءة المقال المحدد',lambda:enrich_item(data,self.editor.cancel),done)

    def update_item(self, reviewed=False):
        item=self.selected()
        if not item:return None
        item['title_ar']=self.title_ar.get().strip()
        item['facts_ar']=self.facts.get('1.0','end').strip()
        item['translation_reviewed']=bool(reviewed)
        save({'items':self.items},self.cache)
        return item

    def review_translation(self):
        item=self.update_item(True)
        if item:self.note.set('حُفظ اعتمادك للترجمة. يبقى السكربت مسودة حتى تراجعه للتسجيل.')

    def generate(self):
        item=self.selected()
        if not item:return
        original_title,original_facts=item.get('title_ar'),item.get('facts_ar')
        reviewed=item.get('translation_reviewed') and original_title==self.title_ar.get().strip() and original_facts==self.facts.get('1.0','end').strip()
        item=self.update_item(reviewed)
        try:
            variant={'أخبار':'news','Short':'short','تحليل':'analysis'}[self.variant.get()]
            self.current_script=script(item,variant)
            self.set_text(self.script_box,self.current_script['text'])
            self.note.set(' | '.join(self.current_script['warnings']) or 'مسودة مقترحة. أضف رأيك وتجربتك قبل التسجيل.')
        except Exception as exc:messagebox.showerror('السكربت',str(exc),parent=self)

    def copy_script(self):
        self.clipboard_clear()
        self.clipboard_append(self.script_box.get('1.0','end').strip())

    def use_script(self):
        item=self.selected()
        text=self.script_box.get('1.0','end').strip()
        if not item or not text:return
        if not item.get('translation_reviewed') or item.get('title_ar')!=self.title_ar.get().strip() or item.get('facts_ar')!=self.facts.get('1.0','end').strip():
            messagebox.showinfo('مراجعة المصدر','راجع الترجمة مع المصدر ثم اعتمدها أولًا.',parent=self);return
        output=self.editor.output()
        output.mkdir(parents=True,exist_ok=True)
        path=output/'news_script.txt'
        path.write_text(text,encoding='utf-8')
        self.editor.paths['script'].set(str(path))
        is_short=self.variant.get()=='Short'
        metadata={'title':load_profile()['script']['title_prefixes']['news']+' | '+item['title_ar'],
                  'sources':[item['url']], 'description':long_description(item['title_ar'],sources=[item['url']]),
                  'type':'short' if is_short else 'long','genre':'news','script_reviewed':True}
        save(metadata,output/'episode.json')
        if self.on_script:self.on_script(metadata)
        self.note.set('السكربت جاهز للتسجيل داخل مشروعك. سجّل بصوتك ثم استورد الصوت؛ لا يوجد نشر تلقائي.')
