"""Reproducible CLI for the same smart editor used by the Arabic GUI."""
import argparse
import json
from pathlib import Path
import sys

import captions
from smart_editor import approve, plan, save
from timeline_render import render


def main():
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    parser = argparse.ArgumentParser(description='RashSpeak Studio 2.1 offline editor')
    sub = parser.add_subparsers(dest='action', required=True)
    analyze = sub.add_parser('analyze')
    analyze.add_argument('--audio', required=True)
    analyze.add_argument('--manifest', required=True)
    analyze.add_argument('--transcript')
    analyze.add_argument('--script')
    analyze.add_argument('--cues', default='')
    analyze.add_argument('--memes', action='store_true')
    analyze.add_argument('--out', required=True)
    transcribe = sub.add_parser('transcribe')
    transcribe.add_argument('--audio', required=True)
    transcribe.add_argument('--model', required=True)
    transcribe.add_argument('--out', required=True)
    for name in ('render', 'approve'):
        p = sub.add_parser(name)
        p.add_argument('--timeline', required=True)
        if name == 'render':
            p.add_argument('--out', required=True)
            p.add_argument('--final', action='store_true')
            p.add_argument('--encoder', choices=['cpu', 'nvenc'], default='cpu')
        else:
            p.add_argument('--reviewed', action='store_true')
            p.add_argument('--accept-warnings', action='store_true')
    args = parser.parse_args()
    if args.action == 'transcribe':
        save(captions.transcribe(args.audio, args.model), args.out)
    elif args.action == 'analyze':
        manifest = json.loads(Path(args.manifest).read_text(encoding='utf-8'))
        transcript = captions.load(args.transcript) if args.transcript else []
        script = Path(args.script).read_text(encoding='utf-8-sig') if args.script else ''
        save(plan(args.audio, manifest, transcript, script, args.cues, args.memes), args.out)
    else:
        timeline = json.loads(Path(args.timeline).read_text(encoding='utf-8'))
        if args.action == 'approve':
            if not args.reviewed:
                parser.error('شاهد المسودة أولًا ثم استخدم --reviewed صراحةً.')
            approve(timeline, args.accept_warnings)
            save(timeline, args.timeline)
        else:
            render(timeline, args.out, final=args.final, encoder=args.encoder)


if __name__ == '__main__':
    main()
