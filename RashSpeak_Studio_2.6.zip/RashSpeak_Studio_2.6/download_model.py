"""Explicit one-time download; narration never leaves this computer."""
import argparse
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', choices=['tiny', 'base', 'small', 'medium'], default='small')
    parser.add_argument('--out')
    args = parser.parse_args()
    try:
        from faster_whisper.utils import download_model
    except ImportError:
        parser.error('Run INSTALL_ARABIC_SUBTITLES.bat first.')
    output = Path(args.out or Path(__file__).parent / 'models' / args.model).resolve()
    download_model(args.model, output_dir=str(output))
    print('Local model ready:', output)


if __name__ == '__main__':
    main()
