#!/usr/bin/env python3
"""RashSpeak Studio v1.0: make a rough-cut from your voice and your own media.

No third-party video downloading or platform publishing. Requires FFmpeg and ffprobe.
Optional faster-whisper generates Arabic SRT files locally.
"""
import argparse
import csv
import json
import math
import random
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from media_tools import run as media_run, tool

VIDEO_TYPES = {'.mp4', '.mov', '.mkv', '.webm', '.avi', '.m4v'}
AUDIO_TYPES = {'.wav', '.mp3', '.m4a', '.aac', '.flac', '.ogg', '.mp4'}


def run(cmd, logger=print, cwd=None):
    return media_run(cmd,cwd=cwd)


def media_duration(path):
    raw = run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration',
               '-of', 'json', str(path)])
    duration = float(json.loads(raw)['format']['duration'])
    if not math.isfinite(duration) or duration < 0.15:
        raise ValueError(f'Invalid media duration: {path}')
    return duration


def select_clips(root, logger=print):
    media = sorted(p for p in Path(root).rglob('*') if p.is_file() and p.suffix.lower() in VIDEO_TYPES)
    good = []
    for path in media:
        try:
            duration = media_duration(path)
            if duration > .8:
                good.append((path, duration))
        except Exception as exc:
            logger(f'Ignoring unreadable video: {path.name}: {exc}')
    return good


def parse_cues(csv_path, duration):
    if not csv_path:
        return []
    cues = []
    with open(csv_path, 'r', encoding='utf-8-sig', newline='') as file:
        reader = csv.DictReader(file)
        if not {'start','end','tag'} <= set(reader.fieldnames or []):
            raise ValueError('cues.csv needs headers: start,end,tag')
        for row in reader:
            s, e = float(row['start']), float(row['end'])
            tag = (row['tag'] or '').strip().lower()
            if not 0 <= s < e <= duration + 1.0:
                raise ValueError(f'Invalid cue start/end: {row}')
            cues.append((s,min(e,duration),tag))
    cues.sort()
    if any(a[1] > b[0] + .001 for a,b in zip(cues,cues[1:])):
        raise ValueError('Cue time ranges may not overlap')
    return cues


def cue_at(time_s, cues):
    for start,end,tag in cues:
        if start <= time_s < end - .0001:
            return tag,end
        if time_s < start:
            return '',start
    return '',float('inf')


def shot_plan(clips, duration, scene_min, scene_max, cues):
    rng = random.Random(71482)
    shots = []
    time_s = 0.0
    last_clip = None
    while time_s + .05 < duration:
        tag, boundary = cue_at(time_s, cues)
        allowed = [(p,d) for p,d in clips if not tag or tag in str(p).lower()]
        if not allowed:
            raise ValueError(f'No clip filename/folder matches cue tag: {tag}')
        if len(allowed) > 1 and last_clip:
            alternatives = [x for x in allowed if x[0] != last_clip]
            if alternatives:
                allowed = alternatives
        path, total = rng.choice(allowed)
        left = duration - time_s
        target = min(left, rng.uniform(scene_min, scene_max), boundary-time_s)
        # Source clip need not fill the whole target; it will loop if shorter.
        src_at = 0 if total < target + .2 else rng.uniform(0, max(0,total-target-.1))
        if target < .04:
            raise RuntimeError('Invalid cue timing caused a zero-length shot')
        shots.append({'start':round(time_s,3), 'end':round(time_s+target,3),
                      'source':str(path), 'source_offset':round(src_at,3),
                      'tag':tag, 'duration':round(target,4)})
        time_s += target
        last_clip = path
    return shots


def render_shot(shot, path, size, encoder, logger):
    w,h = size
    vf = f'scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h},setsar=1,fps=30,format=yuv420p'
    target_duration = shot['duration']
    codec = 'h264_nvenc' if encoder == 'nvenc' else 'libx264'
    quality = ['-cq','24','-preset','p4'] if encoder == 'nvenc' else ['-crf','21','-preset','veryfast']
    cmd = ['ffmpeg','-hide_banner','-loglevel','error','-y',
           '-stream_loop','-1','-ss',shot['source_offset'], '-i',shot['source'],
           '-t',f'{target_duration:.4f}', '-vf',vf, '-an',
           '-c:v',codec,*quality, '-pix_fmt','yuv420p', '-r','30',
           '-video_track_timescale','30000', '-movflags','+faststart',path]
    run(cmd,logger)


def export_srt(audio, output, model_name, logger):
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        logger('Subtitle generation skipped. Run: pip install faster-whisper')
        return None
    logger('Transcribing Arabic subtitles locally (first run downloads model)...')
    model = WhisperModel(model_name, device='cpu', compute_type='int8')
    segments, info = model.transcribe(str(audio),language='ar',beam_size=5,
                                      vad_filter=True, initial_prompt='أخبار ألعاب، بلايستيشن، إكس بوكس، ستيم، كول أوف ديوتي.')
    def stamp(seconds):
        millis = max(0,int(round(seconds*1000)))
        h, rem = divmod(millis,3600000)
        m, rem = divmod(rem,60000)
        s, ms = divmod(rem,1000)
        return f'{h:02}:{m:02}:{s:02},{ms:03}'
    with open(output,'w',encoding='utf-8-sig') as f:
        for i, seg in enumerate(segments,1):
            text = seg.text.strip()
            if text:
                f.write(f'{i}\n{stamp(seg.start)} --> {stamp(seg.end)}\n{text}\n\n')
    logger('Arabic captions generated. Proofread before uploading.')
    return output


def make_short(video, path, seconds, encoder, logger):
    # For a 16:9 gaming scene, keep the entire scene visible over a blurred portrait backdrop.
    vf = ('[0:v]split=2[bg][fg];'
          '[bg]scale=720:1280:force_original_aspect_ratio=increase,'
          'crop=720:1280,boxblur=20:5[back];'
          '[fg]scale=720:1280:force_original_aspect_ratio=decrease[front];'
          '[back][front]overlay=(W-w)/2:(H-h)/2,format=yuv420p[v]')
    codec = 'h264_nvenc' if encoder == 'nvenc' else 'libx264'
    quality = ['-cq','25','-preset','p4'] if encoder == 'nvenc' else ['-crf','22','-preset','veryfast']
    run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',video,
         '-t',f'{seconds:.2f}','-filter_complex',vf,'-map','[v]','-map','0:a:0',
         '-r','30','-c:v',codec,*quality,'-c:a','aac','-b:a','160k',
         '-pix_fmt','yuv420p','-movflags','+faststart',path],logger)


def build(audio, media, output, cues_csv='', scene_min=4.5, scene_max=7.5,
          size=(1920,1080), short_secs=35, subtitles=False, whisper_model='small',
          encoder='cpu', logger=print):
    audio,media,output = Path(audio),Path(media),Path(output)
    if not audio.is_file() or audio.suffix.lower() not in AUDIO_TYPES:
        raise FileNotFoundError('Choose a supported narration audio file.')
    if not media.is_dir():
        raise FileNotFoundError('Choose the directory containing your licensed gameplay clips.')
    for exe in ['ffmpeg','ffprobe']:
        tool(exe)
    if not 2.0 <= scene_min <= scene_max <= 20:
        raise ValueError('Scene duration must be 2–20 seconds; min <= max.')
    voice_duration = media_duration(audio)
    logger(f'Voice: {voice_duration:.1f} seconds')
    clips = select_clips(media,logger)
    if not clips:
        raise RuntimeError('No readable video clips found in media directory.')
    logger(f'{len(clips)} usable video clips found.')
    cues = parse_cues(cues_csv,voice_duration)
    shots = shot_plan(clips, voice_duration,scene_min,scene_max,cues)
    output.mkdir(parents=True,exist_ok=True)
    with open(output/'shotlist.csv','w',encoding='utf-8-sig',newline='') as f:
        cols = ['start','end','source','source_offset','tag','duration']
        writer = csv.DictWriter(f,fieldnames=cols)
        writer.writeheader(); writer.writerows(shots)
    with tempfile.TemporaryDirectory(prefix='rashspeak_') as tmp:
        tmp = Path(tmp)
        segments = []
        for i,shot in enumerate(shots,1):
            dest = tmp/f'shot_{i:04}.mp4'
            logger(f'Rendering scene {i}/{len(shots)}: {Path(shot["source"]).name}')
            render_shot(shot,dest,size,encoder,logger)
            segments.append(dest)
        playlist = tmp/'concat.txt'
        # Relative filenames, no quoting problems from user input paths.
        playlist.write_text(''.join(f"file '{p.name}'\n" for p in segments),encoding='utf-8')
        concat = tmp/'silent.mp4'
        run(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','concat','-safe','0',
             '-i',playlist,'-c','copy',concat],logger,cwd=tmp)
        main = output/'RashSpeak_video.mp4'
        run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',concat,'-i',audio,
             '-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','192k',
             '-af','loudnorm=I=-16:TP=-1.5:LRA=11',
             '-t',f'{voice_duration:.3f}','-movflags','+faststart',main],logger)
        logger(f'Main video ready: {main}')
        if short_secs > 0:
            short_file = output/'RashSpeak_short_first_section.mp4'
            logger('Rendering short from FIRST seconds (not AI highlight selection)...')
            make_short(str(main),str(short_file),min(short_secs,voice_duration),encoder,logger)
            logger(f'Short ready: {short_file}')
    if subtitles:
        export_srt(audio,output/'RashSpeak_ar.srt',whisper_model,logger)
    logger('Done. Verify footage matches narration, licenses, captions and factual accuracy before publishing.')
    return str(main)


def cli():
    if hasattr(sys.stdout,'reconfigure'):sys.stdout.reconfigure(encoding='utf-8',errors='replace')
    parser=argparse.ArgumentParser(description='RashSpeak Studio - narration-to-rough-cut (offline).')
    parser.add_argument('--audio',required=True)
    parser.add_argument('--clips',required=True)
    parser.add_argument('--out',default='output')
    parser.add_argument('--cues',default='')
    parser.add_argument('--size',default='1920x1080')
    parser.add_argument('--short',type=float,default=35)
    parser.add_argument('--min-scene',type=float,default=4.5)
    parser.add_argument('--max-scene',type=float,default=7.5)
    parser.add_argument('--subtitles',action='store_true')
    parser.add_argument('--whisper-model',default='small')
    parser.add_argument('--encoder',choices=['cpu','nvenc'],default='cpu')
    args=parser.parse_args()
    try:
        size=tuple(map(int,args.size.lower().split('x')))
        if len(size)!=2 or min(size)<180 or any(x%2 for x in size):
            raise ValueError('Size needs positive even dimensions')
        build(args.audio,args.clips,args.out,args.cues,args.min_scene,args.max_scene,
              size,args.short,args.subtitles,args.whisper_model,args.encoder)
    except Exception as exc:
        print(f'ERROR: {exc}',file=sys.stderr)
        sys.exit(1)

if __name__=='__main__':
    cli()
