# Current plan — RashSpeak 2.5

The current owner scope overrides the historical publishing-first plan in docs/IMPLEMENTATION_PLAN_LEGACY.md. Full prompt: PROMPT_GEMINI_IMPLEMENTATION_AR.md. Handoff: CLOUD_HANDOFF.md.

- [x] Inspect actual latest source; retain prior WIP and 2.4 restore point; baseline 132 tests.
- [x] Shared non-destructive frame-based multitrack project, editing transactions, Undo/Redo/save/recovery and portable ZIP retained.
- [x] Three cropped transparent Overlay tracks and actual matching preview/export retained.
- [x] Official Gemini settings/client and verified live model, structured contextual sentence/visual/effect/meme/Short planning, guarded offline fallback.
- [x] Natural-language Gemini assistant proposes actual bounded transactions, candidate preview, approval/freshness and one-step Undo.
- [x] Clip/track DSP, volume automation, color/rotation/masks/feather, Scale/Opacity keyframes, exact Ease retiming, Crossfade and visual rate/reverse.
- [x] Manual per-word caption timing/text/style/highlight with source-derived words.
- [x] Internal PyAV proxy player, explicit optional audio-device state; resizable workspace and scrollable properties.
- [x] Persistent snapshot export queue/progress/retry/dead-worker recovery, H.265/Bitrate options, conservative local catalog/dedup/cache eviction.
- [x] Unit/Tk/API-mock/real-FFmpeg verification plus live Gemini and synthetic production/stress/resolution evidence.
- [x] Actual Whisper small weights downloaded, local load/inference checked; no human-ASR claim.
- [x] Prepare authorized-local-video acceptance runner and record YouTube URL access block without false success.
- [x] Actual owner MP3: local Whisper, full Gemini timing/context, shared long/Short project, real exports and source integrity. Owner explicitly bypassed review stops. Quality acceptance remains unapproved; see docs/FULL_REAL_PRODUCTION_AR.md.
- [ ] Windows/audio device/RTX4060/EXE validation.
- [ ] Broader licensed Gameplay/reaction providers; actual Commons access currently403.
- [ ] Automated subject/HUD portrait tracking, graphical curves, motion blur/speed ramping/LUT/color wheels and real-project performance tuning.
- [ ] Optional expanded Thumbnail Studio outside main flow.

See docs/FEATURE_STATUS_AR.md for limits and TEST_RESULTS.txt for final checks. The working expansion is delivered; the full Premiere/Resolve-level scope is not claimed complete; actual recorded-audio output is supplied with documented limits.

- [x] Real recording full Gemini context, metadata entity aliases, source-id grounding, long render partitions/continuous audio, CPU optimization and sparse gap transitions.
- [x] Complete full exports/decode/portable packaging; preserve the source and ASR draft. Latest owner explicitly bypassed reviews for this test. See docs/FULL_REAL_PRODUCTION_AR.md.

- [x] Final real-media audit: low-confidence rows cannot keep previous-game footage; reject known backstage/interview/cosplay search results; rerender corrected project and package Shorts in the correct folder.
