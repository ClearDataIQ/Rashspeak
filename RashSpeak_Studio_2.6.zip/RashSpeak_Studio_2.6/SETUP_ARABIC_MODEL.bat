@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0bootstrap.ps1" -Subtitles -Model
if errorlevel 1 echo Setup failed. Check Internet access and retry.
pause
