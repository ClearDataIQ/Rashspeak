"""A cancellable handoff between the production thread and owner review UI."""
import copy
import threading
from media_tools import Cancelled


class ReviewBridge:
    def __init__(self,events,cancel):
        self.events=events;self.cancel=cancel;self.lock=threading.Lock();self.ready=threading.Event()
        self.response=None;self.token=0;self.pending=None

    def __call__(self,request):
        with self.lock:
            self.token+=1;token=self.token;self.response=None;self.ready.clear();self.pending=token
        self.events.put({'type':'review','request':copy.deepcopy(request),'token':token})
        while not self.ready.wait(.1):
            if self.cancel.is_set():raise Cancelled('أوقفت الإنتاج عند المراجعة؛ التسجيل ونسخ العمل محفوظة.')
        if self.cancel.is_set():raise Cancelled('أوقفت الإنتاج عند المراجعة.')
        with self.lock:
            self.pending=None;return copy.deepcopy(self.response)

    def submit(self,token,response):
        with self.lock:
            if token!=self.pending or self.ready.is_set():return False
            self.response=copy.deepcopy(response);self.ready.set();return True
