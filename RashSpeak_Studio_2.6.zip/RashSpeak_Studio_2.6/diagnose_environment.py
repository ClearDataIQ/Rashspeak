"""Local readiness diagnostics. Never prints keys, tokens or credential paths."""
import argparse
import json
from pathlib import Path
import sys
import tkinter

from app_paths import app_dir
from media_tools import run,tool
from gemini_client import api_key,settings,GeminiClient


def report(live=False):
    result={'python':sys.version.split()[0],'tk':tkinter.TkVersion,'gemini_key_available':bool(api_key()),'gemini_model':settings()['model']}
    try:
        result['ffmpeg']=run(['ffmpeg','-version']).splitlines()[0]
        encoders=run(['ffmpeg','-hide_banner','-encoders'])
        result['encoders']={n:n in encoders for n in ('libx264','libx265','h264_nvenc','hevc_nvenc')}
    except Exception:result['ffmpeg']='unavailable'
    model=app_dir()/'models'/'small';result['whisper_small_files_available']=all((model/name).is_file() for name in ('model.bin','config.json','tokenizer.json'))
    try:
        import sounddevice as sd
        result['audio_output_devices']=sum(d['max_output_channels']>0 for d in sd.query_devices())
    except Exception:result['audio_output_devices']=0
    if live:
        try:result['gemini_models_count']=len(GeminiClient().models());result['gemini_list_models']='success'
        except Exception as exc:result['gemini_list_models']=str(exc)
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--gemini',action='store_true');args=p.parse_args();print(json.dumps(report(args.gemini),ensure_ascii=False,indent=2))
