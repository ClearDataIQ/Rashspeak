@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0bootstrap.ps1" -Install -Subtitles
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m unittest discover -s tests -v
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m pip install "pyinstaller>=6,<7"
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m pip install -r requirements-news.txt
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --windowed --onedir --name RashSpeakStudio25 --collect-all faster_whisper --collect-all ctranslate2 --collect-all av --collect-all sounddevice --hidden-import _sounddevice --collect-all onnxruntime --collect-all tokenizers --collect-all sentencepiece --collect-all googleapiclient gui.py
if errorlevel 1 goto failed
copy /y channel_style.json "dist\RashSpeakStudio25\channel_style.json"
echo Build created under dist\RashSpeakStudio25. It is unsigned and requires testing.
echo Place FFmpeg/ffprobe under tools and a downloaded model under models\small.
pause
exit /b 0
:failed
echo Build failed. Read the error above.
pause
exit /b 1
