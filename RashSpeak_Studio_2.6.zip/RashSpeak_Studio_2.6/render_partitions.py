"""Bounded temporal video renders; one continuous audio mix, unchanged project."""
from copy import deepcopy
from pathlib import Path
import tempfile

from media_tools import Cancelled, probe
from pro_project import sequence, length, new_track, new_clip, retime_animation, edit_digest, validate


def partitions(project, sequence_id):
    from pro_render import used_clips
    seq=sequence(project,sequence_id);total=length(seq);fps=project['fps']
    clips=[c for t,c in used_clips(project,seq) if t['kind'] in ('video','image')]
    boundaries={total}
    for c in clips:
        boundaries.update((c['start'],c['start']+c['duration']))
    for t in seq['tracks']:
        if t['kind']=='text':
            for c in t['clips']:boundaries.update((c['start'],c['start']+c['duration']))
    result=[];start=0
    def safe(end):
        return not any(c['start']<end<c['start']+c['fade_in'] or
                       c['start']+c['duration']-c['fade_out']<end<c['start']+c['duration'] for c in clips)
    while start<total:
        candidates=sorted((x for x in boundaries if start<x<=min(total,start+300*fps)),reverse=True)
        end=None
        for budget in (1,8,128):
            end=next((x for x in candidates if safe(x) and sum(c['start']<x and c['start']+c['duration']>start for c in clips)<=budget),None)
            if end is not None:break
        if end is None:
            raise ValueError('لا يمكن تجزئة هذا التراكب بأمان ضمن 128 مدخلًا متزامنًا؛ خفّض الطبقات المتزامنة أو مدى الانتقال.')
        result.append((start,end));start=end
    return result


def slice_video(project, sequence_id, start, end):
    p=deepcopy(project);s=sequence(p,sequence_id)
    for t in s['tracks']:
        t.pop('volume_automation',None)  # Audio automation is rendered once in the full mix.
        if t['kind'] in ('audio','effect'):
            t['muted']=True;t['clips']=[];continue
        items=[]
        for original in t['clips']:
            a=max(start,original['start']);b=min(end,original['start']+original['duration'])
            if a>=b:continue
            c=deepcopy(original);left=a-c['start'];right=c['start']+c['duration']-b
            retime_animation(c,left,b-a)
            c.update(start=a-start,duration=b-a)
            if t['kind']!='text':
                c['in']+=round((right if c.get('reverse') else left)*c.get('rate',1.))
                media=next(m for m in p['media'] if m['id']==c['media_id'])
                if c['loop'] and media['kind']!='image':c['in']%=max(1,round(media['duration']*p['fps']))
            else:
                # Render slicing must preserve the original text, even across a word boundary.
                c['text']=original['text']
                if original.get('word_timing'):
                    c['word_timing']=[{**w,'start':max(0,w['start']-left),'end':min(b-a,w['end']-left)}
                                      for w in original['word_timing'] if w['start']<left+b-a and w['end']>left]
            c['fade_in']=original['fade_in'] if left==0 else 0
            c['fade_out']=original['fade_out'] if right==0 else 0
            items.append(c)
        t['clips']=items
    boundary=new_track('text','Internal render boundary');boundary['hidden']=True
    boundary['clips']=[new_clip(text='Render boundary',duration=end-start)];s['tracks'].append(boundary)
    p['active_sequence']=s['id'];return validate(p)


def render_partitioned(project,output,sequence_id,size,codec,crf,cancel,on_progress,encoder,bitrate):
    from pro_render import render,used_clips,execute
    from pro_project import media_matches
    s=sequence(project,sequence_id);count=length(s);fps=project['fps'];seconds=count/fps
    active=list(used_clips(project,s));audio=[c for t,c in active if t['kind'] in ('audio','effect')]
    if len(audio)>128:raise ValueError('حد مزيج الصوت المستمر الحالي 128 مقطعًا؛ اجمع المسارات الصوتية أولًا.')
    spans=partitions(project,sequence_id);output=Path(output)
    def progress(value):
        if on_progress:on_progress(min(99,int(value)))
    with tempfile.TemporaryDirectory(prefix='rash-parts-',dir=output.parent) as folder:
        tmp=Path(folder);mix=deepcopy(project)
        for t in sequence(mix,sequence_id)['tracks']:
            if t['kind'] not in ('audio','effect'):t['hidden']=True
        render(mix,tmp/'audio_mix.mp4',sequence_id,size=(320,180),cancel=cancel,
               on_progress=lambda n:progress(n/3))
        lines=['ffconcat version 1.0']
        for i,(a,b) in enumerate(spans):
            if cancel and cancel.is_set():raise Cancelled('أُلغي تصدير الأجزاء.')
            name=f'video_{i:04}.mp4';part=slice_video(project,sequence_id,a,b)
            render(part,tmp/name,sequence_id,size=size,codec=codec,crf=crf,cancel=cancel,encoder=encoder,bitrate=bitrate,
                   on_progress=lambda n,a=a,b=b:progress(100/3+(a+(b-a)*n/100)/count*100/3))
            lines.extend((f"file '{name}'",f'duration {(b-a)/fps:.12f}'))
        manifest=tmp/'parts.ffconcat';manifest.write_text('\n'.join(lines)+'\n',encoding='utf-8')
        target=tmp/'joined.mp4'
        command=['-v','error','-y','-nostdin','-progress',tmp/'join_progress.txt','-f','concat','-safe','1','-i',manifest,
                 '-i',tmp/'audio_mix.mp4','-map','0:v:0','-map','1:a:0','-c','copy','-t',str(seconds),'-movflags','+faststart',target]
        execute(command,tmp/'join_progress.txt',count,cancel,lambda n:progress(200/3+n/3))
        info=probe(target);v=next(x for x in info['streams'] if x['codec_type']=='video')
        if (v['width'],v['height'])!=tuple(size) or abs(float(info['format']['duration'])-seconds)>max(.12,2/fps):
            raise RuntimeError('جمع الأجزاء لا يطابق أبعاد أو توقيت المشروع.')
        if v['codec_name']!=('h264' if codec=='h264' else 'hevc'):raise RuntimeError('ترميز الأجزاء غير مطابق.')
        used={c['media_id'] for _,c in active if c['media_id']}
        if any(not media_matches(m) for m in project['media'] if m['id'] in used):raise ValueError('تغيّر مصدر أثناء التجميع.')
        if cancel and cancel.is_set():raise Cancelled('أُلغي التصدير؛ لم يُستبدل الملف النهائي.')
        target.replace(output)
    if on_progress:on_progress(100)
    return {'path':str(output),'duration':seconds,'size':list(size),'fps':fps,'codec':codec,'encoder':encoder,
            'bitrate':bitrate,'crf':crf,'revision':project['revision'],'model_digest':edit_digest(project),'render_parts':len(spans)}
