"""Original short non-musical effects, contextual suggestions and voice ducking."""
import array
import hashlib
import math
from pathlib import Path
import random
import wave

from media_tools import duration, run
from smart_editor import contains, fingerprint, normalize, reaction, SENSITIVE, CRUCIAL, IMPORTANT_FORMS

TYPES={'whoosh':'انتقال خفيف','pop':'طقة خفيفة','impact':'ضربة قصيرة'}


def library(folder):
    """Procedural noise transients, not copyrighted audio or background music."""
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True);result={};rate=48000
    for kind,seconds in [('whoosh',.45),('pop',.16),('impact',.28)]:
        rng=random.Random(kind);values=array.array('h');smooth=0
        for i in range(round(seconds*rate)):
            t=i/rate;progress=t/seconds;noise=rng.uniform(-1,1)
            smooth=.8*smooth+.2*noise
            envelope=math.sin(math.pi*progress)**2 if kind=='whoosh' else (1-math.exp(-t*400))*math.exp(-t*(35 if kind=='pop' else 17))
            signal=noise-smooth if kind=='whoosh' else smooth
            values.append(round(24000*envelope*signal))
        file=folder/(kind+'.wav')
        peak=max(abs(v) for v in values)
        if peak:values=array.array('h',(round(v*26000/peak) for v in values))
        valid=False
        if file.exists():
            try:
                with wave.open(str(file),'rb') as f:valid=f.getframerate()==rate and f.getnchannels()==1 and f.readframes(f.getnframes())==values.tobytes()
            except (wave.Error,EOFError):pass
        if not valid:
            with wave.open(str(file),'wb') as f:
                f.setnchannels(1);f.setsampwidth(2);f.setframerate(rate);f.writeframes(values.tobytes())
        result[kind]={'type':kind,'path':str(file.resolve()),'duration':seconds,'fingerprint':fingerprint(file),
                      'license':'Original procedural audio','source':'Generated locally by RashSpeak','usage_approved':True}
    return result


def protected(segment):
    text=segment['text']
    return (segment.get('mode') in ('sensitive','crucial','factual','cta') or segment.get('asr_confidence',1)<.65
            or any(contains(text,x) for x in (*SENSITIVE,*CRUCIAL,*IMPORTANT_FORMS,'بحسب','حسب المصدر'))
            or any(c.isdigit() for c in text))


def suggest(timeline,available):
    result=[];last=-10;segments=timeline['segments'];limit=timeline['duration']
    def add(kind,at,reason,confidence):
        nonlocal last
        if at-last<10 or len(result)>=max(1,math.ceil(limit/30)):return
        base=available[kind];seconds=min(base['duration'],limit-at)
        if seconds<.08:return
        result.append({**base,'id':hashlib.sha256(f'{kind}|{at:.4f}'.encode()).hexdigest()[:16],
                       'timestamp':round(at,6),'duration':seconds,'gain_db':-20,'reason':reason,
                       'confidence':confidence,'approved':True})
        last=at
    for i,s in enumerate(segments):
        if i and s.get('story_topic') and s.get('story_topic')!=segments[i-1].get('story_topic'):
            previous=segments[i-1];gap=s['start']-previous['end'];seconds=available['whoosh']['duration']
            if gap>=seconds+.2 and min(s.get('asr_confidence',1),previous.get('asr_confidence',1))>=.65:
                add('whoosh',previous['end']+.1,'انتقال لعبة داخل فجوة بين الكلام؛ لا يغطي المعلومة أو بداية الكلمة',.9)
                if result and result[-1]['type']=='whoosh':result[-1]['gain_db']=-24
        if s.get('semantic') and s['semantic']['effect']=='none':continue
        if protected(s):continue
        mood=reaction(s['text'],s.get('mode','auto'))
        if mood and s.get('editorial_confidence',1)>=.75:
            # SFX is reviewed before optional memes; it is a voice beat in its own right.
            kind=s['semantic']['effect'] if s.get('semantic') else 'pop' if mood=='humor' else 'impact'
            if kind in ('pop','impact'):add(kind,s['start'],'نبرة تعليق واضحة وغير حساسة؛ مستوى منخفض مع خفض تحت صوتك',.85)
        if i and s.get('story_topic') and s.get('story_topic')!=segments[i-1].get('story_topic'):
            gap=s['start']-segments[i-1]['end']
            if gap>=.16 and not protected(segments[i-1]):
                at=segments[i-1]['end'];seconds=available['whoosh']['duration']
                if at+seconds<=s['start']+.02:add('whoosh',at,'تغيير موضوع مؤكد داخل وقفة؛ لا يغطي بداية كلمة',.9)
    return sorted(result,key=lambda e:e['timestamp'])


def validate(effects,limit,segments=None,files=True):
    seen=set();previous=-10
    enabled=sorted((e for e in effects if e.get('approved')),key=lambda e:e['timestamp'])
    if len(enabled)>max(1,math.ceil(limit/30)):raise ValueError('المؤثرات كثيرة؛ خفّف العدد حتى يبقى صوتك هو الأساس.')
    for e in effects:
        if not e.get('id') or e['id'] in seen:raise ValueError('معرّف مؤثر مفقود أو مكرر.')
        seen.add(e['id'])
        at,seconds,gain=map(float,(e['timestamp'],e['duration'],e['gain_db']))
        if not all(math.isfinite(v) for v in (at,seconds,gain)) or not 0<=at<at+seconds<=limit+.001 or not .08<=seconds<=1.2 or not -40<=gain<=-6:
            raise ValueError('المؤثر: توقيت داخل المقطع، مدة 0.08–1.2 ثانية، ومستوى بين -40 و-6 dB.')
        if e.get('approved') and (not e.get('usage_approved') or not e.get('license') or normalize(e['license']) in ('unknown','غير معروف') or not e.get('source')):
            raise ValueError('المؤثر يحتاج مصدرًا ورخصة معتمدين.')
        if files and e.get('approved'):
            if fingerprint(e['path'])!=e['fingerprint'] or duration(e['path'],'audio')+.02<seconds:
                raise ValueError('ملف المؤثر تغير أو مدته غير كافية.')
    for e in enabled:
        if e['timestamp']-previous<10:raise ValueError('اترك عشر ثوانٍ على الأقل بين المؤثرات.')
        if segments and any(protected(s) for s in segments if s['start']<e['timestamp']+e['duration'] and s['end']>e['timestamp']):
            raise ValueError('المؤثر يغطي معلومة مهمة أو كلامًا غير واضح؛ انقله إلى وقفة أو عطّله.')
        previous=e['timestamp']
    return effects


def filters(effects,start,end,first_index=2,voice='voice'):
    """Shared FFmpeg graph for preview and long/Short export, including overlaps."""
    selected=[e for e in effects if e.get('approved') and e['timestamp']<end and e['timestamp']+e['duration']>start]
    if not selected:return [],[f'[{voice}]anull[a]']
    inputs=[];graph=[];labels=[];seconds=end-start
    graph.append(f'[{voice}]asplit={len(selected)+1}[mainvoice]'+''.join(f'[side{i}]' for i in range(len(selected))))
    for i,e in enumerate(selected):
        offset=max(0,start-e['timestamp']);at=max(0,e['timestamp']-start)
        length=min(e['duration']-offset,seconds-at);delay=round(at*1000)
        inputs+=['-ss',str(offset),'-i',e['path']]
        graph.append(f'[{first_index+i}:a]atrim=duration={length},asetpts=PTS-STARTPTS,aformat=sample_fmts=fltp:channel_layouts=stereo,aresample=48000,afade=t=in:d=0.005,afade=t=out:st={max(0,length-.01)}:d=0.01,volume={e["gain_db"]}dB,adelay={delay}:all=1,apad,atrim=duration={seconds}[fx{i}]')
        graph.append(f'[fx{i}][side{i}]sidechaincompress=threshold=0.015:ratio=8:attack=5:release=120[duck{i}]')
        labels.append(f'[duck{i}]')
    graph.append('[mainvoice]'+''.join(labels)+f'amix=inputs={len(selected)+1}:duration=first:normalize=0,alimiter=limit=0.95:level=false:latency=true[a]')
    return inputs,graph


def preview(audio,effects,output,limit,cancel=None,already_processed=False):
    validate(effects,limit)
    inputs,graph=filters(effects,0,limit,first_index=1)
    normal='' if already_processed else 'loudnorm=I=-16:TP=-1.5:LRA=11,'
    voice='[0:a]aformat=channel_layouts=stereo,'+normal+'aresample=48000[voice]'
    run(['ffmpeg','-v','error','-y','-i',audio,*inputs,'-filter_complex_threads','1','-filter_complex',
         ';'.join([voice,*graph]),'-map','[a]','-t',str(limit),'-ar','48000','-c:a','pcm_s16le',output],cancel=cancel)
    return str(output)
