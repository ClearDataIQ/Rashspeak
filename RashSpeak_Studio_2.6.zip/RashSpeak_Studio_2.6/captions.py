"""Logical Unicode Arabic captions: libass handles bidi and shaping once."""
import json
import math
from pathlib import Path
import re
import textwrap
import unicodedata


def validate(segments, duration):
    result = []
    previous = 0.0
    for item in segments:
        start, end = float(item['start']), float(item['end'])
        if not all(math.isfinite(x) for x in (start, end)) or end > duration + .02:
            raise ValueError('توقيت الترجمة خارج مدة الصوت أو غير صالح.')
        end = min(end, duration)
        if 0 <= duration - end <= .001:
            end = duration
        if abs(start - previous) <= .001:
            start = previous
        text = str(item.get('text', '')).strip()
        if not all(math.isfinite(x) for x in (start, end)) or not 0 <= start < end <= duration:
            raise ValueError('توقيت الترجمة خارج مدة الصوت أو غير صالح.')
        if start < previous - .001:
            raise ValueError('جمل الترجمة متداخلة؛ صحح التوقيت قبل المتابعة.')
        if not text:
            raise ValueError('جملة ترجمة فارغة.')
        if item.get('mode', 'auto') not in ('auto', 'factual', 'sensitive', 'crucial', 'cta', 'humor', 'frustration', 'surprise'):
            raise ValueError('نوع الجملة غير معروف.')
        importance = float(item.get('importance', 0))
        if not math.isfinite(importance) or not 0 <= importance <= 10:
            raise ValueError('أهمية الجملة بين 0 و10.')
        result.append({**item, 'start': start, 'end': min(end, duration), 'text': text})
        previous = end
    return result


def stamp(seconds, ass=False):
    units = round(seconds * (100 if ass else 1000))
    h, units = divmod(units, 360000 if ass else 3600000)
    m, units = divmod(units, 6000 if ass else 60000)
    s, fraction = divmod(units, 100 if ass else 1000)
    return f'{h}:{m:02}:{s:02}.{fraction:02}' if ass else f'{h:02}:{m:02}:{s:02},{fraction:03}'


def read_srt(path):
    text = Path(path).read_text(encoding='utf-8-sig').replace('\r', '')
    result = []
    def seconds(t):
        h, m, s = t.replace(',', '.').split(':')
        return int(h) * 3600 + int(m) * 60 + float(s)
    for block in re.split(r'\n\s*\n', text.strip()):
        lines = block.splitlines()
        timing = next((i for i, line in enumerate(lines) if '-->' in line), None)
        if timing is None:
            raise ValueError('صيغة SRT غير صالحة.')
        start, end = lines[timing].split('-->')
        result.append({'start': seconds(start.strip()), 'end': seconds(end.strip()),
                       'text': ' '.join(lines[timing + 1:])})
    return result


def load(path):
    path = Path(path)
    return read_srt(path) if path.suffix.lower() == '.srt' else json.loads(path.read_text(encoding='utf-8-sig'))


def wrapped(text, width=38):
    # Reject invisible overrides and ASS syntax; retain Arabic in logical order.
    text = ''.join(c for c in text if unicodedata.category(c) != 'Cf')
    text = text.replace('\\', '／').replace('{', '〔').replace('}', '〕')
    lines = textwrap.wrap(' '.join(text.split()), width=width, break_long_words=True, break_on_hyphens=False)
    return lines or ['']


def pages(segments, width=38):
    result = []
    for item in segments:
        lines = wrapped(item['text'], width)
        groups = [lines[i:i + 2] for i in range(0, len(lines), 2)]
        total = sum(len(' '.join(g)) for g in groups)
        at = item['start']
        for i, group in enumerate(groups):
            end = item['end'] if i == len(groups) - 1 else at + (item['end'] - item['start']) * len(' '.join(group)) / total
            result.append({'start': at, 'end': end, 'text': '\n'.join(group)})
            at = end
    return result


def write_srt(segments, path):
    text = ''.join(f'{i}\n{stamp(s["start"])} --> {stamp(s["end"])}\n{s["text"]}\n\n' for i, s in enumerate(pages(segments), 1))
    Path(path).write_text(text, encoding='utf-8-sig')


def write_ass(segments, path, size=(1920, 1080), font='Arial', style='gaming', region=(.10, .78, .80, .15),font_size=None,outline=None,highlight=False):
    w, h = size
    x, y, rw, rh = region
    if any(c in font for c in ',\r\n{}\\'):
        raise ValueError('اسم الخط غير صالح.')
    font_size = font_size if font_size is not None else max(18, round(min(h * .048, rh * h / 2.8)))
    outline = outline if outline is not None else 3 if style == 'gaming' else 2
    bold = -1 if style == 'gaming' else 0
    # Position captions inside the chosen rectangle. Explicit wraps guarantee <=2 lines.
    header = f'''[Script Info]
ScriptType: v4.00+
PlayResX: {w}
PlayResY: {h}
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,{font},{font_size},&H00FFFFFF,&H000000FF,&H00101826,&H90000000,{bold},0,0,0,100,100,0,0,1,{outline},1,2,{round(x*w)},{round((1-x-rw)*w)},{round((1-y-rh)*h)},-1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
'''
    width = max(12, int(rw * w / (font_size * .64)))
    events = []
    for item in pages(segments, width):
        content = item['text'].replace('\n', r'\N')
        events.append(f'Dialogue: 0,{stamp(item["start"],True)},{stamp(item["end"],True)},Default,,0,0,0,,{{\\an2\\pos({round((x+rw/2)*w)},{round((y+rh)*h)})}}{content}\n')
    if highlight:
        # Repaint the same full phrase at verified word intervals; never invent word time.
        for s in segments:
            words=s.get('words',[])
            if not words or ' '.join(w['text'] for w in words)!=' '.join(s['text'].split()):continue
            lines=wrapped(s['text'],width)
            if len(lines)>2:continue
            for index,word in enumerate(words):
                parts=[]
                for i,wrd in enumerate(words):
                    clean=' '.join(wrapped(wrd['text'],200))
                    parts.append((r'{\c&H00D2FF&}'+clean+r'{\c&HFFFFFF&}') if i==index else clean)
                text=' '.join(parts)
                events.append(f'Dialogue: 1,{stamp(word["start"],True)},{stamp(word["end"],True)},Default,,0,0,0,,{{\\an2\\pos({round((x+rw/2)*w)},{round((y+rh)*h)})}}{text}\n')
    Path(path).write_text(header + ''.join(events), encoding='utf-8-sig')


def transcribe(audio, model_path, logger=print, cancel=None, device='cpu', dialect='saudi', vocabulary=None, return_words=False):
    if not Path(model_path).is_dir():
        raise ValueError('اختر مجلد نموذج Whisper المحلي. تنزيل النموذج يتم منفصلًا وبموافقتك.')
    try:
        from faster_whisper import WhisperModel
    except ImportError as exc:
        raise RuntimeError('ثبّت التعرف الصوتي باستخدام INSTALL_ARABIC_SUBTITLES.bat أو استورد SRT.') from exc
    from media_tools import Cancelled, duration
    limit = duration(audio, 'audio')
    model = WhisperModel(str(model_path), device=device, compute_type='int8' if device == 'cpu' else 'float16', local_files_only=True)
    prompt = 'تعليق ألعاب باللهجة السعودية: يا جماعة، ذحين، الحين، ترى، تبغى، خلونا، مرة، وش رايكم.' if dialect == 'saudi' else 'تعليق أخبار ألعاب باللغة العربية.'
    prompt += ' أسماء الألعاب: ' + '، '.join(str(x) for x in (vocabulary or ['فورتنايت','ماينكرافت','إكس بوكس','بلايستيشن','GTA','The Witcher','Elden Ring']) if str(x).strip())[:400]
    stream, _ = model.transcribe(str(audio), language='ar', beam_size=5, vad_filter=True, word_timestamps=True,
                                initial_prompt=prompt, condition_on_previous_text=False)
    result, timed_words = [], []
    previous_word=0.0
    for segment in stream:
        if cancel and cancel.is_set():
            raise Cancelled('أُلغي التفريغ.')
        words = list(segment.words or [])
        for word in words:
            start=max(0,word.start,previous_word);end=min(limit,word.end)
            if end > start and word.word.strip():
                timed_words.append({'start':start,'end':end,'text':word.word.strip(),
                                    'probability':float(getattr(word,'probability',0))})
                previous_word=end
        if not words:
            if segment.text.strip() and segment.end > segment.start:
                result.append({'start': max(0, segment.start), 'end': min(limit, segment.end), 'text': segment.text.strip()})
            continue
        group = []
        for word in words:
            group.append(word)
            if len(''.join(x.word for x in group)) >= 64 or word.end - group[0].start >= 5 or word.word.strip().endswith(('؟', '!', '.', '،')):
                result.append({'start': max(0, group[0].start), 'end': min(limit, group[-1].end), 'text': ''.join(x.word for x in group).strip()})
                group = []
        if group:
            result.append({'start': max(0, group[0].start), 'end': min(limit, group[-1].end), 'text': ''.join(x.word for x in group).strip()})
        logger(f'تفريغ {segment.end:.1f} / {limit:.1f} ثانية')
    # ASR rounding can yield adjacent zero-length/overlapping words; keep real word times.
    cleaned = []
    previous = 0
    for s in result:
        s['start'] = max(s['start'], previous)
        if s['end'] > s['start'] and s['text']:
            cleaned.append(s)
            previous = s['end']
    if not cleaned:
        raise ValueError('لم يُكتشف كلام. استورد ترجمة مراجعة أو تابع بمسار اللقطات فقط.')
    cleaned=validate(cleaned, limit)
    return {'segments':cleaned,'words':timed_words} if return_words else cleaned
