"""Content-addressed local index. Unknown/conflicting rights never gain approval."""
from copy import deepcopy
from contextlib import contextmanager
import hashlib
import json
from pathlib import Path
import sqlite3

from app_paths import app_dir
from media_tools import Cancelled
from smart_editor import fingerprint,licensed,normalize


def database():return app_dir()/'output'/'media_library'/'index.sqlite3'


@contextmanager
def connect(path=None):
    file=Path(path or database());file.parent.mkdir(parents=True,exist_ok=True)
    db=sqlite3.connect(file,timeout=10)
    db.execute('CREATE TABLE IF NOT EXISTS assets (sha TEXT PRIMARY KEY, data TEXT NOT NULL)')
    try:
        yield db;db.commit()
    except Exception:db.rollback();raise
    finally:db.close()


def digest(path,cancel=None):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):
            if cancel and cancel.is_set():raise Cancelled('أُلغي فهرسة الوسيط.')
            h.update(block)
    return h.hexdigest()


def remember(asset,path=None,cancel=None):
    a=deepcopy(asset);sha=digest(a['path'],cancel);a['sha256']=sha
    with connect(path) as db:
        db.execute('BEGIN IMMEDIATE')
        row=db.execute('SELECT data FROM assets WHERE sha=?',(sha,)).fetchone()
        if row:
            old=json.loads(row[0])
            if old.get('license')!=a.get('license') or old.get('source')!=a.get('source'):
                a['usage_approved']=False;a['rights_conflict']=True
            a['tags']=sorted(set([*old.get('tags',[]),*a.get('tags',[])]));a['id']=old['id']
            if not a.get('game'):a['game']=old.get('game','')
        db.execute('INSERT OR REPLACE INTO assets VALUES (?,?)',(sha,json.dumps(a,ensure_ascii=False)))
    return a


def search(query='',path=None,approved_only=False):
    needle=normalize(query);result=[]
    with connect(path) as db:
        for row in db.execute('SELECT data FROM assets'):
            a=json.loads(row[0]);file=Path(a['path'])
            if not file.is_file():continue
            # Fingerprints avoid rehashing a large catalog on every UI keystroke.
            if fingerprint(file)!=a.get('fingerprint'):continue
            text=normalize(' '.join([file.name,a.get('game',''),*a.get('tags',[])]))
            if needle and not all(w in text for w in needle.split()):continue
            if approved_only and (not licensed(a) or a.get('rights_conflict')):continue
            result.append(a)
    return result


def for_topic(topic,path=None):
    return [a for a in search(topic,path,True) if a.get('kind') in ('image','video','animation') and
            a.get('role','clip')=='clip' and normalize(a.get('game',''))==normalize(topic)]
