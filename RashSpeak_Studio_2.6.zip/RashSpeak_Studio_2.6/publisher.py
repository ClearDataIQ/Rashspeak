"""RashSpeak Studio 2: official-account OAuth and publishing adapters.
Never asks for passwords. External platform access requires developer apps and approvals.
Secret tokens/keys stored in OS keyring; JSON state only contains non-secret metadata.
"""
from __future__ import annotations
import hashlib
import json
import math
import mimetypes
import os
from pathlib import Path
import secrets
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs, urlencode, urlparse

import requests

APP = 'RashSpeakStudioV2'
STATE_DIR = Path(os.getenv('APPDATA') or Path.home() / '.rashspeak') / 'RashSpeakStudio'
STATE_PATH = STATE_DIR / 'preferences.json'


def load_settings():
    defaults = {'yt_client_json':'', 'tiktok_client_key':'', 'tiktok_redirect':'http://127.0.0.1:8585/callback',
                'ig_client_id':'', 'ig_redirect':'', 'ig_account_id':'',
                'ig_api_version':'v24.0', 'ig_public_video_url':'', 'yt_channel':'', 'yt_channel_id':'', 'ig_username':'', 'tiktok_name':''}
    if STATE_PATH.exists():
        try:
            value=json.loads(STATE_PATH.read_text(encoding='utf-8'))
            for key in defaults:
                if key in value and isinstance(value[key],str): defaults[key]=value[key]
        except (OSError,ValueError):pass
    return defaults


def save_settings(settings):
    settings = {k:v for k,v in settings.items() if k in load_settings() and isinstance(v,str)}
    STATE_DIR.mkdir(parents=True,exist_ok=True)
    tmp = STATE_PATH.with_suffix('.tmp')
    tmp.write_text(json.dumps(settings,ensure_ascii=False,indent=2),encoding='utf-8')
    tmp.replace(STATE_PATH)


def secret_set(key,value):
    import keyring
    if value: keyring.set_password(APP,key,value)
    else:
        try: keyring.delete_password(APP,key)
        except keyring.errors.PasswordDeleteError:pass


def secret_get(key):
    import keyring
    return keyring.get_password(APP,key)


def json_response(resp):
    try: body=resp.json()
    except ValueError: raise RuntimeError(f'Platform HTTP {resp.status_code}: response was not JSON')
    if resp.status_code >= 400:
        # Never echo credentials or full request URL
        msg=body.get('error',body)
        if isinstance(msg,dict): msg=msg.get('message') or msg.get('code') or 'API error'
        raise RuntimeError(f'Platform HTTP {resp.status_code}: {str(msg)[:280]}')
    return body


def require_file(path, extensions=('.mp4','.mov','.webm')):
    file=Path(path)
    if not file.is_file() or file.suffix.lower() not in extensions: raise ValueError('Select a real MP4/MOV/WEBM file.')
    if file.stat().st_size<128:raise ValueError('Video file is empty or too small.')
    return file


def yt_connect(settings):
    try:
        from google_auth_oauthlib.flow import InstalledAppFlow
        from googleapiclient.discovery import build
    except ImportError as exc: raise RuntimeError('Install requirements.txt for Google YouTube integration.') from exc
    file=Path(settings['yt_client_json'])
    if not file.is_file(): raise RuntimeError('Choose Google Cloud OAuth Desktop client JSON first.')
    scopes=['https://www.googleapis.com/auth/youtube.upload','https://www.googleapis.com/auth/youtube.readonly']
    flow=InstalledAppFlow.from_client_secrets_file(str(file),scopes=scopes,autogenerate_code_verifier=True)
    credentials=flow.run_local_server(port=0,open_browser=True,authorization_prompt_message='Open this URL to connect YouTube: {url}')
    client=build('youtube','v3',credentials=credentials,cache_discovery=False)
    channels=client.channels().list(part='snippet',mine=True).execute().get('items',[])
    if not channels: raise RuntimeError('No YouTube channel returned for this Google account.')
    channel=channels[0]
    # Protect refresh and access tokens in OS keyring only
    secret_set('youtube_credentials',credentials.to_json())
    settings['yt_channel']=channel.get('snippet',{}).get('title') or channel.get('id','connected')
    settings['yt_channel_id']=channel['id']
    save_settings(settings)
    return settings['yt_channel']


def yt_upload(file,title,description,privacy='private',publish_at=None,consent=False):
    if not consent:raise RuntimeError('YouTube upload requires explicit destination approval.')
    if privacy not in ('private','unlisted','public'):raise ValueError('Invalid YouTube privacy')
    try:
        from google.oauth2.credentials import Credentials
        from google.auth.transport.requests import Request
        from googleapiclient.discovery import build
        from googleapiclient.http import MediaFileUpload
    except ImportError as exc: raise RuntimeError('YouTube libraries missing. Install requirements.txt') from exc
    val=secret_get('youtube_credentials')
    if not val:raise RuntimeError('Connect your YouTube account first.')
    credentials=Credentials.from_authorized_user_info(json.loads(val))
    if not credentials.valid:
        if not credentials.refresh_token:raise RuntimeError('YouTube connection expired. Connect again.')
        credentials.refresh(Request())
        secret_set('youtube_credentials',credentials.to_json())
    p=require_file(file)
    status={'privacyStatus':privacy,'selfDeclaredMadeForKids':False}
    if publish_at:
        if privacy != 'private':raise ValueError('YouTube scheduled posts must be private until publish time.')
        status['publishAt']=publish_at
    item={'snippet':{'title':title[:100],'description':description[:4900],'categoryId':'20'},'status':status}
    service=build('youtube','v3',credentials=credentials,cache_discovery=False)
    expected=load_settings().get('yt_channel_id')
    channels=service.channels().list(part='id',mine=True).execute().get('items',[])
    if not expected or not any(c.get('id')==expected for c in channels):
        raise RuntimeError('YouTube channel identity changed or was not verified. Reconnect and review the account.')
    request=service.videos().insert(part='snippet,status',body=item,media_body=MediaFileUpload(str(p),mimetype='video/mp4',chunksize=8*1024*1024,resumable=True))
    result=None
    while result is None:
        _, result=request.next_chunk()
    return result['id']


def ig_oauth_url(settings):
    if not settings.get('ig_client_id') or not settings.get('ig_redirect'):
        raise RuntimeError('Configure Instagram App ID and HTTPS OAuth redirect URI.')
    if not settings['ig_redirect'].startswith('https://'):
        raise RuntimeError('Instagram Business Login requires an HTTPS callback configured in Meta Developers.')
    state=secrets.token_urlsafe(25)
    secret_set('ig_pending_state',state)
    url='https://www.instagram.com/oauth/authorize?'+urlencode({
        'client_id':settings['ig_client_id'],'redirect_uri':settings['ig_redirect'],
        'scope':'instagram_business_basic,instagram_business_content_publish',
        'response_type':'code','state':state,'enable_fb_login':'0'})
    return url


def ig_finish_oauth(settings, callback_text):
    secret=secret_get('instagram_client_secret')
    if not secret:raise RuntimeError('Enter and save your Instagram App Secret locally.')
    # Allow URL only to validate state. Do not blindly accept a code with no state.
    parsed=urlparse(callback_text.strip())
    if (parsed.scheme+'://'+parsed.netloc+parsed.path) != settings['ig_redirect'].rstrip('/'):
        raise RuntimeError('The pasted Instagram redirect URL does not match configured redirect URI.')
    params=parse_qs(parsed.query)
    pending=secret_get('ig_pending_state')
    received=params.get('state',[None])[0]
    if not pending or not received or not secrets.compare_digest(received,pending):
        raise RuntimeError('Instagram OAuth state mismatch. Start connection again.')
    if not params.get('code'):raise RuntimeError('No Instagram authorization code in redirect URL.')
    code=params['code'][0].removesuffix('#_')
    resp=requests.post('https://api.instagram.com/oauth/access_token',data={
        'client_id':settings['ig_client_id'],'client_secret':secret,'grant_type':'authorization_code',
        'redirect_uri':settings['ig_redirect'],'code':code},timeout=35)
    data=json_response(resp)
    if 'data' in data and isinstance(data['data'],list):data=data['data'][0]
    token=data.get('access_token')
    if not token:raise RuntimeError('Instagram did not return an access token.')
    account_id=str(data.get('user_id',''))
    # May fail for limited test accounts; keep short token if so, but report expiration.
    try:
        long=json_response(requests.get('https://graph.instagram.com/access_token',params={
            'grant_type':'ig_exchange_token','client_secret':secret,'access_token':token},timeout=35))
        token=long.get('access_token',token)
    except (requests.RequestException,RuntimeError):pass
    secret_set('ig_access_token',token)
    secret_set('ig_pending_state','')
    settings['ig_account_id']=account_id
    try:
        profile=json_response(requests.get('https://graph.instagram.com/me',params={
            'fields':'user_id,username','access_token':token},timeout=25))
        settings['ig_account_id']=str(profile.get('user_id') or profile.get('id') or account_id)
        settings['ig_username']=profile.get('username','')
    except (requests.RequestException,RuntimeError):pass
    save_settings(settings)
    return settings['ig_username'] or settings['ig_account_id']


def ig_publish_reel(settings,video_url,caption,consent=False):
    if not consent:raise RuntimeError('Instagram publishing requires explicit destination approval.')
    token=secret_get('ig_access_token')
    if not token or not settings.get('ig_account_id'):
        raise RuntimeError('Connect Instagram with business/creator publishing permission first.')
    parsed=urlparse(video_url)
    if parsed.scheme != 'https' or not parsed.netloc or not parsed.path.lower().endswith(('.mp4','.mov')):
        raise ValueError('Instagram needs an externally hosted public HTTPS direct MP4/MOV URL. Local paths cannot be published.')
    base=f"https://graph.instagram.com/{settings.get('ig_api_version','v24.0')}"
    user=settings['ig_account_id']
    data=json_response(requests.post(f'{base}/{user}/media',data={
        'media_type':'REELS','video_url':video_url,'caption':caption[:2200],'share_to_feed':'true','access_token':token},timeout=45))
    container=data.get('id')
    if not container:raise RuntimeError('No Instagram container ID returned.')
    for _ in range(24):
        time.sleep(5)
        state=json_response(requests.get(f'{base}/{container}',params={'fields':'status_code','access_token':token},timeout=35))
        if state.get('status_code')=='FINISHED':break
        if state.get('status_code') in ('ERROR','EXPIRED'):
            raise RuntimeError(f'Instagram media processing status: {state.get("status_code")}')
    else:raise RuntimeError('Instagram video was uploaded but still processing. Avoid repeating submission immediately.')
    publish=json_response(requests.post(f'{base}/{user}/media_publish',data={'creation_id':container,'access_token':token},timeout=45))
    if not publish.get('id'):raise RuntimeError('No confirmation ID from Instagram publishing API')
    return publish['id']


def tiktok_authorize_url(settings,direct=False):
    key=settings.get('tiktok_client_key','')
    redirect=settings.get('tiktok_redirect','')
    u=urlparse(redirect)
    if not key or u.hostname not in ('127.0.0.1','localhost') or not u.port or u.scheme!='http':
        raise RuntimeError('Configure TikTok client key and a local http://127.0.0.1:PORT/callback URL.')
    state=secrets.token_urlsafe(24)
    verifier=secrets.token_urlsafe(64)
    challenge=hashlib.sha256(verifier.encode()).hexdigest()  # TikTok Desktop expects hex SHA256
    url='https://www.tiktok.com/v2/auth/authorize/?'+urlencode({
        'client_key':key,'response_type':'code','scope':('user.info.basic,video.upload,video.publish' if direct else 'user.info.basic,video.upload'),
        'redirect_uri':redirect,'state':state,'code_challenge':challenge,'code_challenge_method':'S256'})
    return url,state,verifier


def tiktok_finish(settings,code,verifier):
    secret=secret_get('tiktok_client_secret')
    if not secret:raise RuntimeError('Save TikTok Client Secret before connecting.')
    response=json_response(requests.post('https://open.tiktokapis.com/v2/oauth/token/',data={
        'client_key':settings['tiktok_client_key'],'client_secret':secret,
        'code':code,'grant_type':'authorization_code','redirect_uri':settings['tiktok_redirect'],
        'code_verifier':verifier},timeout=35))
    if 'access_token' not in response:raise RuntimeError('TikTok did not return access token.')
    secret_set('tiktok_access_token',response['access_token'])
    secret_set('tiktok_refresh_token',response.get('refresh_token',''))
    secret_set('tiktok_expires',str(time.time()+response.get('expires_in',86400)))
    secret_set('tiktok_scope',response.get('scope',''))
    settings['tiktok_name']=response.get('open_id','TikTok connected')
    save_settings(settings)
    return settings['tiktok_name']


def tiktok_connect(settings,logger=print,timeout=150,direct=False):
    """Run locally, external browser official TikTok consent; blocks background worker only."""
    url,state,verifier=tiktok_authorize_url(settings,direct=direct)
    parsed=urlparse(settings['tiktok_redirect'])
    result={}
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            if urlparse(self.path).path != parsed.path:
                self.send_error(404);return
            qs=parse_qs(urlparse(self.path).query)
            if qs.get('state',[None])[0]!=state:
                result['error']='TikTok login security state mismatch.'
            elif qs.get('error'):
                result['error']='TikTok login rejected: '+qs['error'][0]
            else:result['code']=qs.get('code',[None])[0]
            self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.end_headers()
            self.wfile.write('<html><body><h3>RashSpeak Studio</h3><p>You can return to the application now.</p></body></html>'.encode())
        def log_message(self,*args):pass
    httpd=HTTPServer((parsed.hostname,parsed.port),Handler)
    httpd.timeout=1
    logger('Opening the official TikTok authorization page...')
    try:
        webbrowser.open(url)
        deadline=time.monotonic()+timeout
        while time.monotonic()<deadline and 'code' not in result and 'error' not in result:
            httpd.handle_request()
    finally:httpd.server_close()
    if result.get('error'):raise RuntimeError(result['error'])
    if not result.get('code'):raise TimeoutError('TikTok login timed out. Try again.')
    return tiktok_finish(settings,result['code'],verifier)


def tiktok_access(settings):
    token=secret_get('tiktok_access_token')
    if not token:raise RuntimeError('Connect TikTok first.')
    if time.time()<float(secret_get('tiktok_expires') or 0)-300:return token
    refresh=secret_get('tiktok_refresh_token')
    if not refresh:raise RuntimeError('TikTok token expired; connect again.')
    body=json_response(requests.post('https://open.tiktokapis.com/v2/oauth/token/',data={
        'client_key':settings['tiktok_client_key'],'client_secret':secret_get('tiktok_client_secret'),
        'grant_type':'refresh_token','refresh_token':refresh},timeout=35))
    secret_set('tiktok_access_token',body['access_token'])
    secret_set('tiktok_refresh_token',body.get('refresh_token',refresh))
    secret_set('tiktok_expires',str(time.time()+body.get('expires_in',86400)))
    if body.get('scope'): secret_set('tiktok_scope',body['scope'])
    return body['access_token']


def chunk_plan(size):
    """TikTok: floor(size/chunk_size) chunks, tail merged into final chunk."""
    if size<1:raise ValueError('Invalid file size')
    if size<=64_000_000:return size,[(0,size)]
    chunk=20_000_000
    count=size//chunk
    if count<1 or count>1000:raise ValueError('File is too large for TikTok API chunk limits')
    result=[]
    for index in range(count):
        begin=index*chunk
        end=(index+1)*chunk if index<count-1 else size
        result.append((begin,end))
    return chunk,result


def tiktok_upload_draft(settings,file,logger=print,consent=False):
    """Upload to TikTok inbox. User must finish publication in TikTok app."""
    if not consent:raise RuntimeError('TikTok inbox upload requires explicit destination approval.')
    p=require_file(file,('.mp4','.mov','.webm'))
    token=tiktok_access(settings)
    size=p.stat().st_size
    if size>4_000_000_000:raise ValueError('TikTok maximum file size 4GB')
    chunk, spans=chunk_plan(size)
    init=json_response(requests.post('https://open.tiktokapis.com/v2/post/publish/inbox/video/init/',
      headers={'Authorization':'Bearer '+token},json={'source_info':{
         'source':'FILE_UPLOAD','video_size':size,'chunk_size':chunk,'total_chunk_count':len(spans)}},timeout=45))
    if init.get('error',{}).get('code')!='ok':raise RuntimeError('TikTok rejected upload: '+str(init.get('error',{}).get('message') or init.get('error',{}).get('code')))
    data=init.get('data',{})
    if not data.get('publish_id'):raise RuntimeError('TikTok did not return a submission ID.')
    upload_url=data.get('upload_url','')
    if not upload_url.startswith('https://'):raise RuntimeError('TikTok did not return an HTTPS upload URL.')
    mime={'mp4':'video/mp4','mov':'video/quicktime','webm':'video/webm'}[p.suffix.lower().lstrip('.')]
    with p.open('rb') as f:
        for i,(begin,end) in enumerate(spans,1):
            f.seek(begin)
            content=f.read(end-begin)
            logger(f'Uploading TikTok chunk {i}/{len(spans)}...')
            resp=requests.put(upload_url,data=content,headers={
                'Content-Type':mime,'Content-Length':str(len(content)),
                'Content-Range':f'bytes {begin}-{end-1}/{size}'},timeout=240)
            if resp.status_code not in (201,206):raise RuntimeError(f'TikTok chunk rejected, HTTP {resp.status_code}')
    return data.get('publish_id','uploaded')



def tiktok_creator_info(settings):
    if 'video.publish' not in (secret_get('tiktok_scope') or '').split(','):
        raise RuntimeError('TikTok connection lacks video.publish. Reconnect with approved Direct Post scope.')
    token=tiktok_access(settings)
    body=json_response(requests.post('https://open.tiktokapis.com/v2/post/publish/creator_info/query/',
            headers={'Authorization':'Bearer '+token},timeout=35))
    if body.get('error',{}).get('code')!='ok':
        raise RuntimeError('TikTok creator_info denied: '+str(body.get('error',{}).get('message','scope')))
    data=body.get('data',{})
    if not data.get('creator_username') or not data.get('privacy_level_options'):
        raise RuntimeError('TikTok did not return required creator settings.')
    return data


def tiktok_post_direct(settings,file,caption,privacy,comment_disabled=False,duet_disabled=False,
                       stitch_disabled=False,brand_content=False,brand_organic=False,
                       is_aigc=False,consent=False,creator_info=None,logger=print):
    if not consent: raise RuntimeError('Direct TikTok posting requires explicit approval on the export screen.')
    if 'video.publish' not in (secret_get('tiktok_scope') or '').split(','):
        raise RuntimeError('TikTok connection lacks approved video.publish scope.')
    p=require_file(file)
    info=creator_info or tiktok_creator_info(settings)
    if privacy not in info['privacy_level_options']:
        raise ValueError('Chosen TikTok privacy setting is not allowed on this account.')
    if not comment_disabled and info.get('comment_disabled'):raise ValueError('Comments disabled by TikTok account settings.')
    if not duet_disabled and info.get('duet_disabled'):raise ValueError('Duets disabled by TikTok account settings.')
    if not stitch_disabled and info.get('stitch_disabled'):raise ValueError('Stitch disabled by TikTok account settings.')
    # TikTok requires disclosure if this is branded content or self-promotion.
    if brand_content and privacy=='SELF_ONLY':raise ValueError('Sponsored posts may have additional TikTok privacy restrictions.')
    token=tiktok_access(settings)
    try:
        from media_tools import duration as media_duration
        seconds=media_duration(p,'video')
    except (OSError,ValueError,RuntimeError,TimeoutError):
        raise RuntimeError('Could not validate TikTok video duration with ffprobe.')
    if seconds>info.get('max_video_post_duration_sec',600):
        raise ValueError('Video exceeds TikTok creator maximum duration.')
    size=p.stat().st_size
    if size>4_000_000_000:raise ValueError('TikTok maximum file size 4GB')
    chunk,spans=chunk_plan(size)
    post_info={'title':caption[:2200], 'privacy_level':privacy,
               'disable_comment':bool(comment_disabled),'disable_duet':bool(duet_disabled),
               'disable_stitch':bool(stitch_disabled),'brand_content_toggle':bool(brand_content),
               'brand_organic_toggle':bool(brand_organic),'is_aigc':bool(is_aigc)}
    body=json_response(requests.post('https://open.tiktokapis.com/v2/post/publish/video/init/',
        headers={'Authorization':'Bearer '+token},json={'post_info':post_info,
        'source_info':{'source':'FILE_UPLOAD','video_size':size,'chunk_size':chunk,
                       'total_chunk_count':len(spans)}},timeout=45))
    if body.get('error',{}).get('code')!='ok':
        raise RuntimeError('TikTok Direct Post denied: '+str(body.get('error',{}).get('message','API refused')))
    data=body.get('data',{})
    if not data.get('publish_id'):raise RuntimeError('TikTok did not return a submission ID.')
    upload_url=data.get('upload_url','')
    if not upload_url.startswith('https://'):raise RuntimeError('TikTok did not return an HTTPS upload URL.')
    mime={'mp4':'video/mp4','mov':'video/quicktime','webm':'video/webm'}[p.suffix.lower().lstrip('.')]
    with p.open('rb') as f:
        for i,(start,end) in enumerate(spans,1):
            f.seek(start);payload=f.read(end-start)
            logger(f'TikTok Direct Post upload {i}/{len(spans)}')
            resp=requests.put(upload_url,data=payload,headers={
              'Content-Type':mime,'Content-Length':str(len(payload)),
              'Content-Range':f'bytes {start}-{end-1}/{size}'},timeout=240)
            if resp.status_code not in (201,206):raise RuntimeError(f'TikTok upload failed: HTTP {resp.status_code}')
    return data.get('publish_id','submitted')

def disconnect(platform,settings):
    keys={'youtube':['youtube_credentials'],'instagram':['ig_access_token','ig_pending_state'],
          'tiktok':['tiktok_access_token','tiktok_refresh_token','tiktok_expires','tiktok_scope']}
    for key in keys[platform]: secret_set(key,'')
    if platform=='youtube':settings['yt_channel']='';settings['yt_channel_id']=''
    elif platform=='instagram':settings['ig_username']='';settings['ig_account_id']=''
    else:settings['tiktok_name']=''
    save_settings(settings)


def publish_log(platform,status,content):
    STATE_DIR.mkdir(parents=True,exist_ok=True)
    f=STATE_DIR/'activity.jsonl'
    entry={'date':time.strftime('%Y-%m-%d %H:%M:%S'),'platform':platform,'status':status,'detail':str(content)[:400]}
    with f.open('a',encoding='utf-8') as stream:stream.write(json.dumps(entry,ensure_ascii=False)+'\n')


def recent_logs(limit=50):
    f=STATE_DIR/'activity.jsonl'
    if not f.is_file():return []
    lines=f.read_text(encoding='utf-8').splitlines()[-limit:]
    try:return [json.loads(x) for x in reversed(lines)]
    except ValueError:return []
