"""Bounded official RSS/Atom collection and local, source-backed Arabic scripts."""
from datetime import datetime, timezone, timedelta
from email.utils import parsedate_to_datetime
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
import re
from urllib.parse import urlparse
import xml.etree.ElementTree as ET

import requests
from app_paths import app_dir
from smart_editor import save

SOURCES = [
    {'id': 'playstation', 'name': 'PlayStation Blog', 'url': 'https://blog.playstation.com/feed/', 'hosts': ['blog.playstation.com']},
    {'id': 'xbox', 'name': 'Xbox Wire', 'url': 'https://news.xbox.com/en-us/feed/', 'hosts': ['news.xbox.com']},
    {'id': 'steam', 'name': 'Steam', 'url': 'https://store.steampowered.com/feeds/news.xml', 'hosts': ['store.steampowered.com', 'steamcommunity.com']},
]


class PlainText(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts, self.ignored = [], 0
    def handle_starttag(self, tag, attrs):
        if tag in ('script', 'style'):
            self.ignored += 1
        if tag in ('p', 'br', 'li'):
            self.parts.append(' ')
    def handle_endtag(self, tag):
        if tag in ('script', 'style'):
            self.ignored = max(0, self.ignored - 1)
        self.parts.append(' ')
    def handle_data(self, data):
        if not self.ignored:
            self.parts.append(data)


def plain(text):
    parser = PlainText()
    parser.feed(text or '')
    return ' '.join(''.join(parser.parts).split())


def date(value):
    try:
        result = parsedate_to_datetime(value)
    except (ValueError, TypeError):
        try:
            result = datetime.fromisoformat(value.replace('Z', '+00:00'))
        except (ValueError, AttributeError):
            return None
    return (result.replace(tzinfo=timezone.utc) if result.tzinfo is None else result).astimezone(timezone.utc)


def parse_feed(payload, source, now=None, days=7):
    if len(payload) > 4_000_000 or b'<!DOCTYPE' in payload.upper() or b'<!ENTITY' in payload.upper():
        raise ValueError('مصدر الأخبار أكبر من الحد أو XML غير آمن.')
    root = ET.fromstring(payload)
    now = now or datetime.now(timezone.utc)
    atom = '{http://www.w3.org/2005/Atom}'
    nodes = root.findall('./channel/item') or root.findall(atom + 'entry')
    result = []
    for node in nodes[:60]:
        title = plain(node.findtext('title') or node.findtext(atom + 'title'))
        url = node.findtext('link') or ''
        if not url:
            link = next((n for n in node.findall(atom + 'link') if n.get('rel', 'alternate') == 'alternate'), None)
            url = link.get('href', '') if link is not None else ''
        parsed = urlparse(url)
        if parsed.scheme != 'https' or parsed.hostname not in source['hosts'] or parsed.username or parsed.password:
            continue
        published = date(node.findtext('pubDate') or node.findtext(atom + 'published') or node.findtext(atom + 'updated'))
        if not title or not published or not now - timedelta(days=days) <= published <= now + timedelta(hours=1):
            continue
        summary = plain(node.findtext('description') or node.findtext(atom + 'summary') or node.findtext(atom + 'content'))
        # One short source excerpt per item, never a full copied article or image library.
        words = summary.split()
        summary = ' '.join(words[:65])
        result.append({'id': hashlib.sha256(url.encode()).hexdigest()[:20], 'source_id': source['id'],
                       'source': source['name'], 'title': title[:240], 'url': url, 'summary': summary,
                       'published': published.isoformat(), 'fetched': now.isoformat(), 'status': 'official',
                       'facts_ar': '', 'title_ar': '', 'translation_reviewed': False})
    return result


def collect(source_ids=None, days=7, logger=print, cancel=None):
    from media_tools import Cancelled
    items, errors = {}, []
    for source in SOURCES:
        if source_ids is not None and source['id'] not in source_ids:
            continue
        if cancel and cancel.is_set():
            raise Cancelled('أُلغي جلب الأخبار.')
        logger('جلب الأخبار من ' + source['name'])
        try:
            with requests.get(source['url'], headers={'User-Agent': 'RashSpeakStudio/2.1 (manual news reader)'},
                              timeout=(10, 25), stream=True, allow_redirects=False) as response:
                response.raise_for_status()
                if response.status_code != 200:
                    raise RuntimeError('المصدر أعاد تحويلًا؛ حدّث الرابط الرسمي بدل اتباعه تلقائيًا.')
                blocks, total = [], 0
                for block in response.iter_content(65536):
                    total += len(block)
                    if total > 4_000_000:
                        raise ValueError('حجم مصدر الأخبار يتجاوز الحد.')
                    if cancel and cancel.is_set():
                        raise Cancelled('أُلغي جلب الأخبار.')
                    blocks.append(block)
                for item in parse_feed(b''.join(blocks), source, days=days):
                    items[item['id']] = item
        except (requests.RequestException, ValueError, RuntimeError, ET.ParseError) as exc:
            errors.append({'source': source['name'], 'error': str(exc)[:240]})
    return {'items': sorted(items.values(), key=lambda x: x['published'], reverse=True), 'errors': errors,
            'fetched': datetime.now(timezone.utc).isoformat(), 'days': days}


class LocalNewsTranslator:
    """Helsinki Marian model via CTranslate2; no hosted inference or API key."""
    def __init__(self, model_dir=None):
        folder = Path(model_dir or app_dir() / 'models/news-helsinki-en-ar')
        if not (folder / 'model.bin').is_file():
            raise RuntimeError('جهّز الترجمة المحلية باستخدام SETUP_NEWS_MODEL.bat أو اكتب خلاصة عربية مراجعة.')
        try:
            import ctranslate2
            import sentencepiece
        except ImportError as exc:
            raise RuntimeError('ثبّت مكتبات الأخبار باستخدام SETUP_NEWS_MODEL.bat.') from exc
        self.translator = ctranslate2.Translator(str(folder), device='cpu', compute_type='int8', inter_threads=1, intra_threads=4)
        self.tokenizer = sentencepiece.SentencePieceProcessor(model_file=str(folder / 'source.spm'))
        self.target = sentencepiece.SentencePieceProcessor(model_file=str(folder / 'target.spm'))

    def translate(self, text):
        text = plain(text)
        if not text:
            return ''
        if re.search('[\u0600-\u06ff]', text) and not re.search('[A-Za-z]{4}', text):
            return text
        # Translate complete short sentences, keep the original beside the result for review.
        parts = re.split(r'(?<=[.!?])\s+', text)
        result = []
        for part in parts:
            tokens = ['>>ara<<', *self.tokenizer.encode(part, out_type=str), '</s>']
            if len(tokens) > 250:
                raise ValueError('اختصر المقتطف قبل الترجمة.')
            translated = self.translator.translate_batch([tokens], beam_size=4, max_decoding_length=256)
            result.append(self.target.decode([t for t in translated[0].hypotheses[0] if t not in ('</s>','<pad>','<s>')]))
        return ' '.join(result)


def translate_item(item, translator):
    return {**item, 'title_ar': translator.translate(item['title']), 'facts_ar': translator.translate(item['summary']),
            'translation_reviewed': False}


def article_excerpt(payload):
    """Select short factual sentences from article body, excluding navigation."""
    from bs4 import BeautifulSoup
    if len(payload) > 4_000_000:
        raise ValueError('حجم المقال يتجاوز الحد.')
    soup = BeautifulSoup(payload, 'html.parser')
    body = soup.select_one('.entry-content') or soup.select_one('article')
    if body is None:
        raise ValueError('تعذر تحديد نص المقال؛ راجع المصدر يدويًا.')
    sentences = []
    for paragraph in body.select('p')[:100]:
        for sentence in re.split(r'(?<=[.!?])\s+', paragraph.get_text(' ', strip=True)):
            if re.search(r'\b(launch\w*|releas\w*|available|updat\w*|includes?|requires?|announc\w*|October|November|December|January|February|March|April|May|June|July|August|September)\b', sentence, re.I):
                if 4 <= len(sentence.split()) <= 60 and sentence not in sentences:
                    sentences.append(sentence)
    selected, count = [], 0
    for sentence in sentences:
        words = len(sentence.split())
        if count + words <= 95:
            selected.append(sentence); count += words
        if len(selected) == 3:
            break
    if not selected:
        raise ValueError('لم تُحدد خلاصة موثوقة آليًا؛ اكتبها بعد قراءة المصدر.')
    return ' '.join(selected)


def enrich_item(item, cancel=None):
    """Explicit single-article fetch, HTTPS allowlist, no media downloads."""
    from media_tools import Cancelled
    source = next((s for s in SOURCES if s['id'] == item.get('source_id')), None)
    parsed = urlparse(item['url'])
    if not source or parsed.scheme != 'https' or parsed.hostname not in source['hosts'] or parsed.username or parsed.password or parsed.port not in (None,443):
        raise ValueError('رابط المقال ليس ضمن المصادر الرسمية.')
    with requests.get(item['url'], timeout=(10,25), stream=True, allow_redirects=False,
                      headers={'User-Agent':'RashSpeakStudio/2.1 (manual news reader)'}) as response:
        response.raise_for_status()
        if response.status_code != 200:
            raise ValueError('المقال أعاد تحويلًا؛ افتحه للتحقق يدويًا.')
        if 'text/html' not in response.headers.get('Content-Type','').lower():
            raise ValueError('المصدر ليس مقال HTML.')
        blocks,total = [],0
        for block in response.iter_content(65536):
            if cancel and cancel.is_set():raise Cancelled('أُلغي جلب المقال.')
            total += len(block)
            if total > 4_000_000:raise ValueError('حجم المقال يتجاوز الحد.')
            blocks.append(block)
    return {**item, 'summary':article_excerpt(b''.join(blocks)), 'title_ar':'', 'facts_ar':'',
            'translation_reviewed':False, 'excerpt_kind':'article_sentences'}


def script(item, variant='news', profile=None):
    from channel_style import load_profile
    profile = profile or load_profile()
    if not item.get('title_ar', '').strip() or not item.get('facts_ar', '').strip():
        raise ValueError('ترجم عنوان الخبر ومقتطفه أو أدخل خلاصة عربية أولًا.')
    title, facts = item['title_ar'].strip(), item['facts_ar'].strip()
    if len(facts.split()) > 110:
        raise ValueError('الخلاصة طويلة؛ اختصرها إلى أهم التفاصيل الموثقة.')
    intro = profile['script']['intro']
    if variant == 'short':
        body = f'يا جماعة، فيه خبر جديد: {title}.\n\nبحسب {item["source"]}، {facts}\n\nوش رايكم؟ الخبر هذا يهمكم ولا لا؟'
    elif variant == 'analysis':
        body = f'{intro}\n\nاليوم خلونا نتكلم عن: {title}.\n\nأول شيء نفصل الخبر عن رأينا. بحسب {item["source"]}، {facts}\n\nالشيء اللي يستاهل نتابعه هنا هو التفاصيل اللي أعلنها المصدر نفسه. خلونا نشوف التجربة قبل ما نعطي حكم نهائي.\n\nوش تتوقعون؟ عطوني رأيكم في التعليقات.'
    elif variant == 'news':
        body = f'{intro}\n\nيا جماعة، وصلنا خبر عن: {title}. خلونا نشوف الزبدة.\n\nبحسب {item["source"]}، {facts}\n\nهذا اللي عندنا من المصدر الرسمي. إذا نزلت تفاصيل زيادة، نرجع لها ونشوف وش تغيّر.\n\nوش رايكم بالخبر؟ وإذا عجبكم المقطع، دعمكم يفرق معي.'
    else:
        raise ValueError('نوع سكربت غير معروف.')
    return {'text': body, 'source_url': item['url'], 'published': item['published'], 'variant': variant,
            'profile_version': profile['version'], 'status': 'DRAFT',
            'warnings': ([] if item.get('translation_reviewed') else ['راجع الترجمة والأرقام وأسماء الألعاب مع المصدر قبل التسجيل.']),
            'personal_opinion_required': variant == 'analysis'}
