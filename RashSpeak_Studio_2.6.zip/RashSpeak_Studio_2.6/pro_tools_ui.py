"""Real clip/track DSP, color/mask and timed-word controls."""
from copy import deepcopy
import tkinter as tk
from tkinter import ttk
from rtl_ui import Label,Button,Treeview,visual,dialogs as messagebox
from pro_subtitles import canonical_words,update_word

BG='#0b1220';CARD='#132138';TEXT='#eef5ff';CYAN='#08BEED';MUTED='#91a9c4'


def button(parent,label,fn):return Button(parent,text=label,command=fn,bg='#223b58',fg=TEXT,relief='flat',padx=10,pady=6)


def fields(parent,definitions):
    values={}
    for key,label,default in definitions:
        row=tk.Frame(parent,bg=CARD);row.pack(fill='x',pady=3);values[key]=tk.StringVar(value=str(default))
        Label(row,text=label,bg=CARD,fg=TEXT,anchor='e').pack(side='right')
        tk.Entry(row,textvariable=values[key],bg=BG,fg=TEXT,insertbackground=TEXT,width=17).pack(side='left')
    return values


def open_tools(editor):
    if editor.busy:return
    if not editor.selected and not editor.selected_track:
        editor.status.set('اختر مقطعًا أو مسارًا أولًا.');return
    clip_id=editor.selected[0] if editor.selected else None
    track,clip=editor.session.clip(clip_id) if clip_id else (editor.session.track(editor.selected_track),None)
    w=tk.Toplevel(editor);w.title('RashSpeak • أدوات احترافية');w.geometry('650x720');w.configure(bg=BG)
    book=ttk.Notebook(w);book.pack(fill='both',expand=True,padx=12,pady=12)
    status=tk.StringVar(value='التأثيرات تظهر في المعاينة والتصدير بعد التحديث.')
    Label(w,textvariable=status,bg=BG,fg=MUTED,wraplength=620).pack(fill='x',padx=12,pady=6)
    def apply(fn):
        if editor.busy:return
        try:fn();editor.refresh();status.set('تم التطبيق والحفظ التلقائي. حدّث المعاينة.')
        except (ValueError,KeyError,OSError) as exc:status.set(str(exc))
    if track['kind'] in ('audio','effect'):
        page=tk.Frame(book,bg=CARD,padx=14,pady=10);book.add(page,text=visual('معالجة الصوت'))
        scope=tk.StringVar(value='clip' if clip else 'track');ttk.Combobox(page,textvariable=scope,values=['clip','track'] if clip else ['track'],state='readonly').pack(fill='x')
        original=(clip or track).get('processing',{})
        values=fields(page,[(k,label,original.get(k,default)) for k,label,default in [
            ('highpass','High-pass Hz',0),('eq_low','EQ منخفض dB',0),('eq_mid','EQ متوسط dB',0),('eq_high','EQ مرتفع dB',0),
            ('threshold_db','Compressor threshold dB',-18),('ratio','Compressor ratio',3),('attack','Attack ms',10),('release','Release ms',120),('loudness','LUFS — off لتعطيله','off')]])
        if original.get('loudness') is None:values['loudness'].set('off')
        toggles={}
        for key,label in [('denoise','تخفيف الضوضاء'),('compressor','Compressor'),('deesser','De-esser')]:
            toggles[key]=tk.BooleanVar(value=original.get(key,False));tk.Checkbutton(page,text=visual(label),variable=toggles[key],bg=CARD,fg=TEXT,selectcolor=BG).pack(anchor='e')
        def set_processing(data):
            editor.session.editable(editor.session.track(track['id']))
            if scope.get()=='track':editor.session.track_state(track['id'],processing=data)
            else:editor.session.properties(clip_id,processing=data)
        def process():
            data={k:float(v.get()) for k,v in values.items() if k!='loudness'};data.update({k:v.get() for k,v in toggles.items()})
            data['loudness']=None if values['loudness'].get().lower()=='off' else float(values['loudness'].get());apply(lambda:set_processing(data))
        def preset():
            for key,value in {'highpass':65,'eq_low':-1,'eq_mid':1.5,'eq_high':.5,'loudness':'off'}.items():values[key].set(str(value))
            for v in toggles.values():v.set(True)
            status.set('إعداد تعليق مقترح؛ تطبيع LUFS معطل لتجنب تكراره فوق الصوت المنظف. طبّق واستمع.')
        row=tk.Frame(page,bg=CARD);row.pack(fill='x',pady=8)
        button(row,'تطبيق الصوت',process).pack(side='right',padx=3);button(row,'إعداد تعليق مقترح',preset).pack(side='right',padx=3)
        button(row,'إلغاء المعالجة',lambda:apply(lambda:set_processing({}))).pack(side='right',padx=3)
        automation=tk.Frame(book,bg=CARD,padx=14,pady=10);book.add(automation,text='Volume Automation')
        tree=Treeview(automation,columns=('frame','db'),show='headings',height=12);tree.heading('frame',text='Frame');tree.heading('db',text='Gain dB');tree.pack(fill='both',expand=True)
        v=fields(automation,[('frame','الإطار (محلي للمقطع / عام للمسار)',0),('gain_db','التغيير فوق الجهارة الأساسية dB',0)])
        def current():return editor.session.clip(clip_id)[1] if scope.get()=='clip' else editor.session.track(track['id'])
        def refresh():
            tree.delete(*tree.get_children())
            for k in current().get('volume_automation',[]):tree.insert('','end',iid=str(k['frame']),values=(k['frame'],k['gain_db']))
        def modify(remove=False):
            def change():
                editor.session.editable(track);at=int(v['frame'].get());keys=deepcopy(current().get('volume_automation',[]));keys=[k for k in keys if k['frame']!=at]
                if not remove:keys.append({'frame':at,'gain_db':float(v['gain_db'].get())})
                keys.sort(key=lambda k:k['frame'])
                if scope.get()=='clip':editor.session.properties(clip_id,volume_automation=keys)
                else:editor.session.track_state(track['id'],volume_automation=keys)
            apply(change);refresh()
        tree.bind('<<TreeviewSelect>>',lambda e:[v['frame'].set(tree.item(tree.selection()[0],'values')[0]),v['gain_db'].set(tree.item(tree.selection()[0],'values')[1])] if tree.selection() else None)
        button(automation,'إضافة / تعديل نقطة',modify).pack(fill='x',pady=4);button(automation,'حذف نقطة',lambda:modify(True)).pack(fill='x');refresh()
    elif clip and track['kind'] in ('video','image'):
        page=tk.Frame(book,bg=CARD,padx=14,pady=12);book.add(page,text=visual('الألوان والدوران'))
        color=clip.get('color',{});values=fields(page,[('exposure','Exposure EV',color.get('exposure',0)),('contrast','Contrast',color.get('contrast',1)),
            ('saturation','Saturation',color.get('saturation',1)),('temperature','Temperature -1..1',color.get('temperature',0)),('rotation','Rotation degrees',clip['transform'].get('rotation',0))])
        def grade():
            def change():
                _,c=editor.session.clip(clip_id);tr=deepcopy(c['transform']);tr['rotation']=float(values['rotation'].get())
                editor.session.properties(clip_id,color={k:float(v.get()) for k,v in values.items() if k!='rotation'},transform=tr)
            apply(change)
        button(page,'تطبيق اللون والدوران',grade).pack(fill='x',pady=12)
        asset=next(a for a in editor.session.project['media'] if a['id']==clip['media_id'])
        if asset['kind']=='video':
            speed=fields(page,[('rate','سرعة اللقطة 0.25–4',clip.get('rate',1.))]);reverse=tk.BooleanVar(value=clip.get('reverse',False))
            tk.Checkbutton(page,text='Reverse',variable=reverse,bg=CARD,fg=TEXT,selectcolor=BG).pack(anchor='e',pady=5)
            Label(page,text='المدة على Timeline ثابتة؛ يحتاج مصدرًا كافيًا أو تكرارًا مفعّلًا.\nالتعليق الصوتي لا يتغير. Reverse حتى 10 ثوانٍ من المصدر.',bg=CARD,fg=MUTED,wraplength=580).pack(fill='x',pady=5)
            button(page,'تطبيق السرعة والاتجاه',lambda:apply(lambda:editor.session.properties(clip_id,rate=float(speed['rate'].get()),reverse=reverse.get()))).pack(fill='x')
        mask_page=tk.Frame(book,bg=CARD,padx=14,pady=12);book.add(mask_page,text='Mask / Feather')
        mask=clip.get('mask') or {'shape':'rectangle','x':.1,'y':.1,'width':.8,'height':.8,'feather':.03}
        shape=tk.StringVar(value=mask['shape']);ttk.Combobox(mask_page,textvariable=shape,values=['rectangle','ellipse'],state='readonly').pack(fill='x')
        m=fields(mask_page,[(k,k,mask[k]) for k in ('x','y','width','height','feather')])
        Label(mask_page,text='قناع يدوي داخل مساحة العنصر. لا يزيل خلفية الشخصية تلقائيًا.',bg=CARD,fg=MUTED,wraplength=590).pack(fill='x',pady=12)
        button(mask_page,'تطبيق القناع',lambda:apply(lambda:editor.session.properties(clip_id,mask={'shape':shape.get(),**{k:float(v.get()) for k,v in m.items()}}))).pack(fill='x')
        button(mask_page,'إزالة القناع',lambda:apply(lambda:editor.session.properties(clip_id,mask=None))).pack(fill='x',pady=6)
    elif clip and track['kind']=='text':
        page=tk.Frame(book,bg=CARD,padx=14,pady=10);book.add(page,text=visual('الكلمات والتوقيت'))
        tree=Treeview(page,columns=('text','start','end'),show='headings',height=10)
        for k,label in [('text','الكلمة'),('start','إطار البداية'),('end','إطار النهاية')]:tree.heading(k,text=label);tree.column(k,width=160)
        tree.pack(fill='both',expand=True);v=fields(page,[('text','الكلمة', ''),('start','البداية من داخل مقطع الترجمة',0),('end','النهاية من داخل مقطع الترجمة',1)])
        def refresh():
            tree.delete(*tree.get_children());_,c=editor.session.clip(clip_id)
            for i,word in enumerate(canonical_words(c,editor.session.project['fps'])):tree.insert('','end',iid=str(i),values=(word['text'],word['start'],word['end']))
        def select(event=None):
            if tree.selection():
                values=tree.item(tree.selection()[0],'values')
                for key,value in zip(('text','start','end'),values):v[key].set(value)
        tree.bind('<<TreeviewSelect>>',select)
        def edit():
            if tree.selection():apply(lambda:update_word(editor.session,clip_id,int(tree.selection()[0]),v['text'].get(),int(v['start'].get()),int(v['end'].get())));refresh()
        button(page,'تعديل الكلمة وتوقيتها',edit).pack(fill='x',pady=6)
        def insert():
            def change():
                _,c=editor.session.clip(clip_id);words=canonical_words(c,editor.session.project['fps']);words.append({'text':v['text'].get().strip(),'start':int(v['start'].get()),'end':int(v['end'].get())});words.sort(key=lambda w:w['start'])
                editor.session.properties(clip_id,word_timing=words,text=' '.join(w['text'] for w in words))
            apply(change);refresh()
        button(page,'إضافة توقيت كلمة يدويًا',insert).pack(fill='x');refresh()
        style_page=tk.Frame(book,bg=CARD,padx=14,pady=12);book.add(style_page,text=visual('وضوح الترجمة'))
        caption=track.get('caption',{'font':'Arial','style':'clean','region':[.1,.78,.8,.15]});styles=fields(style_page,[('font_size','حجم الخط في أبعاد التسلسل',caption.get('font_size',48)),('outline','سمك الحد',caption.get('outline',3))])
        highlight=tk.BooleanVar(value=caption.get('highlight',False));tk.Checkbutton(style_page,text=visual('Highlight للكلمة أثناء نطقها'),variable=highlight,bg=CARD,fg=TEXT,selectcolor=BG).pack(anchor='e',pady=8)
        def style():
            def change():
                current=editor.session.track(track['id']);editor.session.editable(current);cap=deepcopy(current.get('caption',caption));cap.update(font_size=float(styles['font_size'].get()),outline=float(styles['outline'].get()),highlight=highlight.get())
                editor.session.edit('نمط الترجمة',lambda:current.update(caption=cap))
            apply(change)
        button(style_page,'تطبيق نمط الترجمة',style).pack(fill='x')
    return w
