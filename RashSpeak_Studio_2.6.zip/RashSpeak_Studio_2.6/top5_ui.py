import copy
import tkinter as tk
from tkinter import ttk, messagebox
from channel_style import long_description, top5_script
from smart_editor import save

REFERENCE_URL='https://youtu.be/nDXJLcR-IMM'
REFERENCE_LIST=[
    {'name':'Ghost of Tsushima','facts':'عالم مفتوح بطابع الساموراي، فيه استكشاف وقتال بالسيوف ومناظر متنوعة.','why':'إذا يعجبك قتال السيوف والاستكشاف، هذا النوع من التجارب يناسبك.','opinion':'','source':REFERENCE_URL},
    {'name':'The Witcher 3: Wild Hunt','facts':'تلعب دور صياد وحوش في عالم فيه مدن وقرى ومهام وحوارات وقرارات.','why':'القصة والحوارات واختيارات اللاعب هي محور الاختيار هنا.','opinion':'','source':REFERENCE_URL},
    {'name':'Elden Ring','facts':'استكشاف حر، مواجهة زعماء وتطور تدريجي للشخصية مع تحدي مرتفع.','why':'إذا يعجبك التحدي وتكتشف الحل بنفسك، هذه الفكرة تستاهل اهتمامك.','opinion':'','source':REFERENCE_URL},
    {'name':'Red Dead Redemption 2','facts':'عالم الغرب الأمريكي، فيه قصة وتفاصيل في الشخصيات والحياة داخل العالم.','why':'إذا تهمك التفاصيل والقصة وأجواء العالم، هذا سبب ترشيحها في القائمة.','opinion':'','source':REFERENCE_URL},
    {'name':'The Legend of Zelda: Breath of the Wild','facts':'عالم للاستكشاف، فيه تسلق وطبخ وقتال وتجارب تستخدم تفاعل عناصر العالم.','why':'حرية الاستكشاف وتجربة حلول مختلفة هي سبب وضعها في هذا المركز.','opinion':'','source':REFERENCE_URL},
]


class Top5Panel(ttk.Frame):
    def __init__(self,parent,editor,on_script=None):
        super().__init__(parent,padding=18)
        self.editor,self.on_script=editor,on_script
        self.entries=[]
        ttk.Label(self,text='توب فايف — سلسلة مستقلة بهوية القناة',font=('Segoe UI',20,'bold')).pack(anchor='e')
        ttk.Label(self,text='الخمس من اختيارك، من المركز الخامس إلى الأول. السكربت يفصل فكرة اللعبة عن سبب ترشيحك ورأيك.',foreground='#75bdd9',wraplength=980).pack(anchor='e',pady=(3,12))
        row=ttk.Frame(self);row.pack(fill='x')
        self.topic=tk.StringVar(value='ألعاب العالم المفتوح')
        ttk.Entry(row,textvariable=self.topic,justify='right').pack(side='right',fill='x',expand=True)
        ttk.Button(row,text='ابدأ بقائمة مقطعك المرجعي',command=self.load_reference).pack(side='left',padx=6)
        self.tree=ttk.Treeview(self,columns=('rank','name','why'),show='headings',height=5)
        for key,label,width in [('rank','المركز',70),('name','اللعبة',270),('why','ليش اخترتها؟',580)]:
            self.tree.heading(key,text=label,anchor='e');self.tree.column(key,width=width,anchor='e')
        self.tree.pack(fill='x',pady=10)
        self.tree.bind('<Double-1>',lambda event:self.edit())
        row=ttk.Frame(self);row.pack(fill='x')
        for text,fn in [('إضافة لعبة',lambda:self.edit(True)),('تعديل اللعبة',self.edit),('رفع بالترتيب',lambda:self.move(-1)),('نزّل بالترتيب',lambda:self.move(1)),('حذف',self.remove),('توليد السكربت',self.generate)]:
            ttk.Button(row,text=text,command=fn).pack(side='right',padx=3)
        row=ttk.Frame(self);row.pack(fill='x',pady=8)
        ttk.Label(row,text='ألعاب تستحق الذكر قبل الأول (اختياري)').pack(side='right')
        self.mentions=tk.StringVar()
        ttk.Entry(row,textvariable=self.mentions,justify='right').pack(side='left',fill='x',expand=True,padx=8)
        self.script_box=tk.Text(self,wrap='word',font=('Segoe UI',12),height=11,bg='#0d1728',fg='#e4edff',insertbackground='white',relief='flat',padx=14,pady=10)
        self.script_box.tag_configure('rtl',justify='right')
        self.script_box.pack(fill='both',expand=True)
        row=ttk.Frame(self);row.pack(fill='x',pady=8)
        ttk.Button(row,text='اعتماد للتسجيل وحفظ في المشروع',command=self.use_script).pack(side='right')
        self.note=tk.StringVar(value='لم تُختَر ألعاب بعد. لا يولّد البرنامج ترتيبًا أو تجربة شخصية وهمية.')
        ttk.Label(row,textvariable=self.note,foreground='#ffce88',wraplength=760).pack(side='left')

    def refresh(self):
        self.tree.delete(*self.tree.get_children())
        for i,e in enumerate(self.entries):self.tree.insert('','end',iid=str(i),values=(5-i,e['name'],e['why']))
        self.script_box.delete('1.0','end')

    def load_reference(self):
        self.entries=copy.deepcopy(REFERENCE_LIST)
        self.refresh()
        self.note.set('قائمة من مقطعك المنشور في مارس 2025 للإلهام، وليست ترتيبًا جديدًا لعام 2026. عدّل اختياراتك ورأيك.')

    def selected(self):
        return int(self.tree.selection()[0]) if self.tree.selection() else None

    def edit(self,new=False):
        i=None if new else self.selected()
        if i is None and not new:return
        if new and len(self.entries)>=5:
            messagebox.showinfo('توب فايف','عدّل أو احذف لعبة أولًا؛ العدد خمس.',parent=self);return
        e={key:'' for key in ('name','facts','why','opinion','source')} if new else self.entries[i]
        def done(values):
            if not all(values[k].strip() for k in ('name','facts','why','source')):raise ValueError('أكمل الاسم والفكرة وسبب الاختيار والمصدر.')
            if new:self.entries.append(values)
            else:self.entries[i]=values
            self.refresh()
        self.editor.dialog('اختيار اللعبة ومصدر معلوماتها',[('name','اسم اللعبة',e['name']),('facts','فكرة اللعبة وحقائقها',e['facts']),('why','ليش ترشحها؟',e['why']),('opinion','رأيك أو تعليقك الحقيقي (اختياري)',e['opinion']),('source','مصدر الحقائق أو وصف تجربتك',e['source'])],done)

    def move(self,delta):
        i=self.selected()
        if i is not None and 0<=i+delta<len(self.entries):
            self.entries[i],self.entries[i+delta]=self.entries[i+delta],self.entries[i]
            self.refresh();self.tree.selection_set(str(i+delta))

    def remove(self):
        i=self.selected()
        if i is not None:self.entries.pop(i);self.refresh()

    def generate(self):
        try:
            result=top5_script(self.entries,self.topic.get(),[x.strip() for x in self.mentions.get().split(',') if x.strip()])
            self.script_box.delete('1.0','end');self.script_box.insert('1.0',result['text'],'rtl')
            self.note.set('مسودة بأسلوب قائمتك: فكرة اللعبة ثم ليش تلعبها ثم رأيك. راجعها قبل التسجيل.')
        except Exception as exc:messagebox.showerror('توب فايف',str(exc),parent=self)

    def use_script(self):
        text=self.script_box.get('1.0','end').strip()
        if not text:return
        output=self.editor.output();output.mkdir(parents=True,exist_ok=True)
        path=output/'top5_script.txt';path.write_text(text,encoding='utf-8')
        self.editor.paths['script'].set(str(path))
        title='توب 5 | '+self.topic.get().strip()
        sources=list(dict.fromkeys(e['source'] for e in self.entries if e['source'].startswith('https://')))
        metadata={'title':title,'sources':sources,'description':long_description(title,sources=sources),'type':'long','genre':'list','script_reviewed':True}
        save(metadata,output/'episode.json')
        if self.on_script:self.on_script(metadata)
        self.note.set('حُفظ سكربت توب فايف والوصف. سجّل بصوتك، ثم أكمل المونتاج في المسار نفسه.')
