# CODEX BUILD REQUEST — RashSpeak Studio v2.1: Smart Gaming Editor

**User message:** "أبغاه احترافي في تركيب صور الجيف الميمز والترجمة العربية ويعرف متى يحط اللقطات والميمز بشكل مثالي وماتكون مبالغة فيها" and "حولني لكودكس خله يكمل البناء".

The user runs the gaming-news YouTube channel **@RashSpeak**, has ~2,500 subscribers, recorded voiceovers, and very little free time. They want Codex to CONTINUE the attached codebase, not design a hypothetical new project. They will provide a voiceover audio file, clips/graphics/GIFs, and optionally article text/links. Only publishing destinations: **YouTube long-form & Shorts, Instagram Reels, TikTok**. Channel is under YouTube monetization review; prioritize genuine original commentary, human approval, traceable licensed assets, and conservative effects.

## P0: Deliver a working smart offline production pipeline (implement, not just describe)

1. **Input organizer and manifests:** GUI to select voice MP3/WAV; news-script text or pasted script optional; approved clips and image/GIF meme library; per-asset manifest with tags (game title, scene type, mood, allowed usage/license/source), safe file extensions, basic probes and thumbnails. Offline clips-only workflow must still work if script absent.
2. **Arabic speech-to-text with timestamps:** use faster-whisper or comparable local ASR; produce phrase-level time ranges and SRT. Correct obvious segmentation edge cases. Include a GUI review/edit transcript step; do not imply automated transcription is flawless.
3. **Timeline builder based on meaning:** associate phrase/script sections with user-tagged game/subject assets using Arabic keyword matching and synonym normalization with a deterministic fallback. Optional AI semantic-matching plugin may be layered over it (opt-in; don't require an API subscription). No mismatched gameplay silently inserted. Show confidence/warnings, timecoded reason for each suggested clip, and expose drag/move/remove controls or editable timeline table. Respect manual `cues.csv` when present.
4. **Tasteful memes/GIFs:** detect genuine opportunities using a strict opt-in policy: jokes, frustration, surprises, reactions; meme suggestions max **one every 45 seconds** and max **four for a 6-minute video** (adjust caps for other durations), minimum 15 seconds from previous, typically 0.6–2.0 seconds long. Not for factual headlines, emotionally sensitive news, calls to action, or segments with crucial information. User must enable suggestions and approve each. Support still PNG and animated GIF/WebP/video, loop/matte/transparency handling, audio muted by default, and license-aware asset selection. Store `reason`, `asset_id`, `timestamp`, `duration`, `confidence`, `approved` on timeline. Never import random copyrighted reaction GIFs automatically.
5. **Professional Arabic captions:** burned-in selectable Arabic subtitle styles (clean gaming, subtle cinematic) as well as `.srt` (and ideally `.ass`); correctly render RTL script, mixed Arabic/English game titles and numerals; manually selectable legally installed Arabic font; text-safe area, max 2 lines, readable contrast, normal line break placement, timecoded accuracy. Captions should not collide with facecam, HUD, GIF/meme overlays; offer an adjustable caption bounding region. Show caption previews before render.
6. **Dynamic but not excessive edits:** cuts primarily at semantic/topic boundaries, 3–8 seconds typical shot cadence where appropriate, smooth subtle motion on stills, transitions only on major topic changes; voice loudness normalizing and optional background track at restrained volume, licensed only. 16:9 1080p long video and 9:16 1080×1920 Shorts with subject-aware framing or safe blur fallback. Select SHORT highlights based on transcript/news importance, NOT fixed first 35 seconds. User can override all chosen ranges.
7. **Transparent review workflow:** Preview/edit time-coded `timeline.json` of clips/captions/memes/shorts with before/after preview thumbnails and quick rerender. `Render draft` -> `Review warnings & assets` -> `Approve` -> `Export`; never publish automatically.

## P1: Make social accounts usable, without bypassing official platform policies

- Keep existing YouTube OAuth and private-default video upload; verify channel identity. Show account authorization status, scopes and credential expiry; refresh tokens securely. Support selectable upload of long-form vs Short.
- Instagram: connect via official Instagram Login for eligible Creator/Business account; check required permissions and hosted HTTPS MP4 requirement, and surface clear setup errors and upload-progress status. Do not treat successful OAuth mock as working live publish.
- TikTok: support approved `video.upload` inbox/draft flow; direct public posting only if user has `video.publish` permission and API audit approval. Display platform-specific captions/hashtags and user-provided publish confirmation.
- Build a single publish review panel with per-platform toggles YouTube/Instagram/TikTok only, local post history, duplicate-upload guard/idempotency, privacy warning, and full audit log without secrets. Ask consent for each destination at submission.

## P2: UX, release and testing

- Arabic-first modern desktop design; responsive progress indicator while analyzing/encoding; accessible controls and helpful empty states; failure recovery. Prefer maintainable Python widgets/framework and preserve Windows startup support.
- Package an offline Windows installer/EXE if feasible; otherwise provide a robust one-click Windows bootstrap and reproducible build instructions; do not claim signed installers unless signed.
- Add unit and integration tests, including synthetic FFmpeg timeline render; report actual pass/fail. Avoid external API calls in tests. Document limitations, required developer setup, and potential costs in `README_AR.md`.
- If app-store / API permissions cannot be verified, create explicit TODOs and a safe demo mode; do not fake working account connections.

## Definition of done / demonstration

1. Import a sample Arabic WAV plus at least 3 locally licensed/synthetic gameplay-like clips + 2 meme assets.
2. Generate/edit accurate timestamped transcript, timeline with relevant tag-based shot choices, 1 approved funny meme moment, 1 disallowed serious moment; SRT and burned-in correctly shaped Arabic.
3. Export real playable 16:9 MP4 and 9:16 short with different selected highlight than a fixed first-35-seconds fallback.
4. Confirm no meme over subtitles/subject and validate playback with ffprobe.
5. With no external developer keys, app operates fully in offline editor mode and publishing is safely disabled with actionable messages.
6. With mocks, ensure connecting/publishing requires OAuth and explicit per-destination approval; no auto publication.
7. Run tests and include generated previews/test results or reproducible commands, with a short changelog.

## Execution approach

First inventory repo and run baseline tests. Then implement P0 incrementally. Do not stop at an architecture plan or ask the user to choose general tech stack; sensible defaults are above. Only ask for unavoidable external approvals: platform OAuth credentials and permission to publish. After the core editor works, tackle publishing polish, UI, packaging and tests. Use existing v2 files as starting point.
