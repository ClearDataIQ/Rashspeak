# Latest owner request — publish updated source and remove old tool packages (2026-10-15)

Owner explicitly requested uploading the latest tool to GitHub and deleting the old version. This authorizes replacing the old source-package downloads on main with RashSpeak_Studio_2.6.3_WIP.zip. Remove only old RashSpeak_Studio packages and their versioned checksum/manifest/status companions, update download references, preserve video/preview/project outputs and Git history. The latest functional Python source matches the 281-test baseline. This is a WIP source release; automatic Gemini-driven montage acceptance remains unmet. See CHANGELOG_2.6.3_WIP_AR.md and publication evidence under /workspace/quality-audit/source_delivery_2_6_3. A pre-change backup of publication files and source guidance exists at /workspace/restore-points/pre_source_delivery_2_6_3_20261015.tar.gz. Do not ship keys/settings/recordings/media/models or relabel manual previews as automatic success.

---

# Latest requested delivery — new Short after fixes (2026-10-15)

Read docs/SHORT_PREVIEW_AFTER_FIXES_20261015_AR.md. Owner explicitly requested a new Short. A new 12s 1080x1920 preview was produced using the shared Pro compositor and published to the already-authorized GitHub delivery repo at commite339a705162e0422334677a33ad9da3c00a58b2a. Public MP4 bytes/SHA verified by actual download (HTTP200). Manual scene/timing review and one spelling correction are disclosed; no new Gemini call and NOT automatic end-to-end acceptance. Original continuous speech/audio/source video preserved. The editable local project/output is RashSpeak_Downloads/Short_After_Fixes_20261015. No app code changes after281 passing tests. Source release remains2.6.2 WIP; newer2.6.3 Layout WIP ZIP is local. Preserve old outputs and managed-key blocker; do not call this a completed automatic montage.

---

# Latest continuation — Arabic caption pages and image quality (2026-10-15)

Read docs/CAPTION_LAYOUT_REPAIR_2.6.3_AR.md. Current source adds caption_layout.py: Arabic-shaped pixel widths, whole words/Latin game-name chunks, real word-boundary paging and multi-page highlights. Legacy caption preview uses the same style/page/timing as export; Short SRT word times are rebased. Pro cursor windows keep complete active captions and renderer revision invalidates obsolete proxies. Image fallbacks inherit resolution/scene-evidence gates; downloaded native pixels and archive entries are checked, including images in final quality. Gemini outages stop further image calls but allow verified local reuse.

The owner asked to use the old Gemini key. Rechecked actual app credential/keyring and environment names: unavailable. Existing RASH_GOOGLE_API_KEY binding is saved in draft revision19 but not injected. Do not repeat a permission/key question or evade the prior automatic-review rejection. No new live Gemini calls or public release. Automatic tool-only montage acceptance remains unmet. Real-audio caption-only QA is private, not a finished video, and retains ASR errors. Normal production replay is needs_media with no exports and no manual scenes/overrides; source audio SHA unchanged. New restore point /workspace/restore-points/pre_caption_layout_20261015_182939.tar.gz. Final evidence is full_suite_layout_verified.log and caption_layout_real_report.json under /workspace/quality-audit/short_feedback_20261015; check their actual completed result. Preserve failed/aborted earlier logs separately.

---

# Active owner acceptance requirement — 2.6.3 short feedback (2026-10-15)

Read docs/SHORT_FEEDBACK_2.6.3_AR.md first. Owner requires the TOOL ITSELF to reproduce preview quality from the inputs with no developer picking/timing scenes manually. They explicitly rejected a mere assurance after learning some previews had manual editorial choices. Never promise this is met: the actual normal-entrypoint run currently stops at needs_media/Gemini unavailable. Do not publish manually assembled previews as automatic success or call this release complete. No new release was uploaded after2.6.2 WIP commit600e218.

Source changes are real: brief verified image fallback, exact entity/event checks, HD-original preference and resolution checks, larger/thinner captions, optional script, local medium ASR, conservative spelling reconciliation, ASR review/retranscription with backup. The no-script normal run exposed metadata-only same-game footage being counted as a match; require_scene_evidence now blocks that false acceptance, and verified flags persist in archive. Generic gather results/old unverified caches cannot pass Auto final. Existing Pro/manual editing stays usable.

Evidence in /workspace/quality-audit/short_feedback_20261015. normal_production_report.json is BEFORE the evidence guard and is a negative acceptance finding, not success. normal_production_guarded_report.json is the corrected normal entrypoint, real recording with genuine cached medium ASR, no ASR/assets override, no manual scene selection, needs_media/no exports/source unchanged. full_suite_264.log is the final suite. Manual HD diagnostic under RashSpeak_Downloads/Short_Feedback_HD is explicitly labelled manual, has remaining ASR/crop/baked-subtitle limitations and is not a final Short. Preserve both evidence sets. Do not rerun expensive ASR unless needed; medium is1.5GB and already installed.

The owner already consented to managed credential setup. No new consent or chat key needed. Runtime still had no injected key; applying/publishing the saved draft is a product-UI action unavailable to our tools. Do not evade the prior automatic-review rejection of key entry into an escalated terminal. Resume live automatic end-to-end acceptance only through the genuinely applied managed route. Restore point /workspace/restore-points/pre_short_feedback_20261015.tar.gz. Preserve unborn source checkout, previous releases and all real media.

---

# Latest owner task — long-video diagnosis, source repair and authorized previews (2026-10-15)

Read docs/LONG_VIDEO_FAILURE_REPAIR_AR.md first. The owner explicitly asked to publish the partial real previews on GitHub and fix/explain the long-video failure; this supersedes older upload freezes for the requested previews and clearly labelled tested source work. Partial previews were published and remotely hash-verified at main commit54970a2 (previews_2026_10_15). They are NOT completed episodes/Shorts. Never overwrite or relabel rejected2.5 outputs.

Current2.6.2 WIP adds visual_choices.py (8-sentence batches, up to4 validated visual parts per sentence, individual retry caches, same-reviewed-scene variation), steam_sources.py (strict public listing identity/CDN, explicit rights before download, no new API key), later source-analysis windows, license-pending/music-spam filtering, cached grounded context recovery without credentials, and actionable production_diagnostics.py reports. Preserve six review gates, source voice/order, shared Auto/Pro project and3cropped overlays; no AI-generated images/video, mandatory music/thumbnail or automatic publishing.

Latest actual verification is recorded in TEST_RESULTS_2.6.2_WIP.txt. Genuine cached real-audio replay uses no keys, no ASR/assets overrides and no new Gemini requests; editable draft retained, original SHA unchanged, final blocked at needs_media with12.856% matching footage. New live batch/Steam integration remains UNVERIFIED. Automatic approval review rejected entering the Gemini key into an escalated terminal, describing a network-boundary bypass; the key was not entered and that runner was cancelled. Do not try another file/env/terminal route to evade that rejection. Reuse the configured managed secret route only after settings are actually applied and connectivity is verified. Do not request another chat key. Steam hosts are saved only in a draft, not proven active. Full professional montage/style acceptance is still outstanding.

Restore point /workspace/restore-points/pre_long_video_repair_20261015.tar.gz. Source checkout is unborn/untracked; do not reset. Upload clone /workspace/github-delivery/public-upload, existing native Git auth, no PAT needed. Source ZIP must whitelist code/docs/tests only; exclude recordings, settings, media/archive/model caches, all secrets and private projects. Do not create worktrees or spawn agents without an explicit applicable instruction.

---

# Latest continuation — internet fallback real-audio test (2026-10-15)

Read docs/INTERNET_FALLBACK_REAL_TEST_AR.md first. Current source adds source_fallback.py/internet_video.py, actual downloaded-video Gemini analysis, source/choice caching, idea-sensitive archive reuse, CFR excerpt length repair, and audible multi-SFX mixing.232 tests pass. Actual owner recording tested; full run remains needs_media. After mechanical CFR repair matching footage is12.856%, NOT a finished episode. Partial source-backed diagnostic previews and a real SFX audio review are under RashSpeak_Downloads/Real_Test_Internet_Fallback. No new upload/release, no fabricated approvals, no AI-generated media, no source audio mutation. Preserve original audio/Whisper/Gemini caches and real test evidence in /workspace/quality-audit/fallback_2_6_2. Full recording acceptance still fails due missing footage, Gemini quota, and blocked YouTube; never present old2.5 or these partial previews as a corrected finished long/Short production.

# Current owner request — Studio 2.6.1

Owner explicitly requested uploading the updated TOOL now and adding YouTube/Gemini API entry options. This supersedes the earlier source-upload freeze for this tested source release. Keep the video-quality gate; no new final video is approved or produced. Add independent credential UI and safe per-provider connection tests,verify and publish the source ZIP in the existing authorized GitHub repository. Never include actual credentials/recordings/cache/local profiles. No repeat permission needed.

# Latest acceptance instruction — 2026-10-15

Owner requires real-recording testing BEFORE further upload. Read docs/REAL_AUDIO_ACCEPTANCE_2.6_AR.md. Real final-mode test ran and stopped at needs_media; no new final video/Shorts.200 tests pass locally after fixes to game-name labels,stage status,and bounded active-clip frame preview. Existing public2.6 ZIP predates these fixes. Do not upload again until actual official-source long/Short montage passes acceptance. Preserve original recording,Whisper cache,and output/acceptance_2_6_20261015_verified. Runtime network/secure-key activation is the external blocker.

# Active owner update —2.6

Read CLOUD_HANDOFF.md and docs/SOURCE_DIRECTOR_2.6_AR.md first. Owner rejected the2.5 card-based delivery; do not claim it is acceptable montage. Implemented sentence media direction, official YouTube metadata/source analysis, free keyless Commons images, persistent archive/cache, and final coverage gate. Owner forbids ANY AI-generated images/video; Gemini only understands/selects/edits existing genuine media. Source policy rejects declared AI media. Entities and source requests are general, not limited to weapons/maps. Do not request cx or paid image-search APIs. New Google API key was provided in chat; never reproduce/save it in files or source. Native Git delivery is authorized public in the existing repository; old assets stay unchanged. Actual YouTube API access is blocked before authentication, so the key and full new montage are not live-tested. Missing footage must save an editable draft and stop final export.

# RashSpeak Studio — Codex engineering instructions

Current continuation is **2.5**, with real uploaded-audio production and final visual-audit fixes. The owner explicitly authorized completing this test without review stops; do not ask again or fabricate human approvals. Read CLOUD_HANDOFF.md and docs/FULL_REAL_PRODUCTION_AR.md for actual output status. Gemini/context/assistant, Pro effects/word editing/player/queue/library are implemented. Keep six review gates in the app for normal projects, three cropped GIF/meme overlays, manual file publication, and no mandatory thumbnail/music. Direct YouTube remains blocked; the uploaded MP3 exists and must not be replaced by synthetic evidence. Preserve the current source and its restore points.

You are the lead developer continuing an **existing** Python 3 desktop application; do **not** discard or rewrite it without strong justification. Read `README_AR.md`, `CODEX_IMPLEMENTATION_PLAN.md`, `publisher.py`, `gui.py`, `studio.py`, and tests before editing. The product's intended user is the Arabic-speaking owner of YouTube gaming-news channel **@RashSpeak**, working on **Windows 11 with NVIDIA RTX 4060** and limited time. Core workflow: owner records his real voice; the tool helps turn legal gameplay footage into a polished news video and short clips, then submits to selected platforms with review and explicit approval.

## Strict scope
- Target platforms **only**: YouTube videos + Shorts, Instagram Reels, TikTok videos. Do not add X, Facebook, or any other social platform.
- Preserve the user's original voice and authorship; never turn this into a mass content scraper, a bulk spammer, or a copyrighted footage downloader.
- Use **official APIs and OAuth** with least required scopes. The app must **never ask for platform passwords** or bypass API audits/restrictions. Do not make platform publishing claims unless exercised in a real authorized sandbox/account.
- Explicit user consent before external publication. Default YouTube uploads to `private`, TikTok to inbox/draft when direct publishing is not approved, and Instagram to review-ready state if real publishing is unavailable. Show concrete API/app-approval prerequisites.
- Never commit credentials, access tokens, client secrets, local profile data, OAuth redirect URLs containing codes, or test media from third parties. Keep secrets in Windows Credential Manager using `keyring`, consider key lifecycle, refresh, revocation and disconnect.
- Do not send, publish, or schedule content from the user's accounts during development except when the user explicitly authorizes a specific test/action.
- UI in natural Arabic with RTL-aware layouts; clean professional desktop design. Keep project operable offline for editing/rendering and tolerant of missing API credentials.
- Focus on minimal cost; report genuinely necessary paid services separately. Any hosted-file requirement for Instagram must be explicit.

## Project state at handoff (do not overclaim)
- Python/tkinter GUI, FFmpeg rough-cut renderer, cue-tag CSV scene mapping, first-35s short generation, optional faster-whisper Arabic SRT support.
- OAuth and publishing **adapters** for YouTube, Instagram, TikTok in `publisher.py`; platform developer setup and real OAuth/publishing **not end-to-end validated**. There is no approved developer app or connected end-user account bundled here.
- TikTok has draft inbox upload and a Direct Post code path that needs permissions/approval. Instagram currently relies on a directly accessible HTTPS media URL; video hosting is not built.
- Five publisher mock tests passed in the source before packaging, but coverage is thin; there is no production readiness claim.
- `README_AR.md` may omit newer TikTok Direct Post code paths; reconcile docs against the implementation.
- No real scheduling service, semantic audio-to-shot matching, YouTube thumbnail automation, custom EXE installer, or real-account live testing is present yet.

## Approach
1. Audit and run tests before modifying code; enumerate bugs/security issues, especially OAuth state/PKCE, expiry and retry safety, HTTP upload handling, UI threading, media input validation, account mismatch, publication status, rate limits and duplicate posting prevention.
2. Refactor into testable modular architecture incrementally. Keep existing functionality working and leave a migration path for stored preferences and tokens.
3. Build a polished clear workflow: `Project -> Narration -> Media/cues -> Smart rough cut -> Short clip selection -> Review -> Platform-specific metadata -> Submit/schedule -> Status`. Progress, cancel, retry, logs, and previews.
4. Build actionable features, not empty mock buttons. Each screen must show real status and handle missing platform approvals gracefully.
5. Add automated unit/integration tests with API mocks and FFmpeg smoke tests using generated synthetic media. No credentials in test suite. Use `python -m unittest discover -s tests -v` or a documented pytest equivalent.
6. Build Windows distributable packaging only after app launches and tests pass. Include dependency check and FFmpeg setup instructions. Do not claim EXE as signed.
7. Produce concise change log and a checklist separating completed work, tested simulated functionality, and functionality blocked on owner/API review.

## Completion policy
Do not stop at a plan. Implement the highest priority vertical slice and keep going through the backlog as time/tools allow. If blocked by an external platform, complete code plus mocked tests and give the exact owner action required. Never ask the user to paste secret values in chat; use local UI and OAuth/browser flow instead.
