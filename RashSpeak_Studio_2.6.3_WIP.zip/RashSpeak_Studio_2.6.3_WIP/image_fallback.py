"""Short, source-verified image inserts; keep the underlying gameplay afterwards."""
from copy import deepcopy

from smart_editor import normalize,save


def insert_window(request,segments,maximum=2.8):
    a,b=request['start'],request['end'];seconds=min(maximum,b-a)
    anchor=None
    for segment in segments:
        for word in segment.get('words',[]):
            if word['start']<a or word['end']>b:continue
            value=normalize(word['text'])
            if value and any(value in normalize(entity).split()for entity in request.get('entities',[])):
                anchor=word['start'];break
        if anchor is not None:break
    start=min(max(a,anchor-.15 if anchor is not None else a+(b-a-seconds)/2),b-seconds)
    return start,start+seconds


def extend_plan(plan,segments,archive,providers,client,scene_cache=None,cancel=None,budget=6):
    from media_director import build_plan
    result=deepcopy(plan);extra=[];spent=0
    ai_error=plan.get('ai_error','')
    if not ai_error:
        ai_error=next((r.get('reason','تعذر الوصول إلى Gemini.')for r in plan['sentences']if r.get('status')=='ai_unavailable'),'')
    # An exhausted provider is not retried for each image. Verified local reuse still works.
    image_client=None if ai_error else client
    image_providers={'images':providers['images']}if 'images'in providers and image_client is not None else{}
    priority=sorted(plan['sentences'],key=lambda r:(not bool(r.get('event')),not bool(r.get('entities')),r['start']))
    for parent in priority:
        if parent.get('role','clip')!='clip' or parent['kind']!='gameplay' or not parent.get('game'):continue
        if parent['status']in ('cached','downloaded','ready_to_download'):continue
        if spent>=budget:break
        start,end=insert_window(parent,segments)
        semantic={k:deepcopy(parent.get(k,''))for k in ('game','event','idea','entities')}
        semantic.update(visual='image',search_intent='specific_event'if parent.get('event')else'general',queries=[parent.get('query','')],meme=False)
        piece={'start':start,'end':end,'text':parent['text'],'semantic':semantic}
        image=build_plan([piece],archive,image_providers,image_client,
                         scene_cache=scene_cache,cancel=cancel,max_searches=1,
                         min_source_height=parent.get('min_source_height',0),
                         require_scene_evidence=parent.get('require_scene_evidence',False))['sentences'][0]
        if image_client is None and image['status']!='cached':
            image.update(status='ai_unavailable'if ai_error else'needs_ai_selection',
                         reason=ai_error or'يلزم Gemini للتحقق من صورة جديدة؛ استُخدم الأرشيف المحلي فقط.')
        image.update(id=parent['id']+':image',parent_sentence_id=parent['id'],fallback_image=True)
        extra.append(image);spent+=1
        if image['status']=='ai_unavailable'and image_client is not None:
            # One live image failure opens the same circuit for remaining local lookups.
            ai_error=image.get('reason','Gemini unavailable');image_client=None;image_providers={}
    result['sentences']+=extra;result['image_fallback_requests']=len(extra)
    return result
